import { createRouter, createWebHashHistory, type RouteRecordRaw } from 'vue-router'

export const publicRoutes: RouteRecordRaw[] = [
  {
    path: '/',
    name: '/',
    redirect: '/dashboard',
    component: () => import('@/layout/index.vue'),
    children: [
      // {
      //   path: '/dashboard',
      //   name: 'Dashboard',
      //   component: () => import('@/views/dashboard/index.vue'),
      //   meta: {
      //     title: 'dashboard',
      //     icon: 'dashboard',
      //     iconActive: 'dashboard-active',
      //     affix: true
      //   }
      // },
      // {
      //   path: '/basic',
      //   name: 'Basic',
      //   redirect: '/basic/employee',
      //   meta: {
      //     title: 'basic',
      //     icon: 'basic',
      //     iconActive: 'basic-active'
      //   },
      //   children: [
      //     {
      //       path: '/basic/employee',
      //       name: 'Employee',
      //       component: () => import('@/views/basic/employee/index.vue'),
      //       meta: {
      //         title: 'employee',
      //         icon: 'menu-item',
      //         ignoreKeepAlive: true
      //       }
      //     },
      //     {
      //       path: '/basic/dictionary',
      //       name: 'Dictionary',
      //       component: () => import('@/views/basic/dictionary/index.vue'),
      //       meta: {
      //         title: 'dictionary',
      //         icon: 'menu-item',
      //         ignoreKeepAlive: true
      //       }
      //     },
      //     {
      //       path: '/basic/department',
      //       name: 'Department',
      //       component: () => import('@/views/basic/department/index.vue'),
      //       meta: {
      //         title: 'department',
      //         icon: 'menu-item',
      //         ignoreKeepAlive: true
      //       }
      //     },
      //     {
      //       path: '/basic/schedule',
      //       name: 'Schedule',
      //       component: () => import('@/views/basic/schedule/index.vue'),
      //       meta: {
      //         title: 'schedule',
      //         icon: 'menu-item',
      //         ignoreKeepAlive: true
      //       }
      //     },
      //     {
      //       path: '/basic/productionLine',
      //       name: 'ProductionLine',
      //       component: () => import('@/views/basic/productionLine/index.vue'),
      //       meta: {
      //         title: 'productionLine',
      //         icon: 'menu-item',
      //         ignoreKeepAlive: true
      //       }
      //     },
      //     {
      //       path: '/basic/productionProcess',
      //       name: 'ProductionProcess',
      //       component: () => import('@/views/basic/productionProcess/index.vue'),
      //       meta: {
      //         title: 'productionProcess',
      //         icon: 'menu-item',
      //         ignoreKeepAlive: true
      //       }
      //     },
      //     {
      //       path: '/basic/pm',
      //       name: 'PM',
      //       component: () => import('@/views/basic/pm/index.vue'),
      //       meta: {
      //         title: 'pm',
      //         icon: 'menu-item',
      //         ignoreKeepAlive: true
      //       }
      //     },
      //     {
      //       path: '/basic/standardWorkTime',
      //       name: 'StandardWorkTime',
      //       component: () => import('@/views/basic/standardWorkTime/index.vue'),
      //       meta: {
      //         title: 'standardWorkTime',
      //         icon: 'menu-item',
      //         ignoreKeepAlive: true
      //       }
      //     },
      //     {
      //       path: '/basic/productionNode',
      //       name: 'ProductionNode',
      //       component: () => import('@/views/basic/productionNode/index.vue'),
      //       meta: {
      //         title: 'productionNode',
      //         icon: 'menu-item',
      //         ignoreKeepAlive: true
      //       }
      //     },
      //     {
      //       path: '/basic/productionVersion',
      //       name: 'ProductionVersion',
      //       component: () => import('@/views/basic/productionVersion/index.vue'),
      //       meta: {
      //         title: 'productionVersion',
      //         icon: 'menu-item',
      //         ignoreKeepAlive: true
      //       }
      //     }
      //   ]
      // },
      // {
      //   path: '/work',
      //   name: 'Work',
      //   redirect: '/work/workOrder',
      //   meta: {
      //     title: 'work',
      //     icon: 'work',
      //     iconActive: 'work-active'
      //   },
      //   children: [
      //     {
      //       path: '/work/workOrder',
      //       name: 'WorkOrder',
      //       component: () => import('@/views/work/workOrder/index.vue'),
      //       meta: {
      //         title: 'workOrder',
      //         icon: 'menu-item',
      //         ignoreKeepAlive: true
      //       }
      //     },
      //     {
      //       path: '/work/workReport',
      //       name: 'WorkReport',
      //       component: () => import('@/views/work/workReport/index.vue'),
      //       meta: {
      //         title: 'workReport',
      //         icon: 'menu-item',
      //         ignoreKeepAlive: true
      //       }
      //     },
      //     {
      //       path: '/work/workDispatch',
      //       name: 'WorkDispatch',
      //       component: () => import('@/views/work/workDispatch/index.vue'),
      //       meta: {
      //         title: 'workDispatch',
      //         icon: 'menu-item',
      //         ignoreKeepAlive: true
      //       }
      //     }
      //   ]
      // },
      // {
      //   path: '/quality',
      //   name: 'Quality',
      //   redirect: '/quality/ipqc',
      //   meta: {
      //     title: 'quality',
      //     icon: 'quality',
      //     iconActive: 'quality-active'
      //   },
      //   children: [
      //     {
      //       path: '/quality/ipqc',
      //       name: 'IPQC',
      //       component: () => import('@/views/quality/ipqc/index.vue'),
      //       meta: {
      //         title: 'ipqc',
      //         icon: 'menu-item',
      //         ignoreKeepAlive: true
      //       }
      //     }
      //   ]
      // },
    ]
  }
]

const router = createRouter({
  history: createWebHashHistory(import.meta.env.BASE_URL),
  routes: publicRoutes
})

export default router
