import * as signalR from '@microsoft/signalr'
import { SStorage } from './storage'
import useAppStore from '@/stores/app'

const TIME_OUT = 2000
let timer: number

const connection = new signalR.HubConnectionBuilder()
  .withUrl('/PushDataHubService', { accessTokenFactory: () => SStorage.get('token') })
  .configureLogging(signalR.LogLevel.Error)
  .build()

// connection.on('ReceiveMessage', (data: any) => {
//   console.log(data)
// })

const start = async () => {
  const appStore = useAppStore()
  try {
    await connection.start()
    appStore.signalrConnectionStatus = true
  } catch (error) {
    console.log(error)
    restart()
  }
}

const connect = async () => {
  await start()
}

const disconnect = async () => {
  await connection.stop()
}

const onclose = () => {
  connection.onclose(async (error) => {
    console.log('signalR连接断开', error)
    const appStore = useAppStore()
    appStore.signalrConnectionStatus = false
    restart()
  })
}

const restart = () => {
  clearTimeout(timer)
  timer = setTimeout(async () => {
    await start()
  }, TIME_OUT)
}

export { connect, disconnect, connection, onclose }
