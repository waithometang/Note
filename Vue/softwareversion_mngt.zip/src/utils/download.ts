import type { AxiosResponse } from 'axios'

/**
 * 根据二进制大数据下载文件
 * @param data 文件流
 * @param fileName 文件名
 */
export function downloadByBlob(data: BlobPart, fileName: string) {
  const blob = new Blob([data], { type: 'application/octet-stream' })

  const link = document.createElement('a')
  link.style.display = 'none'
  const href = window.URL.createObjectURL(blob)
  link.href = href
  link.download = fileName
  link.setAttribute('target', '_blank')

  document.body.appendChild(link)
  link.click()
  document.body.removeChild(link)

  window.URL.revokeObjectURL(href)
}
/**
 * 根据api下载文件
 * @param api
 * @param params
 */
export async function downloadByApi(api: (args?: any) => Promise<any>, params: any) {
  const response = (await api({
    ...params
  })) as AxiosResponse
  const { data } = response
  if (data.type === 'application/json') {
    const reader = new FileReader() //创建一个FileReader实例
    reader.readAsText(data, 'utf-8') //读取文件,结果用字符串形式表示
    reader.onload = function () {
      //读取完成后,**获取reader.result**
      const res = JSON.parse(reader.result as string)
      ElMessage.error(res.message)
    }
  } else {
    const disposition = response.headers['content-disposition']
    const filenameRegex = /filename[^;=\n]*=((['"]).*?\2|[^;\n]*)/
    const matches = filenameRegex.exec(disposition)
    let filename: string = ''

    if (matches && matches.length > 1) {
      filename = decodeURIComponent(matches[1]).replace(new RegExp('"', 'g'), '') // 解决下载的文件名前后多出下划线bug
    }
    downloadByBlob(data, filename)
  }
}

/**
 * 根据下载地址下载内容
 * @param url
 */
export const downloadByUrl = (url: string) => {
  const downloadLink = document.createElement('a')
  downloadLink.style.display = 'none'
  const href = url
  downloadLink.href = href
  downloadLink.setAttribute('target', '_blank')
  document.body.appendChild(downloadLink)
  downloadLink.click()
  document.body.removeChild(downloadLink)
  window.URL.revokeObjectURL(href)
}
