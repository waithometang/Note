import i18n from '@/locales'
import { watch } from 'vue'
import { storeToRefs } from 'pinia'
import useAppStore from '@/stores/app'

/**
 * 路由国际化处理
 * @param {*} title
 * @returns
 */
export function generateTitle(title: string) {
  return i18n.global.t('route.' + title)
}

/**
 * 国际化监听
 * @param  {...any} cbs 所有的回调
 */
export function watchSwitchLang(...cbs: Function[]) {
  const { language } = storeToRefs(useAppStore())

  watch(language, () => {
    cbs.forEach((cb) => cb(language))
  })
}

// 与后端对照语言
export const acceptLanguageMap = {
  zh: 'zh-CN',
  en: 'en-US',
  de: 'de-DE',
  fr: 'fr-FR'
}
