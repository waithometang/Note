import type { AxiosResponse } from 'axios'
import Request from './request'
import useUserStore from '@/stores/user'

const ssoRequest = new Request({
  baseURL: import.meta.env.VITE_SSO_URL,
  timeout: 1000 * 60 * 5,
  interceptors: {
    // 请求拦截器
    requestInterceptors: (config) => {
      const userStore = useUserStore()
      config.headers['Authorization'] = userStore.token
      return config
    },
    // 响应拦截器
    responseInterceptors: (result: AxiosResponse) => {
      if (result.status === 401) {
        const { logout } = useUserStore()
        logout()
      }

      return result
    }
  }
})

export default ssoRequest
