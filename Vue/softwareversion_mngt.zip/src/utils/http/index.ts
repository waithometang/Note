import type { AxiosResponse } from 'axios'
import Request from './request'
import useUserStore from '@/stores/user'

const hynRequest = new Request({
  baseURL: import.meta.env.VITE_BASE_URL,
  timeout: 1000 * 60 * 5,
  interceptors: {
    // 请求拦截器
    requestInterceptors: (config) => {
      const userStore = useUserStore()
      config.headers['Authorization'] = userStore.token
      return config
    },
    // 响应拦截器
    responseInterceptors: (result: AxiosResponse) => {
      return result
    }
  }
})

export default hynRequest
