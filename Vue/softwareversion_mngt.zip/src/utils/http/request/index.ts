import axios from 'axios'
import type { InternalAxiosRequestConfig, AxiosResponse, AxiosInstance } from 'axios'
import type { RequestConfig, RequestInterceptors } from './types'
import type { HYNResponse } from '@/types/axios'

class Request {
  // axios 实例
  instance: AxiosInstance
  // 拦截器对象
  interceptorsObj?: RequestInterceptors

  constructor(config: RequestConfig) {
    this.instance = axios.create(config)
    this.interceptorsObj = config.interceptors

    // 使用实例拦截器
    this.instance.interceptors.request.use(
      this.interceptorsObj?.requestInterceptors,
      this.interceptorsObj?.requestInterceptorsCatch
    )
    this.instance.interceptors.response.use(
      this.interceptorsObj?.responseInterceptors,
      this.interceptorsObj?.responseInterceptorsCatch
    )
  }
  request<T = any>(config: RequestConfig): Promise<HYNResponse<T>> {
    return new Promise((resolve, reject) => {
      // 单个请求设置拦截器
      if (config.interceptors?.requestInterceptors) {
        config = config.interceptors.requestInterceptors(config as any)
      }

      this.instance
        .request<any, AxiosResponse<HYNResponse<T>>>(config)
        .then((res: AxiosResponse<HYNResponse<T>>) => {
          const { isReturnNativeResponse = false } = config
          // 是否返回原生响应头 比如：需要获取响应头时使用该属性
          if (isReturnNativeResponse) {
            resolve(res as any)
          }

          // 单个请求响应设置拦截器
          if (config.interceptors?.responseInterceptors) {
            const ret = config.interceptors.responseInterceptors(res)
            resolve(ret)
          }

          resolve(res.data)
        })
        .catch((err: any) => {
          if (config.interceptors?.requestInterceptorsCatch) {
            resolve(config.interceptors.requestInterceptorsCatch(err))
          }
          reject(err)
        })
    })
  }
}

export default Request
