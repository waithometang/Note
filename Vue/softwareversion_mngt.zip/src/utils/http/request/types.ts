import type { HYNResponse } from '@/types/axios'
import type { InternalAxiosRequestConfig, AxiosResponse, AxiosRequestConfig } from 'axios'
export interface RequestInterceptors {
  // 请求拦截
  requestInterceptors?: (config: InternalAxiosRequestConfig) => InternalAxiosRequestConfig
  requestInterceptorsCatch?: (err: any) => any
  // 响应拦截
  responseInterceptors?: (response: AxiosResponse<HYNResponse>) => any
  responseInterceptorsCatch?: (err: any) => any
}

// 自定义传入的参数
export interface RequestConfig extends AxiosRequestConfig {
  interceptors?: RequestInterceptors
  // 是否返回原生响应头
  isReturnNativeResponse?: boolean
}

// // 请求参数
// export interface HYNRequestConfig<T> extends RequestConfig {
//   data?: T
// }
