import type { TagsViewItem } from '@/stores/types'
import { isDef } from './is'

// 过滤不需要保存的路由tag
const whiteList = ['/login', '/404', '/401'] // , '/dashboard'

// 是否展示tag
export function isTags(path: string) {
  return !whiteList.includes(path)
}

// 是否固定
export const isAffix = (tag: TagsViewItem | undefined) => {
  return isDef(tag) && tag.meta && tag.meta.affix
}
