import { isProdMode } from '@/utils/env'

let lastSrcs: string[] //上一次获取到的script地址
let needTip = true // 默认开启提示

const scriptReg = /<script.*src=["'](?<src>[^"']+)/gm

async function extractNewScripts() {
  const html = await fetch('/?_timestamp=' + Date.now()).then((resp) => resp.text())
  scriptReg.lastIndex = 0
  const result = []
  let match
  while ((match = scriptReg.exec(html))) {
    match.groups?.src && result.push(match.groups.src)
  }
  return result
}

async function needUpdate() {
  const newScripts = await extractNewScripts()
  if (!lastSrcs) {
    lastSrcs = newScripts
    return false
  }
  let result = false
  if (lastSrcs.length !== newScripts.length) {
    result = true
  }
  for (let i = 0; i < lastSrcs.length; i++) {
    if (lastSrcs[i] !== newScripts[i]) {
      result = true
      break
    }
  }
  lastSrcs = newScripts
  return result
}
const DURATION = 5000

function autoRefresh() {
  try {
    setTimeout(async () => {
      const willUpdate = await needUpdate()
      if (willUpdate) {
        const result = confirm('页面有更新，请刷新查看')
        if (result) {
          location.reload()
        }
        needTip = false // 关闭更新提示，防止重复提醒
      }
      if (needTip) {
        autoRefresh()
      }
    }, DURATION)
  } catch (e) {
    autoRefresh()
  }
}
if (isProdMode()) {
  autoRefresh()
}
