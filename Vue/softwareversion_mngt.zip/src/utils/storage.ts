enum StorageType {
  localStorage = 'localStorage',
  sessionStorage = 'sessionStorage'
}

class StorageHelper {
  storage: Storage

  constructor(type: StorageType) {
    this.storage = type === StorageType.localStorage ? window.localStorage : window.sessionStorage
  }

  set(key: string, value: any) {
    const data = JSON.stringify(value)
    this.storage.setItem(key, data)
  }

  get(key: string) {
    const value = this.storage.getItem(key)
    if (value) {
      try {
        return JSON.parse(value)
      } catch (error) {
        return value
      }
    }
  }

  delete(key: string) {
    this.storage.removeItem(key)
  }

  clear() {
    this.storage.clear()
  }
}

const LStorage = new StorageHelper(StorageType.localStorage)
const SStorage = new StorageHelper(StorageType.sessionStorage)

export { LStorage, SStorage }
