import hynRequest from '@/utils/http'
import type {
  GetInputStoreParams,
  GetInventoryParams,
  GetOutputStoreParams,
  InputStoreGetResultModel,
  InventoryGetResultModel,
  OutputStoreGetResultModel
} from './model/warehouseMngtModel'
/**
 * 物料入库查询
 */
export const getInputStore = (params: GetInputStoreParams) => {
  return hynRequest.request<InputStoreGetResultModel>({
    url: '/InputStore/GetInputStore',
    method: 'get',
    params: params
  })
}
/**
 * 物料出库查询
 */
export const getOutputStore = (params: GetOutputStoreParams) => {
  return hynRequest.request<OutputStoreGetResultModel>({
    url: '/OutputSync/GetOutputStore',
    method: 'get',
    params: params
  })
}
/**
 * 物料库存查询
 */
export const getInventory = (params: GetInventoryParams) => {
  return hynRequest.request<InventoryGetResultModel>({
    url: '/Inventory/GetInventory',
    method: 'get',
    params: params
  })
}
