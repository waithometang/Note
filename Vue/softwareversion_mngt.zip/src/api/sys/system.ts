import hynRequest from '@/utils/http'
import ssoRequest from '@/utils/http/sso'
import type {
  GetUserInfoSSOData,
  GetUserInfoSSOResultModel,
  ISystemInfo,
  UpdateLoginPasswordData
} from './model/systemModel'

/**
 * 获取系统信息
 */
export const getServerData = () => {
  return hynRequest.request<ISystemInfo>({
    url: '/ServerData/GetServerData',
    method: 'get'
  })
}

/**
 * 获取菜单
 */
export const getLoginUserMenu = (params: {
  visitor: boolean
  applicationID: string
  systemType: number
  systemTypeID: string
}) => {
  return ssoRequest.request<any>({
    url: '/AuthServer/GetLoginUserMenu',
    method: 'get',
    params
  })
}

/**
 * 获取权限
 */
export const getLoginUserMenuFunction = (params: { visitor: boolean; systemType: number,systemTypeID: string }) => {
  return ssoRequest.request<any>({
    url: '/AuthServer/GetLoginUserMenuFunction',
    method: 'get',
    params
  })
}

/**
 * 获取用户信息
 */
export const getUserInfoSSO = ({
  loginAccount,
  pageIndex = 0,
  pageSize = 20,
  userName
}: GetUserInfoSSOData) => {
  return ssoRequest.request<GetUserInfoSSOResultModel>({
    url: '/Login/GetViewPaging',
    method: 'post',
    data: { loginAccount, pageIndex, pageSize, userName }
  })
}

/**
 * 修改用户密码
 */
export const updateLoginPassword = (data: UpdateLoginPasswordData) => {
  return ssoRequest.request<boolean>({
    url: '/Login/UpdateLoginPassword',
    method: 'put',
    data
  })
}
