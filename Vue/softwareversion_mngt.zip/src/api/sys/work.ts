import hynRequest from '@/utils/http'
import type {
  AddProductionWoData,
  GetProductionPlanByWoParams,
  GetWorkOrderParams,
  UpdateProductionWoData,
  UpdateProductionWoStateData,
  WorkOrderListGetResultModel,
  GetReportWorkParams,
  ReportWorkListGetResultModel,
  GetWorkDispatchingWoParams,
  WorkDispatchingWoListGetResultModel,
  AddReportWorkData,
  UpdateReportWorkData,
  GetReportWorkDetailParams,
  GetReportWorkDetailModel,
  UpdateReportWorkStateData,
  UpdateDispatchingCompletedData,
  UpdateReportWorkStateModel,
  GetAttendanceParams,
  AttendanceListGetResultModel,
  AddAttendanceData,
  UpdateAttendanceStatusData,
  UpdateAttendanceData,
  UpdateAttendanceOrderStatusAllData,
  GetReportWorkProjectDetailParams,
  GetReportWorkProjectDetailModel,
  GetProductionPlanByWoModel,
  ProductionWoListGetResultModel,
  ProductionWoByWoNoGetResultModel,
  GetProductionWoByWoNoParams,
  GetExceptionRecordParams,
  UpdateAttendanceRevokeConfirmData,
  GetDispatchingGroupByDateData,
  DispatchingGroupByDateGetResultModel,
  AddDispatchingGroupData,
  GetDispatchingGroupParams,
  DispatchingGroupGetResultModel,
  DeleteDispatchingGroupData,
  UpdateDispatchingGroupData,
  GetDispatchingGroupWoParams,
  DispatchingGroupListGetResultModel,
  GetDispatchingEmployeeParams,
  DispatchingEmployeeGetResultModel,
  DeleteDispatchingEmployeeData,
  UpdateDispatchingEmployeeData,
  AddDispatchingEmployeeData,
  GetDispatchingEmployeeByDateData,
  DispatchingEmployeeByDateGetResultModel,
  ExceptionRecordGetResultModel,
  AddExceptionRecordData,
  UpdateExceptionRecordData,
  DeleteExceptionRecordData,
  UpdateExceptionRecordProcessingStateData,
  ADDEmployeeTransferData,
  DeleteEmployeeTransferData,
  EmployeeTransferListGetResultModel,
  GetEmployeeTransferParams,
  UpdateEmployeeTransfer,
  UpdateEmployeeTransferConfirmData,
  UpdateDispatchingGroupCompletedData,
  PerformanceStandardListGetResultModel,
  AddReportWorkProductionPerformanceData,
  AddReportWorkProductionPerformanceResult,
  UpdateHonorRollData,
  AddHonorRollData,
  GetHonorRollParams,
  HonorRollListGetResultModel,
  GetProductionPerformanceParams,
  ProductionPerformanceListGetResultModel,
  AddProductionPerformanceData,
  UpdateProductionPerformanceData,
  GetDispatchingSearchParams,
  DispatchingSearchGetResultModel,
  GetReportWorkSearchParams,
  ReportWorkSearchGetResultModel,
  GetProductionWoByOrderNoParams,
  GetProductionWoByOrderNoModel,
  UpdateProductionWoStateMoreData,
  GetProductionWoListByStartStatusParams,
  GetWorkOrderModel,
  GetDispatchingOrderParams,
  GetDispatchingOrderGetResultModel,
  GetReportWorkEmployeeModel,
  GetOtherReportWorkGetResultModel,
  GetOtherReportWorkParams,
  UpdateOtherReportWorkData,
  AddOtherReportWorkData,
  GetEmployeeStatusModel,
  ExportProductionWoParams,
  ExportReportWorkparams,
  GetDispatchingOtherParams,
  UpdateDispatchingOtherData,
  AddDispatchingOtherData,
  DispatchingOtherGetResultModel,
  GetOtherReportWorkDetailParams,
  GetOtherReportWorkDetailModel,
  UpdateOtherReportWorkStateModel,
  UpdateOtherReportWorkStateData,
  AddOtherReportWorkProductionPerformanceData,
  AddOtherReportWorkProductionPerformanceModel,
  GetOtherReportWorkEmployeeStatusParams,
  GetProductionPerformanceByEmployeeParams,
  ProductionPerformanceByEmployeeGetResultModel,
  TransferDispatchingEmployeeData
} from './model/workModel'
import type { BasicPageParams } from '../model/baseModel'

/**
 * 查询生产工单
 */
export const getProductionWo = (params: GetWorkOrderParams) => {
  return hynRequest.request<WorkOrderListGetResultModel>({
    url: '/ProductionWo/GetProductionWo',
    method: 'get',
    params: params
  })
}

/**
 * 根据工单查询查询生产计划
 */
export const getProductionPlanByWo = (params: GetProductionPlanByWoParams) => {
  return hynRequest.request<GetProductionPlanByWoModel[]>({
    url: '/ProductionWo/GetProductionPlanByWo',
    method: 'get',
    params: params
  })
}

/**
 * 添加生产工单
 */
export const addProductionWo = (data: AddProductionWoData) => {
  return hynRequest.request<boolean>({
    url: '/ProductionWo/AddProductionWo',
    method: 'post',
    data: data
  })
}

/**
 * 修改工单
 */
export const updateProductionWo = (data: UpdateProductionWoData) => {
  return hynRequest.request<boolean>({
    url: '/ProductionWo/UpdateProductionWo',
    method: 'post',
    data: data
  })
}

/**
 * 修改工单状态
 */
export const updateProductionWoState = (data: UpdateProductionWoStateData) => {
  return hynRequest.request<boolean>({
    url: '/ProductionWo/UpdateProductionWoState',
    method: 'post',
    data: data
  })
}
/**
 * 导出工单列表
 */
export const exportProductionWo = (params: ExportProductionWoParams) => {
  return hynRequest.request<boolean>({
    url: '/ProductionWo/ExportProductionWo',
    method: 'get',
    params: params,
    responseType: 'blob',
    isReturnNativeResponse: true
  })
}

/**
 * 查询生产工单业务类型
 */
export const getMODocType = () => {
  return hynRequest.request<{ id: string; name: string; key: string }>({
    url: '/ProductionWo/GetMODocType',
    method: 'get'
  })
}

/**
 * 查询生产报工列表
 */
export const getReportWork = (params: GetReportWorkParams) => {
  return hynRequest.request<ReportWorkListGetResultModel>({
    url: '/ReportWork/GetReportWork',
    method: 'get',
    params: params
  })
}

/**
 * 获取员工关联项目信息
 */
export const getReportWorkProjectDetail = (params: GetReportWorkProjectDetailParams) => {
  return hynRequest.request<GetReportWorkProjectDetailModel[]>({
    url: '/ReportWork/GetReportWorkProjectDetail',
    method: 'get',
    params: params
  })
}

// /**
//  * 添加或编辑报工单
//  */
// export const addReportWork = (data: AddReportWorkData) => {
//   return hynRequest.request<boolean>({
//     url: '/ReportWork/AddReportWork',
//     method: 'post',
//     data
//   })
// }

/**
 * 添加报工单
 */
export const addReportWork = (data: AddReportWorkData) => {
  return hynRequest.request<boolean>({
    url: '/ReportWork/AddReportWork',
    method: 'post',
    data
  })
}

/**
 * 修改报工单
 */
export const updateReportWork = (data: UpdateReportWorkData) => {
  return hynRequest.request<boolean>({
    url: '/ReportWork/UpdateReportWork',
    method: 'post',
    data
  })
}

/**
 * 更改报工单状态
 */
export const updateReportWorkState = (data: UpdateReportWorkStateData) => {
  return hynRequest.request<UpdateReportWorkStateModel>({
    url: '/ReportWork/UpdateReportWorkState',
    method: 'post',
    data
  })
}

/**
 * 导出报工单
 */
export const exportReportWork = (params: ExportReportWorkparams) => {
  return hynRequest.request<boolean>({
    url: '/ReportWork/ExportReportWork',
    method: 'get',
    params,
    responseType: 'blob',
    isReturnNativeResponse: true
  })
}

/**
 * 导出计划实际达成表
 */
export const exportReportWorkScheduling = (params: {
  /**
   * 部门ID
   */
  DepartmentID: string
  /**
   * 班组ID
   */
  GroupID: string
  /**
   * 计划日期
   */
  SchedulingDate: string
}) => {
  return hynRequest.request<boolean>({
    url: '/ReportWork/ExportReportWorkScheduling',
    method: 'get',
    params,
    responseType: 'blob',
    isReturnNativeResponse: true
  })
}

/**
 * 设置派工单完成
 */
export const updateDispatchingCompleted = (data: UpdateDispatchingCompletedData) => {
  return hynRequest.request<boolean>({
    url: '/DispatchingEmployee/UpdateDispatchingCompleted',
    method: 'post',
    data
  })
}

/**
 * 获取生产报工单明细
 */
export const getReportWorkDetail = (params: GetReportWorkDetailParams) => {
  return hynRequest.request<GetReportWorkDetailModel>({
    url: '/ReportWork/GetReportWorkDetail',
    method: 'get',
    params: params
  })
}

/**
 * 查询车间派工单列表
 */
export const getDispatchingGroup = (params: GetDispatchingGroupParams) => {
  return hynRequest.request<DispatchingGroupGetResultModel>({
    url: '/DispatchingGroup/GetDispatchingGroup',
    method: 'get',
    params
  })
}

/**
 * 添加/复制车间派工单
 */
export const addDispatchingGroup = (data: AddDispatchingGroupData) => {
  return hynRequest.request<boolean>({
    url: '/DispatchingGroup/AddDispatchingGroup',
    method: 'post',
    data
  })
}

/**
 * 查询班组指定日期的车间派工单
 */
export const getDispatchingGroupByDate = (params: GetDispatchingGroupByDateData) => {
  return hynRequest.request<DispatchingGroupByDateGetResultModel>({
    url: '/DispatchingGroup/GetDispatchingGroupByDate',
    method: 'get',
    params
  })
}

/**
 * 修改车间派工单
 */
export const updateDispatchingGroup = (data: UpdateDispatchingGroupData) => {
  return hynRequest.request<boolean>({
    url: '/DispatchingGroup/UpdateDispatchingGroup',
    method: 'post',
    data
  })
}

/**
 * 删除车间派工单
 */
export const deleteDispatchingGroup = (data: DeleteDispatchingGroupData) => {
  return hynRequest.request<boolean>({
    url: '/DispatchingGroup/DeleteDispatchingGroup',
    method: 'post',
    data
  })
}

/**
 * 新增派工单时查询剩余最大可填进度比重
 */
export const getDispatchingGroupProportion = (params: { woNo: string; sonProcessID: string }) => {
  return hynRequest.request<{
    maxProportion: number
    maxDispatchingNumber: number
    sumDispatchingNumber: number
    dataDescribe?: string
  }>({
    url: 'DispatchingGroup/GetDispatchingGroupProportion',
    method: 'get',
    params
  })
}

/**
 * 更新车间派工单完成状态
 */
export const updateDispatchingGroupCompleted = (data: UpdateDispatchingGroupCompletedData) => {
  return hynRequest.request<boolean>({
    url: '/DispatchingGroup/UpdateDispatchingGroupCompleted',
    method: 'post',
    data
  })
}

/**
 * 导出车间派工单
 */
export const exportDispatchingGroup = (params: GetWorkDispatchingWoParams) => {
  return hynRequest.request<BlobPart>({
    url: '/DispatchingGroup/ExportDispatchingGroup',
    method: 'get',
    params,
    responseType: 'blob',
    isReturnNativeResponse: true
  })
}

/**
 * 查询派工工单列表
 */
export const getDispatchingWo = (params: GetWorkDispatchingWoParams) => {
  return hynRequest.request<WorkDispatchingWoListGetResultModel>({
    url: '/DispatchingGroup/GetDispatchingWo',
    method: 'get',
    params
  })
}

/**
 * 查询考勤登记信息
 */
export const getAttendance = (params: GetAttendanceParams) => {
  return hynRequest.request<AttendanceListGetResultModel>({
    url: '/Attendance/GetAttendance',
    method: 'get',
    params
  })
}

/**
 * 批量添加考勤登记
 */
export const addAttendance = (data: AddAttendanceData) => {
  return hynRequest.request<boolean>({
    url: '/Attendance/AddAttendance',
    method: 'post',
    data
  })
}

/**
 * 确认生产考勤登记信息
 */
export const updateAttendanceOrderStatus = (data: UpdateAttendanceStatusData) => {
  return hynRequest.request<boolean>({
    url: '/Attendance/UpdateAttendanceOrderStatus',
    method: 'post',
    data
  })
}

/**
 * 撤销确认生产考勤登记信息
 */
export const updateAttendanceRevokeConfirm = (data: UpdateAttendanceRevokeConfirmData) => {
  return hynRequest.request<boolean>({
    url: '/Attendance/UpdateAttendanceRevokeConfirm',
    method: 'post',
    data
  })
}

/**
 * 更新生产考勤登记信息
 */
export const updateAttendance = (data: UpdateAttendanceData) => {
  return hynRequest.request<boolean>({
    url: '/Attendance/UpdateAttendance',
    method: 'post',
    data
  })
}

/**
 * 全部确认生产考勤登记信息
 */
export const updateAttendanceOrderStatusAll = (data: UpdateAttendanceOrderStatusAllData) => {
  return hynRequest.request<boolean>({
    url: '/Attendance/UpdateAttendanceOrderStatusAll',
    method: 'post',
    data
  })
}

/**
 * 导出所有员工指定日期考勤登记
 */
export const exportAttendance = (params: {
  /**
   * 考勤结束日期
   */
  attendanceEndDate: string
  /**
   * 考勤开始日期
   */
  attendanceStartDate: string
}) => {
  return hynRequest.request<BlobPart>({
    url: '/Attendance/ExportAttendance',
    method: 'get',
    params,
    responseType: 'blob',
    isReturnNativeResponse: true
  })
}

/**
 * 查询未开始和执行中的工单列表
 */
export const getProductionWoList = () => {
  return hynRequest.request<ProductionWoListGetResultModel>({
    url: '/ProductionWo/GetProductionWoList',
    method: 'get'
  })
}

/**
 * 获取指定工单
 */
export const getProductionWoByWoNo = (params: GetProductionWoByWoNoParams) => {
  return hynRequest.request<ProductionWoByWoNoGetResultModel>({
    url: '/ProductionWo/GetProductionWoByWoNo',
    method: 'get',
    params
  })
}

/**
 * 组内派工-获取组内派工单
 */
export const getDispatchingEmployee = (params: GetDispatchingEmployeeParams) => {
  return hynRequest.request<DispatchingEmployeeGetResultModel>({
    url: '/DispatchingEmployee/GetDispatchingEmployee',
    method: 'get',
    params
  })
}

/**
 * 添加/复制组内派工单
 */
export const addDispatchingEmployee = (data: AddDispatchingEmployeeData) => {
  return hynRequest.request<boolean>({
    url: '/DispatchingEmployee/AddDispatchingEmployee',
    method: 'post',
    data
  })
}

/**
 * 查询班组指定日期的组内派工单
 */
export const getDispatchingEmployeeByDate = (params: GetDispatchingEmployeeByDateData) => {
  return hynRequest.request<DispatchingEmployeeByDateGetResultModel>({
    url: '/DispatchingEmployee/GetDispatchingEmployeeByDate',
    method: 'get',
    params
  })
}

/**
 * 修改组内派工单
 */
export const updateDispatchingEmployee = (data: UpdateDispatchingEmployeeData) => {
  return hynRequest.request<boolean>({
    url: '/DispatchingEmployee/UpdateDispatchingEmployee',
    method: 'post',
    data
  })
}

/**
 * 转交组内派工单
 */
export const transferDispatchingEmployee = (data: TransferDispatchingEmployeeData) => {
  return hynRequest.request<boolean>({
    url: '/DispatchingEmployee/TransferDispatchingEmployee',
    method: 'post',
    data
  })
}

/**
 * 删除组内派工单
 */
export const deleteDispatchingEmployee = (data: DeleteDispatchingEmployeeData) => {
  return hynRequest.request<boolean>({
    url: '/DispatchingEmployee/DeleteDispatchingEmployee',
    method: 'post',
    data
  })
}

/**
 * 组内派工-查询组内车间派工单
 */
export const getDispatchingGroupWo = (params: GetDispatchingGroupWoParams) => {
  return hynRequest.request<DispatchingGroupListGetResultModel>({
    url: '/DispatchingEmployee/GetDispatchingGroup',
    method: 'get',
    params
  })
}

/**
 * 导出组内派工单
 */
export const exportDispatchingEmployee = (params: {
  /**
   * 结束日期
   */
  DispatchingEndDate: string
  /**
   * 开始日期
   */
  DispatchingStartDate: string
}) => {
  return hynRequest.request<BlobPart>({
    url: '/DispatchingEmployee/ExportDispatchingEmployee',
    method: 'get',
    params,
    responseType: 'blob',
    isReturnNativeResponse: true
  })
}

/**
 * 导出计划人员安排表
 */
export const exportDispatchingScheduling = (params: {
  /**
   * 部门ID
   */
  DepartmentID: string
  /**
   * 班组ID
   */
  GroupID: string
  /**
   * 计划日期
   */
  SchedulingDate: string
}) => {
  return hynRequest.request<BlobPart>({
    url: '/DispatchingEmployee/ExportDispatchingScheduling',
    method: 'get',
    params,
    responseType: 'blob',
    isReturnNativeResponse: true
  })
}

/**
 * 获取生产异常信息
 */
export const getExceptionRecord = (params: GetExceptionRecordParams) => {
  return hynRequest.request<ExceptionRecordGetResultModel>({
    url: '/ExceptionRecord/GetExceptionRecord',
    method: 'get',
    params
  })
}

/**
 * 添加生产异常信息
 */
export const addExceptionRecord = (data: AddExceptionRecordData) => {
  return hynRequest.request<boolean>({
    url: '/ExceptionRecord/AddExceptionRecord',
    method: 'post',
    data
  })
}

/**
 * 修改生产异常信息
 */
export const updateExceptionRecord = (data: UpdateExceptionRecordData) => {
  return hynRequest.request<boolean>({
    url: '/ExceptionRecord/UpdateExceptionRecord',
    method: 'post',
    data
  })
}

/**
 * 删除生产异常信息
 */
export const deleteExceptionRecord = (data: DeleteExceptionRecordData) => {
  return hynRequest.request<boolean>({
    url: '/ExceptionRecord/DeleteExceptionRecord',
    method: 'post',
    data
  })
}

/**
 * 更新生产异常状态信息
 */
export const updateExceptionRecordProcessingState = (
  data: UpdateExceptionRecordProcessingStateData
) => {
  return hynRequest.request<boolean>({
    url: '/ExceptionRecord/UpdateExceptionRecordProcessingState',
    method: 'post',
    data
  })
}

/**
 * 导出生产异常状态信息
 */
export const exportExceptionRecord = (
  params: Omit<GetExceptionRecordParams, keyof BasicPageParams>
) => {
  return hynRequest.request<boolean>({
    url: '/ExceptionRecord/ExportExceptionRecord',
    method: 'get',
    params,
    responseType: 'blob',
    isReturnNativeResponse: true
  })
}

/**
 * 获取人员借调信息
 */
export const getEmployeeTransfer = (params: GetEmployeeTransferParams) => {
  return hynRequest.request<EmployeeTransferListGetResultModel>({
    url: '/EmployeeTransfer/GetEmployeeTransfer',
    method: 'get',
    params
  })
}

/**
 * 添加人员借调信息
 */
export const addEmployeeTransfer = (data: ADDEmployeeTransferData) => {
  return hynRequest.request<boolean>({
    url: '/EmployeeTransfer/AddEmployeeTransfer',
    method: 'post',
    data
  })
}

/**
 * 编辑人员借调信息
 */
export const updateEmployeeTransfer = (data: UpdateEmployeeTransfer) => {
  return hynRequest.request<boolean>({
    url: '/EmployeeTransfer/UpdateEmployeeTransfer',
    method: 'post',
    data
  })
}

/**
 * 删除人员借调信息
 */
export const deleteEmployeeTransfer = (data: DeleteEmployeeTransferData) => {
  return hynRequest.request<boolean>({
    url: '/EmployeeTransfer/DeleteEmployeeTransfer',
    method: 'post',
    data
  })
}

/**
 * 修改人员借调管理状态
 */
export const updateEmployeeTransferConfirm = (data: UpdateEmployeeTransferConfirmData) => {
  return hynRequest.request<boolean>({
    url: '/EmployeeTransfer/UpdateEmployeeTransferConfirm',
    method: 'post',
    data
  })
}

/**
 * 导出人员借调信息
 */
export const exportEmployeeTransfer = (params: GetEmployeeTransferParams) => {
  return hynRequest.request<BlobPart>({
    url: '/EmployeeTransfer/ExportEmployeeTransfer',
    method: 'get',
    params,
    responseType: 'blob',
    isReturnNativeResponse: true
  })
}

/**
 * 查询生产绩效标准
 */
export const getPerformanceStandard = () => {
  return hynRequest.request<PerformanceStandardListGetResultModel>({
    url: '/PerformanceStandard/GetPerformanceStandard',
    method: 'get'
  })
}

/**
 * 报工组长确认
 */
export const addReportWorkProductionPerformance = (
  data: AddReportWorkProductionPerformanceData
) => {
  return hynRequest.request<AddReportWorkProductionPerformanceResult>({
    url: '/ReportWork/AddReportWorkProductionPerformance',
    method: 'post',
    data
  })
}

/**
 * 查询荣誉榜
 */
export const getHonorRoll = (params: GetHonorRollParams) => {
  return hynRequest.request<HonorRollListGetResultModel>({
    url: '/HonorRoll/GetHonorRoll',
    method: 'get',
    params: params
  })
}
/**
 * 添加荣誉榜
 */
export const addHonorRoll = (data: AddHonorRollData) => {
  return hynRequest.request<boolean>({
    url: '/HonorRoll/AddHonorRoll',
    method: 'post',
    data: data
  })
}
/**
 * 修改荣誉榜
 */
export const updateHonorRoll = (data: UpdateHonorRollData) => {
  return hynRequest.request<boolean>({
    url: '/HonorRoll/UpdateHonorRoll',
    method: 'post',
    data: data
  })
}
/**
 * 删除荣誉榜
 */
export const deleteHonorRoll = (data: { id: string }) => {
  return hynRequest.request<boolean>({
    url: '/HonorRoll/DeleteHonorRoll',
    method: 'post',
    data: data
  })
}

/**
 * 查询生产绩效
 */
export const getProductionPerformance = (params: GetProductionPerformanceParams) => {
  return hynRequest.request<ProductionPerformanceListGetResultModel>({
    url: '/ProductionPerformance/GetProductionPerformance',
    method: 'get',
    params: params
  })
}
/**
 * 添加生产绩效
 */
export const addProductionPerformance = (data: AddProductionPerformanceData) => {
  return hynRequest.request<boolean>({
    url: '/ProductionPerformance/AddProductionPerformance',
    method: 'post',
    data: data
  })
}
/**
 * 修改生产绩效
 */
export const updateProductionPerformance = (data: UpdateProductionPerformanceData) => {
  return hynRequest.request<boolean>({
    url: '/ProductionPerformance/UpdateProductionPerformance',
    method: 'post',
    data: data
  })
}
/**
 * 删除生产绩效
 */
export const deleteProductionPerformance = (data: { id: string }) => {
  return hynRequest.request<boolean>({
    url: '/ProductionPerformance/DeleteProductionPerformance',
    method: 'post',
    data: data
  })
}
/**
 * 导出生产绩效
 */
export const exportProductionPerformance = (params: GetProductionPerformanceParams) => {
  return hynRequest.request<BlobPart>({
    url: '/ProductionPerformance/ExportProductionPerformance',
    method: 'get',
    params,
    responseType: 'blob',
    isReturnNativeResponse: true
  })
}

/**
 * 查询指定员工和日期的绩效记录
 */
export const getProductionPerformanceByEmployee = (
  params: GetProductionPerformanceByEmployeeParams
) => {
  return hynRequest.request<ProductionPerformanceByEmployeeGetResultModel>({
    url: '/ProductionPerformance/GetProductionPerformanceByEmployee',
    method: 'get',
    params
  })
}

/**
 * 查询派工单
 */
export const getDispatchingSearch = (params: GetDispatchingSearchParams) => {
  return hynRequest.request<DispatchingSearchGetResultModel>({
    url: '/DispatchingSearch/GetDispatchingSearch',
    method: 'get',
    params: params
  })
}
/**
 * 导出派工单
 */
export const exportDispatchingSearch = (params: GetDispatchingSearchParams) => {
  return hynRequest.request<BlobPart>({
    url: '/DispatchingSearch/ExportDispatchingSearch',
    method: 'get',
    params,
    responseType: 'blob',
    isReturnNativeResponse: true
  })
}

/**
 * 查询报工单
 */
export const getReportWorkSearch = (params: GetReportWorkSearchParams) => {
  return hynRequest.request<ReportWorkSearchGetResultModel>({
    url: '/ReportWorkSearch/GetReportWorkSearch',
    method: 'get',
    params: params
  })
}
/**
 * 导出报工单
 */
export const exportReportWorkSearch = (params: GetReportWorkSearchParams) => {
  return hynRequest.request<BlobPart>({
    url: '/ReportWorkSearch/ExportReportWorkSearch',
    method: 'get',
    params,
    responseType: 'blob',
    isReturnNativeResponse: true
  })
}
/**
 * 导出工单导入模版
 */
export const exportTemplate = () => {
  return hynRequest.request<BlobPart>({
    url: '/ProductionWo/ExportTemplate',
    method: 'get',
    responseType: 'blob',
    isReturnNativeResponse: true
  })
}
/**
 * 查询指定需求分类的单据编号和部件名称等信息
 */
export const getProductionWoByOrderNo = (params: GetProductionWoByOrderNoParams) => {
  return hynRequest.request<GetProductionWoByOrderNoModel>({
    url: '/ProductionWo/getProductionWoByOrderNo',
    method: 'get',
    params: params
  })
}
/**
 * 获取批量开工的工单列表
 */
export const getProductionWoListByStartStatus = (
  params: GetProductionWoListByStartStatusParams
) => {
  return hynRequest.request<GetWorkOrderModel[]>({
    url: '/ProductionWo/GetProductionWoListByStartStatus',
    method: 'get',
    params: params
  })
}

/**
 * 批量更改工单开工状态
 */
export const updateProductionWoStateMore = (data: UpdateProductionWoStateMoreData) => {
  return hynRequest.request<boolean>({
    url: '/ProductionWo/UpdateProductionWoStateMore',
    method: 'post',
    data
  })
}

/**
 * 查询派工单
 */
export const getDispatchingOrder = (params: GetDispatchingOrderParams) => {
  return hynRequest.request<GetDispatchingOrderGetResultModel>({
    url: '/ReportWork/GetDispatchingOrder',
    method: 'get',
    params: params
  })
}
/**
 * 获取派工单的关联员工下拉列表
 */
export const getReportWorkEmployee = (params: {
  /**
   * 组内派工单ID
   */
  dispatchingGroupID: string
}) => {
  return hynRequest.request<GetReportWorkEmployeeModel[]>({
    url: '/ReportWork/GetReportWorkEmployee',
    method: 'get',
    params: params
  })
}
/**
 * 获取其他报工单
 */
export const getOtherReportWork = (params: GetOtherReportWorkParams) => {
  return hynRequest.request<GetOtherReportWorkGetResultModel>({
    url: '/ReportWorkOther/GetOtherReportWork',
    method: 'get',
    params: params
  })
}

/**
 * 添加其他报工单
 */
export const addOtherReportWork = (data: AddOtherReportWorkData) => {
  return hynRequest.request<boolean>({
    url: '/ReportWorkOther/AddOtherReportWork',
    method: 'post',
    data
  })
}

/**
 * 修改其他报工单
 */
export const updateOtherReportWork = (data: UpdateOtherReportWorkData) => {
  return hynRequest.request<boolean>({
    url: '/ReportWorkOther/UpdateOtherReportWork',
    method: 'post',
    data
  })
}
/**
 * 获取员工的考勤和借调状态
 */
export const getEmployeeStatus = (params: { employeeInfoId: string; reportWorkTime: string }) => {
  return hynRequest.request<GetEmployeeStatusModel>({
    url: '/ReportWork/GetEmployeeStatus',
    method: 'get',
    params: params
  })
}

/**
 * 获取其他派工单
 */
export const getDispatchingOther = (params: GetDispatchingOtherParams) => {
  return hynRequest.request<DispatchingOtherGetResultModel>({
    url: '/DispatchingOther/GetDispatchingOther',
    method: 'get',
    params: params
  })
}

/**
 * 批量添加其他派工单
 */
export const addDispatchingOther = (data: AddDispatchingOtherData) => {
  return hynRequest.request<boolean>({
    url: '/DispatchingOther/AddDispatchingOther',
    method: 'post',
    data
  })
}

/**
 * 修改其他派工单
 */
export const updateDispatchingOther = (data: UpdateDispatchingOtherData) => {
  return hynRequest.request<boolean>({
    url: '/DispatchingOther/UpdateDispatchingOther',
    method: 'post',
    data
  })
}

/**
 * 删除其他派工单
 */
export const deleteDispatchingOther = (data: { id: string }) => {
  return hynRequest.request<boolean>({
    url: '/DispatchingOther/DeleteDispatchingOther',
    method: 'post',
    data: data
  })
}

/**
 * 设置其他派工单完成
 */
export const updateDispatchingOtherCompleted = (data: { id: string }) => {
  return hynRequest.request<boolean>({
    url: '/DispatchingOther/UpdateDispatchingOtherCompleted',
    method: 'post',
    data
  })
}

/**
 * 导出其他派工单
 */
export const exportDispatchingOther = (params: GetDispatchingOtherParams) => {
  return hynRequest.request<BlobPart>({
    url: '/DispatchingOther/ExportDispatchingOther',
    method: 'get',
    params,
    responseType: 'blob',
    isReturnNativeResponse: true
  })
}

/**
 * 导出其他报工
 */
export const exportOtherReportWork = (params: GetDispatchingOtherParams) => {
  return hynRequest.request<BlobPart>({
    url: '/ReportWorkOther/ExportReportWork',
    method: 'get',
    params,
    responseType: 'blob',
    isReturnNativeResponse: true
  })
}

/**
 * 获取其他生产报工单明细
 */
export const getOtherReportWorkDetail = (params: GetOtherReportWorkDetailParams) => {
  return hynRequest.request<GetOtherReportWorkDetailModel>({
    url: '/ReportWorkOther/GetReportWorkDetail',
    method: 'get',
    params: params
  })
}

/**
 * 更改报工单状态
 */
export const updateOtherReportWorkState = (data: UpdateOtherReportWorkStateData) => {
  return hynRequest.request<UpdateOtherReportWorkStateModel>({
    url: '/ReportWorkOther/UpdateReportWorkState',
    method: 'post',
    data
  })
}

/**
 * 其他报工组长确认
 */
export const addOtherReportWorkProductionPerformance = (
  data: AddOtherReportWorkProductionPerformanceData
) => {
  return hynRequest.request<AddOtherReportWorkProductionPerformanceModel>({
    url: '/ReportWorkOther/AddReportWorkProductionPerformance',
    method: 'post',
    data
  })
}

/**
 * 获取其他派工单
 */
export const getOtherReportWorkEmployeeStatus = (
  params: GetOtherReportWorkEmployeeStatusParams
) => {
  return hynRequest.request<GetEmployeeStatusModel>({
    url: '/ReportWorkOther/GetEmployeeStatus',
    method: 'get',
    params: params
  })
}
