import hynRequest from '@/utils/http'
import type {
  DepartmentListGetResultModel,
  DictionaryListGetResultModel,
  EmployeeListGetResultModel,
  GroupListGetResultModel,
  GetDepartmentParams,
  GetDictionaryParams,
  GetEmployeeInfoParams,
  GetGroupParams,
  PositionLevelListGetResultModel,
  GetPositionLevelParams,
  AddEmployeeInfoData,
  UpdateEmployeeInfoData,
  GetDictionaryClassifyParams,
  DictionaryClassifyListGetResultModel,
  AddGroupData,
  UpdateGroupData,
  DeleteGroupData,
  AddDepartmentData,
  UpdateDepartmentData,
  DeleteDepartmentData,
  AddDictionaryClassifyData,
  DeleteDictionaryClassifyData,
  AddDictionaryData,
  DeleteDictionaryData,
  UpdateDictionaryData,
  AddProductionLineData,
  AddProductionProcessData,
  DeleteProductionLineData,
  DeleteProductionProcessData,
  GetProductionLineParams,
  GetProductionProcessParams,
  ProductionLineListGetResultModel,
  UpdateProductionLineData,
  UpdateProductionProcessData,
  ScheduleListGetResultModel,
  GetScheduleParams,
  UpdateScheduleData,
  DeleteScheduleData,
  AddScheduleData,
  ProductionProjectListGetResultModel,
  GetProductionProjectParams,
  UpdateProductionProjectData,
  DeleteProductionProjectData,
  AddProductionProjectData,
  StandardWorkTimeListGetResultModel,
  GetStandardWorkTimeParams,
  UpdateStandardWorkTimeData,
  DeleteStandardWorkTimeData,
  AddStandardWorkTimeData,
  ProductionNodeListGetResultModel,
  GetProductionNodeParams,
  AddProductionNodeData,
  UpdateProductionNodeData,
  DeleteProductionNodeData,
  ProductionProcessListGetResultModel,
  GetProductionProcessChildrenParams,
  CopyStandardWorkTimeData,
  ProductionVersionModelListGetResultModel,
  GetProductionVersionParams,
  GetProjectValidVersionParams,
  GetProductionVersionModel,
  GroupSelectListGetResultModel,
  GetProductionNodeModel,
  EmployeeByGroupIDListGetResultModel,
  GetProductionVersionSelectParams,
  GroupListByDepartmentNameGetResultModel,
  DeleteEmployeeInfoData,
  GetGroupLeaderParams,
  GroupLeaderListGetResultModel,
  GetConfirmSignatureTypeParams,
  ConfirmSignatureTypeListGetResultModel,
  AddConfirmSignatureTypeData,
  UpdateConfirmSignatureTypeData,
  GetEmployeeInfoBySelectParams,
  EmployeeInfoBySelectListGetResultModel,
  UpdatePositionClassifyData,
  AddPositionClassifyData,
  PositionClassifyListGetResultModel,
  GetPositionClassifyParams,
  ManufactureGroupListGetResultModel,
  GetUserRequestLogParams,
  GetUserRequestLogData,
  AddMessageData,
  UpdataMessageData,
  MessageGetResultModel,
  GetMessageParams,
  GetNoticeMngtParams,
  NoticeMngtGetResultModel,
  AddNoticeMngtData,
  UpdateNoticeMngtData,
  DeleteNoticeMngtData,
  MessageNoticeTypeGetResultModel,
  OrderAutoConfirmListGetResultModel,
  GetOrderAutoConfirmParams,
  UpdateOrderAutoConfirmData,
  AddOrderAutoConfirmData,
  AddStandardWorkTimeWoExIncludeData,
  DeleteStandardWorkTimeWoExIncludeData,
  GetEmployeeByAttendanceDateParams,
  EmployeeByAttendanceDateGetResultModel,
  GetDictionaryModel
} from './model/basicModel'

/**
 * 获取员工信息
 */
export const getEmployeeInfo = (params: GetEmployeeInfoParams) => {
  return hynRequest.request<EmployeeListGetResultModel>({
    url: '/EmployeeInfo/GetEmployeeInfo',
    method: 'get',
    params: params
  })
}
/**
 * 根据组别获取全部员工信息
 */
export const getEmployeeInfoSelect = (params: { groupID: string; requestDate?: string }) => {
  return hynRequest.request<EmployeeByGroupIDListGetResultModel>({
    url: '/EmployeeInfo/GetEmployeeInfoSelect',
    method: 'get',
    params: params
  })
}

/**
 * 根据ID获取员工信息
 */
export const getEmployeeInfoAssemblyMany = (params: { employeeInfoID: string[] }) => {
  return hynRequest.request<EmployeeListGetResultModel>({
    url: '/EmployeeInfo/GetEmployeeInfoAssemblyMany',
    method: 'get',
    params: params
  })
}

/**
 * 添加员工信息
 */
export const addEmployeeInfo = (data: AddEmployeeInfoData) => {
  return hynRequest.request<boolean>({
    url: '/EmployeeInfo/AddEmployeeInfo',
    method: 'post',
    data: data
  })
}

/**
 * 修改员工信息
 */
export const updateEmployeeInfo = (data: UpdateEmployeeInfoData) => {
  return hynRequest.request<boolean>({
    url: '/EmployeeInfo/UpdateEmployeeInfo',
    method: 'post',
    data: data
  })
}

/**
 * 删除员工信息
 */
export const deleteEmployeeInfo = (data: DeleteEmployeeInfoData) => {
  return hynRequest.request<boolean>({
    url: '/EmployeeInfo/DeleteEmployeeInfo',
    method: 'post',
    data: data
  })
}

/**
 * 导出员工信息
 */
export const exportEmployeeInfo = (params: GetEmployeeInfoParams) => {
  return hynRequest.request<BlobPart>({
    url: '/EmployeeInfo/ExportEmployeeInfo',
    method: 'get',
    params: params,
    responseType: 'blob',
    isReturnNativeResponse: true
  })
}

/**
 * 获取指定日期出勤的在职员工
 */
export const getEmployeeByAttendanceDate = (params: GetEmployeeByAttendanceDateParams) => {
  return hynRequest.request<EmployeeByAttendanceDateGetResultModel>({
    url: '/EmployeeInfo/GetEmployeeByAttendanceDate',
    method: 'get',
    params: params
  })
}

/**
 * 查询等级信息
 */
export const getPositionLevel = (params: GetPositionLevelParams) => {
  return hynRequest.request<PositionLevelListGetResultModel>({
    url: '/PositionLevel/GetPositionLevel',
    method: 'get',
    params: params
  })
}

/**
 * 获取字典表数据
 */
export const getKeyValue = (params: GetDictionaryParams) => {
  return hynRequest.request<DictionaryListGetResultModel>({
    url: '/KeyValue/GetKeyValue',
    method: 'get',
    params: params
  })
}

/**
 * 通过字典分类名称获取KeyValue表
 */
export const getKeyValueByClassify = (params: { typeName: string }) => {
  return hynRequest.request<GetDictionaryModel[]>({
    url: '/KeyValue/GetKeyValueByClassify',
    method: 'get',
    params: params
  })
}

/**
 * 添加字典
 */
export const addKeyValue = (data: AddDictionaryData) => {
  return hynRequest.request<boolean>({
    url: '/KeyValue/AddKeyValue',
    method: 'post',
    data: data
  })
}

/**
 * 修改字典
 */
export const updateKeyValue = (data: UpdateDictionaryData) => {
  return hynRequest.request<boolean>({
    url: '/KeyValue/UpdateKeyValue',
    method: 'post',
    data: data
  })
}
/**
 * 删除字典
 */
export const deleteKeyValue = (data: DeleteDictionaryData) => {
  return hynRequest.request<boolean>({
    url: '/KeyValue/DeleteKeyValue',
    method: 'post',
    data: data
  })
}

/**
 * 获取字典类型
 */
export const getKeyValueClassify = (params: GetDictionaryClassifyParams) => {
  return hynRequest.request<DictionaryClassifyListGetResultModel>({
    url: '/KeyValueClassify/GetKeyValueClassify',
    method: 'get',
    params: params
  })
}

/**
 * 添加字典类型
 */
export const addKeyValueClassify = (data: AddDictionaryClassifyData) => {
  return hynRequest.request<boolean>({
    url: '/KeyValueClassify/AddKeyValueClassify',
    method: 'post',
    data: data
  })
}

/**
 * 删除字典类型
 */
export const deleteKeyValueClassify = (data: DeleteDictionaryClassifyData) => {
  return hynRequest.request<boolean>({
    url: '/KeyValueClassify/DeleteKeyValueClassify',
    method: 'post',
    data: data
  })
}

/**
 * 获取组别信息
 */
export const getGroup = (params: GetGroupParams) => {
  return hynRequest.request<GroupListGetResultModel>({
    url: '/Group/GetGroup',
    method: 'get',
    params: params
  })
}

/**
 * 根据部门ID获取全部组别信息
 */
export const getGroupSelect = (params: { departmentID: string }) => {
  return hynRequest.request<GroupSelectListGetResultModel>({
    url: '/Group/GetGroupSelect',
    method: 'get',
    params
  })
}

/**
 * 添加组别信息
 */
export const addGroup = (data: AddGroupData) => {
  return hynRequest.request<boolean>({
    url: '/Group/AddGroup',
    method: 'post',
    data: data
  })
}

/**
 * 修改组别信息
 */
export const updateGroup = (data: UpdateGroupData) => {
  return hynRequest.request<boolean>({
    url: '/Group/UpdateGroup',
    method: 'post',
    data: data
  })
}

/**
 * 刪除组别信息
 */
export const deleteGroup = (data: DeleteGroupData) => {
  return hynRequest.request<boolean>({
    url: '/Group/DeleteGroup',
    method: 'post',
    data: data
  })
}

/**
 * 获取部门信息
 */
export const getDepartment = (params?: GetDepartmentParams) => {
  return hynRequest.request<DepartmentListGetResultModel>({
    url: '/Department/GetDepartment',
    method: 'get',
    params: params
  })
}

/**
 * 查询制造中心下部门和组别
 */
export const getManufactureDepartment = (params?: { departmentName?: string }) => {
  return hynRequest.request<GroupListByDepartmentNameGetResultModel>({
    url: '/Department/GetManufactureDepartment',
    method: 'get',
    params: params
  })
}

/**
 * 查询制造中心下部门
 */
export const getManufactureDepartmentList = () => {
  return hynRequest.request<GroupListByDepartmentNameGetResultModel>({
    url: '/Department/GetManufactureDepartmentList',
    method: 'get'
  })
}

/**
 * 添加部门信息
 */
export const addDepartment = (data: AddDepartmentData) => {
  return hynRequest.request<boolean>({
    url: '/Department/AddDepartment',
    method: 'post',
    data: data
  })
}

/**
 * 修改部门信息
 */
export const updateDepartment = (data: UpdateDepartmentData) => {
  return hynRequest.request<boolean>({
    url: '/Department/UpdateDepartment',
    method: 'post',
    data: data
  })
}

/**
 * 刪除部门信息
 */
export const deleteDepartment = (data: DeleteDepartmentData) => {
  return hynRequest.request<boolean>({
    url: '/Department/DeleteDepartment',
    method: 'post',
    data: data
  })
}

/**
 * 导出部门信息
 */
export const exportDepartment = (params: GetDepartmentParams) => {
  return hynRequest.request<BlobPart>({
    url: '/Department/ExportDepartmentInfo',
    method: 'get',
    params,
    responseType: 'blob',
    isReturnNativeResponse: true
  })
}

/**
 * 获取生产线列表
 */
export const getProductionLine = (params: GetProductionLineParams) => {
  return hynRequest.request<ProductionLineListGetResultModel>({
    url: '/ProductionLine/GetProductionLine',
    method: 'get',
    params: params
  })
}
/**
 * 获取生产线列表无分页
 */
export const getProductionLineSelect = () => {
  return hynRequest.request<ProductionLineListGetResultModel>({
    url: '/ProductionLine/GetProductionLineSelect',
    method: 'get'
  })
}
/**
 * 获取生产班次信息
 */
export const getSchedule = (params?: GetScheduleParams) => {
  return hynRequest.request<ScheduleListGetResultModel>({
    url: '/Schedule/GetSchedule',
    method: 'get',
    params: params
  })
}
/**
 * 获取所有生产班次信息
 */
export const getScheduleSelectALL = () => {
  return hynRequest.request<ScheduleListGetResultModel>({
    url: '/Schedule/GetScheduleSelectALL',
    method: 'get'
  })
}

/**
 * 添加线体
 */
export const addProductionLine = (data: AddProductionLineData) => {
  return hynRequest.request<boolean>({
    url: '/ProductionLine/AddProductionLine',
    method: 'post',
    data: data
  })
}
/*
 * 添加生产班次信息
 */
export const addSchedule = (data: AddScheduleData) => {
  return hynRequest.request<boolean>({
    url: '/Schedule/AddSchedule',
    method: 'post',
    data: data
  })
}

/**
 * 修改线体
 */
export const updateProductionLine = (data: UpdateProductionLineData) => {
  return hynRequest.request<boolean>({
    url: '/ProductionLine/UpdateProductionLine',
    method: 'post',
    data: data
  })
}
/*
 * 修改生产班次信息
 */
export const updateSchedule = (data: UpdateScheduleData) => {
  return hynRequest.request<boolean>({
    url: '/Schedule/UpdateSchedule',
    method: 'post',
    data: data
  })
}

/**
 * 刪除生产班次信息
 */
export const deleteSchedule = (data: DeleteScheduleData) => {
  return hynRequest.request<boolean>({
    url: '/Schedule/DeleteSchedule',
    method: 'post',
    data: data
  })
}
/**
 * 删除线体
 */
export const deleteProductionLine = (data: DeleteProductionLineData) => {
  return hynRequest.request<boolean>({
    url: '/ProductionLine/DeleteProductionLine',
    method: 'post',
    data: data
  })
}

/**
 * 查询生产工序
 */
export const getProductionProcess = (params: GetProductionProcessParams) => {
  return hynRequest.request<ProductionProcessListGetResultModel>({
    url: '/ProductionProcess/GetProductionProcess',
    method: 'get',
    params: params
  })
}
/**
 * 查询生产工序子节点
 */
export const getProductionProcessChildren = (params: GetProductionProcessChildrenParams) => {
  return hynRequest.request<ProductionProcessListGetResultModel>({
    url: '/ProductionProcess/GetProductionProcessSubordinate',
    method: 'get',
    params: params
  })
}

/**
 * 获取生产计划项目信息
 */
export const getProductionProject = (params?: GetProductionProjectParams) => {
  return hynRequest.request<ProductionProjectListGetResultModel>({
    url: '/ProductionProject/GetProductionProject',
    method: 'get',
    params: params
  })
}

/**
 * 获取所有生产计划项目信息
 */
export const getProductionProjectSelect = (params?: { orderStatus?: number }) => {
  return hynRequest.request<ProductionProjectListGetResultModel>({
    url: '/ProductionProject/GetProductionProjectSelect',
    method: 'get',
    params
  })
}

/**
 * 查询生产顶级工序
 */
export const getProductionProcessTopLevel = (params?: { processID: string }) => {
  return hynRequest.request<ProductionProcessListGetResultModel>({
    url: '/ProductionProcess/GetProductionProcessTopLevel',
    method: 'get',
    params
  })
}

/**
 * 添加生产工序
 */
export const addProductionProcess = (data: AddProductionProcessData) => {
  return hynRequest.request<boolean>({
    url: '/ProductionProcess/AddProductionProcess',
    method: 'post',
    data: data
  })
}
/*
 * 添加生产计划项目信息
 */
export const addProductionProject = (data: AddProductionProjectData) => {
  return hynRequest.request<boolean>({
    url: '/ProductionProject/AddProductionProject',
    method: 'post',
    data: data
  })
}

/**
 * 修改生产工序
 */
export const updateProductionProcess = (data: UpdateProductionProcessData) => {
  return hynRequest.request<boolean>({
    url: '/ProductionProcess/UpdateProductionProcess',
    method: 'post',
    data: data
  })
}

/**
 * 修改生产计划项目信息
 */
export const updateProductionProject = (data: UpdateProductionProjectData) => {
  return hynRequest.request<boolean>({
    url: '/ProductionProject/UpdateProductionProject',
    method: 'post',
    data: data
  })
}

/**
 * 删除生产工序
 */
export const deleteProductionProcess = (data: DeleteProductionProcessData) => {
  return hynRequest.request<boolean>({
    url: '/ProductionProcess/DeleteProductionProcess',
    method: 'post',
    data: data
  })
}
/**
 * 刪除生产计划项目信息
 */
export const deleteProductionProject = (data: DeleteProductionProjectData) => {
  return hynRequest.request<boolean>({
    url: '/ProductionProject/DeleteProductionProject',
    method: 'post',
    data: data
  })
}

/**
 * 查询标准工时
 */
export const getStandardWorkTime = (params: GetStandardWorkTimeParams) => {
  return hynRequest.request<StandardWorkTimeListGetResultModel>({
    url: '/StandardWorkTime/GetStandardWorkTime',
    method: 'get',
    params
  })
}

/**
 * 添加标准工时
 */
export const addStandardWorkTime = (data: AddStandardWorkTimeData) => {
  return hynRequest.request<boolean>({
    url: '/StandardWorkTime/AddStandardWorkTime',
    method: 'post',
    data: data
  })
}
/**
 * 复制标准工时
 */
export const copyStandardWorkTime = (data: CopyStandardWorkTimeData) => {
  return hynRequest.request<boolean>({
    url: '/StandardWorkTime/AddStandardWorkTimeCopyData',
    method: 'post',
    data: data
  })
}

/**
 *修改标准工时
 */
export const updateStandardWorkTime = (data: UpdateStandardWorkTimeData) => {
  return hynRequest.request<boolean>({
    url: '/StandardWorkTime/UpdateStandardWorkTime',
    method: 'post',
    data: data
  })
}

/**
 *删除标准工时
 */
export const deleteStandardWorkTime = (data: DeleteStandardWorkTimeData) => {
  return hynRequest.request<boolean>({
    url: '/StandardWorkTime/DeleteStandardWorkTime',
    method: 'post',
    data: data
  })
}
/**
 *设置排除工单隐藏不显示
 */
export const addStandardWorkTimeWoExInclude = (data: AddStandardWorkTimeWoExIncludeData) => {
  return hynRequest.request<boolean>({
    url: '/StandardWorkTime/AddStandardWorkTimeWoExInclude',
    method: 'post',
    data: data
  })
}
/**
 *取消排除工单隐藏不显示
 */
export const deleteStandardWorkTimeWoExInclude = (data: DeleteStandardWorkTimeWoExIncludeData) => {
  return hynRequest.request<boolean>({
    url: '/StandardWorkTime/DeleteStandardWorkTimeWoExInclude',
    method: 'post',
    data: data
  })
}
/**
 * 导出标准工时
 */
export const exportStandardWorkTime = (params: GetStandardWorkTimeParams) => {
  return hynRequest.request<BlobPart>({
    url: '/StandardWorkTime/ExportStandardWorkTime',
    method: 'get',
    params,
    responseType: 'blob',
    isReturnNativeResponse: true
  })
}
/**
 * 导出标准工时模版
 */
export const exportTemplate = () => {
  return hynRequest.request<BlobPart>({
    url: '/StandardWorkTime/ExportTemplate',
    method: 'get',
    responseType: 'blob',
    isReturnNativeResponse: true
  })
}

/**
 * 获取所有生产节点列表
 */
export const getProductionNodeAll = () => {
  return hynRequest.request<GetProductionNodeModel[]>({
    url: '/ProductionNode/GetProductionNodeAll',
    method: 'get'
  })
}
/**
 * 获取生产节点列表
 */
export const getProductionNode = (params: GetProductionNodeParams) => {
  return hynRequest.request<ProductionNodeListGetResultModel>({
    url: '/ProductionNode/GetProductionNode',
    method: 'get',
    params: params
  })
}
/**
 * 添加生产节点列表
 */
export const addProductionNode = (data: AddProductionNodeData) => {
  return hynRequest.request<boolean>({
    url: '/ProductionNode/AddProductionNode',
    method: 'post',
    data: data
  })
}
/**
 * 修改生产节点列表
 */
export const updateProductionNode = (data: UpdateProductionNodeData) => {
  return hynRequest.request<boolean>({
    url: '/ProductionNode/UpdateProductionNode',
    method: 'post',
    data: data
  })
}
/**
 * 删除生产节点列表
 */
export const deleteProductionNode = (data: DeleteProductionNodeData) => {
  return hynRequest.request<boolean>({
    url: '/ProductionNode/DeleteProductionNode',
    method: 'post',
    data: data
  })
}
/**
 * 获取计划版本管理信息
 */
export const getProductionVersion = (params: GetProductionVersionParams) => {
  return hynRequest.request<ProductionVersionModelListGetResultModel>({
    url: '/ProductionVersion/GetProductionVersion',
    method: 'get',
    params: params
  })
}

/**
 * 确认版本
 */
export const updateProductionVersionStatus = (data: { id: string; orderStatus: number }) => {
  return hynRequest.request<boolean>({
    url: '/ProductionVersion/UpdateProductionVersionStatus',
    method: 'post',
    data: data
  })
}

/**
 * 获取所有计划版本管理信息
 */
export const getProductionVersionSelect = (params: GetProductionVersionSelectParams) => {
  return hynRequest.request<ProductionVersionModelListGetResultModel>({
    url: '/ProductionVersion/GetProductionVersionSelect',
    method: 'get',
    params: params
  })
}

/**
 * 查询项目当前版本号
 */
export const getProjectValidVersion = (params: GetProjectValidVersionParams) => {
  return hynRequest.request<GetProductionVersionModel>({
    url: '/ProductionProject/GetProjectValidVersion',
    method: 'get',
    params: params
  })
}

/**
 * 获取组别组长信息
 */
export const getGroupLeader = (params: GetGroupLeaderParams) => {
  return hynRequest.request<GroupLeaderListGetResultModel>({
    url: '/Group/GetGroupLeader',
    method: 'get',
    params: params
  })
}
/**
 * 导出生产工序
 */
export const exportProductionProcess = (params: GetDepartmentParams) => {
  return hynRequest.request<BlobPart>({
    url: '/ProductionProcess/ExportProductionProcess',
    method: 'get',
    params,
    responseType: 'blob',
    isReturnNativeResponse: true
  })
}

/**
 * 查询确认签字类型
 */
export const getConfirmSignatureType = (params: GetConfirmSignatureTypeParams) => {
  return hynRequest.request<ConfirmSignatureTypeListGetResultModel>({
    url: '/ConfirmSignatureType/GetConfirmSignatureType',
    method: 'get',
    params: params
  })
}
/**
 * 添加确认签字类型
 */
export const addConfirmSignatureType = (data: AddConfirmSignatureTypeData) => {
  return hynRequest.request<boolean>({
    url: '/ConfirmSignatureType/AddConfirmSignatureType',
    method: 'post',
    data: data
  })
}
/**
 * 修改确认签字类型
 */
export const updateConfirmSignatureType = (data: UpdateConfirmSignatureTypeData) => {
  return hynRequest.request<boolean>({
    url: '/ConfirmSignatureType/UpdateConfirmSignatureType',
    method: 'post',
    data: data
  })
}
/**
 * 删除确认签字类型
 */
export const deleteConfirmSignatureType = (data: { id: string }) => {
  return hynRequest.request<boolean>({
    url: '/ConfirmSignatureType/DeleteConfirmSignatureType',
    method: 'post',
    data: data
  })
}

/**
 * 查询员工-选择员工组件
 */
export const getEmployeeInfoBySelect = (params: GetEmployeeInfoBySelectParams) => {
  return hynRequest.request<EmployeeInfoBySelectListGetResultModel>({
    url: '/EmployeeInfo/GetEmployeeInfoBySelect',
    method: 'get',
    params
  })
}

/**
 * 获取岗位分类关系
 */
export const getPositionClassify = (params: GetPositionClassifyParams) => {
  return hynRequest.request<PositionClassifyListGetResultModel>({
    url: '/PositionClassify/GetPositionClassify',
    method: 'get',
    params: params
  })
}
/**
 * 添加岗位分类关系
 */
export const addPositionClassify = (data: AddPositionClassifyData) => {
  return hynRequest.request<boolean>({
    url: '/PositionClassify/AddPositionClassify',
    method: 'post',
    data: data
  })
}
/**
 * 修改岗位分类关系
 */
export const updatePositionClassify = (data: UpdatePositionClassifyData) => {
  return hynRequest.request<boolean>({
    url: '/PositionClassify/UpdatePositionClassify',
    method: 'post',
    data: data
  })
}
/**
 * 删除岗位分类关系
 */
export const deletePositionClassify = (data: { id: string }) => {
  return hynRequest.request<boolean>({
    url: '/PositionClassify/DeletePositionClassify',
    method: 'post',
    data: data
  })
}

/**
 * 查询制造中心下组别
 */
export const getManufactureGroupList = (params: { departmentID: string }) => {
  return hynRequest.request<ManufactureGroupListGetResultModel>({
    url: '/Group/GetManufactureGroupList',
    method: 'get',
    params
  })
}

/**
 * 查询用户操作日志
 */
export const getUserRequestLog = (params: GetUserRequestLogParams) => {
  return hynRequest.request<GetUserRequestLogData>({
    url: '/UserRequestLog/GetUserRequestLog',
    method: 'get',
    params
  })
}
/**
 * 导出用户操作日志
 */
export const exportUserRequestLog = (params: GetUserRequestLogParams) => {
  return hynRequest.request<BlobPart>({
    url: '/UserRequestLog/ExportUserRequestLog',
    method: 'get',
    params,
    responseType: 'blob',
    isReturnNativeResponse: true
  })
}

/**
 * 获取系统消息
 */
export const getMessage = (params: GetMessageParams) => {
  return hynRequest.request<MessageGetResultModel>({
    url: '/MessageRecord/GetMessage',
    method: 'get',
    params
  })
}

/**
 * 添加系统消息
 */
export const addMessage = (data: AddMessageData) => {
  return hynRequest.request<boolean>({
    url: '/MessageRecord/AddMessage',
    method: 'post',
    data
  })
}

/**
 * 修改消息已读状态
 */
export const updateMessageReadStatus = (data: UpdataMessageData) => {
  return hynRequest.request<boolean>({
    url: '/MessageRecord/UpdateMessageReadStatus',
    method: 'post',
    data
  })
}

/**
 * 获取通知管理
 */
export const getNoticeMngt = (params: GetNoticeMngtParams) => {
  return hynRequest.request<NoticeMngtGetResultModel>({
    url: '/NoticeMngt/GetNoticeMngt',
    method: 'get',
    params
  })
}

/**
 * 添加通知管理
 */
export const addNoticeMngt = (data: AddNoticeMngtData) => {
  return hynRequest.request<boolean>({
    url: '/NoticeMngt/AddNoticeMngt',
    method: 'post',
    data
  })
}

/**
 * 修改通知管理
 */
export const updateNoticeMngt = (data: UpdateNoticeMngtData) => {
  return hynRequest.request<boolean>({
    url: '/NoticeMngt/UpdateNoticeMngt',
    method: 'post',
    data
  })
}
/**
 * 删除通知管理
 */
export const deleteNoticeMngt = (data: DeleteNoticeMngtData) => {
  return hynRequest.request<boolean>({
    url: '/NoticeMngt/DeleteNoticeMngt',
    method: 'post',
    data
  })
}

/**
 * 获取消息通知类型
 */
export const getMessageNoticeType = () => {
  return hynRequest.request<MessageNoticeTypeGetResultModel>({
    url: '/NoticeMngt/GetMessageNoticeType',
    method: 'get'
  })
}

/**
 * 获取单据自动确认配置
 */
export const getOrderAutoConfirm = (params: GetOrderAutoConfirmParams) => {
  return hynRequest.request<OrderAutoConfirmListGetResultModel>({
    url: '/OrderAutoConfirm/GetOrderAutoConfirm',
    method: 'get',
    params: params
  })
}
/**
 * 添加确认签字类型
 */
export const addOrderAutoConfirm = (data: AddOrderAutoConfirmData) => {
  return hynRequest.request<boolean>({
    url: '/OrderAutoConfirm/AddOrderAutoConfirm',
    method: 'post',
    data: data
  })
}
/**
 * 修改确认签字类型
 */
export const updateOrderAutoConfirm = (data: UpdateOrderAutoConfirmData) => {
  return hynRequest.request<boolean>({
    url: '/OrderAutoConfirm/UpdateOrderAutoConfirm',
    method: 'post',
    data: data
  })
}
/**
 * 删除确认签字类型
 */
export const deleteOrderAutoConfirm = (data: { id: string }) => {
  return hynRequest.request<boolean>({
    url: '/OrderAutoConfirm/DeleteOrderAutoConfirm',
    method: 'post',
    data: data
  })
}
