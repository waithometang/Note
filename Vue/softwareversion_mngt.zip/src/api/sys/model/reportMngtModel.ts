import type { BasicPageParams, BasicFetchResult } from '@/api/model/baseModel'

export type GetSystemUsageParams = BasicPageParams & {
  /**
   * 开始时间
   */
  BegTime?: string
  /**
   * 结束时间
   */
  EndTime?: string
}

export interface GetAttendanceSystemUsageModel {
  /**
   * 部门已确认人数
   */
  departmentConfirmedNumber: number
  /**
   * 部门
   */
  departmentName: string
  /**
   * 部门已登记人数
   */
  departmentRegisteredNumber: number
  /**
   * 部门未确认人数
   */
  departmentUnConfirmedNumber: number
  /**
   * 部门未登记人数
   */
  departmentUnregisteredNumber: number
  /**
   * 班组已确认人数
   */
  groupConfirmedNumber: number
  /**
   * 班组长姓名
   */
  groupLeaderName: string
  /**
   * 班组
   */
  groupName: string
  /**
   * 班组已登记人数
   */
  groupRegisteredNumber: number
  /**
   * 班组未确认人数
   */
  groupUnConfirmedNumber: number
  /**
   * 班组未登记人数
   */
  groupUnregisteredNumber: number
  /**
   * 日期
   */
  time: string
}
export interface GetEmployeeTransferSystemUsageModel {
  /**
   * 部门已确认人数，部门已确认人数
   */
  departmentConfirmedNumber: number
  /**
   * 部门，部门
   */
  departmentName: string
  /**
   * 部门调出人数
   */
  departmentTransferCallNumber: number
  /**
   * 部门借调人数
   */
  departmentTransferNumber: number
  /**
   * 班组已确认人数，班组已确认人数
   */
  groupConfirmedNumber: number
  /**
   * 班组长姓名，班组长姓名
   */
  groupLeaderName: string
  /**
   * 班组，班组
   */
  groupName: string
  /**
   * 班组调出人数
   */
  groupTransferCallNumber: number
  /**
   * 班组已借调人数
   */
  groupTransferNumber: number
  /**
   * 日期，日期
   */
  time: string
}

export interface GetDispatchingGroupSystemUsageModel {
  /**
   * 部门派工数量
   */
  departmentDispatchingGroupNumber: number
  /**
   * 部门，部门
   */
  departmentName: string
  /**
   * 班组派工数量
   */
  groupDispatchingGroupNumber: number
  /**
   * 班组长姓名，班组长姓名
   */
  groupLeaderName: string
  /**
   * 班组，班组
   */
  groupName: string
  /**
   * 日期，日期
   */
  time: string
}

export interface GetDispatchingOtherSystemUsageModel {
  /**
   * 部门派工数量
   */
  departmentDispatchingGroupNumber: number
  /**
   * 部门，部门
   */
  departmentName: string
  /**
   * 班组派工数量
   */
  groupDispatchingGroupNumber: number
  /**
   * 班组长姓名，班组长姓名
   */
  groupLeaderName: string
  /**
   * 班组，班组
   */
  groupName: string
  /**
   * 日期，日期
   */
  time: string
}

export interface GetReportWorkSystemUsageModel {
  /**
   * 部门，部门
   */
  departmentName: string
  /**
   * 部门报工工时
   */
  departmentReportWorkHours: number | number
  /**
   * 班组长姓名，班组长姓名
   */
  groupLeaderName: string
  /**
   * 班组，班组
   */
  groupName: string
  /**
   * 班组报工工时
   */
  groupReportWorkHoursr: number | number
  /**
   * 日期，日期
   */
  time: string
}

export interface GetWorkErrorReportSystemUsageModel {
  /**
   * 部门，部门
   */
  departmentName: string
  /**
   * 部门报工工时
   */
  departmentExceptionRecordWorkHours: number
  /**
   * 班组长姓名，班组长姓名
   */
  groupLeaderName: string
  /**
   * 班组，班组
   */
  groupName: string
  /**
   * 班组报工工时
   */
  groupExceptionRecordWorkHours: number
  /**
   * 日期，日期
   */
  time: string
}

export interface GetReportWorkOtherSystemUsageModel {
  departmentReportWorkHours: number
  /**
   * 部门，部门
   */
  departmentName: string
  groupReportWorkHoursr: number
  /**
   * 班组长姓名，班组长姓名
   */
  groupLeaderName: string
  /**
   * 班组，班组
   */
  groupName: string
  /**
   * 日期，日期
   */
  time: string
}

export interface GetProductivitySystemUsageModel {
  /**
   * 部门，部门
   */
  departmentName: string
  /**
   * 部门绩效人数
   */
  departmentReportWorkHours: number
  /**
   * 班组长姓名，班组长姓名
   */
  groupLeaderName: string
  /**
   * 班组，班组
   */
  groupName: string
  /**
   * 班组绩效人数
   */
  groupReportWorkHoursr: number | number
  /**
   * 日期，日期
   */
  time: string
}

export type AttendanceSystemUsageGetResultModel = BasicFetchResult<GetAttendanceSystemUsageModel>

export type EmployeeTransferSystemUsageGetResultModel =
  BasicFetchResult<GetEmployeeTransferSystemUsageModel>

export type DispatchingGroupSystemUsageGetResultModel =
  BasicFetchResult<GetDispatchingGroupSystemUsageModel>

export type DispatchingOtherSystemUsageGetResultModel =
  BasicFetchResult<GetDispatchingOtherSystemUsageModel>

export type ReportWorkSystemUsageGetResultModel = BasicFetchResult<GetReportWorkSystemUsageModel>

export type ReportWorkOtherSystemUsageGetResultModel =
  BasicFetchResult<GetReportWorkOtherSystemUsageModel>

export type WorkErrorReportSystemUsageGetResultModel =
  BasicFetchResult<GetWorkErrorReportSystemUsageModel>

export type ProductivitySystemUsageGetResultModel =
  BasicFetchResult<GetProductivitySystemUsageModel>
