import type { BasicPageParams, BasicFetchResult } from '@/api/model/baseModel'

export type GetSoftwareProjectParams = {
  /**
   * 软件项目名称 ->模糊查询
   */
  projectName?: string
}
export type GetCurrentSoftwareVersionParams = {
  /**
   * 版本分支Name
   */
  branchesName?: string
  /**
   * 软件项目ID
   */
  projectID?: number
}

export type GetSoftwareVersionParams = BasicPageParams & {
  /**
   * 版本分支ID
   */
  branchesID?: number
  /**
   * 文件名
   */
  fileName?: string
  /**
   * 软件项目ID
   */
  projectID?: number
  /**
   * 版本号
   */
  versionsNo?: string
  /**
   * 版本状态
   */
  versionsStatus?: number
}

export type GetHistorySoftwareVersionParams = GetSoftwareVersionParams

export type GetSoftwareReportParams = {
  /**
   * 文件名
   */
  fileName?: string
  /**
   * 报告类型ID
   */
  reportTypeID?: string
  /**
   * 软件版本ID
   */
  versionID?: string
}

export type GetSoftwareProjectModel = {
  createTime?: string
  createUserID?: string
  dataDescribe?: null
  dataStatus?: number
  /**
   * ID
   */
  id?: string
  lastModifiedTime?: string
  lastModifiedUserID?: string
  /**
   * 项目名称
   */
  projectName?: string
}

export type AddSoftwareProjectData = {
  /**
   * 备注
   */
  dataDescribe: string
  /**
   * 项目名称
   */
  projectName: string
}

export type UpdateSoftwareProjectData = {
  id: string
  /**
   * 备注
   */
  dataDescribe: string
  /**
   * 项目名称
   */
  projectName: string
}

export type GetCurrentSoftwareVersionModel = {
  /**
   * 版本分支ID
   */
  branchesID?: string
  /**
   * 版本分支Name
   */
  branchesName?: string
  createTime?: string
  createUserID?: string
  createUserName?: string
  dataDescribe?: null
  dataStatus?: number
  /**
   * 文件名
   */
  fileName?: string
  /**
   * ID
   */
  id?: string
  lastModifiedTime?: string
  lastModifiedUserID?: string
  lastModifiedUserName?: string
  /**
   * 软件项目ID
   */
  projectID?: string
  /**
   * 软件项目Name
   */
  projectName?: null
  /**
   * 版本号
   */
  versionsNo?: string
  /**
   * 版本状态
   */
  versionsStatus?: number
  /**
   * 版本提交作者
   */
  versionSubmissionAuthor?: string
  /**
   * 版本更新记录
   */
  versionUpdateRecord?: string
}
export type AddSoftwareVersiontData = {
  /**
   * 版本分支ID
   */
  branchesID: number
  /**
   * 代码库路径
   */
  codeBasePath: string
  /**
   * 代码分支
   */
  codeBranch: string
  /**
   * 代码提交版本号
   */
  codeSubmissionVersion: string
  /**
   * 备注
   */
  dataDescribe: string
  /**
   * 文件名
   */
  fileName: string
  /**
   * 软件项目ID
   */
  projectID: number
  /**
   * 版本号
   */
  versionsNo: string
  /**
   * 版本状态
   */
  versionsStatus: number
  /**
   * 版本提交作者
   */
  versionSubmissionAuthor: string
  /**
   * 版本更新记录
   */
  versionUpdateRecord: string
}
export type UpdateSoftwareVersiontData = {
  id?: string
  dataDescribe?: string
  versionsStatus?: number
}

export type AddSoftwareReportData = {
  dataDescribe?: string
  versionID?: string
  reportTypeID?: string
  fileName?: string
}

export type GetSoftwareVersionModel = {
  downloadStatus?: boolean
  /**
   * 版本分支ID
   */
  branchesID: string
  /**
   * 版本分支Name
   */
  branchesName: string
  createTime: string
  createUserID: string
  /**
   * 创建人名称
   */
  createUserName: string
  dataDescribe: null
  dataStatus: number
  /**
   * 文件名
   */
  fileName: string
  /**
   * ID
   */
  id: string
  lastModifiedTime: string
  lastModifiedUserID: string
  /**
   * 最后修改人名称
   */
  lastModifiedUserName: string
  /**
   * 软件项目ID
   */
  projectID: string
  /**
   * 软件项目Name
   */
  projectName: null
  /**
   * 版本号
   */
  versionsNo: string
  /**
   * 版本状态
   */
  versionsStatus: number
  /**
   * 版本提交作者
   */
  versionSubmissionAuthor: string
  /**
   * 版本更新记录
   */
  versionUpdateRecord: string
}
export type GetSoftwareReportModel = {
  downloadStatus?: boolean
  /**
   * 版本分支ID
   */
  branchesID: string
  /**
   * 版本分支Name
   */
  branchesName: string
  createTime: string
  createUserID: string
  /**
   * 创建人名称
   */
  createUserName: string
  dataDescribe: null
  dataStatus: number
  /**
   * 文件名
   */
  fileName: string
  /**
   * ID
   */
  id: string
  lastModifiedTime: string
  lastModifiedUserID: string
  /**
   * 最后修改人名称
   */
  lastModifiedUserName: string
  /**
   * 软件项目ID
   */
  projectID: string
  /**
   * 软件项目Name
   */
  projectName: null
  /**
   * 版本号
   */
  versionsNo: string
  /**
   * 版本状态
   */
  versionsStatus: number
  /**
   * 版本提交作者
   */
  versionSubmissionAuthor: string
  /**
   * 版本更新记录
   */
  versionUpdateRecord: string
}

export type GetHistorySoftwareVersionModel = GetSoftwareVersionModel

export type SoftwareProjectGetResultModel = GetSoftwareProjectModel[]
export type CurrentSoftwareVersionGetResultModel = GetCurrentSoftwareVersionModel
export type SoftwareVersionGetResultModel = BasicFetchResult<GetSoftwareVersionModel>
export type HistorySoftwareVersionGetResultModel = BasicFetchResult<GetHistorySoftwareVersionModel>
export type SoftwareReportGetResultModel = GetSoftwareReportModel[]
