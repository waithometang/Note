import type { BasicPageParams, BasicFetchResult } from '@/api/model/baseModel'

export type GetInputStoreParams = BasicPageParams & {
  /**
   * 单据类型
   */
  BillType?: string
  /**
   * 结束收货日期
   */
  EndInputTime?: string
  /**
   * 材料名称
   */
  MaterialName?: string
  /**
   * 料号/订单号
   */
  MaterialNoOrOrderNo?: string
  /**
   * 开始收货日期
   */
  StartInputTime?: string
  /**
   * 库位
   */
  Storage?: string
  /**
   * 存储地点
   */
  StoreAddr?: string
}

export interface GetInputStoreModel {
  /**
   * 单据类型
   */
  billType: string
  /**
   * 品牌
   */
  brand: string
  /**
   * 备注
   */
  comments: string
  /**
   * ID
   */
  id: string
  /**
   * 实到数量
   */
  inputCounts: number
  /**
   * 收货日期
   */
  inputTime: string
  /**
   * 收货类型（数字）
   */
  inputType: number
  /**
   * 收货类型(名称)
   */
  inputTypeName: string
  /**
   * 批号
   */
  lotNo: string
  /**
   * 材料名称
   */
  materialName: string
  /**
   * 料号
   */
  materialNo: string
  /**
   * 业务员名称
   */
  operatorName: string
  /**
   * 订单号
   */
  orderNo: string
  /**
   * 收货单号
   */
  receiptNo: string
  /**
   * 规格
   */
  spec: string
  /**
   * 库位
   */
  storage: string
  /**
   * 存储地点
   */
  storeAddr: string
  /**
   * 供应商名称
   */
  supplierName: string
  /**
   * 物料单位名称
   */
  unit: string
}

export type GetOutputStoreParams = BasicPageParams & {
  /**
   * 单据类型
   */
  BillType?: string
  /**
   * 结束出库日期
   */
  EndOutTime?: string
  /**
   * 材料名称
   */
  MaterialName?: string
  /**
   * 料号/订单号
   */
  MaterialNoOrOrderNo?: string
  /**
   * 开始出库日期
   */
  StartOutTime?: string
  /**
   * 库位
   */
  Storage?: string
  /**
   * 存储地点
   */
  StoreAddr?: string
}

export interface GetOutputStoreModel {
  /**
   * 单据类型
   */
  billType: string
  /**
   * 品牌
   */
  brand: string
  /**
   * 备注
   */
  comments: string
  /**
   * ID
   */
  id: string
  /**
   * 批号
   */
  lotNo: string
  /**
   * 材料名称
   */
  materialName: string
  /**
   * 料号
   */
  materialNo: string
  /**
   * 业务员名称
   */
  operatorName: string
  /**
   * 订单号
   */
  orderNo: string
  /**
   * 出库单号
   */
  outBillNo: string
  /**
   * 发货类型(数字)
   */
  outputType: number
  /**
   * 发货类型(名称)
   */
  outputTypeName: string
  /**
   * 出库日期
   */
  outTime: string
  /**
   * 产品编码
   */
  productCode: string
  /**
   * 投产数量
   */
  productionCounts: number
  /**
   * 产品名称
   */
  productName: string
  /**
   * 生产订号
   */
  productOrderNo: string
  /**
   * 实发数量
   */
  realOutCounts: number
  /**
   * 应发数量
   */
  shouldOutCounts: number
  /**
   * 规格
   */
  spec: string
  /**
   * 库位
   */
  storage: string
  /**
   * 存储地点
   */
  storeAddr: string
  /**
   * 供应商名称
   */
  supplierName: string
  /**
   * 单位
   */
  unit: string
}

export type GetInventoryParams = BasicPageParams & {
  /**
   * 结束收货日期
   */
  EndInputTime?: string
  /**
   * 材料名称
   */
  MaterialName?: string
  /**
   * 料号
   */
  MaterialNo?: string
  /**
   * 开始收货日期
   */
  StartInputTime?: string
  /**
   * 库位
   */
  Storage?: string
  /**
   * 存储地点
   */
  StoreAddr?: string
}

export interface GetInventoryModel {
  /**
   * 厂牌
   */
  brand: string
  /**
   * 备注
   */
  comments: string
  /**
   * 现存量
   */
  currentCounts: number
  /**
   * 库存可用量
   */
  enableUseCounts: number
  /**
   * ID
   */
  id: string
  /**
   * 收货日期
   */
  inputTime: string
  /**
   * 批号
   */
  lotNo: string
  /**
   * 料品名称
   */
  materialName: string
  /**
   * 料号
   */
  materialNo: string
  /**
   * 物品分类名称
   */
  materialTypeName: string
  /**
   * 规格
   */
  spec: string
  /**
   * 库位
   */
  storage: string
  /**
   * 存储地点
   */
  storeAddr: string
  /**
   * 存储类型
   */
  storeType: string
  /**
   * 物料单位名称
   */
  unit: string
}

export type InputStoreGetResultModel = BasicFetchResult<GetInputStoreModel>
export type OutputStoreGetResultModel = BasicFetchResult<GetOutputStoreModel>
export type InventoryGetResultModel = BasicFetchResult<GetInventoryModel>
