import type { BasicPageParams, BasicFetchResult } from '@/api/model/baseModel'
export type GetKanBanInfoParams = BasicPageParams & {
  /**
   * 厂区位置
   */
  searchKey?: string
}

export interface GetKanBanInfoModel {
  createTime: string
  createUserID: string
  dataDescribe: string
  dataStatus: number
  /**
   * 启用状态
   */
  orderStatus: number
  /**
   * 主键ID
   */
  id: string
  /**
   * 看板类型（1：人员结构看板；2：项目生产进度，3：员工绩效统计）
   */
  kanBanType: number
  /**
   * 最新连接时间
   */
  lastConnetionTime: string
  /**
   * 最后更新时间
   */
  lastModifiedTime: string
  lastModifiedUserID: string
  /**
   * 最后操作人
   */
  lastModifiedUserName: string
  /**
   * 最大在线时长
   */
  maxOnlineDuration: string
  /**
   * SSO菜单名称
   */
  menuName: string
  /**
   * SSO菜单标题
   */
  menuTitle: string
  /**
   * 在线用户
   */
  onlineUserCount: number
  /**
   * 播放顺序
   */
  playOrder: number
  /**
   * 播放时间(秒)
   */
  playTime: number
  /**
   * 数据切换间隔(秒)
   */
  refreshTime: number
  /**
   * 图片链接
   */
  imageUrl?: string[]
}

export interface AddKanBanInfoData {
  dataDescribe: string
  /**
   * 看板类型（1：人员结构看板；2：项目生产进度，3：员工绩效统计）
   */
  kanBanType: number
  /**
   * SSO菜单名称
   */
  menuName: string
  /**
   * SSO菜单标题
   */
  menuTitle: string
  /**
   * 播放顺序
   */
  playOrder: number
  /**
   * 播放时间(秒)
   */
  playTime: number
  /**
   * 数据切换间隔(秒)
   */
  refreshTime: number
  /**
   * 启用状态
   */
  orderStatus: number
  /**
   * 图片链接
   */
  imageUrl?: string[]
}

export interface UpdateKanBanInfoData {
  dataDescribe: string
  /**
   * 主键ID
   */
  id: string
  /**
   * 播放顺序
   */
  playOrder: number
  /**
   * 播放时间(秒)
   */
  playTime: number
  /**
   * 数据切换间隔(秒)
   */
  refreshTime: number
  /**
   * 启用状态
   */
  orderStatus: number
  /**
   * 图片链接
   */
  imageUrl?: string[]
}

export interface DeleteKanBanInfoData {
  /**
   * 看板主键ID
   */
  id: string
}
export interface ImportCustomImageModel {
  fileType: string
  regionName: string
  fileName: string
  fileSize: string
  fileExt: string
  create_by: string
  create_time: string
  storeType: number
  accessUrl: string
}

export type KanBanInfoListGetResultModel = BasicFetchResult<GetKanBanInfoModel>
export type KanBanInfoByNameListGetResultModel = GetKanBanInfoModel[]
export type CustomImageImportResultModel = ImportCustomImageModel[]
