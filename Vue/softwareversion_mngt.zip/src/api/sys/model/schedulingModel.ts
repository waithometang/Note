import type { BasicPageParams, BasicFetchResult } from '@/api/model/baseModel'

export type GetProductionOrderByProjectIDParams = {
  /**
   * 项目ID
   */
  ProjectID: string
}

export interface GetProductionOrderByProjectIDModel {
  createTime: string
  createUserId: string
  dataDescribe: null
  dataStatus: number
  /**
   * 主键ID
   */
  id: string
  lastModifiedTime: string
  lastModifiedUserId: string
  lastModifiedUserName: null
  /**
   * 订单号
   */
  orderNo: string
  /**
   * 设备台数
   */
  orderNumber: number
  /**
   * 设备状态（1：启用；2：停用）
   */
  orderStatus: number
  /**
   * 设备名称
   */
  productName: string
  /**
   * 项目ID
   */
  projectId: string
  /**
   * 项目名称
   */
  projectName: string
}

export type GetProductionOrderParams = BasicPageParams & {
  /**
   * 项目ID
   */
  ProjectID: string
  /**
   * 设备名称搜索关键字
   */
  SearchKey?: string
}

export interface GetProductionOrderModel {
  /**
   * 创建时间
   */
  createTime: string
  /**
   * 创建人ID
   */
  createUserID: string
  dataDescribe: null
  /**
   * 数据状态 1正常 2删除
   */
  dataStatus: number
  /**
   * 项目ID
   */
  id: string
  /**
   * 最后修改时间
   */
  lastModifiedTime: string
  /**
   * 最后修改人ID
   */
  lastModifiedUserID: string
  /**
   * 操作人
   */
  lastModifiedUserName: string
  /**
   * 需求分类
   */
  orderNo: string
  /**
   * 设备台数
   */
  orderNumber: number
  /**
   * 设备状态（1：启用；2：停用）
   */
  orderStatus: number
  /**
   * 设备名称
   */
  productName: string
  /**
   * 项目ID
   */
  projectID: string
  /**
   * 项目名称
   */
  projectName: string
}
export interface AddProductionOrderData {
  /**
   * 需求分类
   */
  orderNo: string
  /**
   * 设备台数
   */
  orderNumber: number
  /**
   * 设备状态（1：启用；2：停用）
   */
  orderStatus: number
  /**
   * 设备类型ID
   */
  parentProcessId: string
  /**
   * 设备名称
   */
  productName: string
  /**
   * 项目ID
   */
  projectId: string
}
export interface UpdateProductionOrderData {
  /**
   * 主键ID
   */
  id: string
  /**
   * 需求分类
   */
  orderNo: string
  /**
   * 设备台数
   */
  orderNumber: number
  /**
   * 设备状态（1：启用；2：停用）
   */
  orderStatus: number
  /**
   * 设备类型ID
   */
  parentProcessId: string
  /**
   * 设备名称
   */
  productName: string
  /**
   * 项目ID
   */
  projectId: string
}

export interface GetProductionProjectAppointDataModel {
  /**
   * 部门ID
   */
  departmentID: string
  /**
   * 料品形态属性
   */
  itemFormAttribute: string
  /**
   * 料号
   */
  materialNo: string
  /**
   * 需求分类
   */
  orderNo: string
  /**
   * 设备名称
   */
  orderProductName: string
  /**
   * 设备类型ID，顶级工序
   */
  processID: string
  /**
   * 设备类型名称
   */
  processName: string
  /**
   * 部件名称
   */
  productName: string
  /**
   * 单据编号
   */
  woNo: string
  /**
   * 订单数量
   */
  productionOrderNumber: number
}

export interface GetProjectAndProductNameModel {
  /**
   * 项目下设备个数
   */
  childrenCount: number
  /**
   * 项目ID
   */
  id: string
  /**
   * 是否项目
   */
  isProject: boolean
  /**
   * 项目名称
   */
  name: string
  /**
   * 设备列表
   */
  productList: {
    /**
     * 订单设备表主键ID
     */
    id: string
    /**
     * 是否项目
     */
    isProject: boolean
    /**
     * 设备名称
     */
    name: string
    /**
     * 需求分类
     */
    orderNo: string
    /**
     * 项目ID
     */
    projectID: string
  }[]
}

export interface GetProductionWoAndProductModel {
  /**
   * 需求分类列表
   */
  orderList: { name: string; value: string }[]
  /**
   * 部件名称列表
   */
  productNameList: { name: string; value: string }[]
  /**
   * 单据编号列表
   */
  woList: { name: string; value: string }[]
}

export type ProductionProjectAppointDataGetResultModel =
  BasicFetchResult<GetProductionProjectAppointDataModel>
export type ProjectAndProductNameListGetResultModel =
  BasicFetchResult<GetProjectAndProductNameModel>
export type ProductionOrderListGetResultModel = BasicFetchResult<GetProductionOrderModel>
export type ProductionOrderListByProjectIDGetResultModel =
  BasicFetchResult<GetProductionOrderByProjectIDModel>
export type ProductionWoAndProductGetResultModel = GetProductionWoAndProductModel
