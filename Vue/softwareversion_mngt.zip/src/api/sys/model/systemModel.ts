import type { BasicPageParams, BasicFetchResult } from '@/api/model/baseModel'

export interface ISystemInfo {
  /**
   * CPU使用率
   */
  cpuUsedRate: string
  /**
   * 磁盘信息
   */
  diskInfoDTOs: IDiskInfoDTO[]
  /**
   * 可用内存
   */
  memoryAvailable: string
  /**
   * 已使用内存
   */
  memoryUsed: string
  /**
   * 内存使用率
   */
  memoryUsedRate: string
  /**
   * 总内存
   */
  physicalMemory: string
}

export interface IDiskInfoDTO {
  /**
   * 磁盘名
   */
  diskName: string
  /**
   * 可用空间
   */
  freeSpace: string
  /**
   * 磁盘总容量
   */
  totalSpace: string
  /**
   * 已用空间
   */
  usedSpace: string
}

export type GetUserInfoSSOData = BasicPageParams & {
  loginAccount: string

  userName?: string
}

export interface GetUserInfoSSOModel {
  id: string
  roleNames: string
  userName: string
  userLoginWays: object
  dataStatus: number
  dataDescribe: string
  createUserID: string
  createTime: string
  applicationNames: string
  activateStatus: number
  accountNumber: string
  lastModifiedTime: string
  lastModifiedUserID: string
}

export interface UpdateLoginPasswordData {
  id: string
  dataDescribe: string
  loginPassword: string
}

export type GetUserInfoSSOResultModel = BasicFetchResult<GetUserInfoSSOModel>