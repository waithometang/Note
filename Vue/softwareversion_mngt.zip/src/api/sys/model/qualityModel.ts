import type { BasicPageParams, BasicFetchResult } from '@/api/model/baseModel'

export type GetIPQCParams = BasicPageParams & {
  /**
   * 生产场地ID
   */
  ProductionAddressID?: string
  /**
   * 设备名称
   */
  ProductName?: string
  /**
   * 项目ID
   */
  ProjectID?: string
  /**
   * 结果确认（0：未确认，1：OK，2：NG）
   */
  ResultConfirm?: string
  /**
   * 单据编号
   */
  WoNo?: string
}

export type GetExceptionTypeParams = BasicPageParams & {
  ExceptionTypeID?: string
  /**
   * 异常类型名称
   */
  ExceptionTypeName?: string
}

export type GetExceptionByTypeIDParams = BasicPageParams & {
  exceptionTypeID?: string
}

export interface GetIPQCModel {
  productCheckItem: string
  /**
   * 检验员ID
   */
  checkEmployeeID: string
  /**
   * 检验员姓名
   */
  checkEmployeeName: string
  /**
   * 检验数
   */
  checkNum: number
  createTime: string
  createUserID: string
  dataDescribe: string
  /**
   * 备注
   */
  dataStatus: number
  /**
   * 组别ID
   */
  groupID: string
  /**
   * 组别名称
   */
  groupName: string
  /**
   * ID
   */
  id: string
  /**
   * ipqc拆分数据
   */
  ipqcSplitData: IpqcSplitData
  lastModifiedTime: string
  lastModifiedUserID: string
  /**
   * 设备检测项目
   */
  productCheckName: string
  /**
   * 订单数量
   */
  productionOrderNum: number
  /**
   * 部件名称
   */
  productName: string
  /**
   * 项目ID
   */
  projectID: string
  /**
   * 项目名称
   */
  projectName: null
  /**
   * 不合格数
   */
  rejectNum: number
  /**
   * 不良率
   */
  rejectRate: number
  /**
   * 判定结果（-1:不合格，1：合格）
   */
  result: number
  /**
   * 状态（1：延迟，2：进行，3：关闭，4：持续）
   */
  resultConfirm: number
  /**
   * 状态Name（1：延迟，2：进行，3：关闭，4：持续）
   */
  resultConfirmName: string
  /**
   * 检验结果时间
   */
  resultDate: string
  /**
   * 判定结果Name（-1:不合格，1：合格）
   */
  resultName: number
  /**
   * 单据编号
   */
  woNo: string
}

export interface IpqcSplitData {
  /**
   * 实际完成时间
   */
  actualCompletionTime: string
  /**
   * IPQC检验方式ID（KeyValue）
   */
  checkMethodID: string
  /**
   * IPQC检验方式Name（KeyValue）
   */
  checkMethodName: string
  /**
   * 责任部门ID
   */
  dutyDepartmentID: string
  /**
   * 责任部门名称
   */
  dutyDepartmentName: string
  /**
   * 责任人姓名
   */
  dutyEmployeeName: string
  /**
   * 效果确认人
   */
  effectConfirmEmployeeName: string
  /**
   * 效果照片
   */
  effectImagePath: string[] | { url: string }[]
  /**
   * 责任归类ID，字典表
   */
  exceptionClassifyID: string
  /**
   * 责任归类Name，字典表
   */
  exceptionClassifyName: string
  /**
   * 异常描述
   */
  exceptionDescription: string
  /**
   * 异常类型ID
   */
  exceptionTypeID: string
  /**
   * 异常类型Name
   */
  exceptionTypeName: string
  /**
   * 问题类别ID，字典表
   */
  ipqcProblemCategoryID: string
  /**
   * 问题类别Name，字典表
   */
  ipqcProblemCategoryName: string
  /**
   * 问题发生阶段ID，字典表
   */
  ipqcProblemStageID: string
  /**
   * 问题发生阶段Name，字典表
   */
  ipqcProblemStageName: string
  /**
   * 料品形态属性
   */
  itemFormAttribute: string
  /**
   * 长期解决方案
   */
  longTermSolution: string
  /**
   * 异常物料号
   */
  materialNo: string
  /**
   * 预计完成时间
   */
  plannedCompletionTime: string
  /**
   * 图示
   */
  problemImagePath: string[] | { url: string }[]
  /**
   * 检验区域ID
   */
  productionAddressID: string
  /**
   * 检验区域Name
   */
  productionAddressName: string
  /**
   * 原因分析
   */
  reasonAnalyze: string
  /**
   * 严重度（低：1，中：2，高：3）
   */
  severity: number
  /**
   * 严重度（低：1，中：2，高：3）
   */
  severityName: string
  /**
   * 工时损耗
   */
  takeTime: string
  /**
   * 临时解决方案
   */
  temporarySolution: string
}

export interface ADDIPQCData {
  /**
   * 实际完成时间
   */
  actualCompletionTime: string
  /**
   * 检验员ID
   */
  checkEmployeeID: string
  /**
   * IPQC检验方式ID（KeyValue）
   */
  checkMethodID: string
  /**
   * 检验数
   */
  checkNum: number
  dataDescribe: string
  /**
   * 责任部门ID
   */
  dutyDepartmentID: string
  /**
   * 责任人姓名
   */
  dutyEmployeeName: string
  /**
   * 效果确认人
   */
  effectConfirmEmployeeName: string
  /**
   * 效果照片
   */
  effectImagePath: string[] | { url: string }[]
  /**
   * 责任归类ID，字典表
   */
  exceptionClassifyID: string
  /**
   * 异常描述
   */
  exceptionDescription: string
  /**
   * 异常类型ID
   */
  exceptionTypeID: string
  /**
   * 组别ID
   */
  groupID: string
  /**
   * 问题类别ID，字典表
   */
  ipqcProblemCategoryID: string
  /**
   * 问题发生阶段ID，字典表
   */
  ipqcProblemStageID: string
  /**
   * 料品形态属性
   */
  itemFormAttribute?: string
  /**
   * 长期解决方案
   */
  longTermSolution: string
  /**
   * 异常物料号
   */
  materialNo?: string
  /**
   * 预计完成时间
   */
  plannedCompletionTime: string
  /**
   * 图示
   */
  problemImagePath: string[] | { url: string }[]
  /**
   * 设备检测项目
   */
  productCheckName: string
  /**
   * 检验区域ID
   */
  productionAddressID: string
  /**
   * 订单数量
   */
  productionOrderNum: number
  /**
   * 部件名称
   */
  productName: string
  /**
   * 项目ID
   */
  projectID: string
  /**
   * 原因分析
   */
  reasonAnalyze: string
  /**
   * 不合格数
   */
  rejectNum: number
  /**
   * 不良率
   */
  rejectRate: number
  /**
   * 判定结果（-1:不合格，1：合格）
   */
  result: number
  /**
   * 状态（1：延迟，2：进行，3：关闭，4：持续）
   */
  resultConfirm: number
  /**
   * 检验结果时间
   */
  resultDate: string
  /**
   * 严重度（低：1，中：2，高：3）
   */
  severity: number
  /**
   * 工时损耗
   */
  takeTime: number
  /**
   * 临时解决方案
   */
  temporarySolution: string
  /**
   * 单据编号
   */
  woNo: string
}

export interface UpdateIPQCData {
  /**
   * 实际完成时间
   */
  actualCompletionTime: string
  /**
   * 检验员ID
   */
  checkEmployeeID: string
  /**
   * IPQC检验方式ID（KeyValue）
   */
  checkMethodID: string
  /**
   * 检验数
   */
  checkNum: number
  /**
   * 备注
   */
  dataDescribe: string
  /**
   * 责任部门ID
   */
  dutyDepartmentID: string
  /**
   * 责任人姓名
   */
  dutyEmployeeName: string
  /**
   * 效果确认人
   */
  effectConfirmEmployeeName: string
  /**
   * 效果照片
   */
  effectImagePath: string[] | { url: string }[]
  /**
   * 责任归类ID，字典表
   */
  exceptionClassifyID: string
  /**
   * 异常描述
   */
  exceptionDescription: string
  /**
   * 异常类型ID
   */
  exceptionTypeID: string
  /**
   * 组别ID
   */
  groupID: string
  /**
   * ID
   */
  id: string
  /**
   * 问题类别ID，字典表
   */
  ipqcProblemCategoryID: string
  /**
   * 问题发生阶段ID，字典表
   */
  ipqcProblemStageID: string
  /**
   * 长期解决方案
   */
  longTermSolution: string
  /**
   * 预计完成时间
   */
  plannedCompletionTime: string
  /**
   * 图示
   */
  problemImagePath: string[] | { url: string }[]
  /**
   * 检验区域ID
   */
  productionAddressID: string
  /**
   * 原因分析
   */
  reasonAnalyze: string
  /**
   * 不合格数
   */
  rejectNum: number
  /**
   * 不良率
   */
  rejectRate: number
  /**
   * 判定结果（-1:不合格，1：合格）
   */
  result: number
  /**
   * 状态（1：延迟，2：进行，3：关闭，4：持续）
   */
  resultConfirm: number
  /**
   * 检验结果时间
   */
  resultDate: string
  /**
   * 严重度（低：1，中：2，高：3）
   */
  severity: number
  /**
   * 工时损耗
   */
  takeTime: number
  /**
   * 临时解决方案
   */
  temporarySolution: string
}

export interface DeleteIPQCData {
  id: string
}

export interface GetExceptionTypeModel {
  createTime?: string
  createUserID?: string
  dataDescribe?: null
  dataStatus?: number
  /**
   * 异常类型
   */
  exceptionTypeName?: string
  /**
   * 异常ID
   */
  id: string
  exceptionName: string
  lastModifiedTime?: string
  lastModifiedUserID?: string
}

export interface AddExceptionTypeData {
  /**
   * 异常项
   */
  exceptionName: string
  /**
   * 异常类型ID
   */
  exceptionTypeID: string
}

export interface UpdateExceptionTypeData {
  /**
   * 异常类型
   */
  exceptionName: string
  /**
   * ID
   */
  id: string
}

export interface DeleteExceptionTypeData {
  /**
   * ID
   */
  id: string
}

export interface GetExceptionByTypeIDModel {
  /**
   * 异常类型ID
   */
  id: string
  /**
   * 异常类型名称
   */
  name: string
}

export type IPQCListGetResultModel = BasicFetchResult<GetIPQCModel>
export type ExceptionTypeListGetResultModel = BasicFetchResult<GetExceptionTypeModel>
export type ExceptionByTypeIDListGetResultModel = GetExceptionByTypeIDModel[]
