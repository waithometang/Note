import type { BasicPageParams, BasicFetchResult } from '@/api/model/baseModel'

export type GetWorkOrderParams = BasicPageParams & {
  /**
   * 部门ID
   */
  departmentId?: string
  /**
   * 班组ID
   */
  groupId?: string
  /**
   * 筛选工单进度是否完成，ture：已完成，false：未完成
   */
  isFinishOrderSchedule?: boolean
  /**
   * 是否只显示未派工单
   */
  isShowNotDispatching?: boolean
  /**
   * 订单号，选中设备名称时必传
   */
  orderNo?: string
  /**
   * 工单状态（0：未开始；1：执行中；2：已完工，3：已关闭，4：已取消），多选
   */
  orderStatus?: string[]
  /**
   * 设备类型ID
   */
  processId?: string
  /**
   * 生产场地ID集合
   */
  productionAddressId?: string[]
  /**
   * 部件名称
   */
  productName?: string
  /**
   * 项目ID
   */
  projectId?: string
  /**
   * 计划版本号主键ID
   */
  versionId?: string
  /**
   * 工单号
   */
  woNo?: string
}

export type GetProductionPlanByWoParams = BasicPageParams & {
  /**
   * ID
   */
  woID?: string
}

export type GetDispatchingGroupParams = BasicPageParams & {
  /**
   * 车间派工单状态（0：未报工；1：已报工；2：已完工)，默认不传
   */
  OrderStatus?: number
  /**
   * 输入工序任务或班组名称查询
   */
  SearchKey?: string
  /**
   * 单据编号
   */
  WoNo: string
}

export type GetWorkDispatchingWoParams = BasicPageParams & {
  orderNo?: string
  /**
   * 部门ID
   */
  DepartmentID?: string
  /**
   * 工单状态（0：未开始；1：执行中；2：已完工，3：已关闭，4：已取消，5：全部），默认传5或不传
   */
  orderStatus?: number[]
  /**
   * 设备类型ID
   */
  ProcessID?: string
  /**
   * 生产场地ID集合
   */
  ProductionAddressID?: string[]
  /**
   * 设备名称
   */
  ProductName?: string
  /**
   * 项目ID
   */
  projectID: string
  /**
   * 单据编号
   */
  woNo?: string
  /**
   * 是否只显示未派工单
   */
  isShowNotDispatching?: boolean
  /**
   * 筛选工单进度是否完成，ture：已完成，false：未完成
   */
  isFinishOrderSchedule?: boolean
}

export interface ExportProductionWoParams {
  /**
   * 部门ID
   */
  departmentId?: string
  /**
   * 班组ID
   */
  groupId?: string
  /**
   * 是否只显示未派工单
   */
  isShowNotDispatching?: string
  /**
   * 工单状态（0：未开始；1：执行中；2：已完工，3：已关闭，4：已取消），多选
   */
  orderStatus?: string[]
  /**
   * 设备类型ID
   */
  processId?: string
  /**
   * 生产场地ID集合
   */
  productionAddressId?: string[]
  /**
   * 产品名称
   */
  productName?: string
  /**
   * 项目ID
   */
  projectId?: string
  /**
   * 计划版本号主键ID
   */
  versionId?: string
  /**
   * 工单号
   */
  woNo?: string
}

export type GetReportWorkParams = BasicPageParams & {
  /**
   * 车间派工单ID
   */
  dispatchingGroupId: string
  /**
   * 日期
   */
  reportWorkTime: string
  /**
   * 只显示未确认报工 （true：是；false：否)
   */
  isConfirmStatus: boolean
}
export type GetReportWorkProjectDetailParams = {
  /**
   * 车间派工单ID
   */
  dispatchingGroupID: string
  /**
   * 员工ID，当工作类别为1,2,3时才调用该接口
   */
  employeeInfoID: string
}

export type GetAttendanceParams = BasicPageParams & {
  /**
   * 考勤日期
   */
  AttendanceDate?: string
  /**
   * 考勤状态（1：出勤；2：迟到；3：早退；4：缺勤；5：出差；6：旷工）
   */
  AttendanceStatus?: number
  /**
   * 员工工号/名称
   */
  EmployeeInfoNoAndName?: string
  /**
   * 组别ID
   */
  GroupID?: string
  /**
   * 单据状态（1：未确认；2：已确认)
   */
  OrderStatus?: number
  /**
   * 工种，多选
   */
  PositionClassifyID?: string[]
}

export type GetReportWorkDetailParams = {
  /**
   * 组内派工单ID
   */
  dispatchingEmployeeID: string
  /**
   * 员工ID，当工作类别为1,2,3时才调用该接口
   */
  employeeInfoID: string
  /**
   * 报工单ID，当编辑行时必填，新增记录时不填
   */
  reportWorkID?: string
}

export type GetProductionWoByWoNoParams = {
  /**
   * 单据编号
   */
  WoNo: string
}
export type GetExceptionRecordParams = BasicPageParams & {
  /**
   * 部门ID
   */
  departmentId?: string
  /**
   * 异常类型ID
   */
  exceptionTypeId?: string
  /**
   * 结束时间
   */
  execptionEndTime?: string
  /**
   * 开始时间
   */
  execptionStartTime?: string
  /**
   * 班组ID
   */
  groupId?: string
  /**
   * 需求分类
   */
  orderNo?: string
  /**
   * 异常处理状态（0：未处理；1：处理中；2：已处理；3：全部） 默认传3或不传
   */
  processingState?: number[]
  /**
   * 项目ID
   */
  projectId?: string
  /**
   * 单据编号/需求分类/母件编码
   */
  searchKey?: string
  /**
   * 工单号
   */
  woNo?: string
}

export type GetDispatchingGroupWoParams = BasicPageParams & {
  /**
   * 部门ID，为空时需要传班组ID
   */
  DepartmentID: string
  /**
   * 计划日期结束
   */
  EndDate?: string
  /**
   * 班组ID，为空时需要传部门ID
   */
  GroupID: string
  /**
   * 派工单状态（0：未报工；1：已报工；2：已完工)，默认不传
   */
  OrderStatus?: number[]
  /**
   * 设备类型ID
   */
  ProcessID?: string
  /**
   * 工序任务ID
   */
  SonProcessID?: string
  /**
   * 计划日期开始
   */
  StartDate?: string
  /**
   * 单据编号
   */
  woNo?: string
  /**
   * 是否只显示未派工单
   */
  IsShowNotDispatching?: boolean
}

export type GetDispatchingEmployeeParams = BasicPageParams & {
  /**
   * 车间派工ID
   */
  DispatchingGroupID: string
  /**
   * 派工单状态（0：未报工；1：已报工；2：已完工)，默认不传
   */
  OrderStatus?: number
  /**
   * 使用员工工号或姓名模糊查询
   */
  SearchKey?: string
}

export type GetEmployeeTransferParams = BasicPageParams & {
  /**
   * 工种，多选
   */
  PositionClassifyID?: string[]
  /**
   * 工号/姓名
   */
  EmployeeInfoNoAndName?: string
  /**
   * 单据状态（0：未确认；1：借调中；2：已结束；3：已作废）
   */
  OrderStatus?: number[]
  /**
   * 借调开始时间
   */
  TransferBeginTime?: string
  /**
   * 借调部门ID
   */
  TransferDepartmentID?: string
  /**
   * 借调结束时间
   */
  TransferEndTime?: string
  /**
   * 借调组别ID
   */
  TransferGroupID?: string
  /**
   * 借调班组长ID
   */
  TransferLeaderID?: string
  /**
   * 原部门ID
   */
  DepartmentID?: string
  /**
   * 原组别ID
   */
  GroupID?: string
  /**
   * 借调人员ID
   */
  EmployeeInfoID?: string
}

export type GetHonorRollParams = BasicPageParams & {
  /**
   * 员工名称关键字
   */
  searchKey?: string
}

export interface GetHonorRollModel {
  createTime: string
  createUserID: string
  /**
   * 事迹
   */
  dataDescribe: string
  dataStatus: number
  /**
   * 部门ID
   */
  departmentID: string
  /**
   * 部门名称
   */
  departmentName: string
  /**
   * 员工ID
   */
  employeeID: string
  /**
   * 员工名称
   */
  employeeName: string
  /**
   * 类型(1：荣誉榜；2：提升榜)
   */
  honorType: number
  /**
   * 类型名称
   */
  honorTypeName: string
  /**
   * 主键ID
   */
  id: string
  /**
   * 事迹图片URL
   */
  imageUrl: string
  lastModifiedTime: string
  lastModifiedUserID: string
  /**
   * 操作人
   */
  lastModifiedUserName: string
  /**
   * 状态（1：启用；2：停用）
   */
  orderStatus: number
}

export type GetProductionPerformanceParams = BasicPageParams & {
  /**
   * 工种，多选
   */
  PositionClassifyID?: string[]
  /**
   * 开始考核日期
   */
  assessmentBeginTime?: string
  /**
   * 结束考核日期
   */
  assessmentEndTime?: string
  /**
   * 考核日期
   */
  assessmentTime?: string
  /**
   * 部门ID
   */
  departmentId?: string
  /**
   * 员工ID
   */
  employeeId?: string
  /**
   * 班组ID
   */
  groupId?: string
  /**
   * 只显示出勤员工
   */
  isAttendanceDuty?: string
  /**
   * 只显示未评绩效
   */
  isShowNotAssessment?: string
  /**
   * 绩效等级，多选
   */
  performanceLevel?: string[]
  /**
   * 搜索关键字
   */
  searchKey?: string
}

export interface GetProductionPerformanceModel {
  /**
   * 考核时间
   */
  assessmentTime?: string
  /**
   * 考核人ID
   */
  assessorID?: string
  /**
   * 考核人
   */
  assessorName?: string
  /**
   * 考勤状态（1：出勤；2：请假；3：休息；4：离职；5：支援；6：缺勤；7：出差；8：旷工）
   */
  attendanceStatus?: number
  /**
   * 被考核人ID
   */
  beAssessorID?: string
  /**
   * 被考核人姓名
   */
  beAssessorName?: string
  createTime?: string
  createUserID?: string
  dataDescribe?: null
  dataStatus?: number
  /**
   * 部门ID
   */
  departmentID?: string
  /**
   * 部门名称
   */
  departmentName?: string
  /**
   * 组别ID
   */
  groupID?: string
  /**
   * 班组名称
   */
  groupName?: string
  /**
   * 主键ID
   */
  id: string
  lastModifiedTime?: string
  lastModifiedUserID?: string
  /**
   * 绩效等级
   */
  performanceLevel?: string
  /**
   * 绩效分数
   */
  performanceMark?: number
  /**
   * 岗位ID
   */
  positionID?: string
  /**
   * 岗位
   */
  positionName?: string
  [property: string]: any
}

export type GetProductionPerformanceByEmployeeParams = {
  /**
   * 考核日期
   */
  assessmentTime: string
  /**
   * 员工ID
   */
  employeeID: string
}

export interface GetProductionPerformanceByEmployeeModel {
  /**
   * 考核时间
   */
  assessmentTime: null | string
  /**
   * 考核人ID
   */
  assessorID: null | string
  /**
   * 考核人
   */
  assessorName: string
  /**
   * 考勤状态（0：未登记；1：出勤；2：请假；3：休息；4：离职；5：支援；6：缺勤；7：出差；8：旷工）
   */
  attendanceStatus: number | null
  /**
   * 被考核人ID
   */
  beAssessorID: string
  /**
   * 被考核人姓名
   */
  beAssessorName: string
  /**
   * 被考核人工号
   */
  beAssessorNo: string
  createTime: string
  createUserID: string
  dataDescribe?: string
  dataStatus: number
  /**
   * 部门ID
   */
  departmentID: string
  /**
   * 部门名称
   */
  departmentName: string
  /**
   * 组别ID
   */
  groupID: string
  /**
   * 班组长
   */
  groupLeaderName: string
  /**
   * 班组名称
   */
  groupName: string
  /**
   * 主键ID
   */
  id: string
  lastModifiedTime: string
  lastModifiedUserID: string
  /**
   * 操作人
   */
  lastModifiedUserName: string
  /**
   * 绩效等级
   */
  performanceLevel: string
  /**
   * 绩效分数
   */
  performanceMark: number | null
  /**
   * 岗位ID
   */
  positionID: string
  /**
   * 岗位
   */
  positionName: string
}

export type GetDispatchingSearchParams = BasicPageParams & {
  /**
   * 工种，多选
   */
  PositionClassifyID?: string[]
  /**
   * 部门ID
   */
  DepartmentID?: number
  /**
   * 员工ID
   */
  EmployeeID?: number
  /**
   * 结束计划日期
   */
  EndDate?: string
  /**
   * 班组ID
   */
  GroupID?: number
  /**
   * 需求分类
   */
  OrderNo?: string
  /**
   * 状态（0：未报工；1：报工中；2：已完成)
   */
  OrderStatus?: number[]
  /**
   * 设备类型ID
   */
  ProcessID?: number
  /**
   * 部件名称
   */
  ProductName?: string
  /**
   * 项目ID
   */
  ProjectID?: number
  /**
   * 单据编号或需求分类号
   */
  SearchKey?: string
  /**
   * 工序任务ID
   */
  SonProcessID?: number
  /**
   * 开始计划日期
   */
  StartDate?: string
  /**
   * 单据编号
   */
  WoNo?: string
}

export interface GetDispatchingSearchModel {
  /**
   * 工作描述
   */
  workDescription: string
  /**
   * 部门名称
   */
  departmentName: string
  /**
   * 派工数量
   */
  dispatchingNumber: number
  /**
   * 作业者姓名
   */
  employeeName: string
  /**
   * 作业者工号
   */
  employeeNo: string
  /**
   * 班组
   */
  groupName: string
  /**
   * 班组长
   */
  leaderName: string
  /**
   * 需求分类
   */
  orderNo: string
  /**
   * 状态（0：未报工；1：报工中；2：已完成)
   */
  orderStatus: number
  /**
   * 设备类型
   */
  processName: string
  /**
   * 部件名称
   */
  productName: string
  /**
   * 项目名称
   */
  projectName: string
  /**
   * 工序任务
   */
  sonProcessName: string
  /**
   * 计划日期
   */
  startDate: string
  /**
   * 借调状态(0：""；1：借调中)
   */
  transferInStatus: number
  /**
   * 工单号
   */
  woNo: string
}

export type GetReportWorkSearchParams = BasicPageParams & {
  dispatchingName?: string
  /**
   * 工种，多选
   */
  PositionClassifyID?: string[]
  /**
   * 部门ID
   */
  DepartmentID?: number
  /**
   * 员工ID
   */
  EmployeeID?: number
  /**
   * 结束报工日期
   */
  EndReportWorkTime?: string
  /**
   * 班组ID
   */
  GroupID?: number
  /**
   * 需求分类
   */
  OrderNo?: string
  /**
   * 状态（0：未报工；1：未确认；2：已确认；3：已作废）
   */
  OrderStatus?: number
  /**
   * 设备类型ID
   */
  ProcessID?: number
  /**
   * 部件名称
   */
  ProductName?: string
  /**
   * 项目ID
   */
  ProjectID?: number
  /**
   * 单据编号或需求分类号
   */
  SearchKey?: string
  /**
   * 工序任务ID
   */
  SonProcessID?: number
  /**
   * 开始报工日期
   */
  StartReportWorkTime?: string
  /**
   * 单据编号
   */
  WoNo?: string
  /**
   * 工作类别(1：正常工时，2：设计变更，3：来料不良，4：培训，5：6S，6：其他)
   */
  WorkType?: number
}

export interface GetReportWorkSearchModel {
  /**
   * 工作描述
   */
  workDescription: string
  /**
   * 录入人
   */
  createUserName: string
  /**
   * 部门名称
   */
  departmentName: string
  /**
   * 派工数量
   */
  dispatchingNumber: number
  /**
   * 作业者姓名
   */
  employeeName: string
  /**
   * 作业者工号
   */
  employeeNo: string
  /**
   * 完成数量
   */
  finishCount: number
  /**
   * 报工完成率
   */
  finishPercent: number
  /**
   * 班组
   */
  groupName: string
  /**
   * 月份
   */
  month: number
  /**
   * 需求分类
   */
  orderNo: string
  /**
   * 状态（0：未报工；1：未确认；2：已确认；3：已作废）
   */
  orderStatus: number
  /**
   * 设备类型
   */
  processName: string
  /**
   * 部件名称
   */
  productName: string
  /**
   * 项目名称
   */
  projectName: string
  /**
   * 报工日期
   */
  reportWorkTime: string
  /**
   * 工序任务
   */
  sonProcessName: string
  /**
   * 工序完成率
   */
  sumFinishPercent: number
  /**
   * 用时(h)
   */
  takeTime: number
  /**
   * 借调状态(0：""；1：借调中)
   */
  transferInStatus: number
  /**
   * 周别
   */
  week: number
  /**
   * 工单号
   */
  woNo: string
  /**
   * 工作类别(1：正常工时，2：设计变更，3：来料不良，4：培训，5：6S，6：其他)
   */
  workTypeName: string
  /**
   * 当天完成率
   */
  finishPercentName: string
}

export type GetDispatchingOtherParams = BasicPageParams & {
  /**
   * 工种，多选
   */
  PositionClassifyID?: string[]
  /**
   * 部门ID
   */
  departmentID?: string
  /**
   * 派工结束日期
   */
  endDate?: string
  /**
   * 班组ID
   */
  groupID?: string
  /**
   * 派工单状态（0：未报工；1：已报工；2：已完工)，默认0,1
   */
  orderStatusArray?: string[]
  /**
   * 查询员工工号或姓名
   */
  searchKey?: string
  /**
   * 派工开始日期
   */
  startDate?: string
  /**
   * 工作描述
   */
  workDescription?: string
  /**
   * 工作类别(4：培训，5：6S，6：其他)
   */
  workType?: number
  /**
   * 只显示未确认报工 （true：是；false：否)
   */
  isConfirmStatus?: boolean
}

export interface GetDispatchingOtherModel {
  /**
   * 创建时间
   */
  createTime: string
  /**
   * 创建用户ID
   */
  createUserID: string
  dataDescribe: null
  /**
   * 数据状态，当为2代表已经删除，1代表存在
   */
  dataStatus: number
  /**
   * 部门ID
   */
  departmentID: string
  /**
   * 部门名称
   */
  departmentName: string
  /**
   * 已派数量
   */
  dispatchingNumber: number
  /**
   * 作业者ID
   */
  employeeInfoID: string
  /**
   * 作业者姓名
   */
  employeeName: string
  /**
   * 作业者工号
   */
  employeeNo: string
  /**
   * 班组ID
   */
  groupID: string
  /**
   * 班组
   */
  groupName: string
  /**
   * 派工单ID
   */
  id: string
  /**
   * 最后修改时间
   */
  lastModifiedTime: string
  /**
   * 最后修改用户ID
   */
  lastModifiedUserID: string
  /**
   * 班组长ID
   */
  leaderID: string
  /**
   * 班组长名称
   */
  leaderName: string
  /**
   * 派工单状态（0：未报工；1：报工中；2：已完工)
   */
  orderStatus: number
  /**
   * 状态名称
   */
  orderStatusName: string
  /**
   * 计划日期
   */
  startDate: string
  /**
   * 报工日期
   */
  reportDate: string
  /**
   * 总报工数量
   */
  sumFinishCount: number
  /**
   * 总用时
   */
  takeTime: string
  /**
   * 工作描述
   */
  workDescription: string
  /**
   * 工作类别
   */
  workType: number
  /**
   * 工作类别名称
   */
  workTypeName: string
}

export interface GetProductionWoByOrderNoParams {
  /**
   * 需求分类，选中设备名称时必传
   */
  orderNo?: string
  /**
   * 项目ID
   */
  projectID: string
}

export interface GetProductionWoByOrderNoModel {
  /**
   * 需求分类列表
   */
  orderList: OrderList[]
  /**
   * 部件名称列表
   */
  productNameList: ProductNameList[]
  /**
   * 单据编号列表
   */
  woList: WoList[]
}

export interface OrderList {
  name: string
  value: string
}

export interface ProductNameList {
  name: string
  value: string
}

export interface WoList {
  name: string
  value: string
}

export interface GetProductionWoListByStartStatusParams {
  /**
   * 需求分类，选中设备名称时必传
   */
  orderNo?: string
  /**
   * 部件名称
   */
  productName?: string
  /**
   * 项目ID
   */
  projectID: string
  /**
   * 单据编号
   */
  woNo?: string
  /**
   * 工单状态
   */
  orderStatus?: number
}

export type GetOtherReportWorkDetailParams = {
  /**
   * 其他派工单ID
   */
  dispatchingID: string
  /**
   * 报工单ID，当编辑行时必填，新增记录时不填
   */
  reportWorkID?: string
}

export interface GetOtherReportWorkDetailModel {
  /**
   * 派工数量
   */
  dispatchingNumber: number
  /**
   * 最大可填数量
   */
  maxFinishCount: number
  /**
   * 累计完成数量
   */
  sumFinishCount: number
  /**
   * 累计用时
   */
  sumTakeTime: number
}

export interface AddProductionWoData {
  /**
   * 部门ID
   */
  departmentID?: string
  /**
   * 执行PMC 员工ID
   */
  employeeID?: string
  /**
   * 是否新版本保存，true：是；false：否
   */
  isEdit?: boolean
  /**
   * 需求分类
   */
  orderNo?: string
  /**
   * 单据状态（0：未开始；1：执行中；2：已完工，3：已关闭）
   */
  orderStatus?: number
  /**
   * 优先级
   */
  priorityLevel?: number
  /**
   * 设备类型ID
   */
  processID?: string
  /**
   * 生产场地
   */
  productionAddressID?: string
  /**
   * 生产节点集合
   */
  productionPlans?: ProductionPlan[]
  /**
   * 设备名称
   */
  productName?: string
  /**
   * 工单数量(机箱数量、库位数量、机架数量和线材数量)
   */
  productNumberJson?: ProductNumberJson
  /**
   * 项目ID
   */
  projectID?: string
  /**
   * 单据编号
   */
  woNo?: string
  /**
   * 业务类型的名称
   */
  moDocType?: string
}

export interface ProductionPlan {
  /**
   * 物料状态说明
   */
  materialState?: string
  /**
   * 计划日期
   */
  planFinishDate: string
  /**
   * 生产节点ID
   */
  productionNodeID: string
  /**
   * 节点状态（0：待排；1：备料中；2：调试中，3：待上线，4：暂停，5：已完成），对应字典表Key
   */
  productionState: number
  /**
   * 排序号
   */
  sortNo: number
}

/**
 * 工单数量(机箱数量、库位数量、机架数量和线材数量)
 */
export interface ProductNumberJson {
  /**
   * 机箱数量
   */
  chassisNumber: string
  /**
   * 机架数量
   */
  frameNumber: string
  /**
   * 库位数量
   */
  locationNumber: string
  /**
   * 订单数量
   */
  productionOrderNumber: number
  /**
   * 线材数量
   */
  wireNumber: string
  /**
   * PCBA数量
   */
  pcbaNumber: string
}

export interface UpdateProductionWoData {
  /**
   * BOM表主键ID，暂填0
   */
  bomid?: string
  /**
   * 机箱数量
   */
  chassisNumber?: string
  /**
   * 描述
   */
  dataDescribe?: string | null
  /**
   * 部门ID
   */
  departmentID?: string
  /**
   * PMC员工ID
   */
  employeeID?: string
  /**
   * 机架数量
   */
  frameNumber?: string
  /**
   * 工单主键ID
   */
  id: string
  /**
   * 库位数量
   */
  locationNumber?: string
  /**
   * 工单状态（0：未开始；1：执行中；2：已完工，3：已关闭，4：已取消）
   */
  orderStatus?: number
  /**
   * 优先级
   */
  priorityLevel?: number
  /**
   * 生产场地ID
   */
  productionAddressID?: string
  /**
   * 订单数量
   */
  productionOrderNumber?: number
  /**
   * 生产计划数组
   */
  productionPlans: ProductionPlan[]
  /**
   * 工单数量(机箱数量、库位数量、机架数量和线材数量)
   */
  productNumberJson?: ProductNumberJson
  /**
  /**
   * 部件名称
   */
  productName?: string
}

export interface UpdateProductionWoStateData {
  /**
   * 工单ID
   */
  id: string
  /**
   * 操作状态（1：开工；2：完工，3：关单，4：取消）
   */
  orderStatus: number
}

export type GetDispatchingOrderParams = BasicPageParams & {
  /**
   * 工种，多选
   */
  PositionClassifyID?: string[]
  /**
   * 只显示未确认报工 （true：是；false：否)
   */
  isConfirmStatus?: boolean
  /**
   * 部门ID
   */
  departmentID?: string
  /**
   * 组别ID
   */
  groupID?: string
  /**
   * 需求分类
   */
  orderNo?: string
  /**
   * 派工单状态（0：未报工；1：报工中；2：已完工)
   */
  orderStatus?: number[]
  /**
   * 部件名称
   */
  productName?: string
  /**
   * 项目ID
   */
  projectID?: string
  /**
   * 单据编号
   */
  woNo?: string
}

export interface GetDispatchingOrderModel {
  /**
   * 创建时间
   */
  createTime: string
  /**
   * 创建用户ID
   */
  createUserId: string
  dataDescribe: null | string
  /**
   * 数据状态，当为2代表已经删除，1代表存在
   */
  dataStatus: number
  /**
   * 部门ID
   */
  departmentId: string
  /**
   * 部门名称
   */
  departmentName: string
  /**
   * 车间派工数量
   */
  dispatchingNumber: number
  /**
   * 完成率
   */
  finishPercent: number
  /**
   * 组别ID
   */
  groupId: string
  /**
   * 班组名称
   */
  groupName: string
  /**
   * 车间派工单ID
   */
  id: string
  /**
   * 最后修改时间
   */
  lastModifiedTime: string
  /**
   * 最后修改用户ID
   */
  lastModifiedUserId: string
  /**
   * 班组长ID
   */
  leaderId: string
  /**
   * 班组长姓名
   */
  leaderName: string
  /**
   * 需求分类
   */
  orderNo: string
  /**
   * 派工单状态（0：未报工；1：报工中；2：已完工)
   */
  orderStatus: number
  /**
   * 工序任务ID
   */
  processId: string
  /**
   * 工序任务名称
   */
  processName: string
  /**
   * 部件名称
   */
  productName: string
  /**
   * 项目ID
   */
  projectId: string
  /**
   * 项目名称
   */
  projectName: string
  /**
   * 工序任务ID
   */
  sonProcessId: string
  /**
   * 工序任务名称
   */
  sonProcessName: string
  /**
   * 计划日期
   */
  startDate: string
  /**
   * 完成数量
   */
  sumFinishCount: number
  /**
   * 累计用时
   */
  sumTakeTime: number
  /**
   * 单据编号
   */
  woNo: string
}
export interface GetReportWorkEmployeeModel {
  /**
   * 员工姓名
   */
  employeeName: string
  /**
   * 员工工号
   */
  employeeNo: string
  /**
   * 员工ID
   */
  id: string
  [property: string]: any
}

export type GetOtherReportWorkParams = BasicPageParams & {
  /**
   * 其他派工单ID
   */
  dispatchingID?: string
  /**
   * 只显示未确认报工 （true：是；false：否)
   */
  isConfirmStatus?: boolean
  /**
   * 日期
   */
  reportWorkTime: string
}

export interface GetOtherReportWorkModel {
  /**
   * 考勤状态（1：出勤；2：请假；3：休息；4：离职；5：支援；6：缺勤；7：出差；8：旷工）
   */
  attendanceStatus: number
  /**
   * 考勤状态名称
   */
  attendanceStatusName?: string
  createTime?: string
  createUserId?: string
  /**
   * 录入人
   */
  createUserName?: string
  dataStatus?: number
  /**
   * 派工数量
   */
  dispatchingNumber?: number
  /**
   * 员工id
   */
  employeeInfoID?: string
  /**
   * 员工姓名
   */
  employeeName?: string
  /**
   * 员工工号
   */
  employeeNo?: string
  /**
   * 时间终点(H:M)
   */
  endTime?: string
  /**
   * 报工数量
   */
  finishCount?: number
  /**
   * 班组ID
   */
  groupId?: string
  /**
   * 主键ID
   */
  id?: string
  lastModifiedTime?: string
  lastModifiedUserId?: string
  /**
   * 月份
   */
  month?: number
  /**
   * 报工单状态（0：未报工；1：未确认；2：已确认；3：已作废）
   */
  orderStatus: number
  /**
   * 报工日期
   */
  reportWorkTime?: string
  /**
   * 休息时长（H）
   */
  restTime?: number
  /**
   * 班次ID
   */
  scheduleID?: string
  /**
   * 班次类型(1：正常班次，2：其他班次)
   */
  scheduleType?: number
  /**
   * 班次类型名称
   */
  scheduleTypeName?: string
  /**
   * 时间起点(H:M)
   */
  startTime?: string
  /**
   * 用时（H）
   */
  takeTime?: number
  /**
   * 借调状态(0："无借调"；1：借调)
   */
  transferInStatus?: number
  /**
   * 借调状态名称
   */
  transferInStatusName?: string
  /**
   * 周别
   */
  week?: number
  /**
   * 备注
   */
  workDescription?: string
  /**
   * 工作类别(4：培训，5：6S，6：其他)
   */
  workType?: number
  /**
   * 自定义作业班次临时绑定字段
   */
  workTime?: string | string[]
}
export interface GetEmployeeStatusModel {
  transferInStatus: number
  transferInStatusName: string
  attendanceStatus: number
  attendanceStatusName: string
}
export interface GetOtherReportWorkEmployeeStatusParams {
  /**
   * 员工ID
   */
  employeeInfoID: string
  /**
   * 报工日期
   */
  reportWorkTime: string
}

export interface GetWorkOrderModel {
  /**
   * BOM的ID
   */
  bomid: string
  /**
   * 机箱数量
   */
  chassisNumber: string
  /**
   * 创建时间
   */
  createTime: string
  /**
   * 创建用户ID
   */
  createUserID: string
  /**
   * 备注
   */
  dataDescribe?: null | string
  /**
   * 数据状态，当为2代表已经删除，1代表存在
   */
  dataStatus: number
  /**
   * 部门ID
   */
  departmentID: string
  /**
   * 部门名称
   */
  departmentName: string
  /**
   * PMC 员工ID
   */
  employeeID: string
  /**
   * PMC 姓名
   */
  employeeName: string
  /**
   * PMC 工号
   */
  employeeNo: string
  /**
   * 机架数量
   */
  frameNumber: string
  /**
   * 主键ID
   */
  id: string
  /**
   * 最后修改时间
   */
  lastModifiedTime: string
  /**
   * 最后修改用户ID
   */
  lastModifiedUserID: string
  /**
   * 库位数量
   */
  locationNumber: string
  /**
   * 订单号
   */
  orderNo: string
  /**
   * 设备名称
   */
  orderProductName: string
  /**
   * 工单进度
   */
  orderSchedule: number
  /**
   * 工单状态（0：未开始；1：执行中；2：已完工，3：已关闭，4：已取消）
   */
  orderStatus: number
  /**
   * PCBA数量
   */
  pcbaNumber: string
  /**
   * 优先级
   */
  priorityLevel: number
  /**
   * 设备类型ID
   */
  processID: string
  /**
   * 设备类型名称
   */
  processType: string
  /**
   * 生产场地ID
   */
  productionAddressID: string
  /**
   * 生产场地
   */
  productionAddressName: string
  /**
   * 当前完成节点
   */
  productionNodeName: string
  /**
   * 订单数量
   */
  productionOrderNumber: number
  /**
   * 部件名称
   */
  productName: string
  /**
   * 工单数量集合
   */
  productNumberJson: ProductNumberJson
  /**
   * 项目名称
   */
  projectName: string
  /**
   * 版本编码
   */
  versionNo: string
  /**
   * 线束数量
   */
  wireNumber: string
  /**
   * 工单号
   */
  woNo: string
  /**
   * 母件编码
   */
  materialNo: string
  /**
   * 业务类型的名称
   */
  moDocType: string
}

export interface GetProductionPlanByWoModel {
  /**
   * 创建时间
   */
  createTime?: string
  /**
   * 创建用户ID
   */
  createUserID?: string
  /**
   * 备注
   */
  dataDescribe?: null
  /**
   * 数据状态，当为2代表已经删除，1代表存在
   */
  dataStatus?: number
  /**
   * 部门名称
   */
  departmentName?: string
  /**
   * 主键ID
   */
  id?: string
  /**
   * 最后修改时间
   */
  lastModifiedTime?: string
  /**
   * 最后修改用户ID
   */
  lastModifiedUserID?: string
  /**
   * 物料状态
   */
  materialState?: string
  /**
   * 生产场地
   */
  productionAddressName?: string
  /**
   * 节点ID
   */
  productionNodeID?: string
  /**
   * 节点名称
   */
  productionNodeName?: string
  /**
   * 节点状态（0：待排；1：备料中；2：调试中，3：待上线，4：暂停，5：已完成）
   */
  productionState: number
}

export interface GetReportWorkModel {
  /**
   * 借调状态
   */
  transferInStatusName: string
  /**
   * 是否新增行
   */
  isAdd: boolean
  /**
   * 自定义作业班次临时绑定字段
   */
  workTime?: string | string[]
  /**
   * 考勤状态（2：请假；3：休息；4：离职；6：缺勤；7：出差；8：旷工）
   */
  attendanceStatus: number
  /**
   * 创建时间
   */
  createTime: string
  /**
   * 创建用户ID
   */
  createUserId: string
  /**
   * 录入人
   */
  createUserName: string
  /**
   * 描述
   */
  dataDescribe: null | string
  /**
   * 数据状态，当为2代表已经删除，1代表存在
   */
  dataStatus: number
  /**
   * 部门名称
   */
  departmentName: string
  /**
   * 组内派工单ID
   */
  dispatchingEmployeeID: string
  /**
   * 组内派工单信息
   */
  dispatchingEmployeeInfo: string
  /**
   * 派工数量
   */
  dispatchingNumber: number
  /**
   * 作业者ID
   */
  employeeInfoID: string
  /**
   * 作业者姓名
   */
  employeeName: string
  /**
   * 作业者工号
   */
  employeeNo: string
  /**
   * 结束时间，如18:00
   */
  endTime: string
  /**
   * 设备类型名称
   */
  fatherProcessName: string
  /**
   * 报工数量
   */
  finishCount: number
  /**
   * 完成率
   */
  finishPercent: number
  /**
   * 组别ID
   */
  groupId: string
  /**
   * 班组长姓名
   */
  groupLeaderName: string
  /**
   * 班组名称
   */
  groupName: string
  /**
   * 报工单ID
   */
  id: string
  /**
   * 最后修改时间
   */
  lastModifiedTime: string
  /**
   * 最后修改用户ID
   */
  lastModifiedUserId: string
  /**
   * 月份
   */
  month: number
  /**
   * 需求分类
   */
  orderNo: string
  /**
   * 报工单状态（0：未报工；1：未确认；2：已确认；4：无需报工）
   */
  orderStatus: number
  /**
   * 岗位名称
   */
  positionName: string
  /**
   * 工序任务ID
   */
  processId: string
  /**
   * 工序任务名称
   */
  processName: string
  /**
   * 产品名称
   */
  productName: string
  /**
   * 项目ID
   */
  projectId: string
  /**
   * 项目名称
   */
  projectName: string
  /**
   * 报工计算方式(1:按工时 2:按数量)
   */
  reportFinishType: number
  /**
   * 报工日期
   */
  reportWorkTime: string
  /**
   * 休息用时(h)
   */
  restTime: number
  /**
   * 班次ID，为null时 则是自定义时间
   */
  scheduleID?: null | string
  /**
   * 标准工时
   */
  standardWorkHour: number
  /**
   * 开始时间，如08:00
   */
  startTime: string
  /**
   * 用时(h)
   */
  takeTime?: number
  /**
   * 借调状态(0：否；1：是)，当考勤为出勤且为借调时显示
   */
  transferInStatus: number
  /**
   * 周别
   */
  week: number
  /**
   * 单据编号
   */
  woNo: string
  /**
   * 工作类别(1：正常工时，2：设计变更，3：来料不良，4：培训，5：6S，6：其他)
   */
  workType: number
  /**
   * 班次类型（1：正常班次；2：其他班次）
   */
  scheduleType: number
  /**
   * 母件编码
   */
  materialNo: string
}

export interface GetDispatchingGroupModel {
  /**
   * 创建时间
   */
  createTime: string
  /**
   * 创建用户ID
   */
  createUserID: string
  /**
   * 录入人
   */
  createUserName: string
  dataDescribe: null | string
  /**
   * 数据状态，当为2代表已经删除，1代表存在
   */
  dataStatus: number
  /**
   * 部门ID
   */
  departmentID: string
  /**
   * 部门名称
   */
  departmentName: string
  /**
   * 派工数量
   */
  dispatchingNumber: number
  /**
   * 班组ID
   */
  groupID: string
  /**
   * 班组名称
   */
  groupName: string
  /**
   * 车间派工单ID
   */
  id: string
  /**
   * 最后修改时间
   */
  lastModifiedTime: string
  /**
   * 最后修改用户ID
   */
  lastModifiedUserID: string
  /**
   * 班组长
   */
  leaderName: string
  /**
   * 车间派工单状态（0：未报工；1：报工中；2：已完工)
   */
  orderStatus: number
  /**
   * 生产场地
   */
  productionAddressName: string
  /**
   * 部件名称
   */
  productName: string
  /**
   * 进度比重(%)
   */
  proportion: number
  /**
   * 工序任务ID
   */
  sonProcessID: string
  /**
   * 工序任务名称
   */
  sonProcessName: string
  /**
   * 标准工时
   */
  standardWorkHour: string
  /**
   * 计划日期
   */
  startDate: string
  /**
   * 工单号
   */
  woNo: string
}

export interface AddDispatchingGroupData {
  /**
   * 添加生产派工列表
   */
  AddDispatchingGroupList: AddDispatchingGroupList[]
  dataDescribe?: string
}
export interface AddDispatchingGroupList {
  dataDescribe?: string
  /**
   * 派工数量
   */
  dispatchingNumber: number
  /**
   * 组别ID
   */
  groupID: string
  groupName?: string
  /**
   * 工序任务ID
   */
  processID: string
  processName?: string
  /**
   * 派工比例(%)
   */
  proportion: number
  /**
   * 开始日期
   */
  startDate: string
  /**
   * 工单ID
   */
  woID: string
}

export interface UpdateDispatchingGroupData {
  /**
   * 描述
   */
  dataDescribe?: string
  /**
   * 派工数量
   */
  dispatchingNumber: number
  /**
   * 班组ID
   */
  groupID: string
  /**
   * 车间派工单ID
   */
  id: string
  /**
   * 工序任务ID
   */
  processID: string
  /**
   * 计划日期
   */
  startDate: string
  /**
   * 工单ID
   */
  woID: string
}
export interface DeleteDispatchingGroupData {
  /**
   * 派工单ID
   */
  id: string
}

export interface UpdateDispatchingGroupCompletedData {
  /**
   * 报工单ID
   */
  id: string
}

export interface AddReportWorkData {
  /**
   * 组内派工单ID
   */
  dispatchingEmployeeId: string
  /**
   * 组内派工单信息
   */
  employeeInfoId: string
  /**
   * 结束时间，如18:00，有班次ID可不填
   */
  endTime?: string
  /**
   * 报工数量
   */
  finishCount: number
  /**
   * 完成率
   */
  finishPercent: number
  /**
   * 报工日期
   */
  reportWorkTime: string
  /**
   * 休息用时(h)
   */
  restTime: number
  /**
   * 班次ID，正常班次时必填
   */
  scheduleId: string
  /**
   * 班次类型（1：正常班次；2：其他班次）
   */
  scheduleType: number
  /**
   * 开始时间，如08:00，有班次ID可不填
   */
  startTime?: string
  /**
   * 用时(h)
   */
  takeTime: number
  /**
   * 描述
   */
  workDescription: string
  /**
   * 工作类别(1：正常工时，2：设计变更，3：来料不良，4：培训，5：6S，6：其他)
   */
  workType: number
}

export interface UpdateReportWorkData {
  /**
   * 结束时间，如18:00，有班次ID可不填
   */
  endTime: string
  /**
   * 报工数量
   */
  finishCount: number
  /**
   * 完成率
   */
  finishPercent: number
  /**
   * 报工单ID
   */
  id: string
  /**
   * 休息用时(h)
   */
  restTime: number
  /**
   * 班次ID，为null时 则是自定义时间
   */
  scheduleId: string
  /**
   * 开始时间，如08:00，有班次ID可不填
   */
  startTime: string
  /**
   * 用时(h)
   */
  takeTime: number
  /**
   * 描述
   */
  workDescription: string
  /**
   * 工作类别(1：正常工时，2：设计变更，3：来料不良，4：培训，5：6S，6：其他)
   */
  workType: number
}

export interface AddOtherReportWorkData {
  /**
   * 其他派工单ID
   */
  dispatchingId: string
  /**
   * 时间终点(H:M)
   */
  endTime: string
  /**
   * 报工数量
   */
  finishCount: number
  /**
   * 报工日期
   */
  reportWorkTime: string
  /**
   * 休息时长（H）
   */
  restTime: number
  /**
   * 班次ID
   */
  scheduleId: string
  /**
   * 班次类型(1：正常班次，2：其他班次)
   */
  scheduleType: number
  /**
   * 时间起点(H:M)
   */
  startTime: string
  /**
   * 用时（H）
   */
  takeTime: number
  /**
   * 工作描述
   */
  workDescription?: string
}

export interface UpdateOtherReportWorkData {
  /**
   * 作业者ID
   */
  employeeInfoId: string
  /**
   * 时间终点(H:M)
   */
  endTime: string
  /**
   * 报工日期
   */
  reportWorkTime: string
  /**
   * 休息时长（H）
   */
  restTime: number
  /**
   * 班次ID
   */
  scheduleId: string
  /**
   * 班次类型(1：正常班次，2：其他班次)
   */
  scheduleType: number
  /**
   * 时间起点(H:M)
   */
  startTime: string
  /**
   * 用时（H）
   */
  takeTime: number
  /**
   * 工作描述
   */
  workDescription?: string
  /**
   * 工作类别(4、培训，5、6S，6、其他)
   */
  workType: number
}

export interface UpdateReportWorkStateData {
  /**
   * 报工单ID
   */
  id: string
  /**
   * 操作状态（2：组长确认；3：作废）
   */
  orderStatus: number
}

export interface ExportReportWorkparams {
  /**
   * 部门ID
   */
  departmentID?: string
  /**
   * 组别ID
   */
  groupID?: string
  /**
   * 需求分类
   */
  orderNo?: string
  /**
   * 派工单状态（0：未报工；1：报工中；2：已完工)，多选
   */
  orderStatus?: string[]
  /**
   * 页码
   */
  pageIndex?: string
  /**
   * 数量
   */
  pageSize?: string
  /**
   * 部件名称
   */
  productName?: string
  /**
   * 项目ID
   */
  projectId?: string
  /**
   * 单据编号
   */
  woNo?: string
}

export interface UpdateDispatchingCompletedData {
  /**
   * 报工单ID
   */
  id: string
}

export interface ReportWorkDetail {
  /**
   * 作业结束时间，如18:20
   */
  endTime: string
  /**
   * 完成数量
   */
  finishCount: number
  /**
   * 完成百分比
   */
  finishPercent: number
  /**
   * 报工单ID，添加时为Null
   */
  id: string
  /**
   * 报工日期
   */
  reportWorkTime: string
  /**
   * 班次ID，自定义时间为Null
   */
  scheduleID: string
  /**
   * 作业开始时间，如06:30
   */
  startTime: string
  /**
   * 用时
   */
  takeTime: number
  /**
   * 工作描述
   */
  workDescription: string
  /**
   * 工作类别(1：正常工时，2：设计变更，3：来料不良)
   */
  workType: number
}

export interface UpdateReportWorkStateModel {
  /**
   * 提示语：所有报工已完成，是否要结束该派工单?
   */
  message: string
  /**
   * 返回报工单是否完成（1：未完成；2：已完成）
   */
  orderStatus: number
}

export interface GetWorkDispatchingWoModel {
  /**
   * BOM的ID
   */
  bomid?: string
  /**
   * 机箱数量
   */
  chassisNumber?: string
  /**
   * 创建时间
   */
  createTime?: string
  /**
   * 创建用户ID
   */
  createUserID?: string
  /**
   * 备注
   */
  dataDescribe?: string
  /**
   * 数据状态，当为2代表已经删除，1代表存在
   */
  dataStatus?: number
  /**
   * 部门ID
   */
  departmentID?: string
  /**
   * 部门名称
   */
  departmentName?: string
  /**
   * 执行 PMC 员工ID
   */
  employeeID?: string
  /**
   * 执行 PMC 员工姓名
   */
  employeeName?: string
  /**
   * 执行 PMC 员工工号
   */
  employeeNo?: string
  /**
   * 机架数量
   */
  frameNumber?: string
  /**
   * 单主键ID
   */
  id?: string
  /**
   * 最后修改时间
   */
  lastModifiedTime?: string
  /**
   * 最后修改用户ID
   */
  lastModifiedUserID?: string
  /**
   * 线体ID
   */
  lineID?: string
  /**
   * 线体名称
   */
  lineName?: string
  /**
   * 工单进度
   */
  orderSchedule?: number
  /**
   * 工单状态（0：未开始；1：执行中；2：已完工，3：已关闭，4：已取消）
   */
  orderStatus?: number
  /**
   * 优先级
   */
  priorityLevel?: number
  /**
   * 工序ID
   */
  processID?: string
  /**
   * 工序名称
   */
  processType?: string
  /**
   * 生产场地ID
   */
  productionAddressID?: string
  /**
   * 生产场地
   */
  productionAddressName?: string
  /**
   * 当前完成节点
   */
  productionNodeName?: string
  /**
   * 订单数量
   */
  productionOrderNumber?: number
  /**
   * 设备名称
   */
  productName?: string
  /**
   * 版本编码
   */
  versionNo?: string
  /**
   * 单据编号
   */
  woNo?: string
}

export interface GetReportWorkDetailModel {
  /**
   * 派工数量
   */
  dispatchingNumber: number
  /**
   * 最大可填数量
   */
  maxFinishCount: number
  /**
   * 最大可填百分比
   */
  maxFinishPercent: number
  /**
   * 累计完成数量
   */
  sumFinishCount: number
  /**
   * 累计完成率
   */
  sumFinishPercent: number
  /**
   * 累计用时
   */
  sumTakeTime: number
}

export interface GetAttendanceModel {
  /**
   * 考勤日期
   */
  attendanceDate: string
  /**
   * 考勤结束日期
   */
  attendanceEndDate: string
  /**
   * 考勤状态（1：出勤；2：请假；3：休息；4：离职；5：支援；6：缺勤；7：出差；8：旷工）
   */
  attendanceStatus: number
  createTime: string
  createUserID: string
  dataDescribe: string
  dataStatus: number
  /**
   * 部门ID
   */
  departmentID: string
  /**
   * 部门名称
   */
  departmentName: string
  /**
   * 员工ID
   */
  employeeInfoID: string
  /**
   * 员工姓名
   */
  employeeInfoName: string
  /**
   * 组别ID
   */
  groupID: string
  /**
   * 组别名称
   */
  groupName: string
  /**
   * 考勤记录主键ID
   */
  id: string
  lastModifiedTime: string
  lastModifiedUserID: string
  /**
   * 最后操作人
   */
  lastModifiedUserName: string
  /**
   * 单据状态（1：未确认；2：已确认）
   */
  orderStatus: number
  /**
   * 借调状态(0：""；1：借调中)
   */
  transferInStatus: number
}

export interface AddAttendanceData {
  addDataModel: { employeeInfoID: string; transferStatus: number }[]
  /**
   * 考勤日期
   */
  attendanceDate: string
  /**
   * 考勤状态（1：出勤；2：请假；3：休息；4：离职；5：支援；6：缺勤；7：出差；8：旷工）
   */
  attendanceStatus: number
  /**
   * 备注
   */
  dataDescribe: string
  /**
   * 班组ID
   */
  groupID: string
}

export interface UpdateAttendanceData {
  /**
   * 借调状态(0：无借调；1：借调中)
   */
  transferStatus: number
  /**
   * 班组ID
   */
  groupID: string
  /**
   * 考勤开始日期
   */
  attendanceDate: string
  /**
   * 考勤结束日期
   */
  attendanceEndDate?: string
  /**
   * 考勤状态（1：出勤；2：请假；3：休息；4：离职；5：支援；6：缺勤；7：出差；8：旷工）
   */
  attendanceStatus: number
  /**
   * 备注
   */
  dataDescribe: string
  /**
   * 员工ID
   */
  employeeInfoID: string
  /**
   * ID
   */
  id: string
}

export interface UpdateAttendanceStatusData {
  /**
   * ID
   */
  id: string
}
export interface UpdateAttendanceRevokeConfirmData {
  /**
   * ID
   */
  id: string
}
export interface UpdateAttendanceOrderStatusAllData {
  /**
   * 考勤日期
   */
  attendanceDate: string
  /**
   * 组别ID
   */
  groupID: string
}

export interface GetReportWorkProjectDetailModel {
  /**
   * 组内派工单ID
   */
  dispatchingEmployeeID?: string
  /**
   * 组内派工单信息
   */
  dispatchingEmployeeInfo?: string
}

export interface GetDispatchingGroupByDateData {
  /**
   * 班组ID
   */
  GroupID: string
  /**
   * 开始日期
   */
  StartDate: string
  /**
   * 单据编号
   */
  WoNo: string
}
export interface GetDispatchingGroupByDateDataModel {
  /**
   * 创建日期
   */
  createTime?: string
  /**
   * 创建用户ID
   */
  createUserID?: string
  /**
   * 描述
   */
  dataDescribe?: null
  /**
   * 删除状态
   */
  dataStatus?: number
  /**
   * 派工数量
   */
  dispatchingNumber?: number
  /**
   * 班组ID
   */
  groupID?: string
  /**
   * 派工单ID
   */
  id?: string
  /**
   * 最后更新日期
   */
  lastModifiedTime?: string
  /**
   * 更新用户ID
   */
  lastModifiedUserID?: string
  /**
   * 派工状态
   */
  orderStatus?: number
  /**
   * 工序任务ID
   */
  sonProcessID?: string
  /**
   * 计划日期
   */
  startDate?: string
  /**
   * 单据编号
   */
  woNo?: string
}

export interface GetProductionWoListModel {
  id: string
  name: string
}
export interface GetProductionWoByWoNoModel {
  /**
   * bom id
   */
  bomid: string
  /**
   * 机箱数量
   */
  chassisNumber: string
  createTime: string
  createUserID: string
  dataDescribe: null
  dataStatus: number
  /**
   * 部门id
   */
  departmentID: string
  /**
   * 部门名称
   */
  departmentName: string
  /**
   * 员工ID
   */
  employeeID: string
  /**
   * 员工姓名
   */
  employeeName: null
  /**
   * 员工工号
   */
  employeeNo: null
  /**
   * 机架数量
   */
  frameNumber: string
  /**
   * 工单id
   */
  id: string
  lastModifiedTime: string
  lastModifiedUserID: string
  /**
   * 工单进度
   */
  orderSchedule: number
  /**
   * 工单状态
   */
  orderStatus: number
  /**
   * 优先级
   */
  priorityLevel: number
  /**
   * 设备类型id
   */
  processID: string
  /**
   * 设备类型
   */
  processType: null
  /**
   * 生产厂区id
   */
  productionAddressID: string
  /**
   * 生产厂区名称
   */
  productionAddressName: string
  /**
   * 节点名称
   */
  productionNodeName: null
  /**
   * 订单数量
   */
  productionOrderNumber: number
  /**
   * 设备名称
   */
  productName: string
  /**
   * 版本号
   */
  versionNo: string
  /**
   * 单据编号
   */
  woNo: string
}

export interface GetDispatchingGroupWoModel {
  /**
   * 创建时间
   */
  createTime?: string
  /**
   * 创建用户ID
   */
  createUserID?: string
  dataDescribe?: string
  /**
   * 数据状态，当为2代表已经删除，1代表存在
   */
  dataStatus?: number
  /**
   * 部门ID
   */
  departmentID?: string
  /**
   * 部门名称
   */
  departmentName?: string
  /**
   * 派工数量
   */
  dispatchingNumber?: number
  /**
   * 完成进度
   */
  finishPercent?: number
  /**
   * 班组ID
   */
  groupID?: string
  /**
   * 班组名称
   */
  groupName?: string
  /**
   * 组内派工单ID
   */
  id: string
  /**
   * 最后修改时间
   */
  lastModifiedTime?: string
  /**
   * 最后修改用户ID
   */
  lastModifiedUserID?: string
  /**
   * 班组长ID
   */
  leaderID: number
  /**
   * 班组长姓名
   */
  leaderName?: string
  /**
   * 单据状态（0：未报工；1：报工中；2：已完工)
   */
  orderStatus?: number
  /**
   * 设备类型ID
   */
  processID?: string
  /**
   * 设备类型名称
   */
  processName?: string
  /**
   * 产品名称
   */
  productName?: string
  /**
   * 工序任务ID
   */
  sonProcessID?: string
  /**
   * 工序任务名称
   */
  sonProcessName?: string
  /**
   * 标准工时
   */
  standardWorkHour?: number
  /**
   * 计划日期
   */
  startDate?: string
  /**
   * 车间派工已完成数量
   */
  sumFinishCount?: number
  /**
   * 工单号
   */
  woNo?: string
  /**
   * 未派数量
   */
  leftDispatchingCount: number
  /**
   * 母件编码
   */
  materialNo: string
  /**
   * 派工方式
   */
  dispatchingMehtod: number
}

export interface GetDispatchingEmployeeWoModel {
  /**
   * 未派数量
   */
  leftDispatchingCount: number
  /**
   * 创建时间
   */
  createTime: string
  /**
   * 创建用户ID
   */
  createUserID: string
  /**
   * 录入人
   */
  createUserName: string
  /**
   * 描述
   */
  dataDescribe: string
  /**
   * 数据状态，当为2代表已经删除，1代表存在
   */
  dataStatus: number
  /**
   * 派工数量
   */
  dispatchingNumber: number
  /**
   * 作业者ID
   */
  employeeInfoID: string
  /**
   * 作业者姓名
   */
  employeeName: string
  /**
   * 作业者工号
   */
  employeeNo: string
  /**
   * 已完成数量
   */
  finishCount: number
  /**
   * 完成比率
   */
  finishPercent: number
  /**
   * 班组
   */
  groupName: string
  /**
   * 派工单ID
   */
  id: string
  /**
   * 最后修改时间
   */
  lastModifiedTime: string
  /**
   * 最后修改用户ID
   */
  lastModifiedUserID: string
  /**
   * 派工单状态（0：未报工；1：报工中；2：已完工)
   */
  orderStatus: number
  /**
   * 计划日期
   */
  startDate: string
  /**
   * 总用时
   */
  takeTime: number
  /**
   * 借调状态(0：""；1：借调中)
   */
  transferInStatus: number
  /**
   * 单据编号
   */
  woNo: string
}

export interface AddDispatchingEmployeeData {
  /**
   * 员工派工数据集
   */
  dispatchingEmployees: DispatchingEmployee[]
  /**
   * 车间派工ID
   */
  dispatchingGroupID: string
  /**
   * 单据编号
   */
  woNo: string
}

export interface DispatchingEmployee {
  /**
   * 派工数量
   */
  dispatchingNumber: number
  /**
   * 员工名称
   */
  employeeInfoName?: string
  /**
   * 员工ID
   */
  employeeInfoID: string
  /**
   * 计划日期
   */
  startDate: string
}

export interface UpdateDispatchingEmployeeData {
  /**
   * 车间派工ID
   */
  dispatchingGroupID: string
  /**
   * 派工数量
   */
  dispatchingNumber: number
  /**
   * 员工ID
   */
  employeeInfoID: string
  /**
   * 组内派工ID
   */
  id: string
  /**
   * 计划日期
   */
  startDate: string
}

export interface TransferDispatchingEmployeeData {
  /**
   * 派工数量
   */
  dispatchingNumber: number
  /**
   * 转交员工ID
   */
  employeeInfoID: string
  /**
   * 原派工单ID
   */
  id: string
  /**
   * 计划开始日期
   */
  startDate: string
}

export interface DeleteDispatchingEmployeeData {
  id: string
}
export interface GetDispatchingEmployeeByDateData {
  /**
   * 员工ID
   */
  employeeInfoID: string
  /**
   * 开始日期
   */
  startDate: string
}
export interface GetDispatchingEmployeeByDateModel {
  /**
   * 创建日期
   */
  createTime?: string
  /**
   * 创建用户ID
   */
  createUserID?: string
  /**
   * 描述
   */
  dataDescribe?: null
  /**
   * 删除状态
   */
  dataStatus?: number
  /**
   * 派工数量
   */
  dispatchingNumber?: number
  /**
   * 员工ID
   */
  employeeInfoID?: string
  /**
   * 组内派工单ID
   */
  id?: string
  /**
   * 最后更新日期
   */
  lastModifiedTime?: string
  /**
   * 更新用户ID
   */
  lastModifiedUserID?: string
  /**
   * 单据状态（0：未报工；1：报工中；2：已完工)
   */
  orderStatus?: number
  /**
   * 计划日期
   */
  startDate?: string
  /**
   * 单据编号
   */
  woNo?: string
}
export interface GetExceptionRecordModel {
  /**
   * 母件编码
   */
  materialNo?: string
  createTime: string
  createUserID: string
  dataDescribe: null
  dataStatus: number
  /**
   * 部门名称
   */
  departmentName: string
  /**
   * 责任部门
   */
  duty: string
  /**
   * 责任人
   */
  employeeName: string
  /**
   * 异常描述
   */
  exceptionDescription: string
  /**
   * 异常类型
   */
  exceptionTypeName: string
  /**
   * 异常数量
   */
  exceptionNumber: number
  /**
   * 异常工时
   */
  exceptionWorkTime: number
  /**
   * 异常日期
   */
  execptionTime: string
  /**
   * ，异常ID
   */
  id: string
  lastModifiedTime: string
  lastModifiedUserID: string
  /**
   * 处理方式
   */
  processingMode: string
  /**
   * 处理状态
   */
  processingState: number
  /**
   * 项目名称
   */
  projectName: string
  /**
   * 单据编号
   */
  woNo: string
}

export interface AddExceptionRecordData {
  dataDescribe: string
  /**
   * 生产部门ID
   */
  departmentId: string
  /**
   * 责任人名称
   */
  dutyEmployeeName?: string
  /**
   * 责任部门ID
   */
  dutyId?: string
  /**
   * 异常描述
   */
  exceptionDescription?: string
  /**
   * 异常数量
   */
  exceptionNumber: number
  /**
   * 异常类型
   */
  exceptionTypeId: string
  /**
   * 异常工时
   */
  exceptionWorkTime: number
  /**
   * 日期
   */
  execptionTime: string
  /**
   * 班组长ID
   */
  groupEmployeeInfoId: string
  /**
   * 处理方式
   */
  processingMode?: string
  /**
   * 异常处理状态（0：未处理；1：处理中；2：已处理）
   */
  processingState: number
  /**
   * 项目ID
   */
  projectId?: string
  /**
   * 单据编号
   */
  woNo?: string
}
export interface UpdateExceptionRecordData {
  dataDescribe: string
  /**
   * 生产部门ID
   */
  departmentId: string
  /**
   * 责任人名称
   */
  dutyEmployeeName: string
  /**
   * 责任部门ID
   */
  dutyId: string
  /**
   * 异常描述
   */
  exceptionDescription: string
  /**
   * 异常数量
   */
  exceptionNumber: number
  /**
   * 异常类型
   */
  exceptionTypeId: string
  /**
   * 异常工时
   */
  exceptionWorkTime: number
  /**
   * 日期
   */
  execptionTime: string
  /**
   * 班组长ID
   */
  groupEmployeeInfoId: string
  /**
   * 主键ID
   */
  id: string
  /**
   * 处理方式
   */
  processingMode: string
  /**
   * 异常处理状态（0：未处理；1：处理中；2：已处理）
   */
  processingState: number
  /**
   * 项目ID
   */
  projectId?: string
  /**
   * 单据编号
   */
  woNo?: string
}

export interface DeleteExceptionRecordData {
  /**
   * 生产异常信息ID
   */
  id: string
}

export interface UpdateExceptionRecordProcessingStateData {
  /**
   * ID
   */
  id: string
  /**
   * 异常处理状态（0：未处理；1：处理中；2：已处理）
   */
  processingState: number
}

export interface GetEmployeeTransferModel {
  createTime: string
  createUserID: string
  /**
   * 创建人名称
   */
  createUserName: string
  dataDescribe: null | string
  dataStatus: number
  /**
   * 原部门ID
   */
  departmentID: string
  /**
   * 原部门姓名
   */
  departmentName: string
  /**
   * 借调员工ID
   */
  employeeInfoID: string
  /**
   * 借调员工姓名
   */
  employeeInfoName: string
  /**
   * 组别ID
   */
  groupID: string
  /**
   * 原班组姓名
   */
  groupName: string
  /**
   * ID
   */
  id: string
  lastModifiedTime: string
  lastModifiedUserID: string
  /**
   * 最后修改人名称
   */
  lastModifiedUserName: string
  /**
   * 单据状态（0：未确认；1：借调中；2：已结束；3：已作废）
   */
  orderStatus: number
  /**
   * 借调开始时间
   */
  transferBeginTime: string
  /**
   * 借调小时，保留一位小数
   */
  transferHours: number
  /**
   * 借调部门ID
   */
  transferDepartmentID: string
  /**
   * 借调部门姓名
   */
  transferDepartmentName: string
  /**
   * 借调结束时间
   */
  transferEndTime: string
  /**
   * 借调组别ID
   */
  transferGroupID: string
  /**
   * 借调组别姓名
   */
  transferGroupName: string
  /**
   * 借调组长ID
   */
  transferLeaderID: string
  /**
   * 借调组长名称
   */
  transferLeaderName: string
}

export interface ADDEmployeeTransferData {
  /**
   * 借调人员列表
   */
  employeeTransferList: EmployeeTransferList[]
}

export interface EmployeeTransferList {
  /**
   * 借调原因
   */
  dataDescribe?: string
  /**
   * 原部门ID
   */
  departmentID: string
  /**
   * 借调员工ID
   */
  employeeInfoID: string
  /**
   * 组别ID
   */
  groupID: string
  /**
   * 单据状态（0：未确认；1：借调中；2：已结束；3：已作废）
   */
  orderStatus: number
  /**
   * 借调开始时间
   */
  transferBeginTime: string
  /**
   * 借调部门ID
   */
  transferDepartmentID: string
  /**
   * 借调结束时间
   */
  transferEndTime: string
  /**
   * 借调组别ID
   */
  transferGroupID: string
  /**
   * 借调小时，保留一位小数
   */
  transferHours: number
  /**
   * 借调组长ID
   */
  transferLeaderID: string
}

export interface UpdateEmployeeTransfer {
  /**
   * 借调原因
   */
  dataDescribe: string
  /**
   * 借调员工ID
   */
  employeeInfoID: string
  /**
   * ID
   */
  id: string
  /**
   * 借调开始时间
   */
  transferBeginTime: string
  /**
   * 借调小时，保留一位小数
   */
  transferHours: number
  /**
   * 借调部门ID
   */
  transferDepartmentID: string
  /**
   * 借调结束时间
   */
  transferEndTime: string
  /**
   * 借调组别ID
   */
  transferGroupID: string
}
export interface DeleteEmployeeTransferData {
  id: string
}

export interface UpdateEmployeeTransferConfirmData {
  id: string
  orderStatus: number
}

export interface AddReportWorkProductionPerformanceData {
  /**
   * 报工作业者ID
   */
  employeeInfoID: string
  /**
   * 报工单主键ID
   */
  id: string
  /**
   * 绩效等级
   */
  performanceLevel: string
  /**
   * 报工日期
   */
  reportWorkTime: string
}
export interface AddReportWorkProductionPerformanceResult {
  /**
   * 提示语：所有报工已完成，是否要结束该派工单?
   */
  message: string
  /**
   * 返回报工单是否完成（1：未完成；2：已完成）
   */
  orderStatus: number
  [property: string]: any
}

export interface GetPerformanceStandardData {
  /**
   * 绩效颜色
   */
  performanceColor: number
  /**
   * 绩效等级
   */
  performanceLevel: string
  /**
   * 绩效等级积分
   */
  performanceMark: number
  /**
   * 绩效标准比例
   */
  performanceStandardScale: string
}

export interface AddHonorRollData {
  /**
   * 事迹描述
   */
  dataDescribe: string
  /**
   * 部门ID
   */
  departmentId: string
  /**
   * 部门名称
   */
  departmentName: string
  /**
   * 员工ID
   */
  employeeID: string
  /**
   * 员工名称
   */
  employeeName: string
  /**
   * 类型(1：荣誉榜；2：提升榜)
   */
  honorType: number
  /**
   * 事迹图片Url
   */
  imageUrl: string
  /**
   * 状态（1：启用；2：停用）
   */
  orderStatus: number
}

export interface UpdateHonorRollData {
  /**
   * 事迹描述
   */
  dataDescribe: string
  /**
   * 类型(1：荣誉榜；2：提升榜)
   */
  honorType: number
  /**
   * 主键ID
   */
  id: string
  /**
   * 事迹图片Url
   */
  imageUrl: string
  /**
   * 状态（1：启用；2：停用）
   */
  orderStatus: number
}

export interface AddProductionPerformanceData {
  /**
   * 考核时间
   */
  assessmentTime: string
  /**
   * 考核人ID
   */
  assessorID: string
  /**
   * 被考核人ID
   */
  beAssessorID: string
  /**
   * 备注
   */
  dataDescribe: string
  /**
   * 绩效等级
   */
  performanceLevel: string
  [property: string]: any
}
export interface UpdateProductionPerformanceData {
  /**
   * 备注
   */
  dataDescribe?: string
  /**
   * 主键ID
   */
  id: string
  /**
   * 绩效等级
   */
  performanceLevel: string
}

export interface ImportExcelData {
  /**
   * 错误信息，为null则表示导入成功
   */
  errorMessage?: string
  /**
   * 失败数量
   */
  failCount: number
  /**
   * 成功数量
   */
  successCount: number
  /**
   * 导入总条数
   */
  totalCount: number
}

export interface UpdateProductionWoStateMoreData {
  /**
   * 修改的单据编号数据集
   */
  updateProductionWoStateModel: {
    /**
     * 主键ID
     */
    id: string
    /**
     * 批量开工传1，操作状态（1：开工；2：完工，3：关单，4：取消）
     */
    orderStatus: number
  }[]
}

export interface AddDispatchingOtherData {
  dispatchingOtherEmployees: DispatchingOtherEmployee[]
}

export interface DispatchingOtherEmployee {
  /**
   * 派工数量，可为0
   */
  dispatchingNumber: number
  /**
   * 作业者ID
   */
  employeeInfoID: string
  /**
   * 计划开始日期
   */
  startDate: string
  /**
   * 工作描述
   */
  workDescription?: string
  /**
   * 工作类别(4：培训，5：6S，6：其他)
   */
  workType: number
}

export interface UpdateDispatchingOtherData {
  /**
   * 派工数量，可为0
   */
  dispatchingNumber: number
  /**
   * 主键ID
   */
  id: string
  /**
   * 计划开始日期
   */
  startDate: string
  /**
   * 工作描述
   */
  workDescription?: string
  /**
   * 工作类别(4：培训，5：6S，6：其他)
   */
  workType: number
}

export interface UpdateOtherReportWorkStateData {
  /**
   * 报工单ID
   */
  id: string
  /**
   * 操作状态（2：组长确认；3：作废）
   */
  orderStatus: number
}

export interface UpdateOtherReportWorkStateModel {
  /**
   * 提示语：所有报工已完成，是否要结束该派工单?
   */
  message: string
  /**
   * 返回报工单是否完成（1：未完成；2：已完成）
   */
  orderStatus: number
}

export interface AddOtherReportWorkProductionPerformanceData {
  /**
   * 报工单主键ID
   */
  id: string
  /**
   * 绩效等级
   */
  performanceLevel: string
}

export interface AddOtherReportWorkProductionPerformanceModel {
  /**
   * 提示语：所有报工已完成，是否要结束该派工单?
   */
  message: string
  /**
   * 返回报工单是否完成（1：未完成；2：已完成）
   */
  orderStatus: number
}

export type WorkOrderListGetResultModel = BasicFetchResult<GetWorkOrderModel>
export type ProductionPlanListGetResultModel = BasicFetchResult<GetProductionPlanByWoModel>
export type DispatchingGroupGetResultModel = BasicFetchResult<GetDispatchingGroupModel>
export type WorkDispatchingWoListGetResultModel = BasicFetchResult<GetWorkDispatchingWoModel>
export type ReportWorkListGetResultModel = BasicFetchResult<GetReportWorkModel>
export type AttendanceListGetResultModel = BasicFetchResult<GetAttendanceModel>
export type DispatchingGroupByDateGetResultModel = GetDispatchingGroupByDateDataModel[]
export type ProductionWoListGetResultModel = GetProductionWoListModel[]
export type ProductionWoByWoNoGetResultModel = GetProductionWoByWoNoModel
export type DispatchingGroupListGetResultModel = BasicFetchResult<GetDispatchingGroupWoModel>
export type DispatchingEmployeeGetResultModel = BasicFetchResult<GetDispatchingEmployeeWoModel>
export type DispatchingEmployeeByDateGetResultModel = GetDispatchingEmployeeByDateModel[]
export type ExceptionRecordGetResultModel = BasicFetchResult<GetExceptionRecordModel>
export type EmployeeTransferListGetResultModel = BasicFetchResult<GetEmployeeTransferModel>
export type PerformanceStandardListGetResultModel = BasicFetchResult<GetPerformanceStandardData>
export type HonorRollListGetResultModel = BasicFetchResult<GetHonorRollModel>
export type ProductionPerformanceListGetResultModel =
  BasicFetchResult<GetProductionPerformanceModel>
export type ProductionPerformanceByEmployeeGetResultModel = GetProductionPerformanceByEmployeeModel
export type DispatchingSearchGetResultModel = BasicFetchResult<GetDispatchingSearchModel>
export type ReportWorkSearchGetResultModel = BasicFetchResult<GetReportWorkSearchModel>
export type GetDispatchingOrderGetResultModel = BasicFetchResult<GetDispatchingOrderModel>
export type GetOtherReportWorkGetResultModel = GetOtherReportWorkModel[]
export type DispatchingOtherGetResultModel = BasicFetchResult<GetDispatchingOtherModel>
