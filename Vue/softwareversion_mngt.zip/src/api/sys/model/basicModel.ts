import type { BasicPageParams, BasicFetchResult, SelectModel } from '@/api/model/baseModel'

export type GetEmployeeInfoParams = BasicPageParams & {
  /**
   * 考勤日期
   */
  AttendanceDate?: string
  /**
   * 属性ID
   */
  AttributesID?: string
  /**
   * 学历ID
   */
  DegreeID?: string
  /**
   * 部门ID
   */
  departmentID?: string
  /**
   * 员工姓名
   */
  employeeName?: string
  /**
   * 员工工号
   */
  employeeNo?: string
  /**
   * 结束入职时间
   */
  EndDataOfEntry?: string
  /**
   * 结束出生日期
   */
  EndDateOfBirth?: string
  /**
   * 归属组ID
   */
  GroupID?: string
  /**
   * 等级ID
   */
  LevelID?: string
  /**
   * 岗位ID
   */
  PositionID?: string
  /**
   * 职级系列ID
   */
  RankSeriesID?: string
  /**
   * 性别0女1男
   */
  Sex?: string
  /**
   * 开始入职时间
   */
  StartDataOfEntry?: string
  /**
   * 开始出生日期
   */
  StartDateOfBirth?: string
}

export type GetDictionaryParams = BasicPageParams & {
  /**
   * 类型名称
   */
  typeName?: string

  /**
   * 类型id
   */
  keyValueClassifyID?: string

  /**
   * 值
   */
  value?: string
}
export type GetDictionaryClassifyParams = {
  /**
   * 类型描述(暂定)
   */
  TypeDescription?: string
}

export interface GetDepartmentParams {
  /**
   * 部门名称
   */
  DepartmentName?: string
}
export type GetScheduleParams = BasicPageParams & {
  /**
   * 部门名称
   */
  ScheduleName?: string
}
export type GetGroupParams = BasicPageParams & {
  /**
   * 部门ID
   */
  DepartmentID?: string
  /**
   * 组别名称
   */
  GroupName?: string
  /**
   * 生产厂区
   */
  ProductionAddressID?: string
}

export type GetPositionLevelParams = BasicPageParams & {
  /**
   * 岗位等级id
   */
  ID?: string
}

export type GetProductionLineParams = BasicPageParams & {
  /**
   * 线体名称
   */
  LineName?: string
}
export type GetProductionNodeParams = BasicPageParams & {
  /**
   * 生产节点名称
   */
  productionNodeName?: string
}

export type GetProductionProcessParams = {
  /**
   * 工序类型
   */
  processType?: string
}

export type GetProductionProcessChildrenParams = {
  /**
   * 父级ID
   */
  processTypeID: string
  /**
   * 设备名称，需要过滤标准工时
   */
  standardWorkTimeProductName?: string
  /**
   * 项目ID，需要过滤标准工时
   */
  standardWorkTimeProjectID?: string
}

export type GetProductionVersionParams = BasicPageParams & {
  /**
   * 查询结束日期
   */
  EndTime?: string
  /**
   * 版本状态（0：待确认；1：已确认；2：已作废）
   */
  OrderStatus?: number
  /**
   * 项目ID
   */
  projectID: string
  /**
   * 查询开始日期
   */
  StartTime?: string
  /**
   * 版本号
   */
  VersionNo?: string
  /**
   * 单据编号
   */
  woNo?: string
}

export type GetProjectValidVersionParams = {
  /**
   * 项目ID
   */
  projectID?: string
}
export type GetProductionVersionSelectParams = {
  /**
   * 项目ID
   */
  projectID?: string
}
export type GetGroupLeaderParams = {
  /**
   * 部门ID
   */
  departmentID?: string
}

export type GetConfirmSignatureTypeParams = BasicPageParams & {
  /**
   * 查询关键字
   */
  SearchKey?: string
}

export type GetOrderAutoConfirmParams = BasicPageParams & {
  /**
   * 查询关键字
   */
  SearchKey?: string
}

export type GetEmployeeInfoBySelectParams = BasicPageParams & {
  /**
   * 考勤日期
   */
  AttendanceDate?: string
  /**
   * 部门ID
   */
  DepartmentID?: string
  /**
   * 员工姓名或工号
   */
  employeeName?: string
  /**
   * 归属组ID
   */
  GroupID?: string
  /**
   * 岗位ID
   */
  PositionID?: string
}

export type GetPositionClassifyParams = BasicPageParams & {
  /**
   * 岗位Name，对应字典表岗位定义
   */
  PositionName?: string
}

export interface GetPositionClassifyModel {
  createTime?: string
  createUserID?: string
  createUserName?: string
  dataDescribe?: null
  dataStatus?: number
  id: string
  lastModifiedTime?: string
  lastModifiedUserID?: string
  lastModifiedUserName?: string
  positionClassifyID: string
  positionClassifyName: string
  positionID: string
  positionName: string
}

export type GetUserRequestLogParams = BasicPageParams & {
  /**
   * 部门ID
   */
  departmentId?: number
  /**
   * 员工ID
   */
  employeeId?: number
  /**
   * 结束时间
   */
  endLogTime: string
  /**
   * 组别ID
   */
  groupId?: number
  /**
   * 系统模块名称
   */
  moduleName?: string
  /**
   * 开始时间
   */
  startLogTime: string
}

export type GetMessageParams = BasicPageParams & {
  /**
   * 本地消息状态(1:未读,2:已读,3:发送失败)，不传为所有状态
   */
  ReadStatus?: number | ''
}

export type GetNoticeMngtParams = BasicPageParams & {
  /**
   * 搜索关键字，消息类型名称
   */
  SearchKey?: string
}

export interface GetUserRequestLogData {
  /**
   * 部门访问量统计图
   */
  departmentAccessModel: DepartmentAccessModel[]
  /**
   * 系统模块访问统计图
   */
  modelAccessModel: ModelAccessModel[]
  /**
   * 操作日志集合
   */
  userRequestLogAccessModel: BasicFetchResult<GetUserRequestLogModel>
}

export interface DepartmentAccessModel {
  /**
   * 部门名称
   */
  departmentName?: string
  /**
   * 访问量
   */
  departmentSumCount?: number
}

export interface ModelAccessModel {
  /**
   * 系统模块名称
   */
  modelName: string
  /**
   * 访问量
   */
  modelSumCount: number
}

export interface GetUserRequestLogModel {
  /**
   * 操作时间
   */
  createTime: string
  createUserId: string
  dataDescribe: null
  dataStatus: number
  /**
   * 部门
   */
  departmentName: string
  /**
   * 操作人员
   */
  employeeName: string
  /**
   * 账号
   */
  employeeNo: string
  /**
   * 班组
   */
  groupName: string
  /**
   * 主键ID
   */
  id: string
  lastModifiedTime: string
  lastModifiedUserId: string
  /**
   * 系统模块
   */
  moduleName: string
  /**
   * 行为
   */
  operationBehavior: string
}

export interface AddEmployeeInfoData {
  /**
   * 头像
   */
  imageUrl?: string
  /**
   * 属性
   */
  attributesID: number
  /**
   * 备注
   */
  dataDescribe: string
  /**
   * 入职日期
   */
  dataOfEntry: string
  /**
   * 出生日期
   */
  dateOfBirth: string
  /**
   * 学历
   */
  degreeID: number
  /**
   * 部门
   */
  departmentID: number
  /**
   * 员工姓名
   */
  employeeName: string
  /**
   * 员工工号
   */
  employeeNo: string
  /**
   * 组别
   */
  groupID: number
  /**
   * 岗位等级
   */
  levelID: number
  /**
   * 岗位
   */
  positionID: number
  /**
   * 生产厂区
   */
  productionAddressID: number
  /**
   * 职级系列
   */
  rankSeriesID: number
  /**
   * 性别，1男0女
   */
  sex: number
}
export interface UpdateEmployeeInfoData {
  /**
   * 头像
   */
  imageUrl?: string
  /**
   * 属性ID
   */
  attributesID: string
  /**
   * 数据描述
   */
  dataDescribe: string
  /**
   * 部门ID
   */
  departmentID: string
  /**
   * 员工姓名
   */
  employeeName: string
  /**
   * 组别ID
   */
  groupID: string
  /**
   * 员工ID
   */
  id: string
  /**
   * 等级ID
   */
  levelID: string
  /**
   * 岗位ID
   */
  positionID: string
  /**
   * 厂区ID
   */
  productionAddressID: string
  /**
   * 职级系列ID
   */
  rankSeriesID: string
}
export interface DeleteEmployeeInfoData {
  /**
   * 字典id
   */
  id: string
}

export interface AddDictionaryData {
  /**
   * 备注
   */
  dataDescribe: string
  /**
   * 数据描述
   */
  description: string
  /**
   * Key名称
   */
  key: string
  /**
   * 分类ID
   */
  keyValueClassifyID: string
  /**
   * 值
   */
  value: string
}

export interface UpdateDictionaryData {
  /**
   * 数据描述
   */
  dataDescribe: null | string
  /**
   * 描述
   */
  description: null | string
  /**
   * ID
   */
  id: string
  /**
   * key
   */
  key: string
  /**
   * value
   */
  value: string
}

export interface DeleteDictionaryData {
  /**
   * 字典id
   */
  id: string
}

export interface AddDictionaryClassifyData {
  /**
   * 类型描述
   */
  typeDescription: string
  /**
   * 类型名称
   */
  typeName: string
}

export interface DeleteDictionaryClassifyData {
  /**
   * 分类id
   */
  id: string
}

export interface AddProductionLineData {
  /**
   * 线体名称
   */
  lineName: string
}
export interface AddProductionProcessData {
  /**
   * 数据描述
   */
  dataDescribe?: string
  /**
   * 部门ID
   */
  departmentID?: string
  /**
   * 修改设备类型时必填，设备类型关联的工单数量类型，对应Key字典表
   */
  deviceNumberTypeId?: string
  /**
   * 父级ID
   */
  fatherID?: string
  /**
   * 工序类型
   */
  processType?: string
  /**
   * 组内派工数量分配方式
   */
  dispatchingMehtod?: number
}

export interface UpdateProductionLineData {
  /**
   * 线体ID
   */
  id: string
  /**
   * 线体名称
   */
  lineName: string
}

export interface UpdateProductionProcessData {
  /**
   * 数据描述
   */
  dataDescribe?: string
  /**
   * 修改设备类型时必填，设备类型关联的工单数量类型，对应Key字典表
   */
  deviceNumberTypeId?: string
  /**
   * 父级ID
   */
  fatherID?: string
  /**
   * 工序ID
   */
  id?: string
  /**
   * 工序类型
   */
  processType?: string
  /**
   * 组内派工数量分配方式
   */
  dispatchingMehtod?: number
}

export interface DeleteProductionLineData {
  /**
   * 线体id
   */
  id: string
}

export interface DeleteProductionProcessData {
  /**
   * 工序ID
   */
  id: string
}

export interface GetEmployeeInfoModel {
  /**
   * 班组长ID
   */
  groupLeaderID: string
  /**
   * 班组长
   */
  groupLeaderName: string
  /**
   * 考核人
   */
  assessorName?: string
  /**
   * 头像
   */
  imageUrl?: string
  /**
   * 属性
   */
  attributesName?: string
  /**
   * 创建时间
   */
  createTime?: string
  /**
   * 创建人
   */
  createUserID?: string
  /**
   * 组别id
   */
  groupID?: string
  /**
   * 部门id
   */
  departmentID?: string
  /**
   * 备注
   */
  dataDescribe?: string
  /**
   * 入职日期
   */
  dataOfEntry?: string
  /**
   * 数据状态
   */
  dataStatus?: number
  /**
   * 出生日期
   */
  dateOfBirth?: string
  /**
   * 学历
   */
  degreeName?: string
  /**
   * 部门
   */
  departmentName?: string
  /**
   * 员工名称
   */
  employeeName: string
  /**
   * 员工工号
   */
  employeeNo?: string
  /**
   * 组别
   */
  groupName?: string
  /**
   * 员工ID
   */
  id: string
  /**
   * 修改时间
   */
  lastModifiedTime?: string
  /**
   * 修改人
   */
  lastModifiedUserID?: string
  /**
   * 岗位等级
   */
  levelName?: string
  /**
   * 岗位
   */
  positionName?: string
  /**
   * 生产厂区
   */
  productionAddressName?: string
  /**
   * 职级系列
   */
  rankSeriesName?: string
  /**
   * 员工性别，1男0女
   */
  sex?: number
}
export interface GetEmployeeInfoByGroupIDModel {
  departmentID: string
  departmentName: string
  employeeName: string
  employeeNo: string
  groupID: string
  groupName: string
  id: string
  transferInStatus: number
}

export interface GetDepartmentModel {
  createTime: string
  createUserID: string
  dataDescribe: string
  dataStatus: number
  /**
   * 部门名称
   */
  departmentName: string
  /**
   * 父级ID
   */
  fatherID: string | null
  /**
   * 部门ID
   */
  id: string
  lastModifiedTime: string
  lastModifiedUserID: string
  /**
   * 厂区ID
   */
  productionAddressID: string
  /**
   * 子级部门
   */
  sonData: GetDepartmentModel[]
  /**
   * 排序
   */
  sortNo: number
}

export interface GetGroupModel {
  createTime?: string
  createUserID?: string
  dataDescribe?: null
  dataStatus?: number
  departmentID?: string
  departmentName?: null
  employeeInfoName?: null
  groupName?: string
  id: string
  lastModifiedTime?: string
  lastModifiedUserID?: string
  leaderID?: string
  productionAddressName?: string
}

export interface GetPositionLevelModel {
  createTime?: string
  createUserID?: string
  dataDescribe?: null
  dataStatus?: number
  id?: string
  lastModifiedTime?: string
  lastModifiedUserID?: string
  level?: string
  positionID?: string
  positionName?: string
}

export interface GetDictionaryModel {
  createTime: string
  createUserID: string
  dataDescribe: null
  dataStatus: number
  /**
   * 描述
   */
  description: string
  id: string
  /**
   * Key名称
   */
  key: string | number
  lastModifiedTime: string
  lastModifiedUserID: string
  /**
   * 类型名称
   */
  typeName: string
  /**
   * 值
   */
  value: string
}

export interface GetDictionaryClassifyModel {
  createTime: string
  createUserID: string
  dataDescribe: null
  dataStatus: number
  id: string
  isSystemClassify: number
  lastModifiedTime: string
  lastModifiedUserID: string
  typeDescription: string
  typeName: string
}

export interface GetProductionLineModel {
  createTime?: string
  createUserID?: string
  dataDescribe?: null
  dataStatus?: number
  /**
   * 线体ID
   */
  id: string
  lastModifiedTime?: string
  lastModifiedUserID?: string
  /**
   * 线体名称
   */
  lineName?: string
}

export interface GetProductionProcessModel {
  createTime?: string
  createUserID?: string
  dataDescribe?: null
  dataStatus?: number
  /**
   * 父级ID
   */
  fatherID?: string
  /**
   * 工序ID
   */
  id: string
  lastModifiedTime?: string
  lastModifiedUserID?: string
  /**
   * 工序类型
   */
  processType?: string
  /**
   * 标准工时
   */
  standardWrokTime: string
  /**
   * 完成率计算类型（1：数量换算，2：百分比换算）
   */

  conversionType: number
  /**
   * 工单数量类型ID，对应字典表ID
   */
  deviceNumberTypeID?: null | string
  /**
   * 工单数量类型Key，对应字典表Key
   */
  deviceNumberTypeKey?: string
  /**
   * 工单数量类型名称，对应字典表Key
   */
  deviceNumberTypeName?: string
}

export interface AddGroupData {
  /**
   * 数据描述
   */
  dataDescribe: string
  /**
   * 部门ID
   */
  departmentID: string
  /**
   * 组别名称
   */
  groupName: string
  /**
   * 组长ID
   */
  LeaderID: string
  ProductionAddressID: string
}

export interface UpdateGroupData {
  /**
   * 数据描述
   */
  dataDescribe: string
  /**
   * 部门ID
   */
  departmentID: string
  /**
   * 组别名称
   */
  groupName: string
  /**
   * 组别ID
   */
  id: string
  /**
   * 组长ID
   */
  LeaderID: string
  ProductionAddressID: string
}

export interface DeleteGroupData {
  /**
   * 组别ID
   */
  id: string
}

export interface AddDepartmentData {
  /**
   * 数据描述
   */
  dataDescribe: string
  /**
   * 部门名称
   */
  departmentName: string
  /**
   * 父级ID
   */
  fatherID: string
}

export interface UpdateDepartmentData {
  /**
   * 数据描述
   */
  dataDescribe: string
  /**
   * 部门名称
   */
  departmentName: string
  /**
   * 父级ID
   */
  fatherID: string
  /**
   * 部门ID
   */
  id: string
}

export interface DeleteDepartmentData {
  /**
   * 部门ID
   */
  id: string
}

export interface GetScheduleModel {
  createTime: string
  createUserID: string
  dataDescribe: null
  dataStatus: number
  id: string
  lastModifiedTime: string
  lastModifiedUserID: string
  scheduleName: string
  scheduleTime: string
  restTime: string
  workTime: string
  [key: string]: any
}

export interface AddScheduleData {
  /**
   * 备注
   */
  dataDescribe: string
  /**
   * 结束工作时间
   */
  endWorkTime: string
  /**
   * 是否有休息时间
   */
  isRest: number
  /**
   * 休息时间集合
   */
  restTimeData: {
    /**
     * 结束休息时间
     */
    endRestTime?: string
    /**
     * 开始休息时间
     */
    startRestTime?: string
  }[]
  /**
   * 班次名称
   */
  scheduleName: string
  /**
   * 开始工作时间
   */
  startWorkTime: string
}

export interface UpdateScheduleData {
  /**
   * 备注
   */
  dataDescribe: string
  /**
   * 结束工作时间
   */
  endWorkTime: string
  /**
   * ID
   */
  id: string
  /**
   * 是否有休息时间
   */
  isRest: number
  /**
   * 休息时间集合
   */
  restTimeData: { startRestTime: string; endRestTime: string }[]
  /**
   * 班次名称
   */
  scheduleName: string
  /**
   * 开始工作时间
   */
  startWorkTime: string
}

export interface DeleteScheduleData {
  /**
   * 班次ID
   */
  id: string
}

export type GetProductionProjectParams = BasicPageParams & {
  /**
   * 项目状态（1：启用；2：停用；），默认不传
   */
  orderStatus?: number
  /**
   * 项目名称
   */
  projectName?: string
}

export interface GetProductionProjectModel {
  createTime?: string
  createUserID?: string
  dataDescribe?: null
  dataStatus?: number
  id: string
  lastModifiedTime?: string
  lastModifiedUserID?: string
  projectName?: string
}

export interface AddProductionProjectData {
  dataDescribe: string
  projectName: string
  orderStatus: number
}

export type GetStandardWorkTimeByProcessIDParams = {
  /**
   * 需求分类
   */
  orderNo: string
  /**
   * 部件名称
   */
  productName: string
  /**
   * 项目ID
   */
  projectID: string
}

export interface GetStandardWorkTimeByProcessIDModel {
  /**
   * 主键ID
   */
  id: string
  /**
   * 工序产能
   */
  processCapacity: number
  /**
   * 工序ID
   */
  processID: string
  /**
   * 工序名称
   */
  processName: null
  /**
   * 标准工时
   */
  standardWorkHour: number | number
  /**
   * 作业人数
   */
  workNumber: number
}
export interface UpdateProductionProjectData {
  orderStatus: number
  /**
   * 数据描述
   */
  dataDescribe: string
  /**
   * 生产计划项名称
   */
  projectName: string
  /**
   * 生产计划项ID
   */
  id: string
}

export interface DeleteProductionProjectData {
  /**
   * 生产计划项目ID
   */
  id: string
}

export interface GetProductionNodeModel {
  createTime: string
  createUserID: string
  dataDescribe: string
  dataStatus: number
  /**
   * 节点ID
   */
  id: string
  lastModifiedTime: string
  lastModifiedUserID: string
  /**
   * 节点名称
   */
  productionNodeName: string
}

export interface AddProductionNodeData {
  /**
   * 数据描述
   */
  dataDescribe: string
  /**
   * 生产节点名称
   */
  productionNodeName: string
}

export interface UpdateProductionNodeData {
  /**
   * 数据描述
   */
  dataDescribe: string
  /**
   * 节点ID
   */
  id: string
  /**
   * 节点名称
   */
  productionNodeName: string
}

export interface DeleteProductionNodeData {
  /**
   * ID
   */
  id: string
}

export type GetStandardWorkTimeParams = BasicPageParams & {
  /**
   * 编码
   */
  CodeNumber?: string
  /**
   * 结束制定日期
   */
  EndManufactureDate?: string
  /**
   * 需求分类
   */
  OrderNo?: string
  /**
   * 设备名称
   */
  OrderProductName?: string
  /**
   * 设备类型ID =顶级工序ID
   */
  ParentProcessID?: string
  /**
   * 部件名称
   */
  ProductName?: string
  /**
   * 项目ID
   */
  ProjectID?: string
  /**
   * 开始制定日期
   */
  StartManufactureDate?: string
  /**
   * 单据编号
   */
  WoNo?: string
  /**
   * 是否只显示未填部件，选中为true
   */
  IsBeFilled?: boolean
  /**
   * 是否显示隐藏工单，选中为true
   */
  IsShowExclude?: boolean
}

export interface GetStandardWorkTimeModel {
  /**
   * 编码
   */
  codeNumber?: string
  createTime?: string
  createUserID?: string
  createUserName?: string
  dataDescribe?: null
  dataStatus?: number
  /**
   * 主键ID
   */
  id: string
  lastModifiedTime?: string
  lastModifiedUserID?: string
  lastModifiedUserName?: string
  /**
   * 制定日期
   */
  manufactureDate?: string
  /**
   * 需求分类
   */
  orderNo?: string
  /**
   * 设备名称
   */
  orderProductName?: string
  /**
   * 设备类型ID
   */
  parentProcessID?: string
  /**
   * 设备类型名称
   */
  parentProcessName?: string
  /**
   * 部件名称
   */
  productName?: string
  /**
   * 项目ID
   */
  projectID?: string
  /**
   * 项目名称
   */
  projectName?: string
  /**
   * 报工计算方式(1:按工时 2:按数量)
   */
  reportFinishType?: number
  /**
   * 标准工时作业流程
   */
  standardWorkTimeClassifyModel: StandardWorkTimeClassifyModel[]
  /**
   * 合计标准工时
   */
  sumStandardWorkHour?: number
  /**
   * 单据编号
   */
  woNo?: string
}

export interface StandardWorkTimeClassifyModel {
  /**
   * ID
   */
  id: string
  /**
   * 工序产能
   */
  processCapacity: number
  /**
   * 工序ID
   */
  processID: string
  /**
   * 工序名称
   */
  processName: string
  /**
   * 标准工时
   */
  standardWorkHour: number
  /**
   * 作业人数
   */
  workNumber: number
  /**
   * 备注
   */
  dataDescribe?: string
}

export interface CopyStandardWorkTimeData {
  /**
   * 编码
   */
  codeNumber: string
  /**
   * 备注
   */
  dataDescribe?: string
  /**
   * 制定日期
   */
  manufactureDate: string
  /**
   * 目标部件名称
   */
  productName: string
  /**
   * 源记录主键ID
   */
  sourceID: string
}

export interface AddStandardWorkTimeData {
  /**
   * 编码
   */
  codeNumber: string
  /**
   * 需求分类
   */
  orderNo: string
  /**
   * 制定日期
   */
  manufactureDate: string
  /**
   * 设备类型ID
   */
  parentProcessID: string
  /**
   * 部件名称
   */
  productName: string
  /**
   * 项目ID
   */
  projectID: string
  /**
   * 报工计算方式(1:按工时 2:按数量)
   */
  reportFinishType: number
  /**
   * 单据编号
   */
  woNo: string
  addStandardworkTimeModel: AddStandardWorkTimeModel[]
}

export interface AddStandardWorkTimeModel {
  /**
   * 数据描述
   */
  dataDescribe?: string
  /**
   * 工序产能
   */
  processCapacity: number
  /**
   * 工序ID
   */
  processID: string
  /**
   * 标准工时
   */
  standardWorkHour: number
  /**
   * 作业人数
   */
  workNumber: number
}

export interface UpdateStandardWorkTimeData {
  /**
   * 编码
   */
  codeNumber: string
  /**
   * 主键ID
   */
  id: string
  /**
   * 制定日期
   */
  manufactureDate: string
  /**
   * 报工计算方式(1:按工时 2:按数量)
   */
  reportFinishType: number
  /**
   * model集合
   */
  updateStandardworkTimeModel: UpdateStandardworkTimeModel[]
}

export interface UpdateStandardworkTimeModel {
  /**
   * 备注
   */
  dataDescribe?: string
  /**
   * 主键ID，新增时填0
   */
  id?: string
  /**
   * 工序产能
   */
  processCapacity?: number
  /**
   * 工序ID
   */
  processID?: string
  /**
   * 标准工时
   */
  standardWorkHour?: number
  /**
   * 作业人数
   */
  workNumber?: number
}

export interface DeleteStandardWorkTimeData {
  /**
   * 需求分类
   */
  orderNo: string
  /**
   * 设备类型ID
   */
  parentProcessID: string
  /**
   * 部件名称
   */
  productName: string
  /**
   * 项目ID
   */
  projectID: string
}

export interface AddStandardWorkTimeWoExIncludeData {
  /**
   * 需求分类
   */
  orderNo: string
  /**
   * 部件名称
   */
  productName: string
  /**
   * 项目ID
   */
  projectID: string
}

export interface DeleteStandardWorkTimeWoExIncludeData {
  /**
   * 需求分类
   */
  orderNo: string
  /**
   * 设备类型ID
   */
  parentProcessID: string
  /**
   * 部件名称
   */
  productName: string
  /**
   * 项目ID
   */
  projectID: string
}
export interface AddConfirmSignatureTypeData {
  /**
   * 审批方式（1：或签；2：会签；3：依次审批）
   */
  approvalMethod: number
  /**
   * 审批人
   */
  employeeInfoId: string[]
  /**
   * 应用名称，对应SSO获取菜单接口的Name
   */
  typeModuleName: string
  /**
   * 应用名称，对应SSO获取菜单接口的Title
   */
  typeModuleTitle: string
}
export interface UpdateConfirmSignatureTypeData {
  /**
   * 审批方式（1：或签；2：会签；3：依次审批）
   */
  approvalMethod: number
  /**
   * 审批人
   */
  employeeInfoId: string[]
  /**
   * 主键ID
   */
  id: string
  /**
   * 应用名称，对应SSO获取菜单接口的Name
   */
  typeModuleName: string
  /**
   * 应用名称，对应SSO获取菜单接口的Title
   */
  typeModuleTitle: string
}

export interface GetProductionVersionModel {
  /**
   * 确认人
   */
  confirmUserName: string
  createTime: string
  createUserID: string
  dataDescribe: null | string
  dataStatus: number
  /**
   * 计划版本主键ID
   */
  id: string
  /**
   * 最后更新时间
   */
  lastModifiedTime: string
  lastModifiedUserID: string
  /**
   * 操作人
   */
  lastModifiedUserName: string
  /**
   * 版本状态（0：待确认；1：已确认，2：已作废）
   */
  orderStatus: number
  /**
   * 设备类型
   */
  processName: string
  /**
   * 设备名称
   */
  productName: string
  /**
   * 项目ID
   */
  projectID: string
  /**
   * 版本号
   */
  versionNo: string
  /**
   * 单据编号
   */
  woNo: string
}

export interface GetGroupByDepartmentNameModel {
  children?: GetGroupByDepartmentNameModel[]
  childrenCount: number
  id: string
  isGroup: boolean
  name: string
}

export interface GetManufactureDepartmentListModel {
  /**
   * 部门ID
   */
  id: string
  /**
   * 部门名称
   */
  name: string
}

export interface GetGroupLeaderModel {
  /**
   * 组长ID
   */
  leaderID: string
  /**
   * 组长姓名
   */
  leaderName: string
}

export interface GetConfirmSignatureTypeModel {
  /**
   * 审批方式（1：或签；2：会签；3：依次审批）
   */
  approvalMethod: number
  /**
   * 审批人
   */
  confirmationPersonJson?: ConfirmationPersonJson
  createTime?: string
  createUserID?: string
  dataDescribe?: null
  dataStatus?: number
  /**
   * 主键ID
   */
  id: string
  lastModifiedTime?: string
  lastModifiedUserID?: string
  /**
   * 操作人
   */
  lastModifiedUserName: string
  /**
   * 应用名称，对应SSO获取菜单接口的Name
   */
  typeModuleName?: string
  /**
   * 应用名称，对应SSO获取菜单接口的Title
   */
  typeModuleTitle: string
}

/**
 * 审批人
 */
export interface ConfirmationPersonJson {
  /**
   * 员工名称
   */
  employeeName: string
  /**
   * 员工工号
   */
  employeeNo: string
  /**
   * 员工ID
   */
  id: number
}

export interface GetEmployeeInfoBySelectModel {
  /**
   * 创建时间
   */
  createTime: string
  /**
   * 创建人
   */
  createUserID: string
  dataDescribe: null | string
  /**
   * 数据状态
   */
  dataStatus: number
  /**
   * 部门ID
   */
  departmentID: string
  /**
   * 部门
   */
  departmentName: string
  /**
   * 员工名称
   */
  employeeName: string
  /**
   * 员工工号
   */
  employeeNo: string
  /**
   * 组别ID
   */
  groupID: string
  /**
   * 组别
   */
  groupName: string
  /**
   * 员工ID
   */
  id: string
  /**
   * 修改时间
   */
  lastModifiedTime: string
  /**
   * 修改人
   */
  lastModifiedUserID: string
  /**
   * 岗位ID
   */
  positionID: string
  /**
   * 岗位
   */
  positionName: string
  /**
   * 厂区位置
   */
  productionAddressName: string
  /**
   * 借调状态(0：""；1：借调中)
   */
  transferInStatus: number
}
export interface AddPositionClassifyData {
  dataDescribe?: string
  /**
   * 岗位分类ID，对应字典表岗位分类
   */
  positionClassifyID: string
  /**
   * 岗位ID，对应字典表岗位定义
   */
  positionID: string
}
export interface UpdatePositionClassifyData {
  /**
   * 备注
   */
  dataDescribe?: string
  /**
   * ID
   */
  id: string
  /**
   * 岗位分类ID，对应字典表岗位分类
   */
  positionClassifyID: string
}

export interface GetMessageModel {
  /**
   * 消息创建时间
   */
  createTime?: string
  createUserID?: string
  dataDescribe?: null
  dataStatus?: number
  /**
   * 发送者ID
   */
  fromEmployeeID?: string
  /**
   * 主键ID
   */
  id: string
  lastModifiedTime?: string
  lastModifiedUserID?: string
  /**
   * 消息内容
   */
  messageContent?: string
  /**
   * 消息标题
   */
  messageTitle?: string
  /**
   * 系统模块名称
   */
  moduleName?: string
  /**
   * 本地消息状态(1:未读,2:已读,3:发送失败)
   */
  readStatus?: number
  /**
   * 接受者ID
   */
  toEmployeeID?: string
}
export interface AddMessageData {
  /**
   * 发送人ID
   */
  fromEmployeeID: number
  /**
   * 消息内容
   */
  messageContent: string
  /**
   * 消息标题
   */
  messageTitle: string
  /**
   * 系统模块名称
   */
  moduleName: string
  /**
   * 接收人ID
   */
  toEmployeeID: number
}
export interface UpdataMessageData {
  /**
   * 是否全部标记为已读
   */
  allMessageRead: boolean
  /**
   * 消息主键ID，allMessageRead为true时传0，allMessageRead为false时传消息主键ID
   */
  id: string
}

export interface GetNoticeMngtModel {
  createTime: string
  createUserID: string
  dataDescribe: null
  dataStatus: number
  designatedEmployeeJson: DesignatedEmployeeJson[]
  /**
   * 通知指定人员名称
   */
  designatedEmployeeName: string
  /**
   * 是否使用钉钉通知(0:否,1:是)
   */
  dingTalkNotice: number
  /**
   * 主键ID
   */
  id: string
  /**
   * 最后更新时间
   */
  lastModifiedTime: string
  lastModifiedUserID: string
  /**
   * 操作人
   */
  lastModifiedUserName: string
  /**
   * 是否使用本地通知(0:否,1:是)
   */
  localNotice: number
  /**
   * 消息类型ID，对应字典表消息类型
   */
  messageTypeID: string
  /**
   * 消息类型名称
   */
  messageTypeName: string
  /**
   * 通知人员(1:班组长,2:部门经理,3:指定人员)
   */
  noticeEmployeeType: number
  /**
   * 通知人员名称
   */
  noticeEmployeeTypeName: string
  /**
   * 通知频率(1:触发执行,2:定期执行)
   */
  noticeFrequency: number
  /**
   * 定期执行天数
   */
  noticeFrequencyDay: number
  /**
   * 通知频率名称
   */
  noticeFrequencyName: string
  /**
   * 定期执行时间(格式: HH:mm,如08:00)
   */
  noticeFrequencyTime: string
  /**
   * 通知方式
   */
  noticeMessageType: string
  /**
   * 状态（1：启用；2：停用）
   */
  orderStatus: number
}

export interface DesignatedEmployeeJson {
  /**
   * 员工姓名
   */
  employeeName: string
  /**
   * 员工工号
   */
  employeeNo: string
  /**
   * 员工ID
   */
  id: string
}

export interface AddNoticeMngtData {
  /**
   * 通知指定人员ID
   */
  designatedEmployeeID: string[]
  /**
   * 是否使用钉钉通知(0:否,1:是)
   */
  dingTalkNotice: number
  /**
   * 是否使用本地通知(0:否,1:是)
   */
  localNotice: number
  /**
   * 消息类型ID，对应字典表消息类型
   */
  messageTypeID: string
  /**
   * 通知人员(1:班组长,2:部门经理,3:指定人员)
   */
  noticeEmployeeType: number
  /**
   * 通知频率(1:触发执行,2:定期执行)
   */
  noticeFrequency: number
  /**
   * 定期执行天数
   */
  noticeFrequencyDay: number
  /**
   * 定期执行时间(格式: HH:mm,如08:00)
   */
  noticeFrequencyTime: string
  /**
   * 状态（1：启用；2：停用）
   */
  orderStatus: number
}
export interface UpdateNoticeMngtData {
  /**
   * 通知指定人员ID
   */
  designatedEmployeeID: string[]
  /**
   * 是否使用钉钉通知(0:否,1:是)
   */
  dingTalkNotice: number
  /**
   * 主键ID
   */
  id: string
  /**
   * 是否使用本地通知(0:否,1:是)
   */
  localNotice: number
  /**
   * 通知人员(1:班组长,2:部门经理,3:指定人员)
   */
  noticeEmployeeType: number
  /**
   * 通知频率(1:触发执行,2:定期执行)
   */
  noticeFrequency: number
  /**
   * 定期执行天数
   */
  noticeFrequencyDay: number
  /**
   * 定期执行天数
   */
  noticeFrequencyTime: string
  /**
   * 状态（1：启用；2：停用）
   */
  orderStatus: number
}
export interface DeleteNoticeMngtData {
  id: string
}
export interface GetMessageNoticeTypeModel {
  /**
   * 字典表主键ID
   */
  id: string
  /**
   * 消息类型标识值
   */
  key: string
  /**
   * 消息类型名称
   */
  name: string
}

export interface GetOrderAutoConfirmModel {
  /**
   * 确认人ID
   */
  confirmEmployeeId?: string
  /**
   * 确认人名称
   */
  confirmEmployeeName?: string
  /**
   * 单据指定申请人员集合
   */
  createOrderEmployeeJson?: CreateOrderEmployeeJson[]
  /**
   * 单据指定申请人员
   */
  createOrderEmployeeName?: string
  createTime?: string
  createUserId?: string
  dataDescribe?: null
  dataStatus?: number
  /**
   * 单据确认部门ID
   */
  departmentId?: string
  /**
   * 单据确认部门名称
   */
  departmentName?: string
  /**
   * 单据确认班组ID
   */
  groupId?: string
  /**
   * 单据确认班组名称
   */
  groupName?: string
  /**
   * 主键ID
   */
  id: string
  /**
   * 最后更新时间
   */
  lastModifiedTime?: string
  lastModifiedUserId?: string
  /**
   * 操作人
   */
  lastModifiedUserName?: string
  /**
   * 单据类型(考勤登记：Attendance；人员借调：Secondment；生产报工：WorkReport)
   */
  moduleName?: string
  /**
   * 状态（1：启用；2：停用）
   */
  orderStatus: number
  /**
   * 单据自动确认超时时间
   */
  overTime?: number
}

export interface CreateOrderEmployeeJson {
  /**
   * 姓名
   */
  employeeName: string
  /**
   * 工号
   */
  employeeNo: string
  /**
   * 员工ID
   */
  id: string
}

export interface AddOrderAutoConfirmData {
  /**
   * 确认人ID
   */
  confirmEmployeeId: string
  /**
   * 单据指定申请人员Json
   */
  createOrderEmployeeId?: string[]
  /**
   * 单据确认部门ID
   */
  departmentId: string
  /**
   * 单据确认班组ID
   */
  groupId: string
  /**
   * 单据类型(考勤登记：Attendance；人员借调：Secondment；生产报工：WorkReport)
   */
  moduleName: string
  /**
   * 状态（1：启用；2：停用）
   */
  orderStatus: number
  /**
   * 单据自动确认超时时间
   */
  overTime: number
}

export interface UpdateOrderAutoConfirmData {
  /**
   * 单据指定申请人员
   */
  createOrderEmployeeId?: string[]
  /**
   * 单据确认部门ID
   */
  departmentId: string
  /**
   * 单据确认班组ID
   */
  groupId: string
  /**
   * 主键ID
   */
  id: string
  /**
   * 状态（1：启用；2：停用）
   */
  orderStatus: number
  /**
   * 单据自动确认超时时间
   */
  overTime: number
}

export type GetEmployeeByAttendanceDateParams = {
  /**
   * 考勤日期，不传使用当天日期
   */
  AttendanceDate?: string
  /**
   * 部门ID
   */
  DepartmentID?: string
  /**
   * 班组ID
   */
  GroupID?: string
  /**
   * 岗位类型ID
   */
  PositionClassifyID?: string[]
}

export interface GetEmployeeByAttendanceDateModel {
  departmentName: string
  employeeName: string
  employeeNo: string
  groupName: string
  positionName: string
}

/**
 * 请求列表返回值
 */
export type EmployeeListGetResultModel = BasicFetchResult<GetEmployeeInfoModel>
export type EmployeeByGroupIDListGetResultModel = BasicFetchResult<GetEmployeeInfoByGroupIDModel>
export type DepartmentListGetResultModel = BasicFetchResult<GetDepartmentModel>
export type GroupListByDepartmentNameGetResultModel = GetGroupByDepartmentNameModel[]
export type GroupListGetResultModel = BasicFetchResult<GetGroupModel>
export type GroupSelectListGetResultModel = BasicFetchResult<SelectModel>
export type PositionLevelListGetResultModel = BasicFetchResult<GetPositionLevelModel>
export type DictionaryListGetResultModel = BasicFetchResult<GetDictionaryModel>
export type DictionaryClassifyListGetResultModel = BasicFetchResult<GetDictionaryClassifyModel>
export type ProductionLineListGetResultModel = BasicFetchResult<GetProductionLineModel>
export type ProductionProcessListGetResultModel = BasicFetchResult<GetProductionProcessModel>
export type ScheduleListGetResultModel = BasicFetchResult<GetScheduleModel>
export type ProductionProjectListGetResultModel = BasicFetchResult<GetProductionProjectModel>
export type StandardWorkTimeListGetResultModel = BasicFetchResult<GetStandardWorkTimeModel>
export type ProductionNodeListGetResultModel = BasicFetchResult<GetProductionNodeModel>
export type ProductionVersionModelListGetResultModel = BasicFetchResult<GetProductionVersionModel>
export type GroupLeaderListGetResultModel = BasicFetchResult<GetGroupLeaderModel>
export type ConfirmSignatureTypeListGetResultModel = BasicFetchResult<GetConfirmSignatureTypeModel>
export type EmployeeInfoBySelectListGetResultModel = BasicFetchResult<GetEmployeeInfoBySelectModel>
export type PositionClassifyListGetResultModel = BasicFetchResult<GetPositionClassifyModel>
export type ManufactureGroupListGetResultModel = BasicFetchResult<{ id: string; name: string }>
export type StandardWorkTimeByProcessIDtGetResultModel =
  BasicFetchResult<GetStandardWorkTimeByProcessIDModel>
export type MessageGetResultModel = BasicFetchResult<GetMessageModel>
export type NoticeMngtGetResultModel = BasicFetchResult<GetNoticeMngtModel>
export type MessageNoticeTypeGetResultModel = BasicFetchResult<GetMessageNoticeTypeModel>
export type OrderAutoConfirmListGetResultModel = BasicFetchResult<GetOrderAutoConfirmModel>
export type EmployeeByAttendanceDateGetResultModel = GetEmployeeByAttendanceDateModel[]
