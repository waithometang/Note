import hynRequest from '@/utils/http'
import type {
  AddProductionOrderData,
  GetProductionOrderByProjectIDModel,
  GetProductionOrderByProjectIDParams,
  GetProductionOrderParams,
  ProductionOrderListByProjectIDGetResultModel,
  ProductionOrderListGetResultModel,
  ProductionProjectAppointDataGetResultModel,
  ProductionWoAndProductGetResultModel,
  ProjectAndProductNameListGetResultModel,
  UpdateProductionOrderData
} from './model/schedulingModel'
import type {
  GetProductionProjectParams,
  GetStandardWorkTimeByProcessIDParams,
  StandardWorkTimeByProcessIDtGetResultModel
} from './model/basicModel'

/**
 * 根据项目ID获取工单数据
 */
export const getProductionProjectAppointData = (params: { projectID: string; orderNo?: string }) => {
  return hynRequest.request<ProductionProjectAppointDataGetResultModel>({
    url: '/ProductionProject/GetProductionProjectAppointData',
    method: 'get',
    params
  })
}

/**
 * 查询所有项目和订单设备列表
 */
export const getProjectAndProductName = (params: { orderStatus: number }) => {
  return hynRequest.request<ProjectAndProductNameListGetResultModel>({
    url: '/ProductionProject/GetProjectAndProductName',
    method: 'get',
    params
  })
}

/**
 * 获取指定项目的需求分类、设备类型和名称
 */
export const getProductionOrderByProjectID = (params: GetProductionOrderByProjectIDParams) => {
  return hynRequest.request<GetProductionOrderByProjectIDModel[]>({
    url: '/ProductionProject/GetProductionOrderByProjectID',
    method: 'get',
    params: params
  })
}
/**
 * 查询订单和设备
 */
export const getProductionOrder = (params: GetProductionOrderParams) => {
  return hynRequest.request<ProductionOrderListGetResultModel>({
    url: '/ProductionProject/GetProductionOrder',
    method: 'get',
    params: params
  })
}
/**
 * 添加订单和设备
 */
export const addProductionOrder = (data: AddProductionOrderData) => {
  return hynRequest.request<boolean>({
    url: '/ProductionProject/AddProductionOrder',
    method: 'post',
    data: data
  })
}
/**
 * 修改订单和设备
 */
export const updateProductionOrder = (data: UpdateProductionOrderData) => {
  return hynRequest.request<boolean>({
    url: '/ProductionProject/UpdateProductionOrder',
    method: 'post',
    data: data
  })
}
/**
 * 删除订单和设备
 */
export const deleteProductionOrder = (data: { id: string }) => {
  return hynRequest.request<boolean>({
    url: '/ProductionProject/DeleteProductionOrder',
    method: 'post',
    data: data
  })
}

/**
 * 查询所有工单的需求分类、单据编号和部件名称
 */
export const getProductionWoAndProduct = () => {
  return hynRequest.request<ProductionWoAndProductGetResultModel>({
    url: '/ProductionWo/GetProductionWoAndProduct',
    method: 'get'
  })
}

/**
 * 导出生产计划项目
 */
export const exportProductionProject = (params: GetProductionProjectParams) => {
  return hynRequest.request<BlobPart>({
    url: '/ProductionProject/ExportProductionProject',
    method: 'get',
    params,
    responseType: 'blob',
    isReturnNativeResponse: true
  })
}
/**
 * 导出项目管理导入模版
 */
export const exportTemplate = () => {
  return hynRequest.request<BlobPart>({
    url: '/ProductionProject/ExportTemplate',
    method: 'get',
    responseType: 'blob',
    isReturnNativeResponse: true
  })
}

/**
 * 获取指定设备类型的标准工时
 */
export const getStandardWorkTimeByProcessID = (params: GetStandardWorkTimeByProcessIDParams) => {
  return hynRequest.request<StandardWorkTimeByProcessIDtGetResultModel>({
    url: '/StandardWorkTime/GetStandardWorkTimeByProcessID',
    method: 'get',
    params
  })
}
