import hynRequest from '@/utils/http'

import type {
  AddSoftwareProjectData,
  AddSoftwareReportData,
  AddSoftwareVersiontData,
  GetSoftwareProjectParams,
  GetCurrentSoftwareVersionParams,
  UpdateSoftwareVersiontData,
  CurrentSoftwareVersionGetResultModel,
  SoftwareProjectGetResultModel,
  GetSoftwareVersionParams,
  SoftwareVersionGetResultModel,
  SoftwareReportGetResultModel,
  GetSoftwareReportParams,
  UpdateSoftwareProjectData,
  GetHistorySoftwareVersionParams,
  HistorySoftwareVersionGetResultModel
} from './model/versionMngtModel'

/**
 * 查询软件项目信息
 */
export const getSoftwareProject = (params?: GetSoftwareProjectParams) => {
  return hynRequest.request<SoftwareProjectGetResultModel>({
    url: '/SoftwareProject/GetSoftwareProject',
    method: 'get',
    params
  })
}

/**
 * 添加软件项目信息
 */
export const addSoftwareProject = (data: AddSoftwareProjectData) => {
  return hynRequest.request<boolean>({
    url: '/SoftwareProject/AddSoftwareProject',
    method: 'post',
    data
  })
}

/**
 * 修改软件项目信息
 */
export const updateSoftwareProject = (data: UpdateSoftwareProjectData) => {
  return hynRequest.request<boolean>({
    url: '/SoftwareProject/UpdateSoftwareProject',
    method: 'post',
    data
  })
}

/**
 * 查询软件项目当前使用版本信息
 */
export const getCurrentSoftwareVersion = (params: GetCurrentSoftwareVersionParams) => {
  return hynRequest.request<CurrentSoftwareVersionGetResultModel>({
    url: '/SoftwareVersion/GetCurrentSoftwareVersion',
    method: 'get',
    params
  })
}

/**
 * 添加软件版本信息
 */
export const addSoftwareVersion = (data: AddSoftwareVersiontData) => {
  return hynRequest.request<boolean>({
    url: '/SoftwareVersion/AddSoftwareVersion',
    method: 'post',
    data
  })
}

/**
 * 修改软件版本控制状态信息
 */
export const updateSoftwareVersionStatus = (data: UpdateSoftwareVersiontData) => {
  return hynRequest.request<boolean>({
    url: '/SoftwareVersion/UpdateSoftwareVersionStatus',
    method: 'post',
    data
  })
}

/**
 * 添加软件报告信息
 */
export const addSoftwareReport = (data: AddSoftwareReportData) => {
  return hynRequest.request<boolean>({
    url: '/SoftwareReport/AddSoftwareReport',
    method: 'post',
    data
  })
}

/**
 * 查询所有软件版本信息
 */
export const getSoftwareVersion = (params: GetSoftwareVersionParams) => {
  return hynRequest.request<SoftwareVersionGetResultModel>({
    url: '/SoftwareVersion/GetSoftwareVersion',
    method: 'get',
    params
  })
}

/**
 * 下载软件版本
 */
export const loadSoftwareVersion = (data: { id: string }) => {
  return hynRequest.request<BlobPart>({
    url: '/SoftwareVersion/LoadSoftwareVersion',
    method: 'post',
    data,
    responseType: 'blob',
    isReturnNativeResponse: true
  })
}

/**
 * 获取软件测试报告
 */
export const getSoftwareReport = (params: GetSoftwareReportParams) => {
  return hynRequest.request<SoftwareReportGetResultModel>({
    url: '/SoftwareReport/GetSoftwareReport',
    method: 'get',
    params
  })
}

/**
 * 下载软件测试报告
 */
export const loadSoftwareReport = (data: { id: string }) => {
  return hynRequest.request<BlobPart>({
    url: '/SoftwareReport/LoadSoftwareReport',
    method: 'post',
    data,
    responseType: 'blob',
    isReturnNativeResponse: true
  })
}

/**
 * 查询历史版本
 */
export const getHistorySoftwareVersion = (params: GetHistorySoftwareVersionParams) => {
  return hynRequest.request<HistorySoftwareVersionGetResultModel>({
    url: '/SoftwareVersion/GetHistorySoftwareVersion',
    method: 'get',
    params
  })
}

/**
 * 获取所有版本
 * @param params
 * @returns
 */
export const getAllSoftwareVersion = (params: GetCurrentSoftwareVersionParams) => {
  return hynRequest.request<CurrentSoftwareVersionGetResultModel>({
    url: 'SoftwareVersion/GetAllSoftwareVersion',
    method: 'get',
    params
  })
}
