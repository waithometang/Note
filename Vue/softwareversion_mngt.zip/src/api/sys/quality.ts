import hynRequest from '@/utils/http'
import type {
  GetIPQCParams,
  IPQCListGetResultModel,
  ADDIPQCData,
  GetExceptionTypeParams,
  ExceptionTypeListGetResultModel,
  UpdateExceptionTypeData,
  DeleteExceptionTypeData,
  AddExceptionTypeData,
  ExceptionByTypeIDListGetResultModel,
  GetExceptionByTypeIDParams,
  UpdateIPQCData,
  DeleteIPQCData
} from './model/qualityModel'

/**
 * 获取IPQC信息
 */
export const getIPQC = (params: GetIPQCParams) => {
  return hynRequest.request<IPQCListGetResultModel>({
    url: '/IPQC/GetIPQC',
    method: 'get',
    params
  })
}

/**
 * 添加IPQC
 */
export const addIPQC = (data: ADDIPQCData) => {
  return hynRequest.request<boolean>({
    url: '/IPQC/AddIPQC',
    method: 'post',
    data
  })
}

/**
 * 编辑IPQC
 */
export const updateIPQC = (data: UpdateIPQCData) => {
  return hynRequest.request<boolean>({
    url: '/IPQC/UpdateIPQC',
    method: 'post',
    data
  })
}

/**
 * 删除IPQC
 */
export const deleteIPQC = (data: DeleteIPQCData) => {
  return hynRequest.request<boolean>({
    url: '/IPQC/DeleteIPQC',
    method: 'post',
    data
  })
}

/**
 * 导出IPQC
 */
export const exportIPQC = (params: GetIPQCParams) => {
  return hynRequest.request<BlobPart>({
    url: '/IPQC/ExportIPQC',
    method: 'get',
    params,
    responseType: 'blob',
    isReturnNativeResponse: true
  })
}

/**
 * 查询异常分类信息
 */
export const getExceptionType = (params: GetExceptionTypeParams) => {
  return hynRequest.request<ExceptionTypeListGetResultModel>({
    url: '/ExceptionType/GetExceptionType',
    method: 'get',
    params
  })
}

/**
 * 通过类型ID查询异常分类信息
 */
export const getExceptionByTypeID = (params: GetExceptionByTypeIDParams) => {
  return hynRequest.request<ExceptionByTypeIDListGetResultModel>({
    url: '/ExceptionType/GetExceptionByTypeID',
    method: 'get',
    params
  })
}

/**
 * 添加异常分类信息
 */
export const addExceptionType = (data: AddExceptionTypeData) => {
  return hynRequest.request<boolean>({
    url: '/ExceptionType/AddExceptionType',
    method: 'post',
    data
  })
}

/**
 * 更新异常分类信息
 */
export const updateExceptionType = (data: UpdateExceptionTypeData) => {
  return hynRequest.request<boolean>({
    url: '/ExceptionType/UpdateExceptionType',
    method: 'post',
    data
  })
}

/**
 * 删除异常分类信息
 */
export const deleteExceptionType = (data: DeleteExceptionTypeData) => {
  return hynRequest.request<boolean>({
    url: '/ExceptionType/DeleteExceptionType',
    method: 'post',
    data
  })
}
