import hynRequest from '@/utils/http'
import type {
  AttendanceSystemUsageGetResultModel,
  DispatchingGroupSystemUsageGetResultModel,
  DispatchingOtherSystemUsageGetResultModel,
  EmployeeTransferSystemUsageGetResultModel,
  GetSystemUsageParams,
  ProductivitySystemUsageGetResultModel,
  ReportWorkOtherSystemUsageGetResultModel,
  ReportWorkSystemUsageGetResultModel,
  WorkErrorReportSystemUsageGetResultModel
} from './model/reportMngtModel'

/**
 * 系统使用情况 ->考勤 查询
 */
export const getAttendanceSystemUsage = (params: GetSystemUsageParams) => {
  return hynRequest.request<AttendanceSystemUsageGetResultModel>({
    url: '/SystemUsage/GetAttendanceSystemUsage',
    method: 'get',
    params: params
  })
}

/**
 * 系统使用情况 ->人员借调 查询
 */
export const getEmployeeTransferSystemUsage = (params: GetSystemUsageParams) => {
  return hynRequest.request<EmployeeTransferSystemUsageGetResultModel>({
    url: '/SystemUsage/GetEmployeeTransferSystemUsage',
    method: 'get',
    params: params
  })
}

/**
 * 系统使用情况 ->组内派工 查询
 */
export const getDispatchingGroupSystemUsage = (params: GetSystemUsageParams) => {
  return hynRequest.request<DispatchingGroupSystemUsageGetResultModel>({
    url: '/SystemUsage/GetDispatchingGroupSystemUsage',
    method: 'get',
    params: params
  })
}

/**
 * 系统使用情况 ->其他派工 查询
 */
export const getDispatchingOtherSystemUsage = (params: GetSystemUsageParams) => {
  return hynRequest.request<DispatchingOtherSystemUsageGetResultModel>({
    url: '/SystemUsage/GetDispatchingotherSystemUsage',
    method: 'get',
    params: params
  })
}

/**
 * 系统使用情况 ->生产报工 查询
 */
export const getReportWorkSystemUsage = (params: GetSystemUsageParams) => {
  return hynRequest.request<ReportWorkSystemUsageGetResultModel>({
    url: '/SystemUsage/GetReportWorkSystemUsage',
    method: 'get',
    params: params
  })
}

/**
 * 系统使用情况 ->其他报工 查询
 */
export const getReportWorkOtherSystemUsage = (params: GetSystemUsageParams) => {
  return hynRequest.request<ReportWorkOtherSystemUsageGetResultModel>({
    url: '/SystemUsage/GetReportWorkOtherSystemUsage',
    method: 'get',
    params: params
  })
}

/**
 * 系统使用情况 ->生产异常 查询
 */
export const getWorkErrorReportSystemUsage = (params: GetSystemUsageParams) => {
  return hynRequest.request<WorkErrorReportSystemUsageGetResultModel>({
    url: '/SystemUsage/GetExceptionRecordSystemUsage',
    method: 'get',
    params: params
  })
}
/**
 * 系统使用情况 ->生产绩效 查询
 */
export const getProductivitySystemUsage = (params: GetSystemUsageParams) => {
  return hynRequest.request<ProductivitySystemUsageGetResultModel>({
    url: '/SystemUsage/GetPerformanceManagementSystemUsage',
    method: 'get',
    params: params
  })
}

/**
 * 系统使用情况 -> 导出所有模块
 */
export const exportSystemUsage = (params: GetSystemUsageParams) => {
  return hynRequest.request<BlobPart>({
    url: '/SystemUsage/ExportSystemUsage',
    method: 'get',
    params,
    responseType: 'blob',
    isReturnNativeResponse: true
  })
}
