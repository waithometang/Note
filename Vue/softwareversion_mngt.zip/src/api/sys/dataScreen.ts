import hynRequest from '@/utils/http'
import type {
  GetKanBanInfoParams,
  KanBanInfoListGetResultModel,
  AddKanBanInfoData,
  UpdateKanBanInfoData,
  DeleteKanBanInfoData,
  KanBanInfoByNameListGetResultModel,
  CustomImageImportResultModel
} from './model/dataScreenModel'
/**
 * 获取KanBanInfo信息
 */
export const getKanBanInfo = (params?: GetKanBanInfoParams) => {
  return hynRequest.request<KanBanInfoListGetResultModel>({
    url: '/KanBanInfo/GetKanBanInfo',
    method: 'get',
    params
  })
}

/**
 * 获取指定看板名称信息
 */
export const getKanBanInfoByName = (params: { name: string }) => {
  return hynRequest.request<KanBanInfoByNameListGetResultModel>({
    url: '/KanBanInfo/GetKanBanInfoByName',
    method: 'get',
    params
  })
}

/**
 * 添加KanBanInfo
 */
export const addKanBanInfo = (data: AddKanBanInfoData) => {
  return hynRequest.request<boolean>({
    url: '/KanBanInfo/AddKanBanInfo',
    method: 'post',
    data
  })
}

/**
 * 编辑KanBanInfo
 */
export const updateKanBanInfo = (data: UpdateKanBanInfoData) => {
  return hynRequest.request<boolean>({
    url: '/KanBanInfo/UpdateKanBanInfo',
    method: 'post',
    data
  })
}

/**
 * 删除KanBanInfo
 */
export const deleteKanBanInfo = (data: DeleteKanBanInfoData) => {
  return hynRequest.request<boolean>({
    url: '/KanBanInfo/DeleteKanBanInfo',
    method: 'post',
    data
  })
}

/**
 * 看板上传图片
 */
export const importCustomImage = (formData: any) => {
  return hynRequest.request<CustomImageImportResultModel>({
    url: '/KanBanInfo/ImportCustomImage',
    method: 'post',
    data: formData
  })
}
