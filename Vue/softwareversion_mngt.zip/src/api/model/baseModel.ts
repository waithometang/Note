export interface BasicPageParams {
  pageIndex?: number
  pageSize?: number
}

export interface BasicFetchResult<T> {
  result: T[]
  total: number
}

export interface SelectModel {
  label: string
  value: string
}
