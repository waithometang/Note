import type { BasicPageParams, BasicFetchResult } from '@/api/model/baseModel'

export type GetTaskInformationParams = BasicPageParams & {
  /**
   * 任务创建结束时间
   */
  EndCreateTime?: string
  /**
   * 项目名称
   */
  ProjectName?: string
  /**
   * 来源方式ID
   */
  SourceFormID?: number
  /**
   * 任务来源名称ID
   */
  SourceNameID?: number
  /**
   * 任务创建开始时间
   */
  StartCreateTime?: string
  /**
   * 任务名称
   */
  TaskName?: string
  /**
   * 任务状态
   */
  TaskStatus?: number
}

export interface GetTaskInformation {
  actualCompletionTime: string
  assignedIDList: string
  assignedName: string
  createTime: string
  createUserID: string
  createUserName: string
  dataDescribe: null
  dataStatus: number
  detailedDescription: string
  emergencyLevel: number
  extensionDays: number
  id: string
  lastModifiedTime: string
  lastModifiedUserID: string
  lastModifiedUserName: string
  plannedCompletionTime: string
  productName: string
  productNameID: string
  projectName: string
  projectNameID: string
  quotationAmount: number
  sourceForm: string
  sourceFormID: string
  sourceName: string
  sourceNameID: string
  sourceTime: string
  taskName: string
  taskStatus: number
}

export interface AddTaskInformationData {
  /**
   * 指派人ID集合
   */
  assignedIDList: string
  /**
   * 任务状态描述
   */
  dataDescribe?: string
  /**
   * 任务详细描述
   */
  detailedDescription?: string
  /**
   * 紧急程度
   */
  emergencyLevel: number
  /**
   * 计划完成时间
   */
  plannedCompletionTime: string
  /**
   * 产品名称ID
   */
  productNameID: string[]
  /**
   * 项目名称ID
   */
  projectNameID: string
  /**
   * 报价金额
   */
  quotationAmount?: number
  /**
   * 任务来源方式ID
   */
  sourceFormID: string
  /**
   * 任务来源名称ID
   */
  sourceNameID: string
  /**
   * 任务来源时间
   */
  sourceTime: string
  /**
   * 任务名称
   */
  taskName: string
}
export interface UpdateTaskInformationStatusData {
  /**
   * 任务状态描述
   */
  dataDescribe?: string
  /**
   * 被指派人ID集合
   */
  designeeIDList?: string
  /**
   * 任务id
   */
  id: string
  /**
   * 计划完成时间
   */
  plannedCompletionTime?: string
  /**
   * 报价金额
   */
  quotationAmount?: number
  /**
   * 提醒周期
   */
  reminderCycle?: number
  /**
   * 任务状态
   */
  taskStatus?: number
}

export type TaskInformationGetResultModel = BasicFetchResult<GetTaskInformation>
