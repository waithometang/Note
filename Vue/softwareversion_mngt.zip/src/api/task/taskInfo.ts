import hynRequest from '@/utils/http'
import type {
  AddTaskInformationData,
  GetTaskInformationParams,
  TaskInformationGetResultModel,
  UpdateTaskInformationStatusData
} from './model/taskInfoModel'
/**
 * 获取任务信息
 */
export const getTaskInformation = (params?: GetTaskInformationParams) => {
  return hynRequest.request<TaskInformationGetResultModel>({
    url: '/TaskInformation/GetTaskInformation',
    method: 'get',
    params
  })
}

/**
 * 添加任务信息
 */
export const addTaskInformation = (data?: AddTaskInformationData) => {
  return hynRequest.request<boolean>({
    url: '/TaskInformation/AddTaskInformation',
    method: 'post',
    data
  })
}

/**
 * 修改任务状态
 */
export const updateTaskInformationStatus = (data?: UpdateTaskInformationStatusData) => {
  return hynRequest.request<boolean>({
    url: '/TaskInformation/UpdateTaskInformationStatus',
    method: 'post',
    data
  })
}
