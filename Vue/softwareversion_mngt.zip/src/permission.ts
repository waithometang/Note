import router from '@/router/index'
import { getLoginUserMenu } from '@/api/sys/system'

import useAppStore from '@/stores/app'
import useUserStore from '@/stores/user'

import dayjs from 'dayjs'
import { LStorage } from './utils/storage'
import { TIMEOUT } from '@/constant'
import nprogress from 'nprogress'
import { connect, onclose } from './utils/signalr'
import useAuthStore from './stores/auth'

const modules = import.meta.glob('@/views/**/*.vue')
nprogress.configure({ showSpinner: false })

const filterAsyncRoutes = (routes: []) => {
  return routes.map((route: any) => {
    const res: any = {}

    res.name = route.name
    res.path = route.path

    const icons = route.icon.split(';')
    res.meta = {
      title: route.name,
      icon: icons[0],
      iconActive: icons[1],
      orderNo: route.sequenceNumber,
      affix: route.affix,
      ignoreKeepAlive: route.ignoreKeepAlive,
      currentActiveMenu: route.currentActiveMenu,
      hideTab: route.hideTab,
      hideMenu: route.hidMenu
    }

    if (route.name === 'MES_Dashboard') {
      res.name = 'Dashboard'
      res.meta.title = 'Dashboard'
      res.component = modules['/src/views' + route.component]
    } else if (route.component === 'SecondLevelRoutes') {
      res.redirect = route.children[0].path
    } else {
      res.component = modules['/src/views' + route.component]
    }

    if (route.children.length > 0) {
      res.children = filterAsyncRoutes(route.children)
    }
    return res
  })
}

router.beforeEach(async (to, form, next) => {
  nprogress.start()
  const appStore = useAppStore()
  const userStore = useUserStore()
  const authStore = useAuthStore()
  if (
    !userStore.token ||
    dayjs().isAfter(dayjs(LStorage.get(TIMEOUT))) ||
    !userStore.userInfo.userName
  ) {
    userStore.logout()
  } else {
    if (!userStore.hasMenu) {
      const { code, data, message } = await getLoginUserMenu({
        visitor: false,
        applicationID: appStore.appInfo.applicationID,
        systemType: appStore.appInfo.systemType,
        systemTypeID: appStore.appInfo.systemTypeID
      })

      if (code === 200) {
        const filterRoutes = filterAsyncRoutes(data)
        console.log(filterRoutes)

        filterRoutes.forEach((route) => {
          router.addRoute('/', route)
        })
        // 最后添加404页面
        router.addRoute({
          path: '/:pathMatch(.*)*',
          name: 'NotFound',
          component: () => import('@/views/404/index.vue')
        })

        await authStore.getCodeList()
        userStore.hasMenu = true
        await connect() // 建立signalr连接
        onclose()
        next({ ...to, replace: true })
      } else {
        ElMessage.error(message)
      }
    } else {
      next()
    }
  }
})

router.afterEach(() => {
  nprogress.done()
})
