<template>
  <div :class="prefixCls">
    <ul class="context-menu-list" v-if="showRef" ref="wrapRef" :style="getStyle">
      <li
        class="context-menu-item"
        v-for="item in visibleItems"
        :key="item.label"
        @click="item.handler && item.handler(item)"
        :style="{ padding: showIcon || item.icon ? '' : '4px 10px' }"
      >
        <svg-icon v-if="showIcon && item.icon" :icon="item.icon" style="margin-right: 3px" />
        <div>{{ item.label }}</div>
      </li>
    </ul>
  </div>
</template>

<script lang="ts" setup>
import type { Axis, ContextMenuItem } from './typing'
import type { CSSProperties, PropType } from 'vue'
import { computed, nextTick, onMounted, onUnmounted, ref, toRefs, unref } from 'vue'

const prefixCls = 'context-menu'

const props = defineProps({
  width: { type: Number, default: 156 },
  customEvent: { type: Object as PropType<Event>, default: null },
  styles: { type: Object as PropType<CSSProperties> },
  showIcon: { type: Boolean, default: true },
  axis: {
    type: Object as PropType<Axis>,
    default() {
      return { x: 0, y: 0 }
    }
  },
  items: {
    type: Array as PropType<ContextMenuItem[]>,
    default() {
      return []
    }
  }
})

const visibleItems = computed(() => {
  const { items } = toRefs(props)
  return items.value.filter((item) => !item.hidden)
})

const wrapRef = ref(null)
const showRef = ref(false)

const getStyle = computed((): CSSProperties => {
  const { axis, items, styles, width } = props
  const { x, y } = axis || { x: 0, y: 0 }
  // 计算menu高度
  const menuHeight = (items || []).length * 40
  const menuWidth = width
  const body = document.body
  // 计算是否溢出
  const left = body.clientWidth < x + menuWidth ? x - menuWidth : x
  const top = body.clientHeight < y + menuHeight ? y - menuHeight : y

  return {
    ...styles,
    position: 'absolute',
    width: `${width}px`,
    left: `${left + 1}px`,
    top: `${top + 1}px`,
    zIndex: 9999
  }
})

onMounted(() => {
  nextTick(() => (showRef.value = true))
})

onUnmounted(() => {
  const el = unref(wrapRef)
  el && document.body.removeChild(el)
})
</script>

<style lang="scss" scoped>
.context-menu {
  position: fixed;
  top: 0;
  left: 0;
  z-index: 200;
  display: block;
  width: 156px;
  margin: 0;
  list-style: none;
  background-color: #ffffff;
  border: 1px solid rgba(37, 49, 64, 0.1);
  border-radius: 0.25rem;
  background-clip: padding-box;
  user-select: none;

  .context-menu-list {
    padding: 6px;
    border-radius: 4px;
    background-color: #fff;
    border: 1px solid rgba(37, 49, 64, 0.1);
    li {
      font-size: 14px;
      list-style: none;
      color: #000;
      padding: 4px 2px;
      border-radius: 4px;
    }

    .context-menu-item {
      display: flex;
      align-items: center;
      &:hover {
        cursor: pointer;
        background-color: #e5f6ff;
      }
    }
  }
}
</style>
