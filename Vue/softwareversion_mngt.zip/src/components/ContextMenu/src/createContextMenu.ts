import type { CreateContextOptions, ContextMenuProps } from './typing'

import { createVNode, render } from 'vue'
import contextMenuVue from './ContextMenu.vue'
const menuManager: {
  domList: Element[]
  resolve: Fn
} = {
  domList: [],
  resolve: () => {}
}
// 创建右键菜单
export const createContextMenu = function (options: CreateContextOptions) {
  const { event } = options || {}
  // 阻止默认事件
  event && event?.preventDefault()

  return new Promise((resolve) => {
    const body = document.body

    const container = document.createElement('div')
    const propsData: Partial<ContextMenuProps> = {}

    if (options.styles) {
      propsData.styles = options.styles
    }

    if (options.items) {
      propsData.items = options.items
    }

    propsData.showIcon = options.showIcon

    if (options.event) {
      propsData.customEvent = event
      propsData.axis = { x: event.clientX, y: event.clientY }
    }
    // 创建右键菜单虚拟dom
    const vm = createVNode(contextMenuVue, propsData)
    // 渲染右键菜单虚拟dom
    render(vm, container)

    const handleClick = function () {
      menuManager.resolve('')
    }
    // 使用菜单管理工具保存右键菜单
    menuManager.domList.push(container)

    // 移出所有右键菜单
    const remove = function () {
      menuManager.domList.forEach((dom) => {
        try {
          dom && body.removeChild(dom)
        } catch (error) {
          //
        }
      })
      // body删除点击、滚动事件
      body.removeEventListener('click', handleClick)
      body.removeEventListener('scroll', handleClick)
    }
    // 设置管理器
    menuManager.resolve = function (arg) {
      remove()
      resolve(arg)
    }
    remove()
    body.appendChild(container)
    body.addEventListener('click', handleClick)
    body.addEventListener('scroll', handleClick)
  })
}
// 销毁右键菜单
export const destroyContextMenu = function () {
  if (menuManager) {
    menuManager.resolve('')
    menuManager.domList = []
  }
}
