import type { App } from 'vue'

import VXETable from 'vxe-table'
import SvgIcon from '@/components/SvgIcon/index.vue'
import variablesModule from '@/styles/variables.module.scss'

VXETable.config({
  table: {
    stripe: true,
    showOverflow: 'tooltip',
    showHeaderOverflow: 'tooltip',
    rowConfig: {
      isCurrent: true,
      isHover: true
    },
    rowStyle: {
      color: '#2a2a2a'
    },
    headerRowStyle: {
      fontSize: '14px',
      fontFamily: 'Microsoft YaHei, Microsoft YaHei-Bold',
      fontWeight: 700,
      textAlign: 'left',
      color: '#2a2a2a'
    },
    headerCellStyle: {
      borderBottom: '3px solid' + variablesModule.themeColor,
      backgroundColor: '#f0f5ff',
      fontSize: '15px',
      color: '#2a2a2a'
    }
  },
  grid: {
    size: null,
    rowConfig: {
      isCurrent: true,
      isHover: true
    },
    zoomConfig: {
      escRestore: true
    },
    pagerConfig: {
      perfect: false
    },
    toolbarConfig: {
      perfect: false
    },
    proxyConfig: {
      autoLoad: true,
      message: true,
      props: {
        list: null, // 用于列表，读取响应数据
        result: 'data.result', // 用于分页，读取响应数据
        total: 'data.total' // 用于分页，读取总条数
      },
      beforeItem: null,
      beforeColumn: null,
      beforeQuery: null,
      afterQuery: null,
      beforeDelete: null,
      afterDelete: null,
      beforeSave: null,
      afterSave: null
    }
  }
})

export function registerGlobComp(app: App) {
  app.use(VXETable)
  app.component('svg-icon', SvgIcon)
}
