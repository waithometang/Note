<template>
  <el-dialog v-bind="getBindValue" @close="handleClose">
    <slot></slot>
    <template #footer>
      <slot name="footer">
        <div class="dialog-footer">
          <slot name="insertFooter"></slot>
          <el-button v-if="getBindValue.showCancelBtn" @click="handleClose">取消</el-button>
          <slot name="centerFooter"></slot>
          <el-button
            v-if="getBindValue.showConfirmBtn"
            type="primary"
            @click="handleConfirm"
            :loading="getBindValue.confirmLoading"
          >
            确定
          </el-button>
          <slot name="appendFooter"></slot>
        </div>
      </slot>
    </template>
  </el-dialog>
</template>

<script lang="ts" setup>
import type { ModalMethods, ModalProps } from './types'
import type { PropType } from 'vue'
import { ref, unref, getCurrentInstance, computed, useAttrs, watch } from 'vue'
import { omit } from 'lodash-es'

import { deepMerge } from '@/utils/index'

const emit = defineEmits(['register', 'close', 'confirm', 'update:modelValue'])
const props = defineProps({
  modelValue: { type: Boolean },

  showCancelBtn: { type: Boolean, default: true },

  showConfirmBtn: { type: Boolean, default: true },

  confirmLoading: { type: Boolean },

  width: [String, Number] as PropType<string | number>
})
const attrs = useAttrs()

const visibleRef = ref(false)
const propsRef = ref<Partial<ModalProps> | null>(null)

const modalMethods: ModalMethods = {
  setModalProps,
  emitVisible: undefined
}

const instance = getCurrentInstance()

/**
 * @description: 设置modal参数
 */
function setModalProps(attrs: Partial<ModalProps>) {
  // 保存上一次setModalProps的属性
  propsRef.value = deepMerge(unref(propsRef) || {}, attrs)
  // 切换弹框显示
  if (Reflect.has(attrs, 'modelValue')) {
    visibleRef.value = !!attrs.modelValue
  }
}

// Custom title component: get title
const getMergeProps = computed((): Recordable => {
  return {
    ...props,
    ...unref(propsRef)
  }
})

const getBindValue = computed((): Recordable => {
  const attr = {
    ...attrs,
    ...unref(getMergeProps),
    modelValue: unref(visibleRef),
    draggable: true
  }
  return omit(attr, 'title')
})

if (instance) {
  emit('register', modalMethods, instance.uid)
}

const handleClose = (e: Event) => {
  visibleRef.value = false
  emit('close', e)
}

const handleConfirm = (e: Event) => {
  emit('confirm', e)
}
watch(
  () => unref(visibleRef),
  (v) => {
    emit('update:modelValue', v)
    instance && modalMethods.emitVisible?.(v, instance.uid)
  },
  {
    immediate: false
  }
)
</script>

<style lang="scss" scoped></style>
<style lang="scss">
.el-dialog {
  // 滚动条
  ::-webkit-scrollbar {
    width: 5px;
    // border-radius: 10px;
  }

  ::-webkit-scrollbar-track {
    // background-color: darkgrey;
  }

  ::-webkit-scrollbar-thumb {
    border-radius: 10px;
    box-shadow: inset 0 0 6px #fdfdfdcc;
  }
}
</style>
