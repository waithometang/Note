import type { ComputedRef } from 'vue'

/**
 * @description: 弹窗对外暴露的方法
 */
export interface ModalMethods {
  setModalProps: (props: Partial<ModalProps>) => void
  emitVisible?: (open: boolean, uid: number) => void
}
export interface ModalProps {
  minHeight?: number
  height?: number

  draggable?: boolean
  scrollTop?: boolean

  modelValue?: boolean

  loading: boolean

  confirmLoading?: boolean
  showCancelBtn?: boolean
  showConfirmBtn?: boolean
  /**
   * Width of the modal dialog
   * @default 520
   * @type string | number
   */
  width?: string | number
}

export type RegisterFn = (modalMethods: ModalMethods, uuid: number) => void

export interface ReturnMethods extends ModalMethods {
  openModal: <T = any>(props?: boolean, data?: T, openOnSet?: boolean) => void
  closeModal: () => void
  getOpen?: ComputedRef<boolean>
}

export type UseModalReturnType = [RegisterFn, ReturnMethods]

export interface ReturnInnerMethods extends ModalMethods {
  closeModal: () => void
  changeLoading: (loading: boolean) => void
  changeOkLoading: (loading: boolean) => void
  getOpen?: ComputedRef<boolean>
}

export type UseModalInnerReturnType = [RegisterFn, ReturnInnerMethods]
