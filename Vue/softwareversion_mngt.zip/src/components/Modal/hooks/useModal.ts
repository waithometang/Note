import { error } from '@/utils/log'
import {
  ref,
  reactive,
  computed,
  unref,
  watchEffect,
  onUnmounted,
  getCurrentInstance,
  toRaw,
  nextTick
} from 'vue'
import { tryOnUnmounted } from '@vueuse/core'

import { isEqual } from 'lodash-es'
import type {
  ModalMethods,
  ModalProps,
  ReturnMethods,
  UseModalInnerReturnType,
  UseModalReturnType
} from '../types'

const dataTransfer = reactive<any>({})
const visibleData = reactive<{ [key: number]: boolean }>({})

export function useModal(): UseModalReturnType {
  const modalRef = ref<Nullable<ModalMethods>>(null)
  const loaded = ref<Nullable<boolean>>(false)
  const uid = ref<number>(0)

  function register(modalMethod: ModalMethods, uuid: number) {
    if (!getCurrentInstance()) {
      throw new Error('useModal() can only be used inside setup() or functional components!')
    }

    uid.value = uuid

    onUnmounted(() => {
      modalRef.value = null
      loaded.value = false
      dataTransfer[unref(uid)] = null
    })
    if (unref(loaded) && modalMethod === unref(modalRef)) return

    modalRef.value = modalMethod
    loaded.value = true

    modalMethod.emitVisible = (visible: boolean, uid: number) => {
      visibleData[uid] = visible
    }
  }

  const getInstance = () => {
    const instance = unref(modalRef)

    if (!instance) {
      error('useModal instance is undefined!')
    }
    return instance
  }

  const methods: ReturnMethods = {
    setModalProps: (props: Partial<ModalProps>) => {
      getInstance()?.setModalProps(props)
    },
    openModal: <T = any>(visible = true, data?: T, openOnSet = true): void => {
      getInstance()?.setModalProps({ modelValue: visible })

      if (!data) return
      const id = unref(uid)
      if (openOnSet) {
        dataTransfer[id] = null
        dataTransfer[id] = toRaw(data)
        return
      }
      const equal = isEqual(toRaw(dataTransfer[id]), toRaw(data))
      if (!equal) {
        dataTransfer[id] = toRaw(data)
      }
    },
    closeModal: () => {
      getInstance()?.setModalProps({ modelValue: false })
    }
  }
  return [register, methods]
}

export function useModalInner(callbackFn?: Fn): UseModalInnerReturnType {
  const modalRef = ref<Nullable<ModalMethods>>(null)
  const currentInstance = getCurrentInstance()
  const uidRef = ref<number>(0)

  // 注册实例
  const register = (modalInstance: ModalMethods, uuid: number) => {
    tryOnUnmounted(() => {
      modalRef.value = null
    })
    uidRef.value = uuid
    modalRef.value = modalInstance
    currentInstance?.emit('register', modalInstance, uuid)
  }
  // 获取弹框实例
  const getInstance = () => {
    const instance = unref(modalRef)
    if (!instance) {
      error('useModal instance is undefined!')
    }
    return instance
  }

  watchEffect(() => {
    const data = dataTransfer[unref(uidRef)]
    if (!data) return
    if (!callbackFn || !(typeof callbackFn === 'function')) return
    nextTick(() => {
      callbackFn(data)
    })
  })

  // 暴露方法
  const methods = {
    getVisible: computed(() => {
      return visibleData[~~unref(uidRef)]
    }),
    closeModal: () => {
      getInstance()?.setModalProps({ modelValue: false })
    },

    setModalProps: (props: Partial<ModalProps>) => {
      getInstance()?.setModalProps(props)
    },
    changeLoading: (loading = true) => {
      getInstance()?.setModalProps({ loading })
    },
    changeOkLoading: (loading = true) => {
      getInstance()?.setModalProps({ confirmLoading: loading })
    }
  }
  return [register, methods]
}
