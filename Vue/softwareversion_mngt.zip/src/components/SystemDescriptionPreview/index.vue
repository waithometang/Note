<template>
  <router-link class="item" to="/description">
    <el-tooltip :content="$t('component.navBar.pdf')">
      <svg-icon style="color: #008cd6; font-size: 24px" icon="pdf" />
    </el-tooltip>
  </router-link>
</template>

<script lang="ts" setup></script>

<style lang="scss" scoped></style>
