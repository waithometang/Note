import type { ComputedRef, Slots } from 'vue'
import type { GridHeaderProps } from '../types/gridHeader'

import type { FormProps } from '@/components/Form/types/form'

import { unref, computed } from 'vue'
import { isFunction } from '@/utils/is'

export function useGridHeaderForm(propsRef: ComputedRef<Partial<GridHeaderProps>>, slots: Slots) {
  const getFormProps = computed((): Partial<FormProps> => {
    const { advancedSearch } = unref(propsRef)

    return {
      // showAdvancedButton: true,// 是否显示高级查询按钮
      ...advancedSearch
    }
  })

  const getFormSlotKeys: ComputedRef<string[]> = computed(() => {
    const keys = Object.keys(slots)
    return keys
      .map((item) => (item.startsWith('form-') ? item : null))
      .filter((item) => !!item) as string[]
  })

  function replaceFormSlotKey(key: string) {
    if (!key) return ''
    return key?.replace?.(/form-/, '') ?? ''
  }

  return {
    getFormProps,
    replaceFormSlotKey,
    getFormSlotKeys
  }
}
