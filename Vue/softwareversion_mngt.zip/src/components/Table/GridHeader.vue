<template>
  <div class="grid-header">
    <div class="header-container">
      <div class="title-container">
        <template v-if="showTitle">
          <svg-icon style="font-size: 24px" icon="header" />
          <span class="title">{{ title }}</span>

          <slot name="title-after"></slot>
        </template>
      </div>

      <div class="operation-container">
        <slot name="prependOperation"></slot>
        <!-- 快查 -->
        <div v-if="showQuickSearchButton && quickSearchForm" class="quick-search-input">
          <span v-if="quickSearch.singleSearch.showTitle" class="quick-search-title">{{
            quickSearch.singleSearch.title
          }}</span>
          <el-select
            size="large"
            v-if="quickSearch.singleSearch.type === 'select'"
            v-model="quickSearchForm[quickSearch.singleSearch.field]"
            :filterable="
              quickSearch.singleSearch.filterable ||
              (isDef(quickSearch.singleSearch.data) && quickSearch.singleSearch.data.length > 10)
                ? true
                : false
            "
            :placeholder="'请选择' + quickSearch.singleSearch.title"
            clearable
          >
            <el-option
              v-for="item in quickSearch.singleSearch.data"
              :key="item.value"
              :label="item.label"
              :value="item.value"
            >
            </el-option>
          </el-select>

          <el-date-picker
            v-else-if="['date', 'datetime'].indexOf(quickSearch.singleSearch.type) !== -1"
            style="width: 300px"
            :clearable="false"
            unlink-panels
            size="large"
            v-model="quickSearchForm[quickSearch.singleSearch.field]"
            :type="quickSearch.singleSearch.componentProps?.type"
            :value-format="getDateFormat(quickSearch.singleSearch.type)"
            :placeholder="quickSearch.singleSearch.title"
            :shortcuts="getDateShortcuts"
          >
          </el-date-picker>

          <el-input
            v-else
            v-model="quickSearchForm![quickSearch.singleSearch.field]"
            style="width: 220px"
            size="large"
            :placeholder="quickSearch.singleSearch.title"
            @keypress="tiggerPress"
            clearable
          >
          </el-input>
        </div>
        <el-button
          v-if="showQuickSearchButton && !isShowSearchBox"
          size="large"
          type="primary"
          @click="handleSearch"
        >
          <svg-icon style="font-size: 16px" icon="search" />
          <span class="text">查询</span>
        </el-button>
        <el-button
          v-if="showAdvancedSearchButton"
          size="large"
          type="primary"
          @click="handleSearchBoxShow"
          plain
          >高级查询</el-button
        >
        <el-button
          v-if="showAddButton"
          size="large"
          color="#1fc286"
          style="--el-button-text-color: #fff; --el-button-hover-text-color: #fff"
          @click="handleAdd"
        >
          <svg-icon style="font-size: 16px" icon="plus" />
          <span class="text">新增</span>
        </el-button>

        <slot name="appendOperation"></slot>

        <el-tooltip v-if="showImportButton" content="导入">
          <el-button size="large" type="primary" @click="hanldeImport" plain
            ><svg-icon icon="import" style="font-size: 16px" />
          </el-button>
        </el-tooltip>

        <el-tooltip v-if="showExportButton" content="导出">
          <el-button size="large" type="primary" @click="hanldeExport" plain
            ><svg-icon icon="export" style="font-size: 16px" />
          </el-button>
        </el-tooltip>
      </div>
    </div>

    <div v-show="isShowSearchBox" class="grid-search-box-container">
      <div>
        <BasicForm @register="registerForm" v-bind="getFormProps">
          <template #[replaceFormSlotKey(item)]="data" v-for="item in getFormSlotKeys">
            <slot :name="item" v-bind="data || {}"></slot>
          </template>
        </BasicForm>
      </div>
      <div class="operation-container">
        <el-button size="large" type="primary" @click="handleAdvancedSearch">
          <svg-icon style="font-size: 16px" icon="search" />
          <span class="text">查询</span>
        </el-button>

        <el-button
          size="large"
          color="#1fc286"
          style="--el-button-text-color: #fff; --el-button-hover-text-color: #fff"
          @click="handleReset"
        >
          <svg-icon style="font-size: 16px" icon="reset" />
          <span class="text">重置</span>
        </el-button>

        <el-button size="large" @click="handleSearchBoxShow">
          <svg-icon style="font-size: 16px" icon="close-search-box" />
          <span class="text">关闭</span>
        </el-button>
      </div>
    </div>

    <ImportExcelDialog
      v-bind="getUploadProps"
      @register="registerModal"
      @success="handleImportExcelSuccess"
    />
  </div>
</template>

<script lang="tsx" setup generic="T extends Recordable<any>,P extends keyof T">
import type { PropType } from 'vue'
import type { FormProps, FormSchema } from '../Form/types/form'
import type { GridHeaderProps, QuickSearch } from './types/gridHeader'
import type { IDatePickerType } from 'element-plus/es/components/date-picker/src/date-picker.type.mjs'

import { ref, watch, computed, unref, useSlots, nextTick, toRefs, onMounted } from 'vue'
import { cloneDeep, get, set, unset } from 'lodash-es'
import dayjs from 'dayjs'

import BasicForm from '@/components/Form/BasicForm.vue'
import { useForm } from '@/components/Form/hooks/useForm'
import ImportExcelDialog from './components/ImportExcelDialog.vue'

import { useGridHeaderForm } from './hooks/useGridHeaderForm'
import { downloadByApi } from '@/utils/download'
import { error } from '@/utils/log'
import { isDef, isFunction, isNotEmpty } from '@/utils/is'
import { useModal } from '@/components/Modal/hooks/useModal'
import { dateShortcuts } from '@/constant'
import { dateItemType } from '@/components/Form/helper'

const emit = defineEmits([
  'quickSearch',
  'add',
  'advancedSearch',
  'reset',
  'close',
  'importSuccess',
  'exportClick'
])
const props = defineProps({
  title: {
    type: String,
    default: ''
  },
  showTitle: {
    type: Boolean,
    default: true
  },
  showQuickSearchButton: {
    type: Boolean,
    default: true
  },
  showAddButton: {
    type: Boolean,
    default: true
  },
  showAdvancedSearchButton: {
    type: Boolean,
    default: true
  },
  showExportButton: {
    type: Boolean,
    default: false
  },
  exportApi: {
    type: Function as PropType<(args?: any) => Promise<any>>,
    default: null
  },
  exportBefore: {
    type: Function as PropType<(args?: any) => Boolean>
  },
  exportParams: {
    type: Object as PropType<Recordable<any>>,
    defalut: () => {
      return {}
    }
  },
  quickSearch: {
    type: Object as PropType<QuickSearch<QuickSearchForm>>,
    default: () => {
      return {
        searchFormFields: {}
      }
    }
  },
  advancedSearch: {
    type: Object as PropType<Partial<FormProps>>,
    default: () => {
      return {}
    }
  },
  tiggerPress: {
    type: Function,
    default: () => {}
  },
  showImportButton: {
    type: Boolean,
    default: false
  },
  exportTemplateApi: {
    type: Function as PropType<(args?: any) => Promise<any>>,
    default: null
  },
  importUrl: {
    type: String,
    default: ''
  },
  customExport: {
    type: Boolean,
    default: false
  }
})
type QuickSearchForm = Pick<T, P>
type AdvancedSearchForm = Omit<T, P>

const quickSearchForm = ref<QuickSearchForm | undefined>()
const advancedSearchForm = ref<AdvancedSearchForm | undefined>()
const innerPropsRef = ref<Partial<GridHeaderProps>>()
const slots = useSlots()

watch(
  () => props.quickSearch.searchFormFields,
  (newForm) => {
    quickSearchForm.value = newForm
  },
  {
    immediate: true
  }
)

function getDateFormat(type: string) {
  return type === 'date' ? 'YYYY-MM-DD' : 'YYYY-MM-DD HH:mm:ss'
}

const getDateShortcuts = computed(() => {
  const type = props.quickSearch.singleSearch.componentProps?.type as IDatePickerType
  if (type === 'daterange') {
    return props.quickSearch.singleSearch.componentProps?.shortcuts || dateShortcuts
  }
  return []
})

const isShowSearchBox = ref(false)

const [
  registerForm,
  {
    updateSchema,
    getFieldsValue,
    getOriginFieldsValue,
    resetFields,
    setFieldsValue,
    scrollToField,
    setProps,
    resetSchema,
    clearValidate,
    validate,
    validateField,
    appendSchemaByField,
    removeSchemaByField
  }
] = useForm()

const handleSearch = () => {
  let value = undefined
  if (isDef(quickSearchForm.value)) {
    value = quickSearchForm.value[props.quickSearch.singleSearch.field]
  }

  emit('quickSearch', value)
}

const handleSearchBoxShow = () => {
  isShowSearchBox.value = !isShowSearchBox.value
  if (!unref(isShowSearchBox)) {
    handleClose()
  }
}
// 新增
const handleAdd = () => {
  emit('add')
}

const [registerModal, { openModal }] = useModal()
const { exportTemplateApi, importUrl, quickSearch } = toRefs(props)
const getUploadProps = computed(() => ({
  exportTemplateApi: unref(exportTemplateApi),
  importUrl: unref(importUrl)
}))
// 打开导入弹框
const hanldeImport = () => {
  openModal()
}
// 导入成功
const handleImportExcelSuccess = () => {
  emit('importSuccess')
}

const { customExport, exportApi, exportParams, exportBefore } = toRefs(props)
// 导出
const hanldeExport = async () => {
  if (unref(customExport)) {
    return emit('exportClick', getQuickSearchForm, advancedSearchForm, exportParams)
  }

  if (!isFunction(unref(exportApi))) {
    return ElMessage.error('导出不是一个函数')
  }
  const exportBeforeFun = unref(exportBefore)
  if (isDef(exportBeforeFun) && isFunction(exportBeforeFun)) {
    const result = exportBeforeFun()
    if (!result) {
      throw new Error('导出前置检查未通过')
    }
  }
  const loading = ElLoading.service({
    lock: true,
    text: 'Loading',
    background: 'rgba(0, 0, 0, 0.7)'
  })
  try {
    await downloadByApi(unref(exportApi), {
      ...unref(getQuickSearchForm),
      ...unref(advancedSearchForm),
      ...unref(exportParams)
    })
  } catch (e: any) {
    error(e.message)
  } finally {
    loading.close()
  }
}

// 获取所有字段
const getAllFields = computed(
  () =>
    unref(getFormProps)
      ?.schemas?.filter((schema) => !dateItemType.includes(schema.component))
      ?.map((item) => [...(item.fields || []), item.field])
      .flat(1)
      .filter(Boolean)
)
// 获取所有字段组成未定义值的表单
const getAllFieldsUnfForm = (): Recordable<any> => {
  let fields: Recordable<any> = {}

  unref(getAllFields)?.forEach((field) => {
    fields[field] = undefined
  })
  return fields
}

/**
 * 获取高级查询表单并本地缓存
 */
const getAdvancedSearchForm = () => {
  const filedsValue = getFieldsValue() as AdvancedSearchForm
  advancedSearchForm.value = cloneDeep(filedsValue)

  return getFieldsValue()
}

/**
 * 高级查询按钮
 */
const handleAdvancedSearch = () => {
  const filedsValue = getAdvancedSearchForm()
  handleClose()
  emit('advancedSearch', filedsValue)
}

/**
 * 重置按钮
 */
const handleReset = async () => {
  await resetFields()
  await nextTick(() => {})
  const filedsValue = getAdvancedSearchForm()

  isShowSearchBox.value = false
  emit('reset', filedsValue)
}
/**
 * 还原当前的查询条件表单
 */
const restoreForm = () => {
  const allFieldsUnfForm = getAllFieldsUnfForm()
  const form: Recordable<any> = { ...allFieldsUnfForm, ...unref(advancedSearchForm) }
  console.log(form)

  setFieldsValue(form)
}

/**
 * 关闭按钮
 */
const handleClose = async () => {
  restoreForm()
  isShowSearchBox.value = false
  emit('close')
}

const getProps = computed(() => {
  return { ...props, ...unref(innerPropsRef) } as Partial<GridHeaderProps>
})

const getQuickSearchForm = computed(() => {
  const fieldMapToTime = unref(quickSearch).fieldMapToTime
  const searchFormFields = cloneDeep(unref(quickSearch).searchFormFields)

  if (!fieldMapToTime || !Array.isArray(fieldMapToTime)) {
    return searchFormFields
  }
  const [field, [startTimeKey, endTimeKey], format = 'YYYY-MM-DD'] = fieldMapToTime

  if (!field || !startTimeKey || !endTimeKey) {
    return searchFormFields
  }
  if (!get(searchFormFields, field)) {
    unset(searchFormFields, field)
    return searchFormFields
  }

  const [startTime, endTime]: string[] = get(searchFormFields, field)

  const [startTimeFormat, endTimeFormat] = Array.isArray(format) ? format : [format, format]

  if (isNotEmpty(startTime)) {
    set(searchFormFields, startTimeKey, formatTime(startTime, startTimeFormat))
  }
  if (isNotEmpty(endTime)) {
    set(searchFormFields, endTimeKey, formatTime(endTime, endTimeFormat))
  }
  unset(searchFormFields, field)

  return searchFormFields
})

/**
 * @description: 格式化时间
 */
function formatTime(time: string, format: string) {
  if (format === 'timestamp') {
    return dayjs(time).unix()
  } else if (format === 'timestampStartDay') {
    return dayjs(time).startOf('day').unix()
  }
  return dayjs(time).format(format)
}

const { getFormProps, replaceFormSlotKey, getFormSlotKeys } = useGridHeaderForm(getProps, slots)

// watch(isShowSearchBox, () => {
//   getAdvancedSearchForm()
// })

onMounted(() => {
  getAdvancedSearchForm()
})

/**
 * 更新高级查询表单配置
 */
const updateAdvancedSearchForm = async (data: Partial<FormSchema> | Partial<FormSchema>[]) => {
  await updateSchema(data)
  await nextTick(() => {})
  getAdvancedSearchForm()
}

/**
 * 重置高级查询表单
 */
const resetAdvancedSearchFormFields = async () => {
  await resetFields()
  await nextTick(() => {})

  getAdvancedSearchForm()
}

/**
 * 修改高级查询表单字段值
 */
const setAdvancedSearchFormFieldValue = async (data: Recordable<any>) => {
  setFieldsValue(data)
  await nextTick()
  getAdvancedSearchForm()
}
/**
 * 获取所有查询表单（快查+高级查询）
 */
const getSearchForm = computed(() => {
  return {
    ...unref(quickSearchForm),
    ...unref(advancedSearchForm)
  }
})

defineExpose({
  quickSearchForm: getQuickSearchForm,
  advancedSearchForm,
  updateAdvancedSearchForm,
  setAdvancedSearchFormFieldValue,
  getFieldsValue,
  resetFields,
  setFieldsValue,
  scrollToField,
  setProps,
  resetSchema,
  clearValidate,
  validate,
  validateField,
  appendSchemaByField,
  removeSchemaByField,
  getAdvancedSearchForm,
  resetAdvancedSearchFormFields,
  getSearchForm
})
</script>

<style lang="scss" scoped>
.grid-header {
  height: 60px;

  position: relative;

  .header-container {
    flex: 1;
    display: flex;
    justify-content: space-between;
    .title-container {
      display: flex;
      align-items: center;
      .title {
        margin-left: 8px;
        font-size: 18px;
        line-height: 40px;
        font-weight: 600;
        color: #2a2a2a;
      }
    }

    .operation-container {
      display: flex;
      .quick-search-input {
        display: flex;
        align-items: center;
        .quick-search-title {
          font-size: 18px;
          margin-right: 8px;
          color: #303133;
        }
      }
    }
    .el-button {
      margin-left: 20px;
      .text {
        margin-left: 5px;
      }
    }
  }

  .grid-search-box-container {
    position: absolute;
    z-index: 10;
    top: 100%;
    width: 100%;
    padding: 20px;
    background-color: #fff;

    border-radius: 0px 0px 12px 12px;
    box-shadow: 0px 10px 15px rgba(0, 0, 0, 0.05);

    display: flex;
    flex-direction: column;

    .operation-container {
      display: flex;
      justify-content: right;
    }
  }
}
</style>
