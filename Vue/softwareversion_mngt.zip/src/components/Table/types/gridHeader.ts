import type { FormProps } from '@/components/Form/types/form'
import type { ComputedRef } from 'vue'

export interface SelectOption {
  label: string
  value: string
}
export interface SingleSearch<T> {
  /**
   * 字段
   */
  field: T
  /**
   * 快查类型只支持输入框input、日期date、下拉框select
   */
  type: string
  /**
   * 当类型为select时的下拉列表数据
   */
  data?: SelectOption[]
  /**
   * 字段标题
   */
  title?: string
  /**
   * 标题是否显示 (true:显示，false:不显示)
   */
  showTitle?: boolean
  /**
   * 是否可过滤
   */
  filterable?: boolean
  /**
   * 组件props
   */
  componentProps?: Recordable<any>
}

export interface SearchFormFields {
  [key: string]: any
}

export interface QuickSearch<T> {
  /**
   * 单查询条件配置
   */
  singleSearch: SingleSearch<keyof T>
  /**
   * 查询项对象默认值
   */
  searchFormFields: T
  /**
   * 日期数组字段映射到具体时间字段
   */
  fieldMapToTime?: [string, [string, string], (string | [string, string])?]
}

export interface GridHeaderProps {
  /**
   * 标题
   */
  title?: string | ComputedRef<string>
  /**
   * 快查配置
   */
  quickSearch?: QuickSearch<Recordable<any>>
  /**
   * 高级查询配置
   */
  advancedSearch?: Partial<FormProps>
  /**
   * 是否显示标题
   */
  showTitle?: boolean
  /**
   * 是否显示快查按钮
   */
  showQuickSearchButton?: boolean
  /**
   * 是否显示新增按钮
   */
  showAddButton?: boolean
  /**
   * 是否显示导入按钮，默认为false
   */
  showImportButton?: boolean
  /**
   * 是否显示导出按钮，默认为false
   */
  showExportButton?: boolean
  /**
   * 导出函数
   */
  exportApi?: (args?: any) => Promise<any>

  /**
   * 导出前校验
   */
  exportBefore?: () => boolean
  /**
   * 导出参数
   */
  exportParams?: Recordable<any>
  /**
   * 是否显示高级查询
   */
  showAdvancedSearchButton?: boolean
  tiggerPress?: () => void
  /**
   * 导入模版api
   */
  exportTemplateApi?: (args?: any) => Promise<any>
  /**
   * 导入地址 如：/ProductionWo/ImportExcelData
   */
  importUrl?: string
  /**
   * 是否自定义导出
   */
  customExport?: boolean
}

export interface GridHeaderEvent<T extends Recordable<any> = any, P extends keyof T = any> {
  /**
   * 快查按钮点击回调
   * @param value 快查值
   * @returns
   */
  quickSearch?: (value?: string | Date | number) => void
  /**
   * 高级查询按钮点击回调
   * @param fieldsValue 高级查询参数值
   * @returns
   */
  advancedSearch?: (fieldsValue?: Recordable) => void
  /**
   * 重置按钮点击回调
   */
  reset?: () => void
  /**
   * 添加按钮点击回调
   */
  add?: () => void
  /**
   * 关闭高级查询按钮点击回调
   */
  close?: () => void
  /**
   * 导入成功回调
   */
  importSuccess?: () => void
  /**
   * 导出按钮点击回调
   * @param quickSearch 快查参数值
   * @param advancedSearchForm 高级查询参数值
   * @param exportParams 导出参数
   * @returns 
   */
  exportClick?: (quickSearch: Pick<T, P>, advancedSearchForm: Omit<T, P>, exportParams: any) => void
}
