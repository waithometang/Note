import type { ButtonProps } from 'element-plus/lib/components/index.js'
import type { CSSProperties, Component } from 'vue'

export interface ActionItem extends Partial<ButtonProps> {
  onClick?: Fn
  icon?: string
  tooltip?: string
  label?: string
  style?: CSSProperties
  /**
   * @description 业务控制是否显示
   */
  ifShow?: boolean | ((action: ActionItem) => boolean)
  /**
   * @description 权限编码控制是否显示
   */
  auth?: string
  /**
   * @description 气泡确认框配置
   */
  popConfirm?: PopConfirm
}

export interface PopConfirm {
  title?: string
  confirmButtonText?: string
  cancelButtonText?: string
  icon?: string | Component
  hideIcon?: boolean
  hideAfter?: number
  teleported?: boolean
  width?: string | number
  confirm?: (e: MouseEvent) => void
  cancel?: (e: MouseEvent) => void
}

export interface DropMenu {
  onClick?: Fn
  to?: string
  icon?: string
  event?: string
  text: string
  disabled?: boolean
  divider?: boolean
}
