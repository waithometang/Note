<template>
  <div>
    <template v-for="(action, index) in getActions" :key="index">
      <el-tooltip v-if="action.tooltip" v-bind="getTooltip(action.tooltip)">
        <el-button v-bind="getAction(action)" link>
          <svg-icon v-if="action.icon" :icon="action.icon" />
          <template v-if="action.label">{{ action.label }}</template>
        </el-button>
      </el-tooltip>

      <el-button v-else v-bind="getAction(action)">
        <svg-icon style="margin-right: 5px" v-if="action.icon" :icon="action.icon" />
        <template v-if="action.label">{{ action.label }}</template>
      </el-button>

      <el-divider v-if="divider && index < getActions.length - 1" direction="vertical" />
    </template>

    <el-divider
      v-if="divider && 1 <= getActions.length && getDropdownList.length"
      direction="vertical"
    />

    <el-dropdown
      v-if="dropDownActions && getDropdownList.length > 0"
      :hide-on-click="false"
      trigger="click"
    >
      <span>
        <slot name="more"></slot>
        <el-tooltip v-if="!$slots.more" placement="bottom" content="更多">
          <el-button size="default" link>
            <svg-icon icon="view" style="font-size: 14px" class="icon-more" />
          </el-button>
        </el-tooltip>
      </span>

      <template #dropdown>
        <el-dropdown-menu>
          <template v-for="item in getDropdownList" :key="`${item.event}`">
            <el-dropdown-item @click="handleClickMenu(item)" :disabled="item.disabled">
              <el-popconfirm
                v-if="popconfirm && item.popConfirm"
                v-bind="getPopConfirmAttrs(item.popConfirm)"
                :disabled="item.disabled"
              >
                <template #reference>
                  <div>
                    <svg-icon v-if="item.icon" :icon="item.icon" />
                    <span class="ml-1">{{ item.text }}</span>
                  </div>
                </template>
              </el-popconfirm>

              <template v-else>
                <svg-icon style="margin-right: 5px" v-if="item.icon" :icon="item.icon" />
                <template v-if="item.label">{{ item.label }}</template>
              </template>
            </el-dropdown-item>
            <el-divider style="margin: 0" v-if="item.divider" :key="`d-${item.event}`" />
          </template>
        </el-dropdown-menu>
      </template>
    </el-dropdown>
  </div>
</template>

<script lang="ts" setup>
import type { PropType } from 'vue'
import type { ActionItem, DropMenu } from './types/tableAction'
import type { ElTooltipProps } from 'element-plus/lib/components/index.js'

import { computed, toRaw } from 'vue'
import { omit } from 'lodash-es'
import { isBoolean, isFunction, isString } from '@/utils/is'
import useAuthStore from '@/stores/auth'

const props = defineProps({
  actions: {
    type: Array as PropType<ActionItem[]>,
    default: null
  },
  dropDownActions: {
    type: Array as PropType<ActionItem[]>,
    default: null
  },
  divider: {
    type: Boolean,
    default: true
  },
  popconfirm: {
    type: Boolean,
    default: true
  }
})
const emit = defineEmits(['menuEvent'])

const { hasCode } = useAuthStore()

const getActions = computed<ActionItem[]>(() => {
  // 可拓展做按钮权限校验filter
  return (toRaw(props.actions) || [])
    .filter((action) => {
      let show = true
      if (action.auth) {
        show = hasCode(action.auth)
      }
      return show && isIfShow(action)
    })
    .map((action) => {
      return {
        link: true,
        size: 'default',
        ...action
      }
    })
})

function isIfShow(action: ActionItem): boolean {
  const ifShow = action.ifShow

  let isIfShow = true

  if (isBoolean(ifShow)) {
    isIfShow = ifShow
  }
  if (isFunction(ifShow)) {
    isIfShow = ifShow(action)
  }
  return isIfShow
}

const getDropdownList = computed((): any[] => {
  const list = (toRaw(props.dropDownActions) || []).filter((action) => {
    let show = true
    if (action.auth) {
      show = hasCode(action.auth)
    }
    return show && isIfShow(action)
  })
  return list.map((action, index) => {
    const { label, popConfirm } = action
    return {
      ...action,
      ...popConfirm,
      onConfirm: popConfirm?.confirm,
      onCancel: popConfirm?.cancel,
      text: label,
      divider: index < list.length - 1 ? props.divider : false
    }
  })
})

function handleClickMenu(item: DropMenu) {
  const { event } = item
  const menu = getDropdownList.value.find((item) => `${item.event}` === `${event}`)
  emit('menuEvent', menu)
  item.onClick?.()
}

const getPopConfirmAttrs = computed(() => {
  return (attrs: DropMenu & Recordable<any>) => {
    const originAttrs = omit(attrs, ['confirm', 'cancel'])
    if (!attrs.onConfirm && attrs.confirm && isFunction(attrs.confirm))
      originAttrs['onConfirm'] = attrs.confirm
    if (!attrs.onCancel && attrs.cancel && isFunction(attrs.cancel))
      originAttrs['onCancel'] = attrs.cancel
    return originAttrs
  }
})

function getAction(action: ActionItem): Omit<ActionItem, any> {
  return omit(action, 'icon')
}

function getTooltip(data: string | Partial<ElTooltipProps>): Partial<ElTooltipProps> {
  return {
    placement: 'bottom',
    ...(isString(data) ? { content: data } : data)
  }
}
</script>

<style lang="scss" scoped>
.el-dropdown {
  line-height: unset;
}
</style>
