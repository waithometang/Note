export interface FileInfo {
  name?: string
  size?: number
  successCount?: number
  failCount?: number
  totalCount?: number
  errorMessage?: null
}
