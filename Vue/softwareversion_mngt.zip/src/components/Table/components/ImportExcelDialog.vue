<template>
  <BasicModal
    width="25%"
    v-bind="$attrs"
    @register="registerModal"
    title="导入文件"
    :showConfirmBtn="false"
    @close="handleBeforeClose"
  >
    <div class="content-container">
      <div class="upload-container">
        <el-upload
          ref="uploadRef"
          :action="getAction"
          class="upload-excel"
          name="file"
          accept=".xlsx,.xls"
          :headers="{ Authorization: appStore.token }"
          :on-success="handleUploadSuccess"
          :before-upload="handleBeforeUpload"
          :auto-upload="false"
          :show-file-list="true"
          :on-remove="handleRemove"
        >
          <template #trigger>
            <el-button type="primary" size="large" @click="handleSelectFile">选择文件</el-button>
          </template>
          <template #tip>
            <div class="tips-container">
              <div style="font-size: 14px">*支持.xlsx格式(小于10,000条数据),点击下载</div>
              <el-link type="primary" @click="handleDownloadTemplate">模版</el-link>
            </div>
          </template>
        </el-upload>
      </div>
      <div class="file-container">
        <svg-icon :icon="getIcon" style="font-size: 48px" />

        <div class="upload-info-container">
          <template v-if="fileInfo.name">
            <div>{{ fileInfo.name }}</div>
            <div>
              共{{ fileInfo.totalCount }}条数据，成功{{ fileInfo.successCount }}条，失败
              <span style="color: #d43030">{{ fileInfo.failCount }}</span> 条
            </div>
            <div class="error-info">
              <el-scrollbar style="color: #d43030">{{ fileInfo.errorMessage }}</el-scrollbar>
            </div>
          </template>

          <template v-else>请上传文件</template>
        </div>
      </div>
    </div>

    <template #appendFooter>
      <el-button type="primary" @click="handleImport">上传</el-button>
    </template>
  </BasicModal>
</template>

<script lang="ts" setup>
import type { FileInfo } from './types'
import type { UploadFile, UploadInstance, UploadRawFile } from 'element-plus'
import type { PropType } from 'vue'
import type { ModalMethods } from '@/components/Modal/types'

import { ref, unref, toRefs, computed } from 'vue'
import { useModalInner } from '@/components/Modal/hooks/useModal'
import BasicModal from '@/components/Modal/BasicModal.vue'

import { downloadByApi } from '@/utils/download'
import { isFunction } from '@/utils/is'
import { error } from '@/utils/log'
import useUserStore from '@/stores/user'
import { cloneDeep } from 'lodash-es'

const props = defineProps({
  exportTemplateApi: {
    type: Function as PropType<(args?: any) => Promise<any>>,
    default: null
  },
  importUrl: {
    type: String,
    default: ''
  }
})
const emit = defineEmits<{
  register: [modalMethods: ModalMethods, uuid: number]
  success: [{ isUpdate: boolean }]
}>()

const { exportTemplateApi } = toRefs(props)
const [registerModal, { closeModal }] = useModalInner()
// 下载模版
const handleDownloadTemplate = async () => {
  if (!isFunction(unref(exportTemplateApi))) {
    return ElMessage.error('未设置导入模版')
  }

  const loading = ElLoading.service({
    lock: true,
    text: 'Loading',
    background: 'rgba(0, 0, 0, 0.7)'
  })

  try {
    await downloadByApi(unref(exportTemplateApi), {})
  } catch (e: any) {
    error(e.message)
  } finally {
    loading.close()
  }
}

const uploadRef = ref<UploadInstance>()

const appStore = useUserStore()

const handleSelectFile = () => {
  unref(uploadRef)?.submit()
}

const fileInfoDefaultValue = {
  name: undefined,
  size: 0,
  successCount: 0,
  failCount: 0,
  totalCount: 0,
  errorMessage: null
}
const fileInfo = ref<FileInfo>(cloneDeep(fileInfoDefaultValue))
const handleUploadSuccess = (response: any, uploadFile: UploadFile) => {
  Object.assign(fileInfo.value, response.data)
  unref(fileInfo).name = uploadFile.name
  unref(fileInfo).size = uploadFile.size
}
const handleBeforeUpload = (rawFile: UploadRawFile) => {
  if (!props.importUrl) {
    ElMessage.error('必须传递importUrl')
    return Promise.reject()
  }
}

const getAction = computed(() => {
  return import.meta.env.VITE_BASE_URL + props.importUrl
})

const getIcon = computed(() => {
  return unref(fileInfo).name ? 'file' : 'file-empty'
})

const handleRemove = () => {
  fileInfo.value = cloneDeep(fileInfoDefaultValue)
}

const handleBeforeClose = () => {
  fileInfo.value = cloneDeep(fileInfoDefaultValue)

  uploadRef.value?.clearFiles()
}

const handleImport = () => {
  uploadRef.value?.submit()
}
</script>

<style lang="scss" scoped>
.content-container {
  .upload-container {
    display: flex;
    align-items: center;
    .upload-excel {
      // display: flex;
      // align-items: center;
    }
    .tips-container {
      margin-top: 8px;
      flex: 1;
      color: #000;
      display: flex;
      align-items: center;
      // cursor: unset;
    }
  }

  .file-container {
    margin-top: 12px;
    height: 112px;
    opacity: 1;
    border-radius: 4px;

    border: 1px solid rgba(220, 223, 230, 1);

    padding: 20px;

    display: flex;
    align-items: center;
    user-select: none;
    .upload-info-container {
      flex: 1;
      height: 100%;

      margin-left: 24px;

      display: flex;
      flex-direction: column;
      justify-content: center;

      .error-info {
        flex: 1;
        height: 0;
      }
    }
  }
}
</style>
