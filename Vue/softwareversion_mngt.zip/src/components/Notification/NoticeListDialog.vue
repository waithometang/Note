<template>
  <BasicModal width="70%" v-bind="$attrs" @register="registerModal" title="消息列表">
    <template #footer>
      <div></div>
    </template>
    <el-radio-group v-model="ReadStatus" @change="handleReadTabChange" :disabled="loading">
      <el-radio :label="1">未读</el-radio>
      <el-radio :label="2">已读</el-radio>
      <el-radio label="">全部</el-radio>
    </el-radio-group>
    <div v-loading="loading">
      <div v-if="pageConfig.total > 0" class="message-list-wrapper">
        <el-scrollbar class="message-list-container" always ref="scrollbarRef">
          <div class="message-item" v-for="message in messageList" :key="message.id">
            <div class="left">
              <div class="message-title">{{ message.messageTitle }}</div>
              <div class="message-content">{{ message.messageContent }}</div>
              <div class="message-tool">
                <el-button size="small" type="primary" @click="handleReview({ ...message })"
                  >立即查看</el-button
                >
                <el-button
                  v-if="message.readStatus === 1"
                  size="small"
                  type="primary"
                  plain
                  :loading="updateID === message.id"
                  @click="updateStatus(message.id, false)"
                  >标记为已读</el-button
                >
              </div>
            </div>
            <div class="right">{{ message.createTime }}</div>
          </div>
        </el-scrollbar>
        <vxe-pager
          v-model:current-page="pageConfig.currentPage"
          v-model:page-size="pageConfig.pageSize"
          :total="pageConfig.total"
          size="mini"
          @page-change="handlePageChange"
        />
      </div>
      <div v-else class="no-data">无数据</div>
    </div>
  </BasicModal>
</template>

<script setup lang="ts">
import type { GetMessageModel } from '@/api/sys/model/basicModel'
import type { ModalMethods } from '../Modal/types'
import type { ElScrollbar } from 'element-plus'

import { getMessage, updateMessageReadStatus } from '@/api/sys/basic'
import BasicModal from '@/components/Modal/BasicModal.vue'

import { useModalInner } from '@/components/Modal/hooks/useModal'
import router from '@/router'

import { ref, reactive } from 'vue'

const emit = defineEmits<{
  register: [modalMethods: ModalMethods, uuid: number]
  refresh: []
}>()

const ReadStatus = ref(1)
const messageList = ref<GetMessageModel[]>()
const pageConfig = reactive({
  currentPage: 1,
  pageSize: 10,
  total: 0
})
const loading = ref(false)
const updateID = ref('')
const scrollbarRef = ref<InstanceType<typeof ElScrollbar>>()

const [registerModal, { closeModal }] = useModalInner(async (data) => {
  ReadStatus.value = 1
  pageConfig.currentPage = 1
  pageConfig.pageSize = 10
  pageConfig.total = 0
  getMessageList()
})

const handleReadTabChange = async () => {
  pageConfig.currentPage = 1
  await getMessageList()
  scrollbarRef.value?.setScrollTop(0)
}

const handlePageChange = async () => {
  getMessageList()
}

const handleReview = ({ moduleName, id }: GetMessageModel) => {
  router.push({ name: moduleName }).then(() => {
    closeModal()
    updateStatus(id, false)
  })
}

const updateStatus = async (messageID: string, allMessageRead: boolean) => {
  updateID.value = messageID
  try {
    const { code, message } = await updateMessageReadStatus({ id: messageID, allMessageRead })
    if (code === 200) {
      getMessageList()
      emit('refresh')
    } else {
      ElMessage.error(message)
    }
  } finally {
    updateID.value = ''
  }
}

const getMessageList = async () => {
  loading.value = true
  try {
    const { code, data, message } = await getMessage({
      ReadStatus: ReadStatus.value,
      pageIndex: pageConfig.currentPage - 1,
      pageSize: pageConfig.pageSize
    })
    if (code === 200) {
      messageList.value = data.result
      pageConfig.total = data.total
    } else {
      pageConfig.total = 0
      ElMessage.error(message)
    }
  } finally {
    loading.value = false
  }
}
</script>

<style scoped lang="scss">
.el-radio-group {
  margin-bottom: 20px;
}
.message-list-wrapper {
  height: 450px;
  display: flex;
  flex-direction: column;
  justify-content: space-between;
  .message-list-container {
    // flex: 1;
    .message-item {
      display: flex;
      justify-content: space-between;
      border-bottom: 1px solid #eee;
      margin-bottom: 20px;
      margin-right: 15px;
      .left {
        flex: 1;
        overflow: hidden;
        > div {
          padding-bottom: 10px;
        }
        .message-title {
          font-weight: 700;
        }
        .message-content {
          text-overflow: ellipsis;
          overflow: hidden;
          word-break: break-all;
          white-space: nowrap;
        }
      }
      .right {
        min-width: 150px;
        text-align: end;
      }
    }
  }
}

.no-data {
  height: 500px;
  display: flex;
  align-items: center;
  justify-content: center;
}
</style>
