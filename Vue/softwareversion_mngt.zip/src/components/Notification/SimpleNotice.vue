<template>
  <div class="container">
    <div class="header">
      <span class="title">{{ data.messageTitle }}</span>
    </div>
    <div class="content">{{ data.messageContent }}</div>
    <div class="footer">
      <div class="date">{{ data.createTime }}</div>
    </div>
  </div>
</template>

<script setup lang="ts">
import type { GetMessageModel } from '@/api/sys/model/basicModel'
import type { PropType } from 'vue'

const props = defineProps({
  data: {
    type: Object as PropType<GetMessageModel>,
    default: () => ({})
  }
})
</script>

<style scoped lang="scss">
.container {
  padding: 16px;
  border-bottom: 1px solid rgba(232, 232, 232, 1);
  display: flex;
  flex-direction: column;
  gap: 8px;
  cursor: pointer;
  transition: 0.5s all;
  &:hover {
    background-color: #efefef;
  }
  .header {
    font-size: 14px;
    font-weight: 400;
    letter-spacing: 0px;
    line-height: 22px;
    // color: rgba(56, 56, 56, 1);
    color: #000;
    font-weight: 700;
  }
  .content {
    font-size: 14px;
    font-weight: 400;
    letter-spacing: 0px;
    line-height: 22px;
    color: rgba(56, 56, 56, 1);
    text-overflow: ellipsis;
    overflow: hidden;
    word-break: break-all;
    white-space: nowrap;
  }
  .footer {
    .date {
      font-size: 12px;
      font-weight: 400;
      letter-spacing: 0px;
      line-height: 22px;
      color: rgba(128, 128, 128, 1);
    }
  }
}
</style>
