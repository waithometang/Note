<template>
  <div style="cursor: auto">
    <el-popover trigger="click" width="338px" :teleported="false" v-model:visible="popoverVisible">
      <template #reference>
        <el-badge :is-dot="unReadCount !== 0">
          <svg-icon
            style="color: rgba(0, 140, 214, 1); font-size: 20px; cursor: pointer"
            icon="remind"
          />
        </el-badge>
      </template>
      <el-tabs v-model="tabName" class="message-tabs" @tab-change="handleTabChange">
        <el-tab-pane :label="unReadMessageLabel" :name="MESSAGE_TYPE.UNREAD">
          <div class="notice-list-wrapper">
            <el-empty v-if="unReadCount === 0" description="暂无新消息">
              <template #image>
                <img src="../../assets/png/bells.png" alt="" style="width: 76px; height: 73px" />
              </template>
            </el-empty>
            <template v-else>
              <SimpleNotice
                v-for="item in unReadList"
                :key="item.id"
                :data="item"
                @click="handleClickMessageItem(item)"
              />
            </template>
          </div>
          <el-button link class="view-more" type="primary" @click="handleClickViewMore"
            >查看更多></el-button
          >
        </el-tab-pane>
        <el-tab-pane :label="allMessageLabel" :name="MESSAGE_TYPE.ALL">
          <div class="notice-list-wrapper">
            <el-empty v-if="allMessageCount === 0" description="暂无消息">
              <template #image>
                <img src="../../assets/png/bells.png" alt="" style="width: 76px; height: 73px" />
              </template>
            </el-empty>
            <template v-else>
              <SimpleNotice
                v-for="item in allMessageList"
                :key="item.id"
                :data="item"
                @click="handleClickMessageItem(item)"
              />
            </template>
          </div>
          <el-button link class="view-more" type="primary" @click="handleClickViewMore"
            >查看更多></el-button
          >
        </el-tab-pane>
      </el-tabs>
    </el-popover>
  </div>
</template>

<script setup lang="ts">
import type { TabPaneName } from 'element-plus'
import type { GetMessageModel } from '@/api/sys/model/basicModel'

import SimpleNotice from './SimpleNotice.vue'

import { getMessage } from '@/api/sys/basic'
import { ref, onMounted, computed, onUnmounted } from 'vue'
import router from '@/router'
import { MESSAGE_TYPE } from '@/constant'
import useCurrentInstance from '@/hooks/useCurrentInstance'
import { SStorage } from '@/utils/storage'

const unReadCount = ref(0)
const allMessageCount = ref(0)
const tabName = ref('unread')
const unReadList = ref<GetMessageModel[]>()
const allMessageList = ref<GetMessageModel[]>()
const popoverVisible = ref(false)

const unReadMessageLabel = computed(() => {
  let label: string
  if (unReadCount.value <= 99) {
    label = `未读 (${unReadCount.value})`
  } else {
    label = `未读 (99+)`
  }
  return label
})

const allMessageLabel = computed(() => {
  let label: string
  if (allMessageCount.value <= 99) {
    label = `全部 (${allMessageCount.value})`
  } else {
    label = `全部 (99+)`
  }
  return label
})

onMounted(async () => {
  getUnReadMessageList()
  getAllMessageList()
})

const getAllMessageList = async () => {
  const { code, data } = await getMessage({
    pageIndex: 0,
    pageSize: 3
  })
  if (code === 200) {
    allMessageCount.value = data.total
    allMessageList.value = data.result
  } else {
    allMessageCount.value = 0
    allMessageList.value = []
  }
}

const getUnReadMessageList = async () => {
  const { code, data } = await getMessage({
    ReadStatus: 1,
    pageIndex: 0,
    pageSize: 3
  })
  if (code === 200) {
    unReadCount.value = data.total
    unReadList.value = data.result
    SStorage.set('unReadCount', data.total)
  } else {
    unReadCount.value = 0
    unReadList.value = []
  }
}

const handleTabChange = (name: TabPaneName) => {
  console.log(name)
  // if ((name = MESSAGE_TYPE.UNREAD)) {
  //   getUnReadMessageList()
  // } else {
  //   getAllMessageList()
  // }
}

const handleClickMessageItem = (data: GetMessageModel) => {
  router.push({ name: data.moduleName }).then(() => {
    popoverVisible.value = false
  })
}
const handleClickViewMore = () => {
  let moduleName: string

  if (tabName.value === MESSAGE_TYPE.UNREAD) {
    moduleName = 'NoticeList'
  } else {
    moduleName = 'NoticeList'
  }

  router.push({ name: moduleName }).then(() => {
    popoverVisible.value = false
    tabName.value = MESSAGE_TYPE.UNREAD
  })
}

const refreshMessage = () => {
  getUnReadMessageList()
  getAllMessageList()
}

const { proxy } = useCurrentInstance()

proxy.eventBus.on('messageRefresh', refreshMessage)

defineExpose({ refreshMessage })

onUnmounted(() => {
  proxy.eventBus.off('messageRefresh')
})
</script>

<style scoped lang="scss">
:deep(.el-badge__content.is-fixed) {
  top: 6px;
  right: 50%;
  font-size: 10px;
}
:deep(.el-tooltip__trigger) {
  display: flex;
  align-items: center;
}
:deep(.el-badge__content.is-fixed) {
  top: 2px;
  right: 40%;
  background: rgba(212, 48, 48, 1);
}
:deep(.el-popper) {
  padding: 0;
}
:deep(.el-tabs) {
  --el-tabs-header-height: 47px;
  .el-tabs__header {
    margin-bottom: 0;
  }
  .el-tabs__nav {
    padding: 0;
    .el-tabs__active-bar {
      background-color: rgba(0, 140, 214, 1);
    }
    .el-tabs__item {
      width: 100px;
      font-size: 14px;
      font-weight: 500;
      letter-spacing: 0px;
      line-height: 22px;
      color: rgba(0, 0, 0, 0.65);
      &:hover {
        color: rgba(0, 140, 214, 0.8);
      }
      &.is-active {
        color: rgba(0, 140, 214, 1);
      }
    }
  }
}
.message-tabs {
  .view-more {
    width: 100%;
    display: flex;
    height: 46px;
    align-items: center;
    justify-content: center;
    font-size: 12px;
    font-weight: 400;
    letter-spacing: 0px;
    line-height: 22px;
  }
}
.notice-list-wrapper {
  height: 345px;
  border-bottom: 1px solid rgba(232, 232, 232, 1);
}
.el-empty {
  height: 100%;
}

/* :deep(.el-tabs__item) {
  width: 80px;
} */
</style>
