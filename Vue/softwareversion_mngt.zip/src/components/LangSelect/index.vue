<template>
  <el-dropdown class="international" trigger="click" @command="handleSetLanguage">
    <div>
      <el-tooltip :content="$t('component.navBar.lang')" :effect="effect">
        <svg-icon style="color: #008cd6; font-size: 24px" icon="language"></svg-icon>
      </el-tooltip>
    </div>
    <template #dropdown>
      <el-dropdown-menu>
        <el-dropdown-item :disabled="language === 'zh'" command="zh">中文</el-dropdown-item>
        <el-dropdown-item :disabled="language === 'en'" command="en">English</el-dropdown-item>
        <el-dropdown-item :disabled="language === 'de'" command="de">Deutsch</el-dropdown-item>
        <el-dropdown-item :disabled="language === 'fr'" command="fr">French</el-dropdown-item>
      </el-dropdown-menu>
    </template>
  </el-dropdown>
</template>

<script lang="ts" setup>
import { storeToRefs } from 'pinia'
import { useI18n } from 'vue-i18n'
import { ElMessage } from 'element-plus'
import useAppStore from '@/stores/app'

defineProps({
  // 默认主题
  effect: {
    type: String,
    default: 'dark',
    validator: (value: string) => {
      return ['dark', 'light'].indexOf(value) !== -1
    }
  }
})
const appStore = useAppStore()
const { language } = storeToRefs(appStore)
const { setLanguage } = appStore

const i18n = useI18n()
// 切换语言
const handleSetLanguage = (lang: string) => {
  // 切换i18n的locale
  i18n.locale.value = lang
  // 修改pinia 保存的language
  setLanguage(lang)

  ElMessage.success(i18n.t('component.toast.switchLangSuccess'))
}
</script>

<style lang="scss" scoped>
.international {
  font-size: inherit;
}
</style>
