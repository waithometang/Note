import type { TreeNodeData } from 'element-plus/es/components/tree/src/tree.type.mjs'
import type { ComputedRef } from 'vue'
import type { FieldNames } from '../types/tree'
import { unref } from 'vue'

export function useTree(treeDataRef: ComputedRef<TreeNodeData[]>, getFieldNames: FieldNames) {
  const getAllKeys = (list?: TreeNodeData[]) => {
    const keys: string[] = []
    const treeData = list || unref(treeDataRef)
    const { nodeKey, children } = getFieldNames

    treeData.forEach((treeNode) => {
      keys.push(treeNode[nodeKey])
      if (treeNode[children] && treeNode[children].length) {
        keys.push(...getAllKeys(treeNode[children]))
      }
    })

    return keys
  }

  return {
    getAllKeys
  }
}
