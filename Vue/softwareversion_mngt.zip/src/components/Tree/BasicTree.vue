<template>
  <div class="box tree-container">
    <div class="header-container">
      <div class="title" v-if="showTitle">{{ title }}</div>
      <div class="operation-container">
        <el-input v-model="filterText" class="query-input" placeholder="搜索">
          <template #prefix>
            <svg-icon icon="search" />
          </template>
          <template #append>
            <el-dropdown>
              <svg-icon icon="more-one" style="font-size: 24px" />

              <template #dropdown>
                <el-dropdown-menu>
                  <el-dropdown-item @click="expandAll(true)">展开全部</el-dropdown-item>
                  <el-dropdown-item @click="expandAll(false)">折叠全部</el-dropdown-item>
                </el-dropdown-menu>
              </template>
            </el-dropdown>
          </template>
        </el-input>
      </div>
    </div>
    <el-scrollbar class="tree-wrapper">
      <el-tree
        ref="treeRef"
        :data="getTreeData"
        v-bind="getBindValues"
        @node-click="handleNodeClick"
      >
        <template #default="scopeData">
          <BasicTooltip v-if="!formatter" :content="scopeData.node.label" />

          <component v-else :is="formatter(scopeData)" />
        </template>

        <template #[key]="scopeData" v-for="(item, key) in $slots" :key="key">
          <slot :name="key" v-bind="scopeData || {}"></slot>
        </template>
      </el-tree>
    </el-scrollbar>
    <slot name="footer"></slot>
  </div>
</template>

<script lang="ts" setup>
import type { PropType, VNode } from 'vue'
import type { Tree, FieldNames, ContextMenuOptions } from './types/tree'
import type { ContextMenuItem, CreateContextOptions } from '../ContextMenu/src/typing'
import type { TreeNode, ElTree } from 'element-plus'

import { ref, computed, reactive, useAttrs, watch, toRefs, unref } from 'vue'
import { get, omit } from 'lodash-es'

import { isDef, isFunction } from '@/utils/is'
import { warn } from '@/utils/log'
import { useTree } from './hooks/useTree'
import { useContextMenu } from '@/hooks/useContextMenu'
import type Node from 'element-plus/es/components/tree/src/model/node.mjs'

const props = defineProps({
  api: {
    type: Function as PropType<(arg?: any) => Promise<any[]>>,
    default: null
  },
  // api params
  params: {
    type: Object as PropType<any>,
    defalut: () => {
      return {}
    }
  },
  title: {
    type: String,
    default: ''
  },
  showTitle: {
    type: Boolean,
    default: true
  },
  // 立即加载
  immediate: {
    type: Boolean,
    default: true
  },
  // 标签
  labelField: {
    type: String,
    default: 'label'
  },
  // support xxx.xxx.xx
  resultField: {
    type: String,
    default: ''
  },
  // support xxx.xxx.xx
  childrenField: {
    type: String,
    default: 'children'
  },
  keyField: {
    type: String,
    default: 'id'
  },
  // 父子严格关联
  checkStrictly: {
    type: Boolean,
    default: true
  },
  // 展开节点
  expendsKeys: {
    type: Array as PropType<string[]>,
    default: () => {
      return []
    }
  },
  // 右键菜单列表
  nodeContextMenuList: {
    type: Array as PropType<ContextMenuItem[]>
  },
  beforeNodeContextMenuClick: {
    type: Function as PropType<(...arg: any) => Promise<ContextMenuItem[] | ContextMenuOptions>>,
    default: undefined
  },
  formatter: {
    type: Function as PropType<(...arg: any) => VNode | string>,
    default: undefined
  },
  cancleHightlightCurrent: {
    type: Boolean,
    default: false
  }
})
const emit = defineEmits(['select'])
const attrs = useAttrs()
const filterText = ref('')
const treeRef = ref<InstanceType<typeof ElTree>>()
const loading = ref(false)
const apiData = ref<any[]>([])
const isFirstLoaded = ref(false) // 是否首次加载过

const { checkStrictly, expendsKeys } = toRefs(props)
const treeConfigData = reactive({
  checkStrictly: checkStrictly,
  expendsKeys: unref(expendsKeys) || []
})

const getBindValues = computed(() => ({
  props: {
    children: 'children',
    label: 'label'
  },
  defaultExpandedKeys: treeConfigData.expendsKeys,
  filterNodeMethod: filterNodeMethod,
  highlightCurrent: true,
  onNodeContextmenu: handleNodeContextMenu,
  ...attrs,
  ...omit(props, 'title')
}))

const filterNodeMethod = (value: string, data: Tree, node: Node) => {
  // if (!value) return true
  // return data.label.includes(value)

  if (!value) return true
  let _array: boolean[] = []
  getReturnNode(node, _array, value)

  let result = false
  _array.forEach((item) => {
    result = result || item
  })
  return result
}

const getReturnNode = (node: Node, _array: boolean[], value: string) => {
  let isPass = node.data && node.data.label && node.data.label.indexOf(value) !== -1
  isPass ? _array.push(isPass) : ''
  if (!isPass && node.level != 1 && node.parent) {
    getReturnNode(node.parent, _array, value)
  }
}

watch(filterText, (val) => {
  treeRef.value!.filter(val)
})

const getTreeData = computed(() => {
  const opts = generatorTreeNode(unref(apiData))

  return opts
})

/**
 * 生成节点
 */
const generatorTreeNode = (nodes: any) => {
  const { labelField, childrenField } = props
  return nodes.reduce((prev: Tree[], next: Recordable<any>) => {
    if (next) {
      const item = {
        ...omit(next, [labelField]),
        label: next[labelField]
      }
      const children = Reflect.get(next, childrenField)
      if (children) {
        Reflect.set(item, 'children', generatorTreeNode(children))
      }
      prev.push(item)
    }
    return prev
  }, [] as Tree[])
}

async function initialFetch() {
  const api = props.api

  if (!api || !isFunction(api) || loading.value) return
  apiData.value = []

  try {
    loading.value = true
    const res = await api(props.params)
    isFirstLoaded.value = true

    if (Array.isArray(res)) {
      apiData.value = res
      return
    }
    // 深层级获取
    if (props.resultField) {
      apiData.value = get(res, props.resultField) || []
    }
  } catch (error: any) {
    warn(error)
  } finally {
    loading.value = false
  }
}
const { params, immediate } = toRefs(props)
// 获取字段名
const getFieldNames = computed((): Required<FieldNames> => {
  const { childrenField, labelField, keyField } = props
  return {
    children: childrenField,
    label: labelField,
    nodeKey: keyField
  }
})

const { getAllKeys } = useTree(getTreeData, unref(getFieldNames))

watch(
  () => params,
  () => {
    // !unref(isFirstLoaded) &&
    initialFetch()
  },
  { deep: true, immediate: unref(immediate) }
)

// 展开/收缩
const expandAll = (expandAllStatus: boolean) => {
  for (const key of getAllKeys()) {
    const node = treeRef.value?.getNode(key)

    if (isDef(node)) {
      node.expanded = expandAllStatus
    }
  }
}
const activeNode = ref()
// 取消选中
const handleNodeClick = (data: any, node: any, TreeNode: any, event: any) => {
  if (node === activeNode.value && props.cancleHightlightCurrent) {
    treeRef.value?.setCurrentKey()
    activeNode.value = null
    emit('select', null, null, null, event)
  } else {
    activeNode.value = node
    emit('select', data, node, TreeNode, event)
  }
}

const [createContextMenu] = useContextMenu()

const handleNodeContextMenu = async (event: MouseEvent, data: Tree, node: TreeNode) => {
  const { nodeContextMenuList: menuList = [], beforeNodeContextMenuClick } = props
  let contextMenuOptions: CreateContextOptions = { event, items: [] }

  if (beforeNodeContextMenuClick && isFunction(beforeNodeContextMenuClick)) {
    let result = await beforeNodeContextMenuClick(node, event)
    if (Array.isArray(result)) {
      // 菜单项赋值
      contextMenuOptions.items = result
    } else {
      // 合并配置项
      Object.assign(contextMenuOptions, result)
    }
  } else {
    contextMenuOptions.items = menuList
  }
  if (!contextMenuOptions.items?.length) return
  contextMenuOptions.items = contextMenuOptions.items.filter((item) => !item.hidden)
  createContextMenu(contextMenuOptions)
}

defineExpose({ treeRef, getTreeData, initialFetch, expandAll })
</script>

<style lang="scss" scoped>
.tree-container {
  height: 100%;
  background-color: #fff;
  display: flex;
  flex-direction: column;

  .header-container {
    display: flex;
    flex-direction: column;
    .title {
      height: 51px;
      color: #2a2a2a;
      background: rgba(0, 140, 214, 0.25);
      border-radius: 8px;
      box-shadow: 0px 2px 3px 0px rgba(0, 0, 0, 0.06);
      font-size: 14px;
      font-family: Microsoft YaHei-Bold;

      font-weight: bold;

      display: flex;
      justify-content: center;
      align-items: center;
      margin-bottom: 10px;
    }
    .operation-container {
      display: flex;
      align-items: center;
      .query-input {
        flex: 1;

        :deep(.el-input-group__append) {
          padding: 0px;
        }
      }
    }
  }

  .tree-wrapper {
    margin-top: 10px;
    flex: 1;
  }
}
</style>
