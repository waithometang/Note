import type { ContextMenuItem } from '@/components/ContextMenu/src/typing'
import type { TreeComponentProps } from 'element-plus/es/components/tree/src/tree.type.mjs'
import type { VNode } from 'vue'
export interface Tree {
  key?: string
  label: string
  children?: Tree[]
}

export interface FieldNames {
  nodeKey: string
  label: string
  children: string
}

export interface ContextMenuOptions {
  icon?: string
  styles?: any
  items?: ContextMenuItem[]
}

export type TreeProps = {
  /**
   * 请求函数
   */
  api: (arg?: any) => Promise<any>
  /**
   * api参数
   */
  params?: any
  /**
   * 标题
   */
  title?: string
  /**
   * 是否显示标题
   */
  showTitle?: boolean
  /**
   * 自动加载立即执行
   */
  immediate?: boolean
  /**
   * 显示字段名
   */
  labelField?: string
  /**
   * api返回结果字段 支持xxx.xxx.xxx
   */
  resultField?: string
  /**
   * 子节点字段名
   */
  childrenField?: string
  /**
   * 唯一标识的属性名
   */
  keyField?: string
  /**
   * 默认展开项
   */
  expendsKeys?: string[]
  /**
   * 右键菜单配置项
   */
  nodeContextMenuList?: ContextMenuItem[]
  /**
   * 自定义右键菜单配置项
   */
  beforeNodeContextMenuClick?: (...arg: any) => Promise<ContextMenuItem[] | ContextMenuOptions>
  formatter?: (...arg: any) => VNode | string
  /**
   * 是否开启可取消选中树节点功能
   */
  cancleHightlightCurrent?: boolean
} & {
  'onCurrent-change'?: ((...args: any[]) => any) | undefined
  'onNode-expand'?: ((...args: any[]) => any) | undefined
  onCheck?: ((...args: any[]) => any) | undefined
  'onCheck-change'?: ((...args: any[]) => any) | undefined
  onSelect?: ((...args: any[]) => any) | undefined
  'onNode-contextmenu'?: ((...args: any[]) => any) | undefined
  'onNode-collapse'?: ((...args: any[]) => any) | undefined
  'onNode-drag-start'?: ((...args: any[]) => any) | undefined
  'onNode-drag-end'?: ((...args: any[]) => any) | undefined
  'onNode-drop'?: ((...args: any[]) => any) | undefined
  'onNode-drag-leave'?: ((...args: any[]) => any) | undefined
  'onNode-drag-enter'?: ((...args: any[]) => any) | undefined
  'onNode-drag-over'?: ((...args: any[]) => any) | undefined
} & Partial<TreeComponentProps>
