<template>
  <div @click="onToggle" class="screen-full-container">
    <el-tooltip :content="$t('component.navBar.screenfull')" :effect="effect">
      <svg-icon
        :style="{ color: variablesModule.themeColor, fontSize: '24px' }"
        :icon="isFullscreen ? 'fullscreen-exit' : 'fullscreen'"
      ></svg-icon>
    </el-tooltip>
  </div>
</template>

<script lang="ts" setup>
import { ref, onMounted, onUnmounted } from 'vue'
import screenfull from 'screenfull'
import { ElMessage } from 'element-plus'
import { useI18n } from 'vue-i18n'
import variablesModule from '@/styles/variables.module.scss'
import useAppStore from '@/stores/app'

defineProps({
  // 全屏类型，
  // all: 系统全屏
  // main: 主区域全屏
  // custom: 自定义全屏位置
  // type: {
  //   type: String,
  //   default: 'all',
  //   validator(value: string) {
  //     return ['all', 'main', 'custom'].indexOf(value) !== -1
  //   }
  // },
  // elementID: {
  //   type: String,
  //   default: ''
  // },
  // 默认主题
  effect: {
    type: String,
    default: 'dark',
    validator: (value: string) => {
      return ['dark', 'light'].indexOf(value) !== -1
    }
  }
})

const emit = defineEmits(['change'])

const i18n = useI18n()

const { setFullScreen } = useAppStore()

// 是否全屏
const isFullscreen = ref(false)
// 全屏方法 区分不同情况
const onToggle = () => {
  // if (screenfull.isEnabled) {
  //   if (props.type === 'all') {
  //     screenfull.toggle()
  //   } else if (props.type === 'main') {
  //     const element = document.getElementById('main') as HTMLElement
  //     screenfull.toggle(element)
  //   } else {
  //     const element = document.getElementById(props.elementID) as HTMLElement
  //     screenfull.toggle(element)
  //   }
  // } else {
  //   ElMessage.error(i18n.t('title.NoSupportFullscreen'))
  // }

  if (screenfull.isEnabled) {
    setFullScreen(true)
    screenfull.toggle()
  } else {
    ElMessage.error(i18n.t('title.NoSupportFullscreen'))
  }
}
// 监听变化
const change = () => {
  isFullscreen.value = screenfull.isFullscreen
  emit('change', isFullscreen.value)
}
// 绑定监听
onMounted(() => {
  screenfull.on('change', change)
})
// 取消监听
onUnmounted(() => {
  screenfull.off('change', change)
})
</script>

<style lang="scss" scoped></style>
