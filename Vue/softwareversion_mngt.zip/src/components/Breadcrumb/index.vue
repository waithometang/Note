<template>
  <el-breadcrumb id="guide-breadcrumb" class="breadcrumb" separator="/">
    <transition-group name="breadcrumb">
      <el-breadcrumb-item v-for="(item, index) in breadcrumData" :key="item.path">
        <!-- 不可点击 -->
        <span class="no-redirect" v-if="breadcrumData.length - 1 === index">{{
          generateTitle(item.meta.title)
        }}</span>
        <!-- 可点击 -->
        <span class="redirect" @click="onLinkClick(item)" v-else>{{
          generateTitle(item.meta.title)
        }}</span>
      </el-breadcrumb-item>
    </transition-group>
  </el-breadcrumb>
</template>

<script lang="ts" setup>
import { ref, watch } from 'vue'
import { type RouteLocationMatched, useRoute, useRouter } from 'vue-router'
import { generateTitle } from '@/utils/i18n'
const route = useRoute()

// 生成数组数据
const breadcrumData = ref<RouteLocationMatched[]>([])
const getBreadcrumData = () => {
  // route.matched获取当前的路由的标准化记录
  breadcrumData.value = route.matched.filter((item) => item.meta && item.meta.title)
}
// 监听路由变化
watch(
  route,
  () => {
    getBreadcrumData()
  },
  {
    immediate: true
  }
)
const router = useRouter()
const onLinkClick = (item: RouteLocationMatched) => {
  router.push(item.path)
}
</script>

<style lang="scss" scoped>
.breadcrumb {
  display: inline-block;
  font-size: 14px;
  line-height: 50px;
  margin-left: 8px;
  .redirect {
    color: #666;
    font-weight: 600;
    cursor: pointer;
  }
  .redirect:hover {
    color: #62b7e4;
  }
}
</style>
