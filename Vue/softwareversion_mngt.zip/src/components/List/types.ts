export interface ListProps {
  /**
   * 列表api
   */
  api?: (arg?: any) => Promise<any>
  /**
   * 关闭isEnabledApi后生效,传递列表原始数据用于手动管理列表数据
   */
  data?: Recordable[]
  /**
   * 标题
   */
  title: string
  /**
   * 显示字段
   */
  labelField?: string
  /**
   * 值字段
   */
  valueField?: string
  /**
   * 值字段
   */
  tooltipField?: string
  /**
   * 接口列表所在字段 支持xxx.xxx.xxx
   */
  resultField?: string
  /**
   * 是否开启在此点击取消当前活跃项
   */
  isCancelCurrent?: boolean
  /**
   * 自动选中第一个
   */
  autoSelectFirst?: boolean
  immediate?: boolean
  /**
   * 是否显示tooltip
   */
  showTooltip?: boolean
  numberToString?: boolean
  params?: any
  onChange?: (data: { item: any; index?: number }) => void
  /**
   * 是否启用api
   */
  isApiEnabled?: boolean
}
