<template>
  <div class="box list-container">
    <div class="title">{{ title }}</div>

    <el-input v-model="query" placeholder="请输入查询文本" />
    <el-scrollbar class="list-wrapper">
      <TransitionGroup :css="false" @before-enter="onBeforeEnter" @enter="onEnter" @leave="onLeave">
        <el-row
          v-for="(item, index) in getTreeData"
          :key="item.value"
          :data-index="index"
          class="item"
          :class="isDef(activeItem) && unref(activeItem)[valueField] === item.value ? 'active' : ''"
          @click="handleChangeActive(item, index)"
          @contextmenu="handleContext($event, item, index)"
        >
          <el-col v-if="!showTooltip" class="label" :span="24">{{ item.label }}</el-col>

          <el-tooltip v-else v-bind="getTooltip(item.tooltip)">
            <el-col class="label" :span="24">{{ item.label }}</el-col></el-tooltip
          >
        </el-row>
      </TransitionGroup>
    </el-scrollbar>
    <slot name="footer"></slot>
  </div>
</template>

<script lang="ts" setup>
import type { BaseTransitionProps, PropType } from 'vue'

import { computed, nextTick, ref, toRefs, unref, watch } from 'vue'
import gsap from 'gsap'
import { get } from 'lodash-es'

import { isDef, isFunction, isObject, isString } from '@/utils/is'
import { warn } from '@/utils/log'
import type { ElTooltipProps } from 'element-plus'

defineOptions({
  name: 'BasicList'
})

const props = defineProps({
  api: {
    type: Function as PropType<(arg?: any) => Promise<any[]>>,
    default: null
  },
  // 数据
  data: {
    type: Array as PropType<Recordable[]>,
    default: () => {
      return []
    }
  },
  // 标题
  title: {
    type: String,
    default: 'List'
  },
  // 标签
  labelField: {
    type: String,
    default: 'label'
  },
  // 值
  valueField: {
    type: String,
    default: 'value'
  },
  // tooltip
  tooltipField: {
    type: String,
    default: 'tooltip'
  },
  // support xxx.xxx.xx
  resultField: {
    type: String,
    default: ''
  },
  // 是否开启在此点击取消当前活跃项
  isCancelCurrent: {
    type: Boolean,
    default: false
  },
  // 自动选中第一个
  autoSelectFirst: {
    type: Boolean,
    default: false
  },
  // 立即加载
  immediate: {
    type: Boolean,
    default: true
  },
  numberToString: {
    type: Boolean,
    default: false
  },
  showTooltip: {
    type: Boolean,
    default: false
  },
  // api params
  params: {
    type: Object as PropType<any>,
    defalut: () => {
      return {}
    }
  },
  isApiEnabled: {
    type: Boolean,
    default: true
  }
})
const emit = defineEmits<{
  change: [data: { item: any; index?: number }]
  contextClick: [e: MouseEvent, item: Recordable, index: number]
  'data-change': [treeData: any]
}>()

const query = ref('')
const innerTreeData = ref<Recordable[]>([])
const activeItem = ref<Recordable>()
const loading = ref(false)
const isFirstLoaded = ref(false) // 是否首次加载过

// 列表当前活跃项改变
const handleChangeActive = (item: Recordable, index: number) => {
  const { isCancelCurrent } = props
  if (isDef(unref(activeItem)) && unref(activeItem)?.value !== item.value) {
    activeItem.value = item
    emit('change', { item, index })
  } else if (
    isCancelCurrent &&
    isDef(unref(activeItem)) &&
    unref(activeItem)?.value === item.value
  ) {
    // 可取消选中
    activeItem.value = undefined
    emit('change', { item: undefined, index })
  } else {
    activeItem.value = item

    emit('change', { item, index })
  }
}

const getTreeData = computed(() => {
  const { labelField, valueField, tooltipField, numberToString } = props

  return unref(innerTreeData)
    .map((item) => {
      const value = get(item, valueField)
      return {
        ...item,
        label: get(item, labelField),
        value: numberToString ? `${value}` : value,
        tooltip: get(item, tooltipField)
      }
    })
    .filter((item: any) => item.label.toLowerCase().includes(query.value.toLowerCase()))
})

async function fetch() {
  const api = props.api

  if (!api || !isFunction(api) || loading.value) return
  innerTreeData.value = []

  try {
    loading.value = true
    const res = await api(props.params)
    isFirstLoaded.value = true

    if (Array.isArray(res)) {
      innerTreeData.value = res
      emitChange()
      return
    }
    // 深层级获取
    if (props.resultField) {
      innerTreeData.value = get(res, props.resultField) || []
    }
    emitChange()
  } catch (error: any) {
    warn(error)
  } finally {
    loading.value = false
  }
}

const { params, immediate, isApiEnabled, data } = toRefs(props)

watch(
  () => params,
  async () => {
    // !unref(isFirstLoaded) &&
    if (unref(isApiEnabled)) {
      await fetch()

      nextTick(() => {
        const treeData = unref(getTreeData)
        if (props.autoSelectFirst && treeData.length) {
          const item = treeData[0]

          activeItem.value = item

          emit('change', { item })
        }
      })
    }
  },
  { deep: true, immediate: unref(immediate) }
)

function emitChange() {
  emit('data-change', unref(getTreeData))
}

watch(
  data,
  (newData) => {
    if (!props.isApiEnabled) {
      innerTreeData.value = newData || []
      emitChange()
    }
  },
  {
    immediate: true
  }
)

// 动画进入
const onEnter: BaseTransitionProps['onEnter'] = (el, done) => {
  gsap.to(el, {
    opacity: 1,
    height: '1.6em',
    delay: 0.2,
    onComplete: done
  })
}
// 动画离开
const onLeave: BaseTransitionProps['onLeave'] = (el, done) => {
  gsap.to(el, {
    opacity: 0,
    height: 0,
    delay: 0.2,
    onComplete: done
  })
}
// 动画进入之前
const onBeforeEnter: BaseTransitionProps['onBeforeEnter'] = (el) => {
  el.style.opacity = 0
  el.style.height = 0
}

function handleContext(e: MouseEvent, item: Recordable, index: number) {
  emit('contextClick', e, item, index)
}

const getActiveItem = computed(() => unref(activeItem))

function getTooltip(data: string | Partial<ElTooltipProps>): Partial<ElTooltipProps> {
  return {
    placement: 'right',
    ...(isString(data) ? { content: data } : data)
  }
}

defineExpose({ getActiveItem, fetch })
</script>

<style lang="scss" scoped>
.list-container {
  height: 100%;
  display: flex;
  flex-direction: column;

  .title {
    height: 51px;
    color: #2a2a2a;
    background: rgba(0, 140, 214, 0.25);
    border-radius: 8px;
    box-shadow: 0px 2px 3px 0px rgba(0, 0, 0, 0.06);
    font-size: 14px;
    font-family: Microsoft YaHei-Bold;
    font-weight: bold;

    display: flex;
    justify-content: center;
    align-items: center;
    margin-bottom: 10px;
  }
  .list-wrapper {
    margin-top: 10px;
    flex: 1;
    display: flex;
    flex-direction: column;
    .el-row {
      box-sizing: border-box;
      margin-top: 5px;
      border-bottom: 1px solid #f2f2f2;
      border-radius: 4px;

      cursor: pointer;
      &:first-child {
        margin-top: 0px;
      }
    }

    .item {
      opacity: 1;
      height: 2.6em !important;
      font-size: 14px;
      border: 2px solid transparent;

      &:hover {
        background-color: #e5f6ff;
      }
    }

    .active {
      background: rgba(143, 216, 255, 0.23);
      border: 2px solid #008cd6;
      border-radius: 4px;
      box-shadow: 0px 2px 3px 0px rgba(0, 0, 0, 0.06);
    }
    .el-row:last-child {
      margin-bottom: 0;
    }
    .el-col {
      border-radius: 4px;
      padding: 0 20px;
      display: flex;
      align-items: center;
    }

    .label {
      overflow: hidden;
      text-overflow: ellipsis;
      white-space: nowrap;
    }
  }
}
</style>
