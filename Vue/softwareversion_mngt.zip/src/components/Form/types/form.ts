import type {
  FormItemProp,
  FormItemProps,
  FormItemRule,
  FormValidateCallback,
  FormValidationResult,
  RowProps
} from 'element-plus'
import type { ColEx, ComponentType, NamePath } from './index'
import type { Arrayable } from '@vueuse/core'
import type { CSSProperties, VNode } from 'vue'

export type FieldMapToTime = [string, [string, string], (string | [string, string])?][]

export type Rule = FormItemRule & {
  trigger?: 'blur' | 'change' | ['change', 'blur']
}

export interface RenderCallbackParams {
  schema: FormSchema
  values: Recordable
  model: Recordable
  field: string
}

export interface FormActionType {
  validateField: (
    props?: Arrayable<FormItemProp> | undefined,
    callback?: FormValidateCallback | undefined
  ) => FormValidationResult
  validate: (callback?: FormValidateCallback) => Promise<void>
  resetFields: (props?: string | string[]) => Promise<void>
  scrollToField: (prop: FormItemProp) => FormValidationResult
  clearValidate: (props?: Arrayable<FormItemProp> | undefined) => void

  setFieldsValue: (values: Recordable) => Promise<void>
  getFieldsValue: () => Recordable
  getOriginFieldsValue: () => Recordable
  updateSchema: (data: Partial<FormSchema> | Partial<FormSchema>[]) => Promise<void>
  resetSchema: (data: Partial<FormSchema> | Partial<FormSchema>[]) => Promise<void>
  setProps: (formProps: Partial<FormProps>) => Promise<void>

  removeSchemaByField: (field: string | string[]) => Promise<void>
  appendSchemaByField: (
    schema: FormSchema | FormSchema[],
    prefixField: string | undefined,
    first?: boolean | undefined
  ) => Promise<void>
  resetDefaultField: (name?: NamePath[]) => void
}

export type RegisterFn = (formInstance: FormActionType) => void

export type UseFormReturnType = [RegisterFn, FormActionType]

export type Size = 'default' | 'small' | 'large'

export interface FormProps {
  model: Recordable
  /**
   * label宽度
   */
  labelWidth?: number | string
  /**
   * 行布局属性
   */
  rowProps?: RowProps
  /**
   * 日期数组字段映射到具体时间字段
   */
  fieldMapToTime?: FieldMapToTime
  /**
   * 表单配置项
   */
  schemas: FormSchema[]
  /**
   * 行组件样式
   */
  baseRowStyle: CSSProperties
  /**
   * 单元格组件属性
   */
  baseColProps: Partial<ColEx>
  /**
   * 自动设置placeholder
   */
  autoSetPlaceHolder: boolean
  autoSubmitOnEnter: boolean
  submitOnReset: boolean
  submitOnChange: boolean
  size: Size
  disabled: boolean
  showActionButtonGroup: boolean
  showResetButton: boolean
  autoFocusFirstItem: boolean
  showSubmitButton: boolean
  labelAlign: string
  transformDateFunc?: (date: any) => string
  /**
   * 自定义重置前执行函数
   */
  resetFunc?: () => Promise<void>
}

export type RenderOpts = {
  disabled: boolean
  [key: string]: any
}

export interface FormSchema {
  // 字段名
  field: string
  // 扩展多字段 name[]
  fields?: string[]
  // 标签
  label: string
  // 二级标签名
  subLabel?: string
  // v-model绑定的默认值
  valueField?: string
  // 表单修改事件
  changeEvent?: string
  // 标签宽度
  labelWidth?: string | number
  // 组件名
  component: ComponentType
  // 组件属性
  componentProps?:
    | (((opt: {
        schema: FormSchema
        formActionType: FormActionType
        formModel: Recordable
      }) => Recordable) & {
        [key: string]: any
      })
    | {
        [key: string]: any
      }
  // Placeholder 自动设置
  autoSetPlaceHolder?: boolean
  // 是否必录
  required?: boolean | ((renderCallbackParams: RenderCallbackParams) => boolean)
  // 组件后面的内容
  suffix?: string | number | ((values: RenderCallbackParams) => string | number | VNode)
  // 校验规则
  rules?: Rule[]
  // 单元格属性
  colProps?: Partial<ColEx>
  // 默认值
  defaultValue?: any
  // js control
  ifShow?: boolean | ((renderCallbackParams: RenderCallbackParams) => boolean)
  // css control
  show?: boolean | ((renderCallbackParams: RenderCallbackParams) => boolean)

  // Render the content in the form-item tag
  render?: (
    renderCallbackParams: RenderCallbackParams,
    opts: RenderOpts
  ) => VNode | VNode[] | string

  renderColContent?: (
    renderCallbackParams: RenderCallbackParams,
    opts: RenderOpts
  ) => VNode | VNode[] | string

  renderComponentContent?:
    | ((renderCallbackParams: RenderCallbackParams, opts: RenderOpts) => any)
    | VNode
    | VNode[]
    | string

  // 插槽
  slot?: string
  // 是否自动处理与时间相关组件的默认值
  isHandleDateDefaultValue?: boolean
  // 额外默认值数组对象
  defaultValueObj?: { [key: string]: any }

  // Custom slot, similar to renderColContent
  colSlot?: string

  // Reference formModelItem
  itemProps?: Partial<FormItemProps>

  // 动态表单禁用字段
  dynamicDisabled?: boolean | ((renderCallbackParams: RenderCallbackParams) => boolean)
  // 动态校验规则
  dynamicRules?: (renderCallbackParams: RenderCallbackParams) => Rule[]
}
