import type { ColProps } from 'element-plus'

export type InternalNamePath = (string | number)[]
export type NamePath = string | number | InternalNamePath

export type ComponentType =
  | 'ElInput'
  | 'ElTimePicker'
  | 'ElDatePicker'
  | 'ElSlider'
  | 'Select'
  | 'ApiSelect'
  | 'ElCascader'
  | 'ElInputNumber'
  | 'PersonSelect'
  | 'ElTreeSelect'
  | 'ElSwitch'
  | 'ApiCascader'
  | 'ElCheckbox'
  | 'ElDivider'
  | 'ElRadio'
  | 'Radio'
  | 'Text'

export interface ColEx extends ColProps {
  style?: any
}
