import type { ComponentType } from './types'
import type { Rule } from './types/form'

const DATE_TYPE = ['ElDatePicker', 'ElTimePicker']

function genType() {
  return [...DATE_TYPE]
}

/**
 * 时间字段
 */
export const dateItemType = genType()

/**
 * @description: 生成placeholder
 */
export function createPlaceholderMessage(component: ComponentType) {
  if (component.includes('ElInput') || component.includes('Complete')) {
    return '请输入'
  }
  if (component.includes('Picker')) {
    return '请选择'
  }
  if (
    component.includes('ApiCascader') ||
    component.includes('ApiSelect') ||
    component.includes('Select') ||
    component.includes('ElSelect') ||
    component.includes('ElCascader') ||
    component.includes('ElCheckbox') ||
    component.includes('ElRadio') ||
    component.includes('ElSwitch')
  ) {
    return '请选择'
  }
  return ''
}
// 设置组件rule类型
export function setComponentRuleType(rule: Rule, component: ComponentType, valueFormat: string) {
  if (Reflect.has(rule, 'type')) {
    return
  }
  if (['ElDatePicker', 'ElTimePicker'].includes(component)) {
    rule.type = valueFormat ? 'string' : 'object'
  } else if (['ElUpload', 'ElCheckboxGroup', 'ElTimePicker'].includes(component)) {
    rule.type = 'array'
  } else if (['ElInputNumber'].includes(component)) {
    rule.type = 'number'
  }
}

export function createComponentDefaultStyle(component: ComponentType) {
  if (['ElSwitch'].includes(component)) {
    return ''
  } else {
    return 'width: 100%'
  }
}
