<template>
  <el-col v-bind="realColProps" v-if="getShow.isIfShow" v-show="getShow.isShow">
    <template v-if="schema.colSlot">
      <slot :name="schema.colSlot" v-bind="params"></slot>
    </template>
    <template v-else-if="schema.renderColContent">
      <component :is="schema.renderColContent(values, opts)" />
    </template>
    <template v-else>
      <template v-if="schema.component === 'ElDivider'">
        <el-col :span="24">
          <el-divider />
        </el-col>
      </template>
      <el-form-item v-else v-bind="getItemProps" :rules="getRules" :prop="schema.field">
        <template #label>
          <span>
            <template v-if="schema.subLabel">
              <span>
                {{ schema.label }} <span class="text-secondary">{{ schema.subLabel }}</span>
              </span>
            </template>
            <template v-else> {{ schema.label }}</template>
          </span>
        </template>

        <div style="display: flex; flex: 1">
          <div style="flex: 1">
            <template v-if="schema.slot">
              <slot :name="schema.slot" v-bind="params"></slot>
            </template>
            <template v-else-if="schema.render">
              <component :is="schema.render(values, opts)" />
            </template>

            <template v-else>
              <template v-if="!renderComponentContent">
                <component :is="Comp" v-bind="compAttr" />
              </template>
              <template v-else>
                <component :is="Comp" v-bind="compAttr">
                  <component :is="compSlot" />
                </component>
              </template>
            </template>
          </div>

          <template v-if="showSuffix">
            <span class="suffix">
              <component :is="getSuffix" />
            </span>
          </template>
        </div>
      </el-form-item>
    </template>
  </el-col>
</template>

<script lang="tsx" setup>
import type { PropType, Ref, defineComponent } from 'vue'
import type { FormSchema, FormProps, Rule, FormActionType } from '../types/form'

import { computed, ref, toRefs, unref, watch } from 'vue'

import { isBoolean, isDef, isFunction, isNull } from '@/utils/is'
import { cloneDeep, upperFirst } from 'lodash-es'

import {
  createPlaceholderMessage,
  setComponentRuleType,
  createComponentDefaultStyle
} from '../helper'
import { componentMap } from '../componentMap'

defineOptions({
  name: 'FormItem',
  inheritAttrs: false
})
const props = defineProps({
  schema: {
    type: Object as PropType<FormSchema>,
    default: () => ({})
  },
  formProps: {
    type: Object as PropType<FormProps>,
    default: () => ({})
  },
  allDefaultValues: {
    type: Object as PropType<Recordable<any>>,
    default: () => ({})
  },
  formModel: {
    type: Object as PropType<Recordable<any>>,
    default: () => ({})
  },
  setFormModel: {
    type: Function as PropType<(key: string, value: any, schema: FormSchema) => void>,
    default: null
  },
  formActionType: {
    type: Object as PropType<FormActionType>
  }
})

const { schema, formProps } = toRefs(props) as {
  schema: Ref<FormSchema>
  formProps: Ref<FormProps>
}

const getValues = computed(() => {
  const { allDefaultValues, formModel, schema } = props

  return {
    field: schema.field,
    model: formModel,
    values: {
      ...allDefaultValues,
      ...formModel
    } as Recordable<any>,
    schema: schema
  }
})
// 获取组件属性
const getComponentsProps = computed(() => {
  const { schema, formActionType, formModel } = props

  let { componentProps = {} } = schema

  if (isFunction(componentProps)) {
    componentProps = componentProps({ schema, formModel, formActionType }) ?? {}
  }

  return componentProps as Recordable<any>
})
// 获取是否禁用
const getDisable = computed(() => {
  const { disabled: globDisabled } = props.formProps

  const { dynamicDisabled } = props.schema
  const { disabled: itemDisabled = false } = unref(getComponentsProps)
  let disabled = !!globDisabled || itemDisabled

  if (isBoolean(dynamicDisabled)) {
    disabled = dynamicDisabled
  }
  if (isFunction(dynamicDisabled)) {
    disabled = dynamicDisabled(unref(getValues))
  }

  return disabled
})

const getShow = computed((): { isShow: boolean; isIfShow: boolean } => {
  const { show, ifShow } = props.schema

  let isShow = true
  let isIfShow = true

  if (isBoolean(show)) {
    isShow = show
  }
  if (isBoolean(ifShow)) {
    isIfShow = ifShow
  }
  if (isFunction(show)) {
    isShow = show(unref(getValues))
  }
  if (isFunction(ifShow)) {
    isIfShow = ifShow(unref(getValues))
  }

  return { isShow, isIfShow }
})
// 处理校验规则
const getRules = computed((): Rule[] => {
  const { rules: defRules = [], component, label, dynamicRules, required } = props.schema

  if (isFunction(dynamicRules)) {
    return dynamicRules(unref(getValues)) as Rule[]
  }

  let rules: Rule[] = cloneDeep(defRules) as Rule[]

  const defaultMsg = component ? createPlaceholderMessage(component) + label : label
  // 表单校验
  function validator(rule: any, value: any, callback: any) {
    const msg = rule.message || defaultMsg
    if (value === undefined || isNull(value)) {
      // 空值
      return callback(new Error(msg))
    } else if (Array.isArray(value) && value.length === 0) {
      // 数组类型
      return callback(new Error(msg))
    } else if (typeof value === 'string' && value.trim() === '') {
      // 空字符串
      return callback(new Error(msg))
    } else if (
      typeof value === 'object' &&
      Reflect.has(value, 'checked') &&
      Reflect.has(value, 'halfChecked') &&
      Array.isArray(value.checked) &&
      Array.isArray(value.halfChecked) &&
      value.checked.length === 0 &&
      value.halfChecked.length === 0
    ) {
      // 非关联选择的tree组件
      return callback(new Error(msg))
    }
    return callback()
  }

  const getRequired = isFunction(required) ? required(unref(getValues)) : required

  /*
   * 1、若设置了required属性，又没有其他的rules，就创建一个验证规则；
   * 2、若设置了required属性，又存在其他的rules，则只rules中不存在required属性时，才添加验证required的规则
   *     也就是说rules中的required，优先级大于required
   */
  if (getRequired) {
    if (!rules || rules.length === 0) {
      rules = [{ required: getRequired, validator }]
    } else {
      const requiredIndex: number = rules.findIndex((rule) => Reflect.has(rule, 'required'))

      if (requiredIndex === -1) {
        rules.push({ required: getRequired, validator })
      }
    }
  }

  const requiredRuleIndex: number = rules.findIndex(
    (rule) => Reflect.has(rule, 'required') && !Reflect.has(rule, 'validator')
  )

  if (requiredRuleIndex !== -1) {
    const rule = rules[requiredRuleIndex]
    const { isShow } = getShow.value
    // 不显示则取消必录，防止校验报错
    if (!isShow) {
      rule.required = false
    }
    if (component) {
      rule.message = rule.message || defaultMsg

      // 测试字段是否只有空格，添加 whitespace 属性并设为true
      if (component.includes('ElInput') || component.includes('ElTextarea')) {
        rule.whitespace = true
      }
      const valueFormat = unref(getComponentsProps)?.valueFormat
      setComponentRuleType(rule, component, valueFormat)
    }
  }

  // Maximum input length rule check
  const characterInx = rules.findIndex((val) => val.max)
  if (characterInx !== -1 && !rules[characterInx].validator) {
    rules[characterInx].message =
      rules[characterInx].message || `字符数应小于${rules[characterInx].max}位`
  }
  return rules
})

const { component } = schema.value
const realColProps = computed(() => ({ ...formProps.value.baseColProps, ...schema.value.colProps }))
const values = unref(getValues)
const opts = { disabled: unref(getDisable) }
const params = ref({ ...values, ...opts })

const { field } = schema.value

const getItemProps = computed(() => ({
  labelWidth: unref(schema).labelWidth,
  ...unref(schema).itemProps
}))

const showSuffix = computed(() => {
  const { suffix } = props.schema

  return !!suffix
})
const getSuffix = computed(() => {
  const { suffix } = props.schema

  return isFunction(suffix)
    ? (suffix(unref(getValues)) as ReturnType<typeof defineComponent>)
    : { suffix }
})

const { renderComponentContent, changeEvent = 'Update:modelValue', valueField } = unref(schema)

// 从map中获取组件
const Comp = componentMap.get(component) as ReturnType<typeof defineComponent>

// 组件属性
const compAttr: Recordable<any> = computed(() => {
  // 事件键名
  const eventKey = `on${upperFirst(changeEvent)}`
  // 监听组件触发改变
  const on = {
    [eventKey]: (...args: Nullable<Recordable<any>>[]) => {
      // 执行自定义函数
      if (propsData[eventKey]) {
        propsData[eventKey](...args)
      }
      const value = args[0]
      props.setFormModel(field, value, props.schema)
    }
  }

  const { autoSetPlaceHolder, size } = unref(formProps)

  // 组件props
  const propsData: Recordable<any> = {
    clearable: true,
    size,
    style: createComponentDefaultStyle(component),
    ...unref(getComponentsProps),
    disabled: unref(getDisable)
  }

  // const isCreatePlaceholder = !propsData.disabled && autoSetPlaceHolder

  // Range类型组件提示是一个数组
  // if (isCreatePlaceholder && component) {
  if (component) {
    propsData.placeholder = isDef(unref(getComponentsProps)?.placeholder)
      ? unref(getComponentsProps)?.placeholder
      : createPlaceholderMessage(component)
  }
  propsData.codeField = field
  propsData.formValues = unref(getValues)
  const { formModel } = toRefs(props)
  const getBindValue: Recordable<any> = {
    [valueField || 'modelValue']: formModel.value[field]
  }
  return {
    ...propsData,
    ...on,
    ...unref(getBindValue)
  }
})

// 组件插槽
const compSlot = isFunction(renderComponentContent)
  ? { ...renderComponentContent(unref(getValues), { disabled: unref(getDisable) }) }
  : {
      default: () => renderComponentContent
    }
</script>

<style lang="scss" scoped></style>
