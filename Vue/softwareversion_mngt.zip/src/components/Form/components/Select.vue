<template>
  <el-select v-bind="getAttrs" v-model="state" @change="handleChange">
    <el-option
      v-for="item in getOptions"
      :key="item[valueField]"
      :label="item.label"
      :value="item.value"
      :disabled="item.disabled"
    >
      <template v-if="$slots.default">
        <slot :option="item"></slot>
      </template>
      <template v-if="slots?.default">
        <component :is="slots?.default" :option="item" />
      </template>
    </el-option>
  </el-select>
</template>

<script lang="ts" setup>
import type { PropType, VNode } from 'vue'
import { ref, computed, useAttrs, watch, unref } from 'vue'

import { useRuleFormItem } from '@/hooks/useFormItem'

interface Slots {
  default?: (...args: any) => VNode | string
}
defineOptions({
  name: 'SelectPro',
  inheritAttrs: false
})
const props = defineProps({
  modelValue: {
    type: [Array, Object, String, Number]
  },
  disabled: {
    type: Boolean,
    default: false
  },
  labelField: {
    type: String,
    default: 'label'
  },
  valueField: {
    type: String,
    default: 'value'
  },
  defaultSelectFirst: {
    type: Boolean,
    default: false
  },
  options: {
    type: Array as PropType<Recordable>,
    default: () => {
      return []
    }
  },
  slots: {
    type: Object as PropType<Slots>,
    default: () => {
      return {}
    }
  }
})

type OptionsItem = { label: string; value: string; disabled?: boolean; [key: string]: any }

const emit = defineEmits(['change', 'update:modelValue', 'options-change', 'defaultChange'])

const emitData = ref<any>([])
const attrs = useAttrs()

// 内部维护状态并同步外层，可尝试defineModel宏
const [state] = useRuleFormItem(props, 'modelValue', 'change', emitData)

const getAttrs = computed(() => ({
  ...attrs,
  disabled: props.disabled
}))

const getOptions = computed((): OptionsItem[] => {
  const { labelField, valueField, options, modelValue } = props

  const filterField = { key: 'dataStatus', value: 1 }

  const newOption = options
    .filter((item: any) => {
      if (Reflect.has(item, filterField.key)) {
        return item[filterField.key] === filterField.value || item[valueField] === modelValue
      }
      return true
    })
    .map((option: any) => {
      return {
        // ...omit(option, [labelField, valueField]),
        disabled: Reflect.has(option, filterField.key)
          ? option[filterField.key] !== filterField.value
          : false,
        ...option,
        label: option[labelField],
        value: option[valueField]
      }
    })
  return newOption
})

watch(
  () => state.value,
  (newValue) => {
    emit('update:modelValue', newValue)
  }
)

watch(getOptions, (newOptions) => {
  if (props.defaultSelectFirst && newOptions.length) {
    state.value = newOptions[0].value
  }
})

const handleChange = (value: typeof props.modelValue) => {
  const option = getOptions.value.find((option: OptionsItem) => option.value === value)
  emitData.value = [option, unref(getOptions)]

  // emit('change', value, option, getOptions)
}

function emitChange() {
  emit('options-change', unref(getOptions))
}

watch(getOptions, () => {
  emitChange()
})
</script>

<style lang="scss" scoped></style>
