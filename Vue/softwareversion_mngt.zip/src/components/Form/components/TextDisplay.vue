<template>
  {{ modelValue }}
</template>

<script lang="ts" setup>
defineOptions({
  name: 'TextDisplay',
  inheritAttrs: false
})
defineProps({
  modelValue: {
    type: String
  }
})
</script>

<style lang="scss" scoped></style>
