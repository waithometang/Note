<template>
  <el-radio-group v-bind="getBindValues" v-model="state" @change="handleChange">
    <el-radio
      v-for="item in getOptions"
      :key="item.label"
      :label="item.label"
      :disabled="item.disabled"
    >
      {{ item.display }}
    </el-radio>
  </el-radio-group>
</template>

<script lang="ts" setup>
import type { PropType } from 'vue'
import { ref, computed, useAttrs, watch } from 'vue'
import { omit } from 'lodash-es'

import { useRuleFormItem } from '@/hooks/useFormItem'
defineOptions({
  name: 'Radio',
  inheritAttrs: false
})
const props = defineProps({
  modelValue: {
    type: [Array, Object, String, Number]
  },
  disabled: {
    type: Boolean,
    default: false
  },
  labelField: {
    type: String,
    default: 'label'
  },
  displayField: {
    type: String,
    default: 'display'
  },
  options: {
    type: Array as PropType<Recordable>,
    default: () => {
      return []
    }
  }
})

const emit = defineEmits(['change', 'update:modelValue'])

const emitData = ref<any>([])
const attrs = useAttrs()

// 内部维护状态并同步外层，可尝试defineModel宏
const [state] = useRuleFormItem(props, 'modelValue', 'change', emitData)

const getBindValues = computed(() => ({
  ...attrs,
  disabled: props.disabled
}))

const getOptions = computed(() => {
  const { labelField, displayField, options } = props

  const newOption = options.map((option: any) => {
    return {
      ...omit(option, [labelField, displayField]),
      label: option[labelField],
      display: option[displayField]
    }
  })
  return newOption
})

watch(
  () => state.value,
  (newValue) => {
    emit('update:modelValue', newValue)
  }
)

const handleChange = (value: typeof props.modelValue) => {
  emitData.value = value
}
</script>

<style lang="scss" scoped>
.el-radio {
  margin-right: 15px;
}
</style>
