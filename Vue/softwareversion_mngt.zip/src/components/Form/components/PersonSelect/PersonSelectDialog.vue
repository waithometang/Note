<template>
  <BasicModal
    width="1500px"
    v-bind="$attrs"
    @register="registerModal"
    title="选择人员"
    @open="handleOpen"
    @confirm="handleSubmit"
  >
    <div class="container">
      <basic-tree ref="basicTreeRef" v-bind="listOptions" />

      <vxe-grid class="box table-wrapper" ref="gridRef" v-bind="gridOptions" v-on="gridEvents">
        <template #top>
          <GridHeader
            ref="gridHeaderRef"
            v-bind="headerOptions"
            @quickSearch="handleQuickSearch"
            @advancedSearch="handleAdvancedSearch"
            @reset="handleReset"
          />
        </template>
        <template #employeeName="{ row }">
          <div style="display: flex; align-items: center">
            <div>{{ row.employeeName }}</div>
            <el-tag
              v-if="row.transferInStatus === 1"
              type="warning"
              size="small"
              effect="plain"
              style="margin-left: 5px"
              >借调</el-tag
            >
          </div>
        </template>
      </vxe-grid>
    </div>
  </BasicModal>
</template>

<script lang="tsx" setup>
import type { ComponentExposed } from 'vue-component-type-helpers'
import type {
  GetEmployeeInfoBySelectModel,
  GetEmployeeInfoBySelectParams
} from '@/api/sys/model/basicModel'
import type { ModalMethods } from '@/components/Modal/types'
import type { VxeGridInstance, VxeGridProps, VxeGridListeners } from 'vxe-table'
import type { GridHeaderProps } from '@/components/Table/types/gridHeader'
import type { TreeProps } from '@/components/Tree/types/tree'
import BasicTree from '@/components/Tree/BasicTree.vue'

import { ref, reactive, unref, computed, type PropType } from 'vue'
import {
  getDepartment,
  getKeyValue,
  getGroupSelect,
  getEmployeeInfoBySelect
} from '@/api/sys/basic'

import { useModalInner } from '@/components/Modal/hooks/useModal'
import BasicModal from '@/components/Modal/BasicModal.vue'

import GridHeader from '@/components/Table/GridHeader.vue'

const emit = defineEmits<{
  register: [modalMethods: ModalMethods, uuid: number]
  success: [{ res: GetEmployeeInfoBySelectModel[] }]
}>()

const props = defineProps({
  multiple: {
    type: Boolean,
    default: false
  },
  departmentID: {
    type: String
  },
  attendanceDate: {
    type: String,
    default: ''
  },
  requestDate: {
    type: String,
    default: ''
  },
  groupID: {
    type: String
  },
  beforeConfirm: {
    type: Function as PropType<(res: GetEmployeeInfoBySelectModel[]) => boolean>
  }
})

const basicTreeRef = ref<InstanceType<typeof BasicTree>>()

const currentDepartmentID = ref<string>()
// 列表配置
const listOptions = reactive<TreeProps>({
  api: getDepartment,
  title: '部门列表',
  labelField: 'departmentName',
  resultField: 'data.result',
  childrenField: 'sonData',
  nodeKey: 'id',
  onSelect: async (node) => {
    await handleNodeClick(node)
    currentDepartmentID.value = node.id
    gridRef.value?.commitProxy('reload')
  }
})

const handleNodeClick = async (node: any) => {
  await gridHeaderRef.value?.setAdvancedSearchFormFieldValue({ groupID: '' })
  await updateGroupList(node.id)
}

const updateGroupList = async (departmentID?: string) => {
  if (!departmentID) {
    await gridHeaderRef.value?.updateAdvancedSearchForm({
      field: 'groupID',
      componentProps: {
        options: []
      }
    })
  } else {
    const { data } = await getGroupSelect({
      departmentID: departmentID
    })
    const groupList = data.result
    await gridHeaderRef.value?.updateAdvancedSearchForm({
      field: 'groupID',
      componentProps: {
        options: unref(groupList)
      }
    })
  }
}

const gridHeaderRef =
  ref<ComponentExposed<typeof GridHeader<GetEmployeeInfoBySelectParams, 'employeeName'>>>()
const headerOptions = reactive<GridHeaderProps>({
  title: `员工信息`,
  showAddButton: false,
  quickSearch: {
    singleSearch: {
      field: 'employeeName',
      type: 'input',
      title: '工号/姓名'
    },
    searchFormFields: { employeeName: '' }
  },
  advancedSearch: {
    labelWidth: 90,
    schemas: [
      {
        field: 'groupID',
        component: 'Select',
        label: '组别',
        componentProps: {
          options: []
        },
        colProps: {
          span: 8
        }
      },
      {
        field: 'positionID',
        component: 'ApiSelect',
        label: '岗位',
        componentProps: {
          api: getKeyValue,
          resultField: 'data.result',
          labelField: 'value',
          valueField: 'id',
          params: {
            typeName: 'Position'
          }
        },
        colProps: {
          span: 8
        }
      },
      {
        field: 'attendanceDate',
        component: 'ElDatePicker',
        label: '考勤日期',
        ifShow() {
          return props.attendanceDate ? true : false
        },
        componentProps: {
          valueFormat: 'YYYY-MM-DD'
        },
        colProps: {
          span: 8
        }
      },
      {
        field: 'requestDate',
        component: 'ElDatePicker',
        label: '借调日期',
        ifShow() {
          return props.requestDate ? true : false
        },
        componentProps: {
          disabled: true,
          valueFormat: 'YYYY-MM-DD'
        },
        colProps: {
          span: 8
        }
      }
    ]
  }
})

const gridRef = ref<VxeGridInstance>()
const gridOptions = computed<VxeGridProps<GetEmployeeInfoBySelectModel>>(() => {
  const type = props.multiple ? 'checkbox' : 'radio'
  return {
    border: true,
    height: 'auto',
    align: null,
    columnConfig: {
      resizable: true
    },
    radioConfig: { reserve: false, trigger: 'row' }, // 是否保留勾选状态
    checkboxConfig: { reserve: false, trigger: 'row' }, // 是否保留勾选状态
    columns: [
      { type: type, width: 50 },
      { type: 'seq', width: 50 },
      { field: 'employeeNo', title: '工号' },
      { field: 'employeeName', title: '姓名', slots: { default: 'employeeName' } },
      { field: 'positionName', title: '岗位' },
      { field: 'departmentName', title: '部门' },
      { field: 'groupName', title: '班组' },
      { field: 'productionAddressName', title: '厂区' }
    ],
    rowConfig: {
      keyField: 'id'
    },
    pagerConfig: {
      enabled: true,
      pageSize: 20
    },
    proxyConfig: {
      autoLoad: false,
      ajax: {
        query: ({ page }) => {
          const quickSearchForm = gridHeaderRef.value?.quickSearchForm
          const advancedSearchForm = gridHeaderRef.value?.getAdvancedSearchForm()

          const data: GetEmployeeInfoBySelectParams = {
            ...quickSearchForm,
            ...advancedSearchForm,
            DepartmentID: currentDepartmentID.value
          }

          return getEmployeeInfoBySelect({
            pageIndex: page.currentPage - 1, // 由于后端接口限制，首页从0开始
            pageSize: page.pageSize,
            ...data
          })
        }
      }
    }
  }
})

const gridEvents = reactive<VxeGridListeners<GetEmployeeInfoBySelectModel>>({
  // cellClick({ row }) {
  // }
})

const handleAdvancedSearch = () => {
  gridRef.value?.commitProxy('reload')
}

const handleReset = () => {
  gridRef.value?.commitProxy('reload')
}

const handleQuickSearch = () => {
  gridRef.value?.commitProxy('reload')
}

const [registerModal, { closeModal }] = useModalInner()

// 提交
const handleSubmit = async () => {
  let res: GetEmployeeInfoBySelectModel[]
  if (props.multiple) {
    res = gridRef
      .value!.getCheckboxRecords(true)
      .concat(gridRef.value!.getCheckboxReserveRecords(true))
  } else {
    const list = gridRef.value!.getRadioRecord() ? [gridRef.value!.getRadioRecord()] : []
    const other = gridRef.value!.getRadioReserveRecord(true)
      ? [gridRef.value!.getRadioReserveRecord(true)]
      : []

    res = list.concat(other)
  }
  if (typeof props.beforeConfirm === 'undefined' || props.beforeConfirm?.(res)) {
    emit('success', { res })
    closeModal()
  }
}
const handleOpen = async () => {
  await gridHeaderRef.value?.resetFields()
  await gridRef.value?.removeRadioRow()
  await gridRef.value?.removeCheckboxRow()
  await gridRef.value?.clearCurrentRow()
  basicTreeRef.value?.treeRef?.setCurrentKey()
  currentDepartmentID.value = props.departmentID

  await gridHeaderRef.value?.setFieldsValue({
    attendanceDate: props.attendanceDate,
    requestDate: props.requestDate
  })

  if (props.departmentID) {
    await updateGroupList(props.departmentID)

    await gridHeaderRef.value?.setFieldsValue({ groupID: props.groupID })
    basicTreeRef.value?.treeRef?.setCurrentKey(props.departmentID, true)
  }

  gridRef.value?.commitProxy('reload')
}
</script>

<style lang="scss" scoped>
.container {
  display: flex;
  gap: 20px;
  height: 60vh;
}

.vxe-grid {
  flex: 1;
}
:deep(.grid-search-box-container) {
  .el-input {
    margin-bottom: 20px;
  }
}
</style>
