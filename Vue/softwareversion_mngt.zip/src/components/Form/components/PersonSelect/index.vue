<template>
  <div class="select-container">
    <div class="disabled-cover" v-if="disabled"></div>
    <div
      class="select-wrapper el-input"
      :class="{ disabled: disabled, danger: validateState === 'error' }"
    >
      <div class="content" :class="inputValue ? '' : 'placeholder'">
        <Tooltip :content="inputValue ? inputValue : '请选择人员'" />
        <svg-icon
          v-if="inputValue"
          style="font-size: 16px; color: #000"
          icon="close"
          class="clear"
          @click="handleClear"
        />
      </div>
      <div class="svg-wrapper" @click="openPersonSelectDialog">
        <svg-icon style="font-size: 16px; color: #000" icon="search" />
      </div>
    </div>
  </div>
  <PersonSelectDialog
    @register="registerModal"
    @success="handleSuccess"
    append-to-body
    :multiple="multiple"
    :attendanceDate="attendanceDate"
    :requestDate="requestDate"
    :departmentID="departmentID"
    :groupID="groupID"
    :beforeConfirm="beforeConfirm"
  />
</template>

<script setup lang="ts">
import type { GetEmployeeInfoBySelectModel, GetEmployeeInfoModel } from '@/api/sys/model/basicModel'
import type { PropType } from 'vue'

import { useModal } from '@/components/Modal/hooks/useModal'

import PersonSelectDialog from './PersonSelectDialog.vue'
import Tooltip from '@/components/Tooltip/BasicTooltip.vue'

import { computed, ref, watch, onMounted } from 'vue'
import { useFormItem } from 'element-plus'

import { getEmployeeInfoAssemblyMany } from '@/api/sys/basic'

defineOptions({
  name: 'PersonSelect',
  inheritAttrs: false
})

const [registerModal, { openModal }] = useModal()
const { formItem } = useFormItem()

const props = defineProps({
  modelValue: {
    type: [String, Array<string>]
  },
  employeeName: {
    type: String
  },
  disabled: {
    type: Boolean,
    default: false
  },
  multiple: {
    type: Boolean,
    default: false
  },
  departmentID: {
    type: String
  },
  attendanceDate: {
    type: String
  },
  requestDate: {
    type: String
  },
  groupID: {
    type: String
  },
  formatter: {
    type: Function as PropType<(info: GetEmployeeInfoModel) => string>,
    default: (info: GetEmployeeInfoModel) => {
      return info.employeeName
    }
  },
  beforeConfirm: {
    type: Function as PropType<(res: GetEmployeeInfoBySelectModel[]) => boolean>
  }
})

const emit = defineEmits(['update:modelValue', 'change', 'confirm', 'clear'])

const inputValue = ref('')

const validateState = computed(() => formItem?.validateState)

const getEmployeeInfo = async (value: string | string[]) => {
  let reqData: string[]

  if (props.multiple) {
    if (!(value instanceof Array)) {
      throw new Error('值类型限制为array,得到的是' + typeof value)
    }
    reqData = value
  } else {
    if (typeof value !== 'string') {
      throw new Error('值类型限制为string,得到的是' + typeof value)
    }
    reqData = [value]
  }
  if (reqData.length === 0) {
    inputValue.value = ''
    return
  }

  const { code, data } = await getEmployeeInfoAssemblyMany({
    employeeInfoID: reqData
  })
  if (code === 200) {
    inputValue.value = data.result.map((item) => props.formatter(item)).join('，')
  }
}

watch(
  () => props.modelValue,
  async (value) => {
    if (!value) {
      inputValue.value = ''
    } else {
      if (props.multiple) {
        inputValue.value = (value as string[]).map((item) => item).join(',')
      } else {
        inputValue.value = value as string
      }
      getEmployeeInfo(value)
    }

    emit('change', value)
    formItem?.validate('change').catch((err) => console.warn(err)) // 修复重置表单时的报错打印
  },
  { immediate: true } //解决表格编辑时 回显不出来name的问题
)

const openPersonSelectDialog = () => {
  openModal()
}

const handleClear = () => {
  emit('update:modelValue', '')
  emit('clear')
}

const handleSuccess = ({ res }: { res: GetEmployeeInfoBySelectModel[] }) => {
  let modalValue: string[] | string
  let data: GetEmployeeInfoBySelectModel[] | GetEmployeeInfoBySelectModel
  if (res.length > 0) {
    if (props.multiple) {
      modalValue = res.map((item) => item.id)
      data = res
    } else {
      modalValue = res[0]['id']
      data = res[0]
    }
    emit('update:modelValue', modalValue)
    emit('confirm', data)
  }
}
</script>

<style lang="scss" scoped>
.select-container {
  position: relative;
  overflow: hidden;
  .disabled-cover {
    position: absolute;
    left: 0;
    right: 0;
    top: 0;
    bottom: 0;
    // pointer-events: none;
    z-index: 2;
    cursor: not-allowed;
    // background-color: #f5f7fa;
  }
  .select-wrapper {
    --el-input-inner-height: calc(var(--el-input-height, 32px) - 2px);
    display: inline-flex;
    box-shadow: 0 0 0 1px var(--el-input-border-color, var(--el-border-color)) inset;
    border-radius: var(--el-input-border-radius, var(--el-border-radius-base));
    padding: 1px 0;
    overflow: hidden;
    min-height: var(--el-input-inner-height);
    transition: var(--el-transition-box-shadow);
    background-color: var(--el-input-bg-color, var(--el-fill-color-blank));
    &.disabled {
      background-color: var(--el-disabled-bg-color);
    }
    &.danger {
      box-shadow: 0 0 0 1px var(--el-color-danger) inset;
    }
    &:hover {
      box-shadow: 0 0 0 1px var(--el-input-hover-border-color) inset;
      .clear {
        display: block !important;
      }
    }
    .content {
      cursor: text;
      flex: 1;
      width: 0;
      position: relative;
      padding-left: 11px;
      padding-right: 20px;
      overflow: hidden;
      .clear {
        display: none;
        position: absolute;
        right: 5px;
        top: 50%;
        transform: translateY(-50%);
        cursor: pointer;
      }
    }
  }
}

.svg-wrapper {
  padding: 0 15px;
  background-color: var(--el-input-border-color);
  margin-right: 1px;
  display: flex;
  align-items: center;
  overflow: hidden;
  cursor: pointer;
  .svg {
    vertical-align: middle;
  }
}
.placeholder {
  color: var(--el-text-color-placeholder);
}
</style>
