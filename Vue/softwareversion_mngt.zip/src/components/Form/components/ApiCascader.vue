<template>
  <el-cascader
    ref="cascaderRef"
    v-bind="getAttrs"
    v-model="state"
    :options="options"
    :props="getProps"
    @change="handleChange"
  >
    <template #empty v-if="loading">
      <span>
        <svg-icon :class="{ spin: loading }" icon="loading" />
        请等待数据加载完成...
      </span>
    </template>
  </el-cascader>
</template>

<script lang="ts" setup>
import type { PropType, WritableComputedRef } from 'vue'
import type { CascaderProps, CascaderValue } from 'element-plus'

import { computed, ref, toRefs, unref, useAttrs, warn, watch, nextTick } from 'vue'
import { get, omit } from 'lodash-es'
import { ElCascader, useFormItem } from 'element-plus'

import { useRuleFormItem } from '@/hooks/useFormItem'
import { isFunction } from '@/utils/is'

interface OptionsItem {
  value: string
  label: string
  children?: OptionsItem[]
}

const props = defineProps({
  modelValue: {
    type: [Array, Object, String, Number]
  },
  api: {
    type: Function as PropType<(arg?: any) => Promise<any>>,
    default: null
  },
  // api params
  params: {
    type: Object as PropType<any>,
    defalut: () => {
      return {}
    }
  },
  numberToString: {
    type: Boolean,
    default: false
  },
  labelField: {
    type: String,
    default: 'label'
  },
  valueField: {
    type: String,
    default: 'value'
  },
  // support xxx.xxx.xx
  resultField: {
    type: String,
    default: ''
  },
  // support xxx.xxx.xx
  childrenField: {
    type: String,
    default: 'children'
  },
  cascaderProps: {
    type: Object as PropType<CascaderProps>,
    default: () => {
      return {}
    }
  },
  disabled: {
    type: Boolean,
    default: false
  },
  // Execute immediately
  immediate: {
    type: Boolean,
    default: true
  }
})
const emit = defineEmits(['defaultChange', 'change', 'update:modelValue'])

const cascaderRef = ref<InstanceType<typeof ElCascader>>()
const attrs = useAttrs()
const emitData = ref<any>([])
const loading = ref(false)
const isFirstLoaded = ref(false) // 是否首次加载过
const apiData = ref<any[]>([])
const options = ref<OptionsItem[]>([])

// 内部维护状态并同步外层，可尝试defineModel宏
const [state] = useRuleFormItem(props, 'modelValue', 'change', emitData) as unknown as [
  WritableComputedRef<CascaderValue>
]

const getAttrs = computed(() => ({
  ...attrs,
  disabled: props.disabled
}))

const getProps = computed(
  (): CascaderProps => ({
    checkStrictly: true,
    ...props.cascaderProps
  })
)

watch(
  apiData,
  (data) => {
    const opts = generatorOptions(data)

    options.value = opts
  },
  { deep: true }
)
/**
 * 生成options
 */
const generatorOptions = (options: any) => {
  const { labelField, valueField, numberToString, childrenField } = props
  return options.reduce((prev: OptionsItem[], next: Recordable<any>) => {
    if (next) {
      const value = next[valueField]
      const item = {
        ...omit(next, [labelField, valueField]),
        label: next[labelField],
        value: numberToString ? `${value}` : value
      }
      const children = Reflect.get(next, childrenField)
      if (children) {
        Reflect.set(item, 'children', generatorOptions(children))
      }
      prev.push(item)
    }
    return prev
  }, [] as OptionsItem[])
}

const initialFetch = async () => {
  const api = props.api

  if (!api || !isFunction(api) || loading.value) return

  apiData.value = []

  try {
    loading.value = true
    const res = await api(props.params)
    isFirstLoaded.value = true

    if (Array.isArray(res)) {
      apiData.value = res
      return
    }
    // 深层级获取
    if (props.resultField) {
      apiData.value = get(res, props.resultField) || []
    }
  } catch (error: any) {
    warn(error)
  } finally {
    loading.value = false
  }
}

const { formItem } = useFormItem()
watch(
  () => state.value,
  (newValue) => {
    emit('update:modelValue', newValue)
    nextTick(() => {
      formItem?.validate('change').catch((err) => console.warn(err)) // 修复重置表单时的报错打印
    })
  }
)

const { params, immediate } = toRefs(props)

watch(
  () => params,
  () => {
    !unref(isFirstLoaded) && initialFetch()
  },
  { deep: true, immediate: unref(immediate) }
)

const handleChange = (value: typeof props.modelValue) => {
  const cascaderNode = cascaderRef.value?.getCheckedNodes(true)!
  if (cascaderNode.length) {
    const { data } = cascaderNode[0]

    emitData.value = [data]
  }

  // emit('change', value)
}
defineExpose({ cascaderRef })
</script>

<style lang="scss" scoped></style>
