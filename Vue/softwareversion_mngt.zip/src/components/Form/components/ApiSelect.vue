<template>
  <el-select v-bind="getAttrs" v-model="state" @visibleChange="handleFetch" @change="handleChange">
    <template #[item]="data" v-for="item in Object.keys($slots)">
      <slot :name="item" v-bind="data || {}"></slot>
    </template>

    <el-option
      v-for="item in getOptions"
      :key="item.value"
      :label="item.label"
      :value="item.value"
      :disabled="item.disabled"
    >
      <template v-if="$slots.default">
        <slot :option="item"></slot>
      </template>
      <template v-if="slots?.default">
        <component :is="slots?.default" :option="item" />
      </template>
    </el-option>

    <template #empty v-if="loading">
      <span>
        <svg-icon :class="{ spin: loading }" icon="loading" />
        请等待数据加载完成...
      </span>
    </template>
  </el-select>
</template>

<script lang="ts" setup>
import type { PropType, VNode } from 'vue'
import { ref, unref, watch, useAttrs, computed, toRefs } from 'vue'
import { get, omit } from 'lodash-es'

import { useRuleFormItem } from '@/hooks/useFormItem'
import { isFunction } from '@/utils/is'
import { warn } from '@/utils/log'

type OptionsItem = { label: string; value: string; disabled?: boolean }

interface Slots {
  default?: (...args: any) => VNode | string
}

defineOptions({
  name: 'ApiSelect',
  inheritAttrs: false
})
const props = defineProps({
  modelValue: {
    type: [Array, Object, String, Number]
  },
  api: {
    type: Function as PropType<(arg?: any) => Promise<any>>,
    default: null
  },
  // api params
  params: {
    type: Object as PropType<any>,
    defalut: () => {
      return {}
    }
  },
  // support xxx.xxx.xx
  resultField: {
    type: String,
    default: ''
  },
  // Execute immediately
  immediate: {
    type: Boolean,
    default: true
  },
  alwaysLoad: {
    type: Boolean,
    default: false
  },

  disabled: {
    type: Boolean,
    default: false
  },
  numberToString: {
    type: Boolean,
    default: false
  },
  labelField: {
    type: String,
    default: 'label'
  },
  valueField: {
    type: String,
    default: 'value'
  },
  options: {
    type: Array as PropType<OptionsItem[]>,
    default: () => {
      return []
    }
  },
  slots: {
    type: Object as PropType<Slots>,
    default: () => {
      return {}
    }
  }
})

const emit = defineEmits(['options-change', 'change', 'update:modelValue'])

const innerOptions = ref<any[]>([])
const loading = ref(false)
// 是否首次加载过
const isFirstLoaded = ref(false)

const emitData = ref<any[]>([])
const attrs = useAttrs()

// 内部维护状态并同步外层，可尝试defineModel宏
const [state] = useRuleFormItem(props, 'modelValue', 'change', emitData)

const getOptions = computed((): OptionsItem[] => {
  const { labelField, valueField, numberToString, modelValue } = props

  const filterField = { key: 'dataStatus', value: 1 }

  let data = unref(innerOptions)
    .filter((item) => {
      if (Reflect.has(item, filterField.key)) {
        return item[filterField.key] === filterField.value || item[valueField] === modelValue
      }
      return true
    })
    .reduce((prev, next: any) => {
      if (next) {
        const value = get(next, valueField)
        prev.push({
          ...omit(next, [labelField, valueField]),
          label: get(next, labelField),
          value: numberToString ? `${value}` : value,
          disabled: Reflect.has(next, filterField.key)
            ? next[filterField.key] !== filterField.value
            : false
        })
      }
      return prev
    }, [] as OptionsItem[])

  return data.length > 0 ? data : props.options
})

const getAttrs = computed(() => ({
  ...attrs,
  disabled: props.disabled
}))

watch(
  () => state.value,
  (newValue) => {
    emit('update:modelValue', newValue)
  }
)

const { params, immediate } = toRefs(props)

watch(
  () => params,
  () => {
    !unref(isFirstLoaded) && fetch()
  },
  { deep: true, immediate: unref(immediate) }
)

async function fetch() {
  const api = props.api

  if (!api || !isFunction(api) || loading.value) return
  innerOptions.value = []

  try {
    loading.value = true
    const res = await api(props.params)
    isFirstLoaded.value = true

    if (Array.isArray(res)) {
      innerOptions.value = res
      return
    }
    // 深层级获取
    if (props.resultField) {
      innerOptions.value = get(res, props.resultField) || []
    }
  } catch (error: any) {
    warn(error)
  } finally {
    loading.value = false
  }
}

async function handleFetch(visible: boolean) {
  if (visible) {
    if (props.alwaysLoad) {
      await fetch()
    } else if (!props.immediate && !unref(isFirstLoaded)) {
      await fetch()
    }
  }
}

function emitChange() {
  emit('options-change', unref(getOptions))
}
const handleChange = (value: typeof props.modelValue) => {
  const option = getOptions.value.find((option: OptionsItem) => option.value === value)
  emitData.value = [option]

  // emit('change', option)
}

watch(getOptions, () => {
  emitChange()
})
</script>

<style lang="scss" scoped></style>
