<template>
  <el-form ref="formElRef" v-bind="getBindValue" :model="formModel">
    <el-row v-bind="getRow">
      <slot name="formHeader"></slot>
      <template v-for="schema in getSchema" :key="schema.field">
        <FormItem
          :schema="schema"
          :formProps="getProps"
          :allDefaultValues="defaultValueRef"
          :formModel="formModel"
          :setFormModel="setFormModel"
          :formActionType="formActionType"
        >
          <template #[item]="data" v-for="item in Object.keys($slots)">
            <slot :name="item" v-bind="data || {}"></slot>
          </template>
        </FormItem>
      </template>
      <slot name="formFooter"></slot>
    </el-row>
  </el-form>
</template>

<script lang="ts" setup>
import type { CSSProperties, PropType, Ref } from 'vue'
import type { FieldMapToTime, Size, FormSchema, FormProps, FormActionType } from './types/form'
import type { ColEx } from './types'

import { ref, reactive, computed, unref, useAttrs, onMounted, watch } from 'vue'
import { cloneDeep } from 'lodash-es'
import dayjs from 'dayjs'
import FormItem from './components/FormItem.vue'

import { useFormValues } from './hooks/useFormValues'
import { dateItemType } from './helper'
import { useFormEvents } from './hooks/useFormEvent'
import { deepMerge } from '@/utils'

const props = defineProps({
  // 字段
  model: {
    type: Object as PropType<Recordable>,
    default: () => ({})
  },
  // 标签宽度
  labelWidth: {
    type: [Number, String] as PropType<number | string>,
    default: 0
  },
  // 将表单内时间区域的映射成 2 个字段
  fieldMapToTime: {
    type: Array as PropType<FieldMapToTime>,
    default: () => []
  },
  // 表单配置规则
  schemas: {
    type: Array as PropType<FormSchema[]>,
    default: () => []
  },
  baseRowStyle: {
    type: Object as PropType<CSSProperties>
  },
  baseColProps: {
    type: Object as PropType<Partial<ColEx>>
  },
  autoSetPlaceHolder: {
    type: Boolean,
    default: true
  },
  // 在INPUT组件上单击回车时，是否自动提交
  autoSubmitOnEnter: {
    type: Boolean,
    default: false
  },
  //   重置时是否重置表单
  submitOnReset: {
    type: Boolean,
    default: false
  },
  size: {
    type: String as PropType<Size>,
    default: 'default'
  },
  // 禁用表单
  disabled: {
    type: Boolean,
    default: false
  },
  // 是否显示操作按钮
  showActionButtonGroup: {
    type: Boolean,
    default: true
  },
  // 显示重置按钮
  showResetButton: {
    type: Boolean,
    default: true
  },
  // 是否聚焦第一个输入框，只在第一个表单项为input的时候作用
  autoFocusFirstItem: {
    type: Boolean,
    default: false
  },
  // 显示确认按钮
  showSubmitButton: {
    type: Boolean,
    default: true
  },
  // 标签对其方式
  labelAlign: {
    type: String
  },
  transformDateFunc: {
    type: Function as PropType<Fn>,
    default: (date: any) => {
      return date?.format?.('YYYY-MM-DD HH:mm:ss') ?? date
    }
  }
})

const emit = defineEmits(['reset', 'submit', 'register', 'field-value-change']) as EmitType
const attrs = useAttrs()

const formModel = reactive<any>({})
const defaultValueRef = ref({})
const isInitedDefaultRef = ref(false)
const propsRef = ref<Partial<FormProps>>({})
const schemaRef = ref<FormSchema[] | null>(null)
const formElRef = ref<FormActionType | null>(null)
// 获取props属性
const getProps = computed((): FormProps => {
  return { ...props, ...unref(propsRef) } as FormProps
})

const getRow = computed(() => {
  const { baseRowStyle = {} as CSSProperties, rowProps } = unref(getProps)
  return {
    style: baseRowStyle,
    ...rowProps
  }
})

// 获取绑定在组件上的属性
const getBindValue = computed(() => ({ ...attrs, ...props, ...unref(getProps) }))

// 获取配置项
const getSchema = computed((): FormSchema[] => {
  const schemas: FormSchema[] = unref(schemaRef) || (unref(getProps).schemas as any)

  for (const schema of schemas) {
    const { defaultValue, component, componentProps, isHandleDateDefaultValue = true } = schema
    // 处理日期类型
    if (isHandleDateDefaultValue && defaultValue && dateItemType.includes(component)) {
      const valueFormat = componentProps ? componentProps['valueFormat'] : null
      // 处理非数组类型
      if (!Array.isArray(defaultValue)) {
        schema.defaultValue = valueFormat
          ? dayjs(defaultValue).format(valueFormat)
          : dayjs(defaultValue)
      } else {
        const def: any[] = []
        defaultValue.forEach((item) => {
          def.push(valueFormat ? dayjs(item).format(valueFormat) : dayjs(item))
        })
        schema.defaultValue = def
      }
    }
  }

  return cloneDeep(schemas as FormSchema[])
})
// 处理表单值
const { handleFormValues, initDefault } = useFormValues({
  getProps,
  defaultValueRef,
  getSchema,
  formModel
})

const {
  setFieldsValue,
  getFieldsValue,
  clearValidate,
  validate,
  validateField,
  updateSchema,
  resetSchema,
  resetFields,
  scrollToField,
  appendSchemaByField,
  removeSchemaByField,
  resetDefaultField,
  getOriginFieldsValue
} = useFormEvents({
  emit,
  getProps,
  formModel,
  getSchema,
  defaultValueRef,
  formElRef: formElRef as Ref<FormActionType>,
  schemaRef: schemaRef as Ref<FormSchema[]>,
  handleFormValues
})

async function setProps(formProps: Partial<FormProps>): Promise<void> {
  propsRef.value = deepMerge(unref(propsRef) || {}, formProps)
}

function setFormModel(key: string, value: any, schema: FormSchema) {
  formModel[key] = value
  emit('field-value-change', key, value)

  if (schema && schema.itemProps) {
    validateField(key).catch((_) => {})
  }
}

watch(
  () => getSchema.value,
  (schema) => {
    if (unref(isInitedDefaultRef)) {
      return
    }
    if (schema?.length) {
      initDefault()
      isInitedDefaultRef.value = true
    }
  }
)

const formActionType: FormActionType = {
  setProps,
  setFieldsValue,
  getFieldsValue,
  resetFields,
  updateSchema,
  validateField,
  validate,
  scrollToField,
  clearValidate,
  resetSchema,
  appendSchemaByField,
  removeSchemaByField,
  resetDefaultField,
  getOriginFieldsValue
}

onMounted(() => {
  initDefault()
  emit('register', formActionType)
})
</script>

<style lang="scss" scoped></style>
