import type { Component } from 'vue'
import type { ComponentType } from './types/index'

import 'element-plus/theme-chalk/el-cascader.css'
import 'element-plus/theme-chalk/el-cascader-panel.css'
import 'element-plus/theme-chalk/el-input-number.css'
import 'element-plus/theme-chalk/el-switch.css'

import {
  ElInput,
  ElTimePicker,
  ElDatePicker,
  ElCascader,
  ElInputNumber,
  ElTreeSelect,
  ElSwitch,
  ElCheckbox,
  ElDivider,
  ElRadio
} from 'element-plus'

import Select from './components/Select.vue'
import Radio from './components/Radio.vue'
import ApiSelect from './components/ApiSelect.vue'
import ApiCascader from './components/ApiCascader.vue'
import PersonSelect from './components/PersonSelect/index.vue'
import TextDisplay from './components/TextDisplay.vue'

const componentMap = new Map<ComponentType, Component>()

componentMap.set('ElInput', ElInput)
componentMap.set('ElTimePicker', ElTimePicker)
componentMap.set('ElDatePicker', ElDatePicker)
componentMap.set('ElCascader', ElCascader)
componentMap.set('ElInputNumber', ElInputNumber)
componentMap.set('ElSwitch', ElSwitch)
componentMap.set('ElCheckbox', ElCheckbox)
componentMap.set('ElTreeSelect', ElTreeSelect)
componentMap.set('ElDivider', ElDivider)
componentMap.set('ElRadio', ElRadio)

componentMap.set('Select', Select)
componentMap.set('Radio', Radio)
componentMap.set('ApiSelect', ApiSelect)
componentMap.set('PersonSelect', PersonSelect)
componentMap.set('ApiCascader', ApiCascader)
componentMap.set('Text', TextDisplay)

export { componentMap }
