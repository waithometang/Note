import { nextTick, onUnmounted, ref, unref, watch } from 'vue'
import type { FormActionType, FormProps, FormSchema, UseFormReturnType } from '../types/form'

import type { DynamicProps } from '@/types/utils'
import { error } from '@/utils/log'
import { isProdMode } from '@/utils/env'
import { getDynamicProps } from '@/utils'
import type { FormItemProp, FormValidateCallback, FormValidationResult } from 'element-plus'
import type { Arrayable } from '@vueuse/core'
import type { NamePath } from '../types'

type Props = Partial<DynamicProps<FormProps>>

export function useForm(props?: Props): UseFormReturnType {
  const formRef = ref<Nullable<FormActionType>>(null)
  const loadedRef = ref<Nullable<boolean>>(false)

  async function getForm() {
    const form = unref(formRef)

    if (!form) {
      error('表单实例尚未获取，请确保在执行表单操作时已呈现表单！')
    }
    await nextTick()
    return form as FormActionType
  }

  function register(instance: FormActionType) {
    isProdMode() &&
      onUnmounted(() => {
        formRef.value = null
        loadedRef.value = null
      })

    if (unref(loadedRef) && isProdMode() && instance === unref(formRef)) return

    formRef.value = instance
    loadedRef.value = true

    watch(
      () => props,
      () => {
        // 设置属性
        props && instance.setProps(getDynamicProps(props))
      },
      {
        immediate: true,
        deep: true
      }
    )
  }

  const methods: FormActionType = {
    scrollToField: async (prop: FormItemProp): FormValidationResult => {
      const form = await getForm()
      return form.scrollToField(prop)
    },
    setProps: async (formProps: Partial<FormProps>) => {
      const form = await getForm()
      form.setProps(formProps)
    },

    updateSchema: async (data: Partial<FormSchema> | Partial<FormSchema>[]) => {
      const form = await getForm()
      form.updateSchema(data)
    },

    resetSchema: async (data: Partial<FormSchema> | Partial<FormSchema>[]) => {
      const form = await getForm()
      form.resetSchema(data)
    },

    clearValidate: async (props?: Arrayable<FormItemProp> | undefined): Promise<void> => {
      const form = await getForm()
      form.clearValidate(props)
    },

    resetFields: (props) => {
      // 修复表单重置后，页面变化了，但是由于异步问题导致表单内部的状态没有及时同步
      return new Promise((resolve) => {
        getForm().then(async (form) => {
          await form.resetFields(props)
          resolve()
        })
      })
    },

    // TODO promisify
    getFieldsValue: <T>() => {
      return unref(formRef)?.getFieldsValue() as T
    },

    getOriginFieldsValue: <T>() => {
      return unref(formRef)?.getOriginFieldsValue() as T
    },

    setFieldsValue: async <T>(values: T) => {
      const form = await getForm()
      form.setFieldsValue(values as Recordable)
    },

    validate: async (callback?: FormValidateCallback): Promise<void> => {
      const form = await getForm()
      return form.validate(callback)
    },

    validateField: async (
      props?: Arrayable<FormItemProp> | undefined,
      callback?: FormValidateCallback
    ): FormValidationResult => {
      const form = await getForm()
      return form.validateField(props, callback)
    },
    appendSchemaByField: async (
      schema: FormSchema | FormSchema[],
      prefixField: string | undefined,
      first?: boolean
    ) => {
      const form = await getForm()
      form.appendSchemaByField(schema, prefixField, first)
    },
    removeSchemaByField: async (field: string | string[]) => {
      unref(formRef)?.removeSchemaByField(field)
    },
    resetDefaultField: async (nameList?: NamePath[]) => {
      unref(formRef)?.resetDefaultField(nameList)
    }
  }

  return [register, methods]
}
