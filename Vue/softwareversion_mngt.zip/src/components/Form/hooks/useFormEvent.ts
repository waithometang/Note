import type { Arrayable } from '@vueuse/core'
import type { FormItemProp, FormValidateCallback, FormValidationResult } from 'element-plus'
import type { FormActionType, FormProps, FormSchema } from '../types/form'
import type { ComputedRef, Ref } from 'vue'

import { unref, toRaw } from 'vue'
import dayjs from 'dayjs'
import { cloneDeep, get, set, uniqBy } from 'lodash-es'

import { isArray, isDef, isEmpty, isFunction, isNullOrUnDef, isObject, isString } from '@/utils/is'
import { error } from '@/utils/log'
import { dateItemType } from '../helper'
import { deepMerge } from '@/utils'
import type { NamePath } from '../types'

interface UseFormActionContext {
  emit: EmitType
  getProps: ComputedRef<FormProps>
  getSchema: ComputedRef<FormSchema[]>
  formModel: Recordable
  defaultValueRef: Ref<Recordable>
  formElRef: Ref<FormActionType>
  schemaRef: Ref<FormSchema[]>
  handleFormValues: Fn
}

function tryConstructArray(field: string, values: Recordable = {}): any[] | undefined {
  const pattern = /^\[(.+)\]$/
  if (pattern.test(field)) {
    const match = field.match(pattern)
    if (match && match[1]) {
      const keys = match[1].split(',')
      if (!keys.length) {
        return undefined
      }

      const result: any = []
      keys.forEach((k, index) => {
        set(result, index, values[k.trim()])
      })

      return result.filter(Boolean).length ? result : undefined
    }
  }
}

function tryConstructObject(field: string, values: Recordable = {}): Recordable | undefined {
  const pattern = /^\{(.+)\}$/
  if (pattern.test(field)) {
    const match = field.match(pattern)
    if (match && match[1]) {
      const keys = match[1].split(',')
      if (!keys.length) {
        return
      }

      const result = {}
      keys.forEach((k) => {
        set(result, k.trim(), values[k.trim()])
      })

      return Object.values(result).filter(Boolean).length ? result : undefined
    }
  }
}
export function useFormEvents({
  emit,
  getProps,
  formModel,
  getSchema,
  defaultValueRef,
  formElRef,
  schemaRef,
  handleFormValues
}: UseFormActionContext) {
  // 重置表单
  async function resetFields(props?: string | string[]): Promise<void> {
    const { resetFunc } = unref(getProps)
    // 执行自定义重置函数
    resetFunc && isFunction(resetFunc) && (await resetFunc())

    const formEl = unref(formElRef)
    if (!formEl) return

    if (props) {
      if (isArray(props)) {
        props.forEach((prop) => {
          const schema = unref(getSchema).find((item) => item.field === prop)

          const defaultValueObj = schema?.defaultValueObj
          const fieldKeys = Object.keys(defaultValueObj || {})
          if (fieldKeys.length) {
            fieldKeys.map((field) => {
              formModel[field] = defaultValueObj![field]
            })
          }
          formModel[prop] = getDefaultValue(schema, defaultValueRef, prop)
        })
      } else if (isString(props)) {
        const schema = unref(getSchema).find((item) => item.field === props)
        formModel[props] = getDefaultValue(schema, defaultValueRef, props)
      }
    } else {
      // 默认值赋值
      Object.keys(formModel).forEach((key) => {
        const schema = unref(getSchema).find((item) => item.field === key)
        const defaultValueObj = schema?.defaultValueObj
        const fieldKeys = Object.keys(defaultValueObj || {})
        if (fieldKeys.length) {
          fieldKeys.map((field) => {
            formModel[field] = defaultValueObj![field]
          })
        }

        formModel[key] = getDefaultValue(schema, defaultValueRef, key)
      })
    }

    // 清空校验信息
    setTimeout(() => {
      clearValidate()
    }, 0)

    emit('reset', toRaw(formModel))
  }
  // 获取所有字段
  const getAllFields = () =>
    unref(getSchema)
      .map((item) => [...(item.fields || []), item.field])
      .flat(1)
      .filter(Boolean)

  // const setFieldsValue = async (values: Recordable): Promise<void> => {
  //   if (Object.keys(values).length === 0) {
  //     return
  //   }

  //   const fields = getAllFields()

  //   fields.forEach((key) => {
  //     const schema = unref(getSchema).find((item) => item.field === key)
  //     const value = get(values, key)
  //     const hasKey = Reflect.has(values, key)

  //     const { componentProps } = schema || {}
  //     let _props = componentProps as any
  //     if (typeof componentProps === 'function') {
  //       _props = _props({
  //         formModel: unref(formModel),
  //         formActionType: unref(formActionType),
  //         schema: schema
  //       })
  //     }

  //     const setDateFieldValue = (v: any) => {
  //       return v ? (_props?.valueFormat ? v : dayjs(v)) : null
  //     }

  //     let constructValue
  //     // 日期 组件
  //     if (isDef(schema?.component) && itemIsDateComponent(schema?.component)) {
  //       constructValue = tryConstructArray(key, values)
  //       console.log(values, key)

  //       const fieldValue = constructValue || value

  //       // 数组类型格式化
  //       if (Array.isArray(fieldValue)) {
  //         const arr: any[] = []
  //         for (const ele of fieldValue) {
  //           arr.push(setDateFieldValue(ele))
  //         }
  //         unref(formModel)[key] = arr
  //       } else {
  //         console.log(fieldValue)

  //         unref(formModel)[key] = fieldValue
  //         // ? _props?.valueFormat
  //         //   ? fieldValue
  //         //   : dayjs(fieldValue)
  //         // : null

  //         // setDateFieldValue(fieldValue)
  //       }
  //     }

  //     // 0| '' is allow
  //     if (hasKey) {
  //       constructValue = get(value, key)
  //       const fieldValue = constructValue || value
  //       unref(formModel)[key] = fieldValue
  //       if (_props?.onChange) {
  //         _props?.onChange(fieldValue)
  //       }
  //     } else {
  //       // key not exist
  //       // refer:https://github.com/vbenjs/vue-vben-admin/issues/3795
  //     }
  //   })
  //   // validate().catch()
  // }

  const setFieldsValue = async (values: Recordable): Promise<void> => {
    if (Object.keys(values).length === 0) {
      return
    }

    const fields = getAllFields()

    fields.forEach((key) => {
      const schema = unref(getSchema).find((item) => item.field === key)
      const value = get(values, key)
      const hasKey = Reflect.has(values, key)

      const { componentProps } = schema || {}
      let _props = componentProps as any
      if (typeof componentProps === 'function') {
        _props = _props({
          formModel: unref(formModel),
          formActionType: unref(formActionType),
          schema: schema
        })
      }

      const constructValue = tryConstructArray(key, values) || tryConstructObject(key, values)

      // 0| '' is allow
      if (hasKey || !!constructValue) {
        const fieldValue = constructValue || value
        // 日期 type
        if (itemIsDateType(key)) {
          // 数组类型格式化
          if (Array.isArray(fieldValue)) {
            const arr: any[] = []
            for (const ele of fieldValue) {
              arr.push(ele ? dayjs(ele) : null)
            }
            unref(formModel)[key] = arr
          } else {
            unref(formModel)[key] = fieldValue
              ? _props?.valueFormat
                ? fieldValue
                : dayjs(fieldValue)
              : null
          }
        } else {
          unref(formModel)[key] = fieldValue
        }
        if (_props?.onChange) {
          _props?.onChange(fieldValue)
        }
      } else {
        // key not exist
        // refer:https://github.com/vbenjs/vue-vben-admin/issues/3795
      }
    })
    // validate().catch()
  }

  /**
   * @description: Set form default value
   */
  function resetDefaultField(nameList?: NamePath[]) {
    if (!Array.isArray(nameList)) {
      return
    }
    if (Array.isArray(nameList) && nameList.length === 0) {
      return
    }
    const validKeys: string[] = []
    const keys = Object.keys(unref(formModel))
    if (!keys) {
      return
    }
    nameList.forEach((key: any) => {
      if (keys.includes(key)) {
        validKeys.push(key)
        unref(formModel)[key] = cloneDeep(unref(get(defaultValueRef.value, key)))
      }
    })
    validate().catch((_) => {})
  }

  const clearValidate = (props?: Arrayable<FormItemProp> | undefined) => {
    unref(formElRef)?.clearValidate(props)
  }

  /**
   * @description: 根据 field 删除 Schema
   */
  async function removeSchemaByField(fields: string | string[]): Promise<void> {
    const schemaList: FormSchema[] = cloneDeep(unref(getSchema))
    if (!fields) {
      return
    }

    let fieldList: string[] = isString(fields) ? [fields] : fields
    if (isString(fields)) {
      fieldList = [fields]
    }
    for (const field of fieldList) {
      _removeSchemaByFeild(field, schemaList)
    }
    schemaRef.value = schemaList
  }

  /**
   * @description: Delete based on field name
   */
  function _removeSchemaByFeild(field: string, schemaList: FormSchema[]): void {
    if (isString(field)) {
      const index = schemaList.findIndex((schema) => schema.field === field)
      if (index !== -1) {
        // 删除数据对象的属性与字段配置
        delete formModel[field]
        schemaList.splice(index, 1)
      }
    }
  }

  /**
   * @description: 在某个字段后插入，如果没传指定 field，则插入到最后,当 first = true 时插入到第一个位置
   */
  async function appendSchemaByField(
    schema: FormSchema | FormSchema[],
    prefixField?: string,
    first = false
  ) {
    const schemaList: FormSchema[] = cloneDeep(unref(getSchema))
    const addSchemaIds: string[] = Array.isArray(schema)
      ? schema.map((item) => item.field)
      : [schema.field]

    if (schemaList.find((item) => addSchemaIds.includes(item.field))) {
      error('该表单项已被添加')
      return
    }

    const index = schemaList.findIndex((schema) => schema.field === prefixField)
    const _schemaList = isObject(schema) ? [schema as FormSchema] : (schema as FormSchema[])
    // 如果插入到某一字段后的参数与插入到第一个位置参数不存在
    if (!prefixField || index === -1 || first) {
      first ? schemaList.unshift(..._schemaList) : schemaList.push(..._schemaList)
    } else if (index !== -1) {
      // 插入到指定字段后
      schemaList.splice(index + 1, 0, ..._schemaList)
    }
    schemaRef.value = schemaList
    _setDefaultValue(schema)
  }

  const getFieldsValue = () => {
    const formEl = unref(formElRef)
    if (!formEl) return {}

    return handleFormValues(toRaw(unref(formModel)))
  }

  const getOriginFieldsValue = () => {
    const formEl = unref(formElRef)
    if (!formEl) return {}

    return toRaw(unref(formModel))
  }

  const updateSchema = (data: Partial<FormSchema> | Partial<FormSchema>[]): any => {
    let updateData: Partial<FormSchema>[] = []
    // 组装更新字段列表
    if (isObject(data)) {
      updateData.push(data as FormSchema)
    }
    if (isArray(data)) {
      updateData = [...data]
    }
    // 判断是否含有field字段
    const hasField = updateData.every((item) => Reflect.has(item, 'field') && item.field)
    if (!hasField) {
      error('所有的表单子配置项都必须含有一个field字段')
      return
    }

    const schema: FormSchema[] = []
    const updatedSchema: FormSchema[] = []
    // 合并配置项
    unref(getSchema).forEach((val) => {
      let _val: any

      // 找到配置项
      updateData.forEach((item) => {
        if (val.field === item.field) {
          _val = item
        }
      })
      // 配置项存在则合并配置项
      if (_val !== undefined && val.field === _val.field) {
        const newSchema = deepMerge(val, _val)
        updatedSchema.push(newSchema as FormSchema)
        schema.push(newSchema as FormSchema)
      } else {
        schema.push(val)
      }
    })
    _setDefaultValue(updatedSchema)

    schemaRef.value = uniqBy(schema, 'field')
  }

  function _setDefaultValue(data: FormSchema | FormSchema[]) {
    let schemas: FormSchema[] = []
    if (isObject(data)) {
      schemas.push(data as FormSchema)
    }
    if (isArray(data)) {
      schemas = [...data]
    }

    const obj: Recordable = {}
    const currentFieldsValue = getFieldsValue()
    // 默认值设置
    schemas.forEach((item) => {
      if (
        Reflect.has(item, 'field') &&
        item.field &&
        !isNullOrUnDef(item.defaultValue) &&
        (!(item.field in currentFieldsValue) ||
          isNullOrUnDef(currentFieldsValue[item.field]) ||
          isEmpty(currentFieldsValue[item.field]))
      ) {
        obj[item.field] = item.defaultValue
      }
    })
    // 设置表单数据
    setFieldsValue(obj)
  }
  async function resetSchema(data: Partial<FormSchema> | Partial<FormSchema>[]) {
    let updateData: Partial<FormSchema>[] = []
    if (isObject(data)) {
      updateData.push(data as FormSchema)
    }
    if (isArray(data)) {
      updateData = [...data]
    }

    const hasField = updateData.every((item) => Reflect.has(item, 'field') && item.field)

    if (!hasField) {
      error('所有的表单子配置项都必须含有一个field字段')
      return
    }
    schemaRef.value = updateData as FormSchema[]
  }

  const validate = (callback?: FormValidateCallback | undefined): Promise<void> => {
    return unref(formElRef)?.validate(callback)
  }
  function validateField(
    props?: Arrayable<FormItemProp> | undefined,
    callback?: FormValidateCallback | undefined
  ): FormValidationResult {
    return unref(formElRef)?.validateField(props, callback)
  }

  async function scrollToField(prop: FormItemProp): FormValidationResult {
    return await unref(formElRef)?.scrollToField(prop)
  }

  // /**
  //  * @description: Is it Date Component
  //  */
  // function itemIsDateComponent(key: string) {
  //   return dateItemType.includes(key)
  // }

  function itemIsDateType(key: string) {
    return unref(getSchema).some((item) => {
      return item.field === key ? dateItemType.includes(item.component) : false
    })
  }
  const formActionType = {
    clearValidate,
    validate,
    validateField,
    getFieldsValue,
    updateSchema,
    resetSchema,
    resetFields,
    setFieldsValue,
    scrollToField,
    appendSchemaByField,
    removeSchemaByField,
    resetDefaultField,
    getOriginFieldsValue
  }

  return formActionType
}
// 获取单个默认值
function getDefaultValue(
  schema: FormSchema | undefined,
  defaultValueRef: UseFormActionContext['defaultValueRef'],
  key: string
) {
  let defaultValue = cloneDeep(defaultValueRef.value[key])
  const isInput = checkIsInput(schema)
  if (isInput) {
    return defaultValue || ''
  }
  if (!defaultValue && schema && checkIsRangeSlider(schema)) {
    defaultValue = [0, 0]
  }
  return defaultValue
}
// 检查是否slider数组
function checkIsRangeSlider(schema: FormSchema) {
  if (
    schema.component === 'ElSlider' &&
    schema.componentProps &&
    isObject(schema.componentProps) &&
    schema.componentProps.range
  ) {
    return true
  }
}
// 检查是否input
function checkIsInput(schema?: FormSchema) {
  return schema?.component && 'ElInput' === schema.component
}
