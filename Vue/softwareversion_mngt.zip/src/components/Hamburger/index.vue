<template>
  <div class="hamburger-container" @click="toggleClick">
    <svg-icon
      class-name="hamburger"
      style="font-size: 24px"
      :icon="sidebarOpened ? 'hamburger-opened' : 'hamburger-closed'"
    ></svg-icon>
  </div>
</template>

<script lang="ts" setup>
import useAppStore from '@/stores/app'
import { storeToRefs } from 'pinia'
const appStore = useAppStore()
const { sidebarOpened } = storeToRefs(appStore)
const { triggerSidebarOpened } = appStore
const toggleClick = () => {
  triggerSidebarOpened()
}
</script>

<style lang="scss" scoped>
.hamburger-container {
  border-radius: 0px 8px 8px 0px;
  cursor: pointer;

  left: -5px;
  top: 40px;
}
</style>
