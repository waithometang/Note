<template>
  <div class="container">
    <div
      v-if="enabledLeftSide"
      v-show="leftSideVisiable"
      class="left-side"
      :style="{ width: getLeftSideWidth }"
    >
      <slot name="leftSide" />
    </div>
    <div class="main">
      <div
        v-if="enabledLeftSide && !hideLeftSideToggle"
        class="left-side-icon"
        @click="leftSideVisiable = !leftSideVisiable"
      >
        <svg-icon icon="left" :class="leftSideVisiable ? '' : 'rotate'" style="font-size: 20px" />
      </div>

      <div
        v-if="enabledRightSide && !hideRightSideToggle"
        class="right-side-icon"
        @click="rightSideVisiable = !rightSideVisiable"
      >
        <svg-icon icon="left" :class="rightSideVisiable ? 'rotate' : ''" style="font-size: 20px" />
      </div>
      <slot name="default" />
    </div>
    <div
      v-if="enabledRightSide"
      v-show="rightSideVisiable"
      class="right-side"
      :style="{ width: getRightSideWidth }"
    >
      <slot name="rightSide" />
    </div>
  </div>
</template>

<script lang="ts" setup>
import { ref, computed, toRefs, unref, useSlots } from 'vue'
import { isNumber } from '@/utils/is'

defineOptions({
  name: 'LayoutContainer'
})

const props = defineProps({
  // 是否启用左侧栏
  enableLeftSide: {
    type: Boolean,
    default: true
  },
  // 是否启用右侧栏
  enableRightSide: {
    type: Boolean,
    default: true
  },
  // 左侧栏宽度
  leftSideWidth: {
    type: [String, Number],
    default: '14vw'
  },
  // 右侧栏宽度
  rightSideWidth: {
    type: [String, Number],
    default: '14vw'
  },
  // 是否隐藏左侧栏切换按钮
  hideLeftSideToggle: {
    type: Boolean,
    default: false
  },
  // 是否隐藏右侧栏切换按钮
  hideRightSideToggle: {
    type: Boolean,
    default: false
  }
})

// 侧边栏是否折叠
const leftSideVisiable = ref(true)
const rightSideVisiable = ref(true)

const { leftSideWidth, rightSideWidth } = toRefs(props)

const enabledLeftSide = computed(() => {
  return props.enableLeftSide && !!useSlots().leftSide
})
const enabledRightSide = computed(() => {
  return props.enableRightSide && !!useSlots().rightSide
})

const getLeftSideWidth = computed(() =>
  isNumber(unref(leftSideWidth)) ? `${unref(leftSideWidth)}px` : unref(leftSideWidth)
)
const getRightSideWidth = computed(() =>
  isNumber(unref(rightSideWidth)) ? `${unref(rightSideWidth)}px` : unref(rightSideWidth)
)
</script>

<style lang="scss" scoped>
.container {
  position: absolute;
  display: flex;
  width: 100%;
  height: 100%;
  .left-side {
    flex: none;
    margin: $margin 0 $margin $margin;

    overflow: auto;

    transition:
      width 3s,
      var(--el-transition-color);
  }
  .main {
    margin-inline-start: $margin;
    position: relative;
    flex: 1;
    width: 0;

    .rotate {
      transform: rotate(180deg);
    }
    .left-side-icon,
    .right-side-icon {
      z-index: 1;
      position: absolute;
      width: 28px;
      height: 28px;

      background-color: #fff;
      border-radius: 50%;
      box-shadow: 0px 0px 10px rgba(0, 0, 0, 0.05);
      cursor: pointer;

      display: flex;
      align-items: center;
      justify-content: center;

      transition:
        background-color 0.3s,
        var(--el-transition-color);

      &:hover {
        color: $themeColor;
      }
    }
    .left-side-icon {
      top: 50%;
      left: -14px;
    }
    .right-side-icon {
      top: 50%;
      right: 14px;
    }
  }
  .right-side {
    flex: none;
    margin-inline-start: $margin;
    margin: $margin $margin $margin 0;
    overflow: auto;
  }
}
</style>
