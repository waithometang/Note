<template>
  <el-tooltip :content="content" placement="bottom" :disabled="!isShowTooltip">
    <div class="text-hidden" @mouseenter="visibilityChange($event)">{{ content }}</div>
  </el-tooltip>
</template>

<script lang="ts" setup>
import { ref } from 'vue'

defineProps({
  content: {
    type: String,
    default: ''
  }
})
const isShowTooltip = ref(false)

const visibilityChange = (event: MouseEvent) => {
  const el = event.target as HTMLElement
  const elWidth = el?.scrollWidth // 文本的实际宽度   scrollWidth：对象的实际内容的宽度，不包边线宽度，会随对象中内容超过可视区后而变大。
  const contentWidth = el?.clientWidth // 文本的可视宽度 clientWidth：对象内容的可视区的宽度，不包滚动条等边线，会随对象显示大小的变化而改变。
  if (elWidth > contentWidth) {
    // 实际宽度 > 可视宽度  文字溢出
    isShowTooltip.value = true
  } else {
    // 否则为不溢出
    isShowTooltip.value = false
  }
}
</script>

<style lang="scss" scoped>
.text-hidden {
  overflow: hidden;
  white-space: nowrap;
  text-overflow: ellipsis;
}
</style>
