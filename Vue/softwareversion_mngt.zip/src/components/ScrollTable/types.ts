export interface TableColumn {
  field: string
  title: string
  width?: string | number
}

export interface ScrollTableProps<T> {
  data: T[]
  columns: TableColumn[]
}

export type TableRowWidth = 552 | 1173 | 864

export interface BaseList {
  index?: number
}
