<template>
  <div class="table-container" style="color: #fff">
    <div class="table-header">
      <div v-if="showIndex" class="table-header-cell table-header-cell-index">#</div>
      <div
        class="table-header-cell"
        v-for="column in columns"
        :key="column.field"
        :style="getColumnStyle(column)"
      >
        {{ column.title }}
      </div>
    </div>
    <div class="table-body" ref="tableBodyRef">
      <TransitionGroup
        ref="listRef"
        tag="ul"
        :class="['table-row-container', animate ? 'animate' : '']"
        :css="false"
        @before-enter="onBeforeEnter"
        @enter="onEnter"
        @leave="onLeave"
      >
        <li
          v-for="(row, index) in getList"
          :key="index"
          class="table-row"
          :class="getBgClass"
          :data-index="index"
          @mouseenter="handleStop()"
          @mouseleave="handleUp()"
          :style="getListStyle"
        >
          <div v-if="showIndex" class="table-row-cell table-row-cell-index">
            {{ row.index }}
          </div>
          <div
            v-for="column in columns"
            :key="column.field"
            class="table-row-cell"
            :style="getColumnStyle(column)"
          >
            {{ row[column.field] }}
          </div>
        </li>
      </TransitionGroup>
      <div v-if="!list.length" class="list-empty">
        {{ emptyText }}
      </div>
    </div>
  </div>
</template>
<!--  generic="T extends BaseList" -->
<script lang="ts" setup>
import type { TableColumn, TableRowWidth, BaseList } from './types'
import type { PropType, BaseTransitionProps, ComponentPublicInstance, Ref } from 'vue'

import { watch, ref, toRef, computed, toRefs, onMounted, onUnmounted } from 'vue'
import gsap from 'gsap'
import { nextTick } from 'vue'
import { unref } from 'vue'
import { isNumber, isString } from '@/utils/is'
import { cloneDeep } from 'lodash-es'
import { useElementSize } from '@vueuse/core'
const props = defineProps({
  columns: {
    type: Array as PropType<TableColumn[]>,
    default: () => {
      return []
    }
  },
  data: {
    type: Array as PropType<any[]>,
    default: () => {
      return []
    }
  },
  bgWidth: {
    type: Number as PropType<TableRowWidth>,
    default: 552
  },
  rowHeight: {
    type: Number,
    default: 40
  },
  // showNumber: {
  //   type: Number,
  //   default: 5
  // },
  emptyText: {
    type: String,
    default: '暂无数据'
  },
  showIndex: {
    type: Boolean,
    default: true
  }
})
const { columns, showIndex, rowHeight } = toRefs(props)

const tableBodyRef = ref()
const { height } = useElementSize(tableBodyRef)
const showNumber = computed(() => Math.ceil(unref(height) / unref(rowHeight)))

const getBgClass = computed(() => 'table-row-' + props.bgWidth)

const getListStyle = computed(() => ({
  height: unref(rowHeight) + 'px'
}))

// 动画进入
const onEnter: BaseTransitionProps['onEnter'] = (el, done) => {
  gsap.to(el, {
    opacity: 1,
    height: unref(rowHeight) + 'px',
    delay: el.dataset.index * 0.15,
    onComplete: done,
    animation: 'list 0.4s infinite'
  })
}

// 动画离开
const onLeave: BaseTransitionProps['onLeave'] = (el, done) => {
  gsap.to(el, {
    opacity: 0,
    height: 0,
    delay: 0.2,
    onComplete: done
  })
}
// 动画进入之前
const onBeforeEnter: BaseTransitionProps['onBeforeEnter'] = (el) => {
  el.style.opacity = 0
  el.style.height = 0
}

const rowGap = 8 // 垂直方向行间距
const realRowHeight = computed(() => unref(rowHeight) + rowGap)

const list = computed(() => {
  let count = 0
  const data = props.data.map((item: any) => {
    item.index = ++count
    return item
  })
  return data
})

const getColumnStyle = (column: TableColumn) => {
  const { width } = column
  let realWidth = isNumber(width) ? width + 'px' : width
  let realFlex = realWidth ? 'unset' : '1'
  return { width: realWidth, flex: realFlex }
}

let animate = ref(false) // 动画开启标识
let timer: number // 定时器
let listRef = ref<ComponentPublicInstance>()

watch(animate, (newAnimate: boolean) => {
  nextTick(() => {
    if (!listRef.value || unref(list).length < unref(showNumber)) {
      return
    }
    if (newAnimate) {
      // listRef.value.$el.style.transform = `-${props.rowHeight}px`
      listRef.value.$el.style.transform = `translateY(-${unref(realRowHeight)}px)`
    } else {
      // listRef.value.$el.style.marginTop = '0'
      listRef.value.$el.style.transform = 'translateY(0px)'
    }
  })
})
const getList = ref<any[]>([])
function StartCarousel() {
  animate.value = true
  if (!listRef.value || unref(list).length < unref(showNumber)) {
    return
  }
  setTimeout(() => {
    list.value.push(list.value[0])
    list.value.shift()
    getList.value = unref(list).slice(0, unref(showNumber))
    animate.value = false
  }, 500)
}

watch(
  list,
  () => {
    getList.value = unref(list).slice(0, 20)
  },
  {
    immediate: true
  }
)

function startAnimate() {
  timer = setInterval(StartCarousel, 2000)
}

function stopAnimate() {
  clearInterval(timer)
}

function handleStop() {
  stopAnimate()
}

function handleUp() {
  startAnimate()
}

onMounted(() => {
  startAnimate()
})

onUnmounted(() => {
  stopAnimate()
})
</script>

<style lang="scss" scoped>
.table-container {
  height: 100%;

  flex: 1;
  display: flex;
  flex-direction: column;
  padding: 12px 24px 24px 24px;

  .table-header {
    display: flex;
    justify-content: space-evenly;
    color: rgba(255, 255, 255, 0.8);

    position: relative;
    padding-left: 10px;
    .table-header-cell {
      flex: 1;
      display: flex;
      justify-content: center;
    }

    .table-header-cell-index {
      // position: absolute;
      flex: unset;
      width: 50px;
      left: 10px;
    }
  }

  .table-body {
    flex: 1;
    position: relative;
    overflow: hidden;

    display: flex;
    flex-direction: column;
    gap: 10px;
    .table-row-container {
      flex: 1;
      width: 100%;
      position: absolute;

      top: 0;
      left: 0;
      width: 100%;

      display: flex;
      flex-direction: column;
      gap: 8px;
      // animation: scroll 2s linear infinite normal;
      .table-row {
        background: url('@/assets/png/data-screen-table-row-552.png') no-repeat;
        background-size: 100% 100%;

        display: flex;
        justify-content: space-evenly;

        padding-left: 10px;

        position: relative;
        .table-row-cell {
          flex: 1;
          font-size: 14px;
          line-height: 14px;
          font-weight: 400;
          letter-spacing: 0px;
          color: rgba(255, 255, 255, 1);

          text-align: center;

          margin: auto 0;
          overflow: hidden;

          display: -webkit-box;
          -webkit-box-orient: vertical;
          -webkit-line-clamp: 2;
        }

        .table-row-cell-index {
          // position: absolute;
          // top: 50%;
          // left: 10px;
          // transform: translate((0, -50%));
          width: 50px;
          flex: unset;

          display: flex;
          align-items: center;
          justify-content: center;
        }
      }
      .table-row-1173 {
        background: url('@/assets/png/data-screen-table-row-1173.png') no-repeat;
        background-size: 100% 100%;
      }
      .table-row-864 {
        background: url('@/assets/png/data-screen-table-row-864.png') no-repeat;
        background-size: 100% 100%;
      }
      .table-row-552 {
        background: url('@/assets/png/data-screen-table-row-552.png') no-repeat;
        background-size: 100% 100%;
      }
    }
    .list-empty {
      position: absolute;
      height: 100%;
      width: 100%;
      display: flex;
      align-items: center;
      justify-content: center;
      color: rgba(255, 255, 255, 0.5);
    }
    .animate {
      transition: all 0.5s ease-out;
    }
  }
}
</style>
