<template>
  <span class="svg">
    <!-- 展示内部静态资源图标 -->
    <svg class="svg-icon" :class="className" aria-hidden="true">
      <use :xlink:href="iconName" />
    </svg>
  </span>
</template>

<script lang="ts" setup>
import { computed } from 'vue'
const props = defineProps({
  // icon 图标
  icon: {
    type: String,
    required: true
  },
  // 图标类名
  className: {
    type: String,
    default: ''
  }
})
// const emit = defineEmits(['click'])
// const onClick = ($event) => {
//   emit('click', $event)
// }
/**
 * 内部图标
 */
const iconName = computed(() => `#icon-${props.icon}`)
</script>

<style lang="scss" scoped>
:focus {
  outline: unset;
}
.svg {
  display: inline-block;
  user-select: none;
  .svg-icon {
    width: 1em;
    height: 1em;

    vertical-align: -0.25em;
    fill: currentColor;
    overflow: hidden;

    display: flex;
    justify-content: center;
    align-items: center;
  }
}
</style>
