<template>
  <div class="backboard-container">
    <div style="opacity: 0.5">
      <div class="corner top-left"></div>
      <div class="corner top-right"></div>
      <div class="corner bottom-left"></div>
      <div class="corner bottom-right"></div>
      <div class="bg-mask"></div>
    </div>

    <slot></slot>
  </div>
</template>

<script setup lang="ts"></script>

<style scoped lang="scss">
.backboard-container {
  position: relative;
  .bg-mask {
    position: absolute;
    top: 0;
    left: 0;
    right: 0;
    bottom: 0;
    opacity: 0.3;
    background-color: rgba(47, 85, 143, 1);
    border: 1.71px solid rgba(61, 127, 255, 1);
  }
  .corner {
    position: absolute;
    background-color: rgba(61, 127, 255, 1);
    width: 5px;
    height: 5px;
    // z-index: 1;
  }
}
.top-left {
  left: 0;
  top: 0;
  transform: translate(-1px, -1px);
  clip-path: polygon(0 0, 0 50%, 0 100%, 50% 100%, 50% 50%, 100% 50%, 100% 0);
}
.top-right {
  top: 0;
  right: 0;
  transform: translate(1px, -1px) rotate(90deg);
  clip-path: polygon(0 0, 0 50%, 0 100%, 50% 100%, 50% 50%, 100% 50%, 100% 0);
}
.bottom-left {
  left: 0;
  bottom: 0;
  transform: translate(-1px, 1px) rotate(-90deg);
  clip-path: polygon(0 0, 0 50%, 0 100%, 50% 100%, 50% 50%, 100% 50%, 100% 0);
}
.bottom-right {
  bottom: 0;
  right: 0;
  transform: translate(1px, 1px) rotate(180deg);
  clip-path: polygon(0 0, 0 50%, 0 100%, 50% 100%, 50% 50%, 100% 50%, 100% 0);
}
</style>
