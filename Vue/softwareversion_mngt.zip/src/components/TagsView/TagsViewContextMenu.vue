<template>
  <ul class="context-menu-container">
    <li @click="onRefresh" :class="isActiveTag ? '' : 'disabled'">
      <el-row>
        <el-col :span="6">
          <svg-icon icon="refresh" className="tags-icon"></svg-icon>
        </el-col>
        <el-col :span="18">{{ $t('component.contextMenu.Refresh') }}</el-col>
      </el-row>
    </li>
    <li v-if="!isAffix(selectedTag)" @click="onCloseCurrent">
      <el-row>
        <el-col :span="6">
          <svg-icon icon="close" className="tags-icon"></svg-icon>
        </el-col>
        <el-col :span="18">{{ $t('component.contextMenu.Close') }}</el-col>
      </el-row>
    </li>
    <el-divider style="margin: 0" />
    <li @click="onMaximize">
      <el-row>
        <el-col :span="6">
          <svg-icon icon="maximize" className="tags-icon"></svg-icon>
        </el-col>
        <el-col :span="18">{{ $t('component.contextMenu.Maximize') }}</el-col>
      </el-row>
    </li>
    <el-divider style="margin: 0" />
    <li @click="onCloseLeft">{{ $t('component.contextMenu.closeLeft') }}</li>
    <li @click="onCloseRight">{{ $t('component.contextMenu.closeRight') }}</li>
    <li @click="onCloseAll">{{ $t('component.contextMenu.CloseAll') }}</li>
    <li @click="onCloseOther">{{ $t('component.contextMenu.CloseOther') }}</li>
  </ul>
</template>

<script lang="ts" setup>
import type { TagsViewItem } from '@/stores/types'

import { computed, nextTick, type PropType } from 'vue'
import useAppStore from '@/stores/app'
import { storeToRefs } from 'pinia'
import useCurrentInstance from '@/hooks/useCurrentInstance'
import { useRoute, useRouter } from 'vue-router'
import { isAffix } from '@/utils/tags'

import { RemoveTagsType } from '@/enums/tagsEnum'

const props = defineProps({
  index: {
    type: Number,
    required: true
  },
  selectedTag: {
    type: Object as PropType<TagsViewItem>
  }
})
const emit = defineEmits(['close'])

const appStore = useAppStore()
const { removeTagsView, toLastView, setFullScreen } = appStore

const route = useRoute()
// 是否当前活跃路由
const isActive = (tag: TagsViewItem) => {
  return tag.path === route.path
}

const getCurrentMenu = () => {
  return tagsViewList.value[props.index]
}

// 是否当前活跃页签
const isActiveTag = computed(() => {
  const menuItem = getCurrentMenu()
  if (!menuItem) return false
  return isActive(menuItem)
})

// 关闭左侧
const onCloseLeft = () => {
  removeTagsView({
    type: RemoveTagsType.LEFT,
    index: props.index,
    selectedTag: props.selectedTag
  })
  emit('close')
}
// 关闭右侧
const onCloseRight = () => {
  removeTagsView({
    type: RemoveTagsType.RIGHT,
    index: props.index,
    selectedTag: props.selectedTag
  })
  emit('close')
}

// 关闭其他
const onCloseOther = () => {
  removeTagsView({
    type: RemoveTagsType.OTHER,
    index: props.index,
    selectedTag: props.selectedTag
  })
  emit('close')
}

// 关闭所有
const onCloseAll = () => {
  removeTagsView({
    type: RemoveTagsType.ALL,
    index: props.index,
    selectedTag: props.selectedTag
  })
  emit('close')
}

// 关闭当前
const onCloseCurrent = () => {
  const menuItem = getCurrentMenu()
  removeTagsView({ type: 'index', index: props.index })
  proxy.eventBus.emit('onTabViewClose', menuItem)
  if (isActive(menuItem)) {
    toLastView(props.index)
  }
  emit('close')
}

const router = useRouter()
// 最大化
const onMaximize = () => {
  const isActive = isActiveTag.value
  // 不是当前tag则跳转路由
  if (!isActive) {
    const currentTag = getCurrentMenu()
    router.push(currentTag.path)
  }
  // 下一帧全屏
  nextTick(() => {
    setFullScreen(true)
  })
}
// 刷新
const { tagsViewList } = storeToRefs(appStore)
const { proxy } = useCurrentInstance()
const onRefresh = () => {
  const menuItem = getCurrentMenu()
  if (!isActive(menuItem)) {
    return
  }
  // const menuItem = tagsViewList.value[props.index]
  proxy.eventBus.emit('onTabViewRefresh', menuItem)
}
</script>

<style lang="scss" scoped>
.context-menu-container {
  position: fixed;
  background: #fff;
  z-index: 10000;
  list-style-type: none;
  padding: 5px 0;
  border-radius: 4px;
  font-size: 12px;
  font-weight: 400;
  color: #333;
  box-shadow: 2px 2px 3px 0 rgba(0, 0, 0, 0.3);

  min-width: 110px;
  li {
    margin: 0;
    padding: 7px 16px;
    font-size: 12px;
    cursor: pointer;
    &:hover {
      background: #eee;
    }

    :deep(.tags-icon) {
      width: 12px;
      height: 12px;
    }
  }

  li.disabled {
    cursor: not-allowed;
    color: var(--el-text-color-disabled);
  }
}
</style>
