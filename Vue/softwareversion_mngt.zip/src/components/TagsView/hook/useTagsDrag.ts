import { nextTick } from 'vue'
import useAppStore from '@/stores/app'
import { useSortable } from '@/hooks/useSortable'
import { isNullAndUnDef } from '@/utils/is'

export function useTagsDrag() {
  const { sortTags } = useAppStore()

  nextTick(() => {
    const el = document.querySelector('.tags-view-container .tags-view-list') as HTMLElement

    const { initSortable } = useSortable(el, {
      filter: (e) => {
        const el = e.target as HTMLDivElement
        const text = el.innerText

        if (!text) return true
        return false
      },
      onEnd: (evt) => {
        const { oldIndex, newIndex } = evt

        if (isNullAndUnDef(oldIndex) || isNullAndUnDef(newIndex) || oldIndex === newIndex) {
          return
        }
        // 重新排序
        sortTags(oldIndex, newIndex)
      },
      draggable: '.tags-view-item'
    })
    initSortable()
  })
}
