<template>
  <el-scrollbar ref="scrollRef" class="tags-view-scrollbar" @wheel.passive="changeScroll">
    <div class="tags-view-container">
      <transition-group tag="ul" class="tags-view-list" name="list">
        <router-link
          ref="tagRef"
          v-for="(tag, index) in getTagsViewList"
          :key="tag.fullPath"
          class="tags-view-item"
          :class="isActive(tag) ? 'active' : ''"
          :to="{ path: tag.fullPath }"
          :style="{
            borderColor: isActive(tag) ? cssVar.menuBg : ''
          }"
          @contextmenu.prevent="openMenu($event, index, tag)"
        >
          <svg-icon
            class="split"
            v-show="isActive(tag) || index === 0 ? false : true"
            style="z-index: 9; position: absolute; left: -10px"
            icon="tags-view-split"
          ></svg-icon>
          <span class="tags-text">{{ tag.title }}</span>
          <span
            class="close"
            @click.prevent.stop="onCloseClick(index)"
            :class="isActive(tag) ? 'active-close' : ''"
            v-if="!isAffix(tag)"
          >
            <svg-icon :icon="'close'" class-name="close-icon"></svg-icon>
          </span>
        </router-link>
      </transition-group>

      <tags-view-context-menu
        @close="closeMenu"
        :style="position"
        :index="selectIndex"
        :selectedTag="selectedTag"
        v-show="visible"
      />
    </div>
  </el-scrollbar>
</template>

<script lang="ts" setup>
import type { TagsViewItem } from '@/stores/types'
import type { RouteMeta, RouterLinkProps } from 'vue-router'

import { ref, reactive, watch, nextTick, onMounted, computed } from 'vue'
import { storeToRefs } from 'pinia'
import { useRoute } from 'vue-router'
import TagsViewContextMenu from './TagsViewContextMenu.vue'
import useAppStore from '@/stores/app'
import useThemeStore from '@/stores/theme'
import useCurrentInstance from '@/hooks/useCurrentInstance'
import { useTagsDrag } from './hook/useTagsDrag'
import { isAffix } from '@/utils/tags'
import { RouterLink } from 'vue-router'

const appStore = useAppStore()
const { tagsViewList } = storeToRefs(appStore)
const themeStore = useThemeStore()
const { cssVar } = storeToRefs(themeStore)
const route = useRoute()

// 过滤隐藏页签
const getTagsViewList = computed(() => tagsViewList.value.filter((item) => !item.meta?.hideTab))

// 鼠标滚轮处理tagsview滚动
const scrollRef = ref()

// 判断是否活跃页签
const isActive = (tag: TagsViewItem) => {
  const { path, fullPath, meta = {} } = route
  const { currentActiveMenu, hideTab } = meta as RouteMeta
  const isHide = !hideTab ? null : currentActiveMenu
  const p = isHide || path || fullPath

  return tag.path === p

  // return tag.path === route.path
}
// 关闭tag 的点击事件
const { proxy } = useCurrentInstance()
const { removeTagsView, toLastView } = appStore
const onCloseClick = (index: number) => {
  const tag = getTagsViewList.value[index]
  removeTagsView({ type: 'index', index })
  proxy.eventBus.emit('onTabViewClose', tag)
  if (isActive(tag)) {
    toLastView(index)
  }
  scrollRef.value.update()
}

// 鼠标右键
const visible = ref(false)
const position = reactive({
  top: '',
  left: ''
})
const selectIndex = ref(0)
const selectedTag = ref<TagsViewItem>()
// 打开上下文菜单
const openMenu = (e: MouseEvent, index: number, tag: TagsViewItem) => {
  const menuMinWidth = 150

  const offsetLeft = scrollRef.value.wrapRef.getBoundingClientRect().left
  const offsetWidth = scrollRef.value.wrapRef.offsetWidth
  const maxLeft = offsetWidth - menuMinWidth + offsetLeft

  const left = e.clientX + 15 // 15: 正常右边距

  if (left > maxLeft) {
    position.left = maxLeft + 'px'
  } else {
    position.left = left + 'px'
  }

  position.top = e.clientY + 'px'

  selectIndex.value = index
  selectedTag.value = tag
  visible.value = true
}
// 关闭菜单
const closeMenu = () => {
  visible.value = false
  scrollRef.value.update()
}
// 水平滚动
const changeScroll = (e: WheelEvent) => {
  closeMenu()
  const scrollbar = scrollRef.value

  scrollbar.setScrollLeft(scrollbar.wrapRef.scrollLeft - -e.deltaY)
}
const tagRef = ref()
// 跳转到指定tagsItem
const moveToTarget = () => {
  // 确保 addTagsViewList 先执行
  nextTick(() => {
    const tags = tagRef.value

    if (tags) {
      for (const tag of tags) {
        if (tag.to.path === route.path) {
          scrollTo(tag)
          break
        }
      }
    }
  })
}
// 滚动条滚动到指定tag
const scrollTo = (currentTag: RouterLinkProps) => {
  const wrap$ = scrollRef.value.wrapRef // 滚动条el
  const containerWidth$ = wrap$.offsetWidth // 容器宽度 固定不变

  const tagList = tagRef.value // 所有tagsitem 的ref列表

  let firstTag = null // 首个tag
  let lastTag = null // 最后一个tag
  // find first tag and last tag
  if (tagList.length > 0) {
    firstTag = tagList[0]
    lastTag = tagList[tagList.length - 1]
  }

  if (firstTag === currentTag) {
    // 情况1: 活跃tag等于第一个tag
    wrap$.scrollLeft = 0
  } else if (lastTag === currentTag) {
    // 情况2: 活跃tag等于最后一个tag
    // 容器滚动条宽度tagsitem没有溢出时等于容器宽度，因此滚动条不移动
    wrap$.scrollLeft = wrap$.scrollWidth - containerWidth$
  } else {
    // 情况3: 活跃tag居于中间
    // find preTag and nextTag
    const currentIndex = tagList.findIndex((item: RouterLinkProps) => item === currentTag)
    const prevTag = tagList[currentIndex - 1]
    const nextTag = tagList[currentIndex + 1]

    // the tag's offsetLeft after of nextTag
    const afterNextTagOffsetLeft = nextTag.$el.offsetLeft + nextTag.$el.offsetWidth

    // the tag's offsetLeft before of prevTag
    const beforePrevTagOffsetLeft = prevTag.$el.offsetLeft
    if (afterNextTagOffsetLeft > wrap$.scrollLeft + containerWidth$) {
      wrap$.scrollLeft = afterNextTagOffsetLeft - containerWidth$
    } else if (beforePrevTagOffsetLeft < wrap$.scrollLeft) {
      wrap$.scrollLeft = beforePrevTagOffsetLeft
    }
  }
}

// 点击其他位置处理
watch(visible, (val) => {
  if (val) {
    document.body.addEventListener('click', closeMenu)
  } else {
    document.body.removeEventListener('click', closeMenu)
  }
})
// 防刷新
onMounted(() => {
  moveToTarget()
  useTagsDrag()
})

watch(
  () => route.path,
  () => {
    moveToTarget()
  }
)
</script>

<style lang="scss" scoped>
.tags-view-scrollbar {
  :deep(.el-scrollbar__bar.is-horizontal) {
    height: 5px;
    bottom: 0px;
  }
  .tags-view-container {
    width: 100%;
    height: 40px;

    .tags-view-list {
      height: 40px;
      width: 100%;
      background-color: #fff;
      position: relative;
      padding: 2px 15px 0 10px;
      font-size: 14px;

      user-select: none;

      display: flex;
      .tags-view-item {
        position: relative;
        background-color: transparent;
        padding: 10px 15px;

        border-radius: 10px 10px 0 0;
        cursor: pointer;
        // transition: 0.2s;
        display: flex;
        justify-content: center;
        white-space: nowrap;
        // transition: transiform 500ms ease;

        // close 按钮
        .close {
          margin-left: 10px;
          padding-left: 5px;
          display: flex;
          justify-content: center;
          align-items: center;
          // display: none;

          :deep(.close-icon) {
            width: 18px;
            height: 18px;
            border-radius: 50%;
            transition: all 0.3s cubic-bezier(0.645, 0.045, 0.355, 1);
            transform-origin: 100% 50%;

            &:before {
              transform: scale(0.6);
              display: inline-block;
              vertical-align: -3px;
            }
            &:hover {
              background-color: #b4bccc;
              color: #fff;
            }
          }
        }

        .split {
          :deep(.svg-icon) {
            font-size: 21px;
          }
        }
        .active-close {
          :deep(.close-icon) {
            color: #fff;
          }
        }
      }

      .tags-view-item::before,
      .tags-view-item::after {
        position: absolute;
        bottom: 0;
        content: '';
        width: 20px;
        height: 20px;
        border-radius: 100%;
        box-shadow: 0 0 0 40px transparent; /*使用box-shadow不影响尺寸*/
        // transition: 0.2s;  // before/after小尾巴问题
      }
      .tags-view-item::before {
        left: -20px;
        clip-path: inset(50% -10px 0 50%);
      }
      .tags-view-item::after {
        right: -20px;
        clip-path: inset(50% 50% 0 -10px);
      }
      .tags-view-item:hover {
        background-color: #62b7e4;
        color: #fff;
        .split {
          display: none;
        }
        & + a {
          .split {
            display: none;
          }
        }
      }
      .tags-view-item:hover::before,
      .tags-view-item:hover::after {
        box-shadow: 0 0 0 30px #62b7e4;
      }
      .tags-view-item.active {
        background-color: #008cd6;
        z-index: 1;
        color: #fff;

        & + a {
          .split {
            display: none;
          }
        }
      }
      .tags-view-item.active::before,
      .tags-view-item.active::after {
        box-shadow: 0 0 0 30px #008cd6;
      }
    }
  }
}
</style>
