<template>
  <div class="svg">
    <svg-icon style="font-size: 28px" icon="menu-expand"></svg-icon>
  </div>
</template>

<script lang="ts" setup></script>

<style lang="scss" scoped></style>
