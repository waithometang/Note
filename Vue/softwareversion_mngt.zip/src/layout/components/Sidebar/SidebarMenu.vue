<template>
  <el-menu
    :collapse="!sidebarOpened"
    :default-active="activeMenu"
    :unique-opened="true"
    :collapse-transition="false"
    router
  >
    <sidebar-item
      v-for="item in routes"
      :key="item.path"
      :currentIndexPath="currentIndexPath"
      :route="item"
    ></sidebar-item>
  </el-menu>
</template>

<script lang="ts" setup>
import { useRouter, useRoute } from 'vue-router'
import { filterRoutes, generateMenus } from '@/utils/route'
import { computed, ref, unref, watch } from 'vue'
import SidebarItem from './SidebarItem.vue'

import { storeToRefs } from 'pinia'
import useAppStore from '@/stores/app'

// 根据路由表生成menu
const router = useRouter()
const route = useRoute()

const routes = computed(() => {
  // 过滤重复路由
  const fRoutes = filterRoutes(router.getRoutes())
  return generateMenus(fRoutes)
})

// 当前活跃菜单
const activeMenu = computed(() => {
  const path =
    (route || unref(route)).meta?.currentActiveMenu ||
    (route || unref(route)).path
  return path
})

// 折叠
const { sidebarOpened } = storeToRefs(useAppStore())
// 当前活跃的子菜单
const currentIndexPath = ref<string[]>([])

watch(
  route,
  () => {
    currentIndexPath.value = route.matched.map((item) => item.path)
  },
  {
    immediate: true
  }
)
</script>

<style lang="scss" scoped></style>
