<template>
  <div class="svg">
    <svg-icon style="font-size: 28px" icon="menu-collapsed"></svg-icon>
  </div>
</template>

<script lang="ts" setup></script>

<style lang="scss" scoped></style>
