<template>
  <div class="sidebar-container">
    <div class="logo-container">
      <transition name="el-zoom-in-center">
        <svg-icon
          v-show="sidebarOpened"
          icon="menu-logo"
          class-name="menu-logo"
        ></svg-icon>
      </transition>
      <hamburger class="hamburger" />
    </div>
    <el-scrollbar class="vertical-menus-scrollbar" :style="menuPadding">
      <sidebar-menu></sidebar-menu>
    </el-scrollbar>
  </div>
</template>

<script lang="ts" setup>
import SidebarMenu from './SidebarMenu.vue'
import Hamburger from '@/components/Hamburger/index.vue'

import useAppStore from '@/stores/app'
import { storeToRefs } from 'pinia'
import { computed } from 'vue'

const appStore = useAppStore()
const { sidebarOpened } = storeToRefs(appStore)

const menuPadding = computed(() => {
  return sidebarOpened.value ? 'padding: 0 20px' : 'padding: 0'
})
// const logoHeight = '35'
</script>

<style lang="scss" scoped>
.sidebar-container {
  height: 100%;
  overflow: hidden;
  .logo-container {
    height: 35px;
    line-height: 35px;
    padding: 2px;
    margin: 30px 0;

    display: flex;
    justify-content: center;
    align-items: center;
    .hamburger {
      padding: 20px;
      display: flex;
      align-items: center;
      justify-content: center;
    }
    :deep(.menu-logo) {
      width: 100%;
      height: 35px;
    }
  }
  .vertical-menus-scrollbar {
    height: calc(100vh - 95px);
  }
}
</style>
