<template>
  <template v-if="isDef(icon)">
    <!-- element icon -->
    <el-icon :size="14" v-if="icon.includes('el-icon')" class="sub-el-icon">
      <component :is="elIconHandle(icon)" />
    </el-icon>
    <!-- 非 element icon -->
    <svg-icon v-else style="font-size: 24px" :icon="icon"></svg-icon>
  </template>
  <!-- 文本 -->
  <span
    class="menu-item-text"
    style="
      display: block;
      width: 90%;
      overflow: hidden;
      white-space: nowrap;
      text-overflow: ellipsis;
    "
    :title="generateTitle(title)"
    >{{ generateTitle(title) }}</span
  >
</template>

<script lang="ts" setup>
import { generateTitle } from '@/utils/i18n'
import { isDef } from '@/utils/is'
defineProps({
  title: {
    type: String,
    required: true
  },
  icon: {
    type: String,
    required: true
  }
})
// 处理el图标
const elIconHandle = (icon: string) => {
  return icon.slice(icon.lastIndexOf('-') + 1, icon.length)
}
</script>

<style lang="scss" scoped>
.menu-item-text {
  user-select: none;
}
</style>
