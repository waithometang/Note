<template>
  <div class="sidebar-item">
    <el-sub-menu
      v-if="menuHasChildren(route) && getShowMenu"
      :index="route.path"
      :expand-open-icon="SubMenuOpenIcon"
      :expand-close-icon="SubMenuCloseIcon"
      v-bind="$attrs"
    >
      <template #title>
        <menu-item :title="route.meta!.title" :icon="handleIcon(route)" />
      </template>
      <sidebar-item
        v-for="item in route.children"
        :key="item.path"
        :route="item"
        class="multi-submenu"
      >
      </sidebar-item>
    </el-sub-menu>
    <el-menu-item v-if="!menuHasChildren(route) && getShowMenu" :index="route.path">
      <menu-item :title="route.meta!.title" :icon="handleIcon(route)" />
    </el-menu-item>
  </div>
</template>

<script lang="ts" setup>
import { computed, type PropType } from 'vue'
import MenuItem from './MenuItem.vue'
import SubMenuOpenIcon from './SubMenuOpenIcon.vue'
import SubMenuCloseIcon from './SubMenuCloseIcon.vue'
import type { RouteRecordRaw } from 'vue-router'
const props = defineProps({
  route: {
    type: Object as PropType<RouteRecordRaw>,
    required: true
  },
  currentIndexPath: {
    type: Array,
    default: () => {
      return []
    }
  }
})
// 获取显示菜单
const getShowMenu = computed(() => !props.route.meta?.hideMenu)

// 菜单是否含有子菜单
const menuHasChildren = (route: RouteRecordRaw) => {
  return Reflect.has(route, 'children') && !!route.children && route.children.length > 0
}

// 处理图标状态
const handleIcon = (route: RouteRecordRaw) => {
  return props.currentIndexPath.includes(route.path) && route.meta && route.meta.iconActive
    ? route.meta.iconActive
    : route.meta!.icon as string
}
</script>

<style lang="scss">
.el-menu--collapse {
  /*隐藏文字*/
  .menu-item-text {
    display: none !important;
  }
}
</style>
