<template>
  <div class="footer-container" v-show="signalrConnectionStatus">
    <el-skeleton :loading="loading" animated :throttle="500">
      <template #template>
        <div class="skeleton-item">
          <el-skeleton-item variant="text" style="width: 30%" />
        </div>
      </template>
      <template #default>
        <div class="info">
          <span>{{ $t('CpuUsage') }}</span>
          <span>{{ systemInfo?.cpuUsedRate }}%</span>
        </div>
        <div class="info">
          <span>{{ $t('MemoryUsage') }}</span>
          <span>{{ systemInfo?.memoryUsedRate }}%</span>
        </div>
        <div class="system-info" v-for="disk in systemInfo?.diskInfoDTOs" :key="disk.diskName">
          <span>{{ $t('disk', [disk.diskName]) }}</span>
          <span> {{ $t('DiskRate', [disk.freeSpace, disk.totalSpace]) }} </span>
          <svg-icon
            class="exclamation-icon"
            v-show="handleExclamation(disk.freeSpace, disk.totalSpace).show"
            :style="handleExclamation(disk.freeSpace, disk.totalSpace).style"
            icon="exclamation"
          ></svg-icon>
        </div>
      </template>
    </el-skeleton>

    <span class="version">{{ $t('systemVersion', ['0.0.1']) }}</span>

    <svg-icon
      class="svg-icon"
      :class="{ rotate: loading }"
      icon="loop"
      style="color: #008cd6"
      @click="loadServerInfo"
    ></svg-icon>
  </div>
</template>

<script lang="ts" setup>
import type { IDiskInfoDTO, ISystemInfo } from '@/api/sys/model/systemModel'

import { ref, computed, onUnmounted } from 'vue'
import cookie from 'js-cookie'
import { useI18n } from 'vue-i18n'
import { debounce } from 'lodash-es'
import { ElNotification } from 'element-plus'

import { connection } from '@/utils/signalr'
import useAppStore from '@/stores/app'

const SERVER_DATA = 'ReceiveMessage'

const i18n = useI18n()
const systemInfo = ref<ISystemInfo>()
const loading = ref(false)

let notificationInstance: any

const appStore = useAppStore()

const signalrConnectionStatus = computed(() => {
  const status = appStore.signalrConnectionStatus
  if (status) {
    getServerInfo()
  }
  return status
})

// 获取服务器电脑信息
const getServerInfo = async () => {
  await connection.invoke('StartGetServerDataMessageToAllClientsAsync')
}

connection.on(SERVER_DATA, (data) => {
  systemInfo.value = JSON.parse(data) as ISystemInfo
  handleSystemInfo(systemInfo.value.diskInfoDTOs)
})

// 清空cookie 每次登录、刷新显示一次
cookie.remove('diskNotificationShow')

// 加载系统信息
const loadServerInfo = debounce(
  async () => {
    loading.value = true
    await getServerInfo()
    loading.value = false
  },
  800,
  { leading: true }
)

// 处理感叹图标
const handleExclamation = (freeSpace: number | string, totalSpace: number | string) => {
  freeSpace = Number(freeSpace)
  totalSpace = Number(totalSpace)
  const percentage = (freeSpace / totalSpace) * 100
  if (percentage < 10) {
    return {
      show: true,
      style: {
        color: '#ff2e00'
      }
    }
  } else if (percentage < 30) {
    return {
      show: true,
      style: {
        color: '#ffcc00'
      }
    }
  } else {
    return {
      show: false,
      style: {
        color: '#9b9b9b'
      }
    }
  }
}

// 处理系统信息
const handleSystemInfo = (diskInfoDTOs: IDiskInfoDTO[]) => {
  const diskNotificationShow = !cookie.get('diskNotificationShow')

  // 判断cookie是否
  if (diskNotificationShow) {
    const warningDisk: string[] = []

    diskInfoDTOs.forEach((disk) => {
      const percentage = (Number(disk.freeSpace) / Number(disk.totalSpace)) * 100
      if (percentage < 30) {
        warningDisk.push(disk.diskName)
      }
    })

    const num = 0.5 // 失效时间是几小时
    const time = new Date(new Date().getTime() + num * 60 * 60 * 1000)
    cookie.set('diskNotificationShow', 'true', {
      expires: time
    })

    if (warningDisk.length) {
      if (notificationInstance) {
        notificationInstance.close()
      }
      notificationInstance = ElNotification({
        title: i18n.t('KindReminder'),
        message: i18n.t('InsufficientDiskSpace', [warningDisk.join('、')]),
        position: 'bottom-right',
        type: 'error',
        duration: 0,
        offset: 16 // 默认偏移16 底栏高度32
      })
    }
  }
}

onUnmounted(() => {
  connection.off(SERVER_DATA)
})
</script>

<style lang="scss" scoped>
.footer-container {
  height: 100%;
  font-size: 12px;
  color: #303030;

  display: flex;
  justify-content: right;
  align-items: center;
  .skeleton-item {
    display: flex;
    align-items: center;
    justify-content: right;
    margin-right: 20px;
  }
  .info {
    overflow: hidden;
    white-space: nowrap;
    margin-right: 40px;
  }
  .system-info {
    overflow: hidden;
    white-space: nowrap;
    margin-right: 30px;
    color: #9b9b9b;

    display: flex;
    align-items: center;
    .exclamation-icon {
      margin-left: 5px;
    }
  }
  .svg-icon {
    cursor: pointer;
    font-size: 16px;
  }

  .rotate {
    animation: flash 1s ease-in-out infinite;
    :deep(.svg-icon) {
      color: #2a2a2a;
    }
  }

  @keyframes flash {
    0% {
      transform: rotate(0deg);
    }
    50% {
      transform: rotate(180deg);
    }
    100% {
      transform: rotate(360deg);
    }
  }
}
</style>
@/api/sys/system
