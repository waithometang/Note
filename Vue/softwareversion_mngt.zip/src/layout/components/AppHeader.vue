<template>
  <!-- 操作栏 -->
  <div class="app-operation">
    <div class="left-operation">
      <breadcrumb class="breadcrumb-container" />
    </div>
    <div class="right-operation">
      <a class="item" :href="switchAppUrl">
        <el-tooltip :content="$t('component.navBar.switchApp')">
          <svg-icon style="color: #008cd6; font-size: 24px" icon="switch-app" />
        </el-tooltip>
      </a>
      <screenfull class="item" />
      <system-description-preview class="item" />
      <!-- <Notification class="item" />
      <lang-select class="item" /> -->

      <el-dropdown trigger="click">
        <div class="user operation">
          <svg-icon class="user-icon" icon="user"></svg-icon>
          <span class="user-text">{{ userInfo.userName }}</span>
        </div>
        <template #dropdown>
          <el-dropdown-menu>
            <el-dropdown-item @click="showUpdatePassword">{{
              $t('changePassword')
            }}</el-dropdown-item>
            <el-dropdown-item @click="logout">{{ $t('logout') }}</el-dropdown-item>
          </el-dropdown-menu>
        </template>
      </el-dropdown>
    </div>
  </div>
  <!-- 页签 -->
  <tags-view class="tags-view"></tags-view>
  <BasicModal
    width="556px"
    v-bind="$attrs"
    @register="registerModal"
    title="修改密码"
    @confirm="handleSubmit"
  >
    <BasicForm @register="registerForm"> </BasicForm>
  </BasicModal>
</template>

<script lang="ts" setup>
import type { UpdateLoginPasswordData } from '@/api/sys/model/systemModel'
import LangSelect from '@/components/LangSelect/index.vue'
import Breadcrumb from '@/components/Breadcrumb/index.vue'
import Screenfull from '@/components/Screenfull/index.vue'
import Notification from '@/components/Notification/index.vue'
import SystemDescriptionPreview from '@/components/SystemDescriptionPreview/index.vue'
import { ref, computed, nextTick } from 'vue'
import { useI18n } from 'vue-i18n'
import useUserStore from '@/stores/user'
import useAppStore from '@/stores/app'
import { useModal } from '@/components/Modal/hooks/useModal'
import { useForm } from '@/components/Form/hooks/useForm'
import { getUserInfoSSO, updateLoginPassword } from '@/api/sys/system'

const i18n = useI18n()

const userStore = useUserStore()

const appStore = useAppStore()

const switchAppUrl = computed(
  () => `${import.meta.env.VITE_SSO_BASE_URL}/#/app-entry?appid=` + appStore.appInfo.applicationID
)

const userInfo = computed(() => userStore.userInfo)
// 登出操作
const logout = () => {
  const { logout } = userStore
  ElMessageBox.confirm(i18n.t('isLogout'), i18n.t('KindReminder'), {
    type: 'warning'
  }).then(() => {
    logout()
  })
}

const [registerModal, { openModal, closeModal }] = useModal()

const [registerForm, { setFieldsValue, resetFields, getFieldsValue, clearValidate, validate }] =
  useForm({
    labelWidth: 86,
    schemas: [
      {
        field: 'id',
        component: 'ElInput',
        label: '',
        ifShow: false
      },
      {
        field: 'loginPassword',
        component: 'ElInput',
        label: '新密码',
        rules: [{ required: true, trigger: 'blur' }],
        componentProps: {
          type: 'password',
          showPassword: true
        }
      },
      {
        field: 'confirmPassword',
        component: 'ElInput',
        label: '确认密码',
        rules: [
          {
            required: true,
            trigger: 'blur',
            validator(rule, value, cb) {
              const data = getFieldsValue() as UpdateLoginPasswordData
              if (data.loginPassword !== value) {
                cb('两次密码不一致')
              } else {
                cb()
              }
            }
          }
        ],
        componentProps: {
          type: 'password',
          showPassword: true
        }
      },
      {
        field: 'dataDescribe',
        component: 'ElInput',
        label: '描述',
        componentProps: { disabled: true }
      }
    ]
  })

// 打开修改密码对话框
const showUpdatePassword = async () => {
  openModal()

  await nextTick()
  await resetFields()

  try {
    const { code, data, message } = await getUserInfoSSO({
      loginAccount: userStore.userInfo.userName
    })
    if (code === 200 && data.result.length > 0) {
      await setFieldsValue({ id: data.result[0].id, dataDescribe: data.result[0].dataDescribe })
    } else {
      ElMessage.error('获取用户描述失败,' + message)
    }
  } catch (error: any) {
    ElMessage.error(error.message)
  }

  clearValidate()
}

const handleSubmit = async () => {
  await validate()
  const form = getFieldsValue() as UpdateLoginPasswordData
  try {
    const { code, data, message } = await updateLoginPassword(form)
    if (code === 200 && data) {
      ElMessage.success('修改成功')
      closeModal()
      setTimeout(() => {
        userStore.logout()
      }, 1000)
    } else {
      ElMessage.error(message)
    }
  } catch (error: any) {
    ElMessage.error(error.message)
  }
}
</script>

<style lang="scss" scoped>
$bgColor: #f1f1f1;
.tags-view {
  height: 40px;
}
.app-operation {
  height: 30px;
  width: 100%;
  border-bottom: 1px solid #f5f6f8;
  -webkit-app-region: drag;
  -webkit-user-select: none;

  // background-color: $bgColor;
  display: flex;
  justify-content: space-between;
  align-items: center;
  .left-operation {
    display: flex;
    align-items: center;
    :deep(.breadcrumb) {
      line-height: 20px;
    }
  }
  .right-operation {
    display: flex;
  }
  .left-operation,
  .right-operation {
    -webkit-app-region: no-drag;
  }
  .item {
    margin-right: 10px;
    display: flex;
    justify-content: center;
    align-items: center;
    cursor: pointer;
  }
  .user {
    font-size: 16px;
    margin-right: 20px;
    display: flex;
    justify-content: center;
    align-items: center;
    cursor: pointer;
    .user-icon {
      margin-right: 5px;
    }
    .user-text {
      text-decoration: underline;
      color: $themeColor;
    }
  }
  .menu-bar {
    // background-color: $bgColor;
  }
}
</style>
