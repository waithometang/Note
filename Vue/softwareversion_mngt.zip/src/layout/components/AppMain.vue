<template>
  <router-view v-slot="{ Component, route }">
    <template v-if="Component">
      <transition name="fade" mode="out-in">
        <keep-alive :include="state.keepAliveComponentNameList" :max="20">
          <component :is="wrap(route.fullPath, Component)" :key="state.componentKey"></component>
        </keep-alive>
      </transition>
    </template>
  </router-view>
</template>

<script lang="ts" setup>
import type { TagsViewItem } from '@/stores/types'

import useAppStore from '@/stores/app'
import { nextTick, onBeforeMount, onMounted, onUnmounted, ref, watch, h, type VNode } from 'vue'
import { useRoute } from 'vue-router'
import { isTags } from '@/utils/tags.js'
import useCurrentInstance from '@/hooks/useCurrentInstance'

import { generateTitle, watchSwitchLang } from '@/utils/i18n'
import { storeToRefs } from 'pinia'

const appStore = useAppStore()
const { tagsViewList } = storeToRefs(appStore)
const { addTagsViewList, changeTagsView } = appStore
const route = useRoute()
// 生成title
const getTitle = (route: TagsViewItem) => {
  let title = ''
  // 没有元信息
  if (!route.meta) {
    const pathArr = route.path.split('/')
    title = pathArr[pathArr.length - 1]
  } else {
    // 国际化处理
    title = generateTitle(route.meta.title as string) // generateTitle(route.meta.title)
  }
  return title
}

// 监听当前路由 添加新的tag加入tagList中
watch(
  () => route.path,
  () => {
    if (!isTags(route.path)) return
    const { fullPath, meta, name, params, path, query } = route
    addTagsViewList({
      fullPath,
      meta,
      name,
      params,
      path,
      query,
      title: getTitle(route)
    })
  },
  {
    immediate: true
  }
)

// 页面刷新、关闭
const state = ref<{
  componentKey: string
  keepAliveComponentNameList: string[]
}>({
  componentKey: route.fullPath,
  keepAliveComponentNameList: []
})

const { proxy } = useCurrentInstance()
// 添加缓存
const addKeepAliveComponentName = (keepAliveName: string) => {
  if (keepAliveName) {
    const exist = state.value.keepAliveComponentNameList.find((name) => {
      return name === keepAliveName
    })
    if (exist) {
      return
    }

    state.value.keepAliveComponentNameList.push(keepAliveName)
  }
}
// 卸载时取消订阅
onUnmounted(() => {
  proxy.eventBus.off('onTabViewRefresh')
  proxy.eventBus.off('onTabViewClose')
})

onBeforeMount(() => {
  // 刷新页面
  proxy.eventBus.on('onTabViewRefresh', (menuItem: TagsViewItem) => {
    state.value.keepAliveComponentNameList = state.value.keepAliveComponentNameList.filter(
      (item) => {
        return item !== menuItem.fullPath
      }
    )
    state.value.componentKey = ''
    nextTick(() => {
      state.value.componentKey = menuItem.fullPath

      const ignoreKeepAlive = menuItem.meta?.ignoreKeepAlive
      !ignoreKeepAlive && addKeepAliveComponentName(menuItem.fullPath)
    })
  })
  // 关闭页面
  proxy.eventBus.on('onTabViewClose', (menu: TagsViewItem) => {
    state.value.keepAliveComponentNameList = state.value.keepAliveComponentNameList.filter(
      (name) => menu.fullPath !== name
    )
  })
})
onMounted(() => {
  // 确保刷新页面时也能正确取得当前路由 keepAlive 参数
  const ignoreKeepAlive = route.meta?.ignoreKeepAlive
  !ignoreKeepAlive && addKeepAliveComponentName(route.fullPath)
})

watch(
  () => route.path,
  () => {
    if (route.path) {
      state.value.componentKey = route.fullPath

      const ignoreKeepAlive = route.meta?.ignoreKeepAlive
      !ignoreKeepAlive && addKeepAliveComponentName(route.fullPath)
    }
  }
)

// 监听语言变化, tag国际化
watchSwitchLang(() => {
  tagsViewList.value.forEach((route: TagsViewItem, index: number) => {
    changeTagsView({ index, tag: { ...route, title: getTitle(route) } })
  })
})

// 加壳解决  https://github.com/vuejs/core/issues/6222 vue bug
const wrapperMap = new Map()

const wrap = (fullPath: string, component: VNode) => {
  let wrapper

  const wrapperName = fullPath

  if (wrapperMap.has(wrapperName)) {
    wrapper = wrapperMap.get(wrapperName)
  } else {
    wrapper = {
      name: wrapperName,
      render() {
        return h('div', { className: 'app-main' }, component)
      }
    }
    wrapperMap.set(wrapperName, wrapper)
  }

  return h(wrapper)
}
</script>

<style lang="scss" scoped>
.app-main {
  width: 100%;
  height: 100%;

  box-sizing: border-box;
}
</style>
