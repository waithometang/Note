<template>
  <div class="common-layout">
    <el-container>
      <el-aside
        v-show="!tagFullScreen"
        class="sidebar-container"
        :width="width"
      >
        <sidebar />
      </el-aside>
      <el-container>
        <el-header v-show="!tagFullScreen" class="header">
          <app-header />
        </el-header>
        <el-main class="main" id="main">
          <app-main />
        </el-main>
        <el-footer v-show="!tagFullScreen" class="footer" height="32px">
          <app-footer />
        </el-footer>
      </el-container>
    </el-container>

    <CloseFullScreen v-if="tagFullScreen" />
  </div>
</template>

<script lang="ts" setup>
import { ref, computed } from 'vue'
import { storeToRefs } from 'pinia'

import AppHeader from './components/AppHeader.vue'
import AppFooter from './components/AppFooter.vue'
import AppMain from './components/AppMain.vue'
import CloseFullScreen from './components/CloseFullScreen.vue'
import Sidebar from './components/Sidebar/index.vue'

import useAppStore from '@/stores/app'

// 折叠
const { sidebarOpened, tagFullScreen } = storeToRefs(useAppStore())

const width = computed(() => {
  // '240px' : '64px'
  return sidebarOpened.value ? '300px' : '64px'
})
</script>

<style lang="scss" scoped>
.common-layout {
  background-color: #ffffff;
  height: 100%;
  width: 100%;
  display: flex;
  .sidebar-container {
    background-color: #ffffff;
    box-shadow: 0px 0px 10px 0px rgba(0, 0, 0, 0.05);
    z-index: 1;
  }
  .header {
    background-color: #ffffff;
    box-shadow: 0px 0px 6px 0px rgba(0, 0, 0, 0.08);
    z-index: 11;
  }
  .main {
    background-color: #f6f8f9;
    position: relative;
    overflow-x: hidden;
  }
  .footer {
    background-color: #ffffff;
    box-shadow: 0px 0px 6px 0px rgba(0, 0, 0, 0.08);
    z-index: 1;
  }
}
</style>
