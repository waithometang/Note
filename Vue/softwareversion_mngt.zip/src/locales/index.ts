import { createI18n } from 'vue-i18n'

import mZhLocale from './lang/zh.json'
import mEnLocale from './lang/en.json'
import { LStorage } from '@/utils/storage'
import { LANG } from '@/constant'

const messages = {
  zh: {
    ...mZhLocale
  },
  en: {
    ...mEnLocale
  }
}

const i18n = createI18n({
  // 使用 Composition API 模式，则需要将其设置为false
  legacy: false,
  // 全局注入 $t 函数
  globalInjection: true,
  locale: LStorage.get(LANG) || 'zh',
  fallbackLocale: 'zh', // 如果没有找到要显示的语言，则默认显示 ‘en’，
  silentFallbackWarn: true, // 控制台上不打印警告
  messages
})

export default i18n
