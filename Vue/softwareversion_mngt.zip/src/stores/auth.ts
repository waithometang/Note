import { ref } from 'vue'
import { defineStore } from 'pinia'
import { getLoginUserMenuFunction } from '@/api/sys/system'
import useAppStore from './app'
import useUserStore from './user'

const useAuthStore = defineStore('auth', () => {
  const codeList = ref<string[]>([])

  const setCodeList = (_codeList: string[]) => {
    codeList.value = _codeList
  }

  const hasCode = (code: string) => {
    return codeList.value.some((item) => item === code)
  }

  const getCodeList = async () => {
    try {
      const appStore = useAppStore()
      const userStore = useUserStore()
      const { code, data, message } = await getLoginUserMenuFunction({
        visitor: userStore.userInfo.userName === 'visitors',
        systemType: appStore.appInfo.systemType,
        systemTypeID: appStore.appInfo.systemTypeID
      })
      if (code === 200) {
        setCodeList(data)
      } else {
        ElMessage.error('获取权限失败,' + message)
      }
    } catch (error: any) {
      ElMessage.error(error.message)
    }
  }

  return { codeList, hasCode, setCodeList, getCodeList }
})

export default useAuthStore
