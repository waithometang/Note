import type { userInfo } from './types/user'

import { reactive, ref } from 'vue'
import { defineStore, storeToRefs } from 'pinia'
import dayjs from 'dayjs'

import { TOKEN, TIMEOUT, USER_INFO } from '@/constant'
import { SStorage } from '@/utils/storage'

import useAppStore from './app'

const useUserStore = defineStore('user', () => {
  const token = ref<string>(SStorage.get(TOKEN))

  const userInfo = reactive<userInfo>(SStorage.get(USER_INFO) || {})

  const hasMenu = ref(false)

  const setUserInfo = ({ token, userName, tokenType, expirationTimeUnixTimeSeconds }: userInfo) => {
    userInfo.userName = userName
    userInfo.tokenType = tokenType
    userInfo.expirationTimeUnixTimeSeconds = expirationTimeUnixTimeSeconds
    userInfo.token = tokenType + ' ' + token
    setToken(userInfo.token, Number(expirationTimeUnixTimeSeconds))
    SStorage.set(USER_INFO, userInfo)
  }

  const setToken = (_token: string, timeout: number) => {
    SStorage.set(TOKEN, _token)
    SStorage.set(TIMEOUT, dayjs().add(timeout).toString())
    token.value = _token
  }

  const logout = () => {
    const { tagsViewList } = storeToRefs(useAppStore())
    tagsViewList.value = []
    SStorage.clear()
    window.location.href = `${import.meta.env.VITE_SSO_BASE_URL}?logout=true&isPassive=false` //sso登陆页 isPassive是否被动退出
  }

  return {
    token,
    userInfo,
    hasMenu,
    setUserInfo,
    setToken,
    logout
  }
})

export default useUserStore
