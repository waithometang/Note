export type AppInfo = {
  apiUrl: string
  applicationID: string
  applicationName: string
  createTime: string
  factory: string
  icon: string
  iconUrl: string
  nativeProductLineType: number
  productLineType: number
  productLineTypeValue: string
  systemType: number
  systemTypeID: string
  systemTypeValue: string
  typeCoding: string
  webUrl: string
}
