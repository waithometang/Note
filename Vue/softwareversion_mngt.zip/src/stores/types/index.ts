import type { RouteLocationNormalized } from 'vue-router'

export interface TagsViewItem
  extends Omit<RouteLocationNormalized, 'matched' | 'hash' | 'redirectedFrom'> {
  title?: string
}