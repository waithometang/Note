export type userInfo = {
  token: string
  tokenType: string
  expirationTimeUnixTimeSeconds: string
  userName: string
}
