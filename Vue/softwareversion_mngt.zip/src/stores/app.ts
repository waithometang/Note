import type { AppInfo } from './types/app'
import type { TagsViewItem } from './types'

import { ref, reactive } from 'vue'
import { defineStore } from 'pinia'

import { LANG, TAGS_VIEW, APP_INFO } from '@/constant'
import { LStorage, SStorage } from '@/utils/storage'
import { useRouter } from 'vue-router'

import { RemoveTagsType } from '@/enums/tagsEnum'

const useAppStore = defineStore('app', () => {
  const language = ref<string>(LStorage.get(LANG) || 'zh')
  const tagsViewList = ref<TagsViewItem[]>(SStorage.get(TAGS_VIEW) || [])
  const lastDragEndIndex = ref<number>(0)
  const tagFullScreen = ref(false)
  const sidebarOpened = ref(true)
  const appInfo = reactive<AppInfo>(SStorage.get(APP_INFO) || {})
  const signalrConnectionStatus = ref(false)

  const setLanguage = (newLanguage: string) => {
    LStorage.set(LANG, newLanguage)
    language.value = newLanguage
  }

  const setAppInfo = ({
    apiUrl,
    applicationID,
    applicationName,
    systemType,
    createTime,
    factory,
    icon,
    webUrl,
    iconUrl,
    nativeProductLineType,
    productLineType,
    productLineTypeValue,
    systemTypeID,
    systemTypeValue,
    typeCoding
  }: AppInfo) => {
    appInfo.apiUrl = apiUrl
    appInfo.applicationID = applicationID
    appInfo.applicationName = applicationName
    appInfo.createTime = createTime
    appInfo.factory = factory
    appInfo.icon = icon
    appInfo.iconUrl = iconUrl
    appInfo.nativeProductLineType = nativeProductLineType
    appInfo.productLineType = productLineType
    appInfo.productLineTypeValue = productLineTypeValue
    appInfo.systemType = systemType
    appInfo.systemTypeID = systemTypeID
    appInfo.systemTypeValue = systemTypeValue
    appInfo.typeCoding = typeCoding
    appInfo.webUrl = webUrl
    SStorage.set(APP_INFO, appInfo)
  }

  const addTagsViewList = (tag: TagsViewItem) => {
    // 处理重复
    const isFind = tagsViewList.value.find((item) => {
      return item.path === tag.path
    })
    if (!isFind) {
      tagsViewList.value.push(tag)
      // 数据持久化
      SStorage.set(TAGS_VIEW, tagsViewList.value)
    }
  }
  /**
   * 为指定的 tag 修改 title
   */
  const changeTagsView = ({ index, tag }: { index: number; tag: TagsViewItem }) => {
    tagsViewList.value[index] = tag
    SStorage.set(TAGS_VIEW, tagsViewList.value)
  }
  const router = useRouter()

  // 跳转上一个路径
  const toLastView = (index: number) => {
    const latestView = tagsViewList.value.slice(-1)[0]

    // 是否存在最后一个页签
    if (latestView) {
      // 关闭的页面右侧还有页面时
      if (tagsViewList.value.length - 1 >= index) {
        const currentView = tagsViewList.value[index]

        return router.push(currentView.path)
      }
      // 右侧没有页面则跳转最后一个
      router.push(latestView.path)
    } else {
      // 不存在跳转首页
      return router.push('/')
    }
  }
  /**
   * 关闭tagsView
   * @param {type: 'other' || 'right' || 'index'} paylod
   */
  const removeTagsView = (payload: { selectedTag?: TagsViewItem; index: number; type: string }) => {
    switch (payload.type) {
      case RemoveTagsType.INDEX:
        tagsViewList.value.splice(payload.index, 1)
        break

      case RemoveTagsType.LEFT:
        handleCloseLeftOrRightTags(tagsViewList.value.slice(0, payload.index))
        break
      case RemoveTagsType.RIGHT:
        handleCloseLeftOrRightTags(
          tagsViewList.value.slice(payload.index + 1, tagsViewList.value.length)
        )
        break
      case RemoveTagsType.OTHER: {
        router.push(payload.selectedTag!.fullPath)
        tagsViewList.value = tagsViewList.value.filter((tag) => {
          return tag.meta.affix || tag.path === payload.selectedTag!.path
        })
        break
      }
      case RemoveTagsType.ALL:
        tagsViewList.value = tagsViewList.value.filter((tag) => {
          return tag.meta.affix
        })
        router.push('/')
        break

      default:
        break
    }
    SStorage.set(TAGS_VIEW, tagsViewList.value)
  }
  /**
   * 关闭左侧或者关闭右侧
   * @param {*} tags 左侧或者右侧页签
   */
  const handleCloseLeftOrRightTags = (tags: TagsViewItem[]) => {
    const tagsFilter = tags.filter((tag) => {
      const affix = tag?.meta?.affix ?? false
      if (!affix) {
        return true
      }
      return false
    })

    tagsViewList.value = tagsViewList.value.filter((tag) => {
      return !tagsFilter.find((filterTag) => filterTag.fullPath === tag.fullPath)
    })
  }

  /**
   * 排序tagsItem
   * @param {*} oldIndex
   * @param {*} newIndex
   */
  const sortTags = (oldIndex: number, newIndex: number) => {
    const currentTab = tagsViewList.value[oldIndex]
    tagsViewList.value.splice(oldIndex, 1)
    tagsViewList.value.splice(newIndex, 0, currentTab)
    lastDragEndIndex.value = lastDragEndIndex.value + 1
    SStorage.set(TAGS_VIEW, tagsViewList.value)
  }

  const setFullScreen = (fullScreen: boolean) => {
    tagFullScreen.value = fullScreen
  }

  const triggerSidebarOpened = () => {
    sidebarOpened.value = !sidebarOpened.value
  }

  return {
    language,
    setLanguage,
    addTagsViewList,
    tagsViewList,
    changeTagsView,
    toLastView,
    sortTags,
    removeTagsView,
    tagFullScreen,
    setFullScreen,
    sidebarOpened,
    triggerSidebarOpened,
    appInfo,
    setAppInfo,
    signalrConnectionStatus
  }
})

export default useAppStore
