import { defineStore } from 'pinia'
import { ref, computed } from 'vue'
import variablesModule from '@/styles/variables.module.scss'

const useThemeStore = defineStore('theme', () => {
  const variables = ref(variablesModule)
  // 自定义的主题色包
  const cssVar = computed(() => variables.value)

  return { cssVar }
})

export default useThemeStore
