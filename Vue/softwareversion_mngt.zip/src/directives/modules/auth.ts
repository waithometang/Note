/**
 * v-auth
 * example: v-auth="'0000'" / v-auth="['0000','0001']"
 */
import useAuthStore from '@/stores/auth'
import type { Directive, DirectiveBinding } from 'vue'

const auth: Directive = {
  mounted(el: HTMLElement, binding: DirectiveBinding<string>) {
    const { value } = binding
    const authStore = useAuthStore()
    if (!authStore.hasCode(value)) {
      el.remove()
    }
  }
}

export default auth
