// 返回类型
export interface HYNResponse<T = any> {
  code: number
  data: T
  message: string
  responseAddress: string
  status: boolean
}
