declare interface Fn<T = any, R = T> {
  (...arg: T[]): R
}
// 将对象的所有值指定为同类型
declare type Recordable<T = any> = Record<string, T>
// 可能为空
declare type Nullable<T> = T | null

declare type EmitType = (event: string, ...args: any[]) => void

type Expand<T> = T extends infer O ? { [K in keyof O]: O[K] } : never

type ExpandRecursively<T> = T extends object
  ? T extends infer O
    ? { [K in keyof O]: ExpandRecursively<O[K]> }
    : never
  : T

/**
 * @description 泛型组件出口类型
 * @deprecated 废弃 https://github.com/vuejs/language-tools/issues/3206
 */
type GenericComponentExports<D extends (...p: any[]) => any> =
  //这里获取组件通用类型
  import('vue').ComponentPublicInstance &
    //这里获取defineExpose暴露的数据类型
    Parameters<NonNullable<NonNullable<ReturnType<D>['__ctx']>['expose']>>[0]
