export {}

declare module 'vue-router' {
  interface RouteMeta extends Record<string | number | symbol, unknown> {
    // 路由序号
    orderNo?: number
    // 侧边栏和面包屑中展示的名字
    title: string
     // 默认图标
     icon?: string
     // 激活图标
     iconActive?: string

    // 忽略保持缓存
    ignoreKeepAlive?: boolean
    // 固定tagviews页签
    affix?: boolean
    // 当前活跃菜单路径 详情页需要配置
    currentActiveMenu?: string
    // 隐藏tagview
    hideTab?: boolean
    // 隐藏菜单
    hideMenu?: boolean
  }
}
