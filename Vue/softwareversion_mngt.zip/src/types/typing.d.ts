import type dayjs from 'dayjs'

export {}

declare module 'vue' {
  interface ComponentCustomProperties {
    $dayjs: (date?: dayjs.ConfigType) => dayjs.Dayjs
  }
  interface AllowedComponentProps {
    [key: string]: any
  }
}
