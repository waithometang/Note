// 初始样式
import 'normalize.css'
import '@/styles/index.scss'
import 'element-plus/es/components/message/style/index'
import 'nprogress/nprogress.css'
import '@/permission'
// 引入自动更新提醒
import '@/utils/autoUpdate.ts'
import { createApp } from 'vue'

import pinia from '@/stores'

import i18n from '@/locales'

import App from './App.vue'
import router from './router'

import mitt from 'mitt'

import dayjs from 'dayjs'
import duration from 'dayjs/plugin/duration'
import isBetween from 'dayjs/plugin/isBetween'
import 'dayjs/locale/zh-cn' // 导入本地化语言
dayjs.extend(duration)
dayjs.extend(isBetween)
dayjs.locale('zh-cn')

// 注册自定义指令
import directives from '@/directives/index'
// 虚拟注册svgIcon
import 'virtual:svg-icons-register'
// 注册全局组件
import { registerGlobComp } from '@/components/registerGlobComp'

const app = createApp(App)

registerGlobComp(app)

app.config.globalProperties.eventBus = mitt()
app.config.globalProperties.$dayjs = dayjs

app.use(i18n)
app.use(pinia)
app.use(router)
app.use(directives)

app.mount('#app')
