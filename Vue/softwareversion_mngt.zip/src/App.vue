<script setup lang="ts">
import { computed, onMounted } from 'vue'
import { storeToRefs } from 'pinia'
import { RouterView } from 'vue-router'

import useAppStore from '@/stores/app'
import useUserStore from '@/stores/user'
import zhCn from 'element-plus/dist/locale/zh-cn.mjs'
import en from 'element-plus/dist/locale/en.mjs'
import dayjs from 'dayjs'
import { LStorage } from './utils/storage'
import { TIMEOUT } from '@/constant'

const appStore = useAppStore()
const userStore = useUserStore()

// el plus语言包处理
const { language } = storeToRefs(appStore)
const locale = computed(() => {
  switch (language.value) {
    case 'zh':
      return zhCn
    case 'en':
      return en
    default:
      return zhCn
  }
})

//sso 登陆获取参数
const ssoParams = new URLSearchParams(location.search)

if (ssoParams.get('userInfo')) {
  const loginInfo = JSON.parse(ssoParams.get('loginInfo') as string)
  const userInfo = JSON.parse(ssoParams.get('userInfo') as string)
  const appInfo = JSON.parse(ssoParams.get('appInfo') as string)

  const language = ssoParams.get('language') as string
  const localeLanguage = () => {
    switch (language) {
      case 'zh-cn':
        return 'zh'
      case 'en-us':
        return 'en'
      default:
        return 'zh'
    }
  }

  userStore.setUserInfo(userInfo)
  appStore.setLanguage(localeLanguage())
  appStore.setAppInfo(appInfo)

  window.location.href = appStore.appInfo.webUrl
}

if (!userStore.token || dayjs().isAfter(dayjs(LStorage.get(TIMEOUT)))) {
  userStore.logout()
}
</script>

<template>
  <el-config-provider :locale="locale" :button="{ autoInsertSpace: true }">
    <router-view></router-view>
  </el-config-provider>
</template>

<style scoped></style>
