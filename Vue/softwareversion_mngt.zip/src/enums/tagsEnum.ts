export enum RemoveTagsType {
  INDEX = 'index',
  LEFT = 'left',
  RIGHT = 'right',
  OTHER = 'other',
  ALL = 'all'
}
