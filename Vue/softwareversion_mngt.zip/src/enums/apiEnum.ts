export enum ApiSelectParams {
  pageSize = 1000000
}
