// token
export const TOKEN = 'token'

// token过期时间
export const TIMEOUT = 'timeout'

// 用户信息
export const USER_INFO = 'userInfo'

// 应用信息
export const APP_INFO = 'appInfo'

// tags-view
export const TAGS_VIEW = 'tagsView'

// LANG
export const LANG = 'language'

// 新增
export const ADD = 'add'

// 修改
export const UPDATE = 'update'

// excel导出过期时间
export const EXCEL_TIMEOUT = 60 * 60 * 1000

// 是否显示disk警告提示 cookie字段
export const DISK_NOTIFICATION_SHOW = 'diskNotificationShow'

// 看板配置
export const DATASCREEN_CONFIG = {
  /**
   * 看板tooltip与高亮切换速度，单位ms
   */
  interval: 5000
}

// 消息通知分类
export enum MESSAGE_TYPE {
  UNREAD = 'unread',
  READ = 'read',
  ALL = 'all'
}

export const dateShortcuts = [
  {
    text: '近7天',
    value: () => {
      const end = new Date()
      const start = new Date()
      start.setTime(start.getTime() - 3600 * 1000 * 24 * 6)
      return [start, end]
    }
  },
  {
    text: '近15天',
    value: () => {
      const end = new Date()
      const start = new Date()
      start.setTime(start.getTime() - 3600 * 1000 * 24 * 14)
      return [start, end]
    }
  },
  {
    text: '近30天',
    value: () => {
      const end = new Date()
      const start = new Date()
      start.setTime(start.getTime() - 3600 * 1000 * 24 * 29)
      return [start, end]
    }
  }
]
