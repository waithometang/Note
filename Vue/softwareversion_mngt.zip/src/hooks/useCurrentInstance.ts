import { getCurrentInstance, type ComponentInternalInstance } from 'vue'

/**
 * 获取组件实例
 * @returns
 */
export default function useCurrentInstance() {
  if (!getCurrentInstance()) {
    throw new Error(
      'useCurrentInstance() can only be used inside setup() or functional components!'
    )
  }
  const { appContext } = getCurrentInstance() as ComponentInternalInstance
  const proxy = appContext.config.globalProperties
  return {
    proxy
  }
}
