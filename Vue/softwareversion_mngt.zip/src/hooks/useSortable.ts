import { nextTick, unref, type Ref } from 'vue'

import type { Options } from 'sortablejs'

// 创建拖拽元素
export function useSortable(el: HTMLElement | Ref<HTMLElement>, options?: Options) {
  function initSortable() {
    nextTick(async () => {
      if (!el) return
      const Sortable = (await import('sortablejs')).default
      // unref 防止传入ref
      Sortable.create(unref(el), {
        animation: 500,
        delay: 400,
        delayOnTouchOnly: true,
        ...options
      })
    })
  }

  return { initSortable }
}
