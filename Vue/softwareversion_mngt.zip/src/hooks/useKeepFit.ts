import { unref, onUnmounted } from 'vue'
import { storeToRefs } from 'pinia'
import useAppStore from '@/stores/app'
import { debounce } from 'lodash-es'

interface KeepFit {
  dw: number
  dh: number
  el: string
}
export function useKeepFit(options: KeepFit) {
  const { tagFullScreen } = storeToRefs(useAppStore())
  const { dw, dh, el = 'body' } = options
  let scale = 1

  const dom = document.querySelector(el) as HTMLElement
  dom.style.transformOrigin = `0 0`
  dom.style.overflow = 'hidden'

  const handleWindowResize = () => {
    const dom = document.querySelector(el) as HTMLElement
    let clientHeight = 0
    let clientWidth = 0

    if (!unref(tagFullScreen)) {
      const dom = document.querySelector('.app-main') as HTMLElement
      const domRect = dom.getBoundingClientRect()

      clientHeight = domRect.height
      clientWidth = domRect.width
    } else {
      clientHeight = document.documentElement.clientHeight
      clientWidth = document.documentElement.clientWidth
    }

    scale = clientWidth / clientHeight < dw / dh ? clientWidth / dw : clientHeight / dh

    dom.style.height = `${clientHeight / scale}px`
    dom.style.width = `${clientWidth / scale}px`
    dom.style.transform = `scale(${scale})`
  }
  handleWindowResize()

  const resizeDebounced = debounce(handleWindowResize, 50)
  const resizeObserver = new ResizeObserver(resizeDebounced)

  const mainDom = document.querySelector('.app-main') as HTMLElement
  resizeObserver.observe(mainDom)

  onUnmounted(() => {
    resizeObserver.disconnect()
  })
}
