<template>
  <div class="page-container">
    <vxe-grid class="box" ref="gridRef" v-bind="gridOptions">
      <template #top>
        <GridHeader
          ref="gridHeaderRef"
          v-bind="headerOptions"
          @quickSearch="handleQuickSearch"
          @advancedSearch="handleAdvancedSearch"
          @reset="handleReset"
        >
        </GridHeader>
      </template>
    </vxe-grid>
  </div>
</template>

<script setup lang="ts">
import type { ComponentExposed } from 'vue-component-type-helpers'
import type { VxeGridInstance, VxeGridProps } from 'vxe-table'
import type { GridHeaderProps } from '@/components/Table/types/gridHeader'

import { reactive, ref } from 'vue'

import GridHeader from '@/components/Table/GridHeader.vue'
import type { GetInputStoreModel, GetInputStoreParams } from '@/api/sys/model/warehouseMngtModel'
import { getInputStore } from '@/api/sys/warehouseMngt'
import dayjs from 'dayjs'
import { dateShortcuts } from '@/constant'

defineOptions({
  name: 'MaterialIn',
  inheritAttrs: false
})

const gridHeaderRef =
  ref<ComponentExposed<typeof GridHeader<GetInputStoreParams, 'MaterialNoOrOrderNo'>>>()

const headerOptions = reactive<GridHeaderProps>({
  title: '物料入库查询',
  quickSearch: {
    singleSearch: {
      field: 'MaterialNoOrOrderNo',
      type: 'input',
      title: '料号/订单号'
    },
    searchFormFields: { MaterialNoOrOrderNo: '' }
  },
  advancedSearch: {
    labelWidth: 120,
    fieldMapToTime: [['InputTime', ['StartInputTime', 'EndInputTime'], 'YYYY-MM-DD']],
    schemas: [
      {
        field: 'MaterialName',
        component: 'ElInput',
        label: '料品名称',
        componentProps: {},
        colProps: {
          span: 8
        }
      },
      {
        field: 'Storage',
        component: 'ElInput',
        label: '库位',
        componentProps: {},
        colProps: {
          span: 8
        }
      },
      {
        field: 'StoreAddr',
        component: 'ElInput',
        label: '储存地点',
        componentProps: {},
        colProps: {
          span: 8
        }
      },
      {
        field: 'BillType',
        component: 'ElInput',
        label: '单据类型',
        componentProps: {},
        colProps: {
          span: 8
        }
      },
      {
        field: 'InputTime',
        component: 'ElDatePicker',
        label: '收货日期',
        defaultValue: [dayjs().subtract(7, 'day'), dayjs()],
        componentProps: {
          type: 'daterange',
          unlinkPanels: true,
          shortcuts: dateShortcuts,
          valueFormat: 'YYYY-MM-DD'
        },
        colProps: {
          span: 8
        }
      }
    ]
  },
  showAddButton: false
})

const gridRef = ref<VxeGridInstance>()
const gridOptions = reactive<VxeGridProps<GetInputStoreModel>>({
  border: true,
  height: 'auto',
  align: null,
  columnConfig: {
    resizable: true
  },
  columns: [
    { type: 'seq', width: 50 },
    { field: 'materialNo', title: '料号', width: 150 },
    { field: 'orderNo', title: '订单号', minWidth: 150 },
    { field: 'materialName', title: '料品名称', minWidth: 200 },
    { field: 'spec', title: '规格', minWidth: 200 },
    { field: 'brand', title: '厂牌', minWidth: 160 },
    { field: 'storage', title: '库位', minWidth: 150 },
    { field: 'lotNo', title: '批号', minWidth: 150 },
    { field: 'unit', title: '物料单位名称', minWidth: 120 },
    { field: 'supplierName', title: '供应商名称', minWidth: 150 },
    { field: 'inputTime', title: '收货日期', minWidth: 150 },
    { field: 'billType', title: '单据类型', minWidth: 150 },
    { field: 'inputCounts', title: '实到数量', minWidth: 100 },
    { field: 'storeAddr', title: '储存地点', minWidth: 120 },
    { field: 'operatorName', title: '业务员名称', minWidth: 140 },
    { field: 'receiptNo', title: '收货单号', minWidth: 140 },
    { field: 'inputTypeName', title: '收货类型', minWidth: 100 },
    { field: 'comments', title: '备注', minWidth: 140 }
  ],
  pagerConfig: {
    enabled: true,
    pageSize: 20
  },
  proxyConfig: {
    ajax: {
      query: ({ page }) => {
        const quickSearchForm = gridHeaderRef.value?.quickSearchForm
        const advancedSearchForm = gridHeaderRef.value?.advancedSearchForm
        return getInputStore({
          pageIndex: page.currentPage - 1, // 由于后端接口限制，首页从0开始
          pageSize: page.pageSize,
          ...quickSearchForm,
          ...advancedSearchForm
        })
      }
    }
  }
})

const handleQuickSearch = () => {
  gridRef.value?.commitProxy('reload')
}

const handleAdvancedSearch = () => {
  gridRef.value?.commitProxy('reload')
}

const handleReset = () => {
  gridRef.value?.commitProxy('reload')
}
</script>

<style scoped></style>
