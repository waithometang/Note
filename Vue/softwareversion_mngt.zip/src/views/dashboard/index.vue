<template>
  <div class="dashboard-container"></div>
</template>

<script lang="ts" setup>
defineOptions({
  name: 'dashboard',
  inheritAttrs: false
})
</script>

<style lang="scss" scoped>
.dashboard-container {
  width: 100%;
  height: 100%;
  background: url('@/assets/png/dashboard.png') no-repeat;
  background-size: 100% 100%;
}
</style>
