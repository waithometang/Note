<template>
  <LayoutContainer>
    <template #leftSide>
      <basic-list ref="basicListRef" v-bind="listOptions" />
    </template>

    <div class="grid-container">
      <vxe-grid class="box" ref="gridRef" v-bind="gridOptions">
        <template #top>
          <GridHeader
            ref="gridHeaderRef"
            v-bind="headerOptions"
            @quickSearch="handleQuickSearch"
            @advancedSearch="handleAdvancedSearch"
            @reset="handleReset"
          />
        </template>

        <template #orderStatus="{ row }">
          <el-tag :type="getOrderStatusInfo(row.orderStatus).type">
            {{ getOrderStatusInfo(row.orderStatus).text }}
          </el-tag>
        </template>
        <template #operation="{ row }">
          <TableAction
            :actions="[
              {
                tooltip: '确认',
                icon: 'finish-wo-status',
                onClick: handleConfirm.bind(null, row),
                ifShow: () => row.orderStatus === 0
              }
            ]"
          />
        </template>
      </vxe-grid>
    </div>
  </LayoutContainer>
</template>

<script setup lang="ts">
import type { ComponentExposed } from 'vue-component-type-helpers'
import type { VxeGridInstance, VxeGridProps } from 'vxe-table'
import type { GridHeaderProps } from '@/components/Table/types/gridHeader'
import type {
  GetProductionVersionModel,
  GetProductionVersionParams
} from '@/api/sys/model/basicModel'
import type { ComputedRef } from 'vue'
import type { ListProps } from '@/components/List/types'

import { reactive, ref, computed } from 'vue'

import {
  getProductionProject,
  getProductionVersion,
  updateProductionVersionStatus
} from '@/api/sys/basic'

import GridHeader from '@/components/Table/GridHeader.vue'
import TableAction from '@/components/Table/TableAction.vue'
import { dateShortcuts } from '@/constant'
import BasicList from '@/components/List/BasicList.vue'

defineOptions({
  name: 'ProductionVersion',
  inheritAttrs: false
})

// 列表配置
const listOptions = reactive<ListProps>({
  title: '项目列表',
  valueField: 'id',
  labelField: 'projectName',
  isCancelCurrent: true,
  api: getProductionProject,
  resultField: 'data.result',
  onChange({ item }) {
    if (item) {
      gridRef.value?.commitProxy('reload')
    } else {
      gridRef.value?.remove()
    }
  }
})

const basicListRef = ref<ComponentExposed<typeof BasicList>>()

const gridHeaderRef = ref<ComponentExposed<typeof GridHeader<GetProductionVersionParams, 'woNo'>>>()

const headerOptions = reactive<GridHeaderProps>({
  title: '计划版本管理',
  quickSearch: {
    singleSearch: {
      field: 'woNo',
      type: 'input',
      title: '单据编号'
    },
    searchFormFields: { woNo: '' }
  },
  advancedSearch: {
    labelWidth: 120,
    fieldMapToTime: [['createdTime', ['StartTime', 'EndTime'], 'YYYY-MM-DD']],
    schemas: [
      {
        field: 'versionNo',
        component: 'ElInput',
        label: '版本号',
        colProps: {
          span: 8
        }
      },
      {
        field: 'orderStatus',
        component: 'Select',
        label: '状态',
        componentProps: {
          options: [
            {
              label: '待确认',
              value: 0
            },
            {
              label: '已确认',
              value: 1
            },
            {
              label: '已作废',
              value: 2
            }
          ]
        },
        colProps: {
          span: 8
        }
      },
      {
        field: 'createdTime',
        component: 'ElDatePicker',
        label: '日期',
        componentProps: {
          type: 'daterange',
          unlinkPanels: true,
          shortcuts: dateShortcuts,
          valueFormat: 'YYYY-MM-DD'
        },
        colProps: {
          span: 8
        }
      }
    ]
  },
  showAddButton: false
})

const handleQuickSearch = () => {
  gridRef.value?.commitProxy('reload')
}

const handleAdvancedSearch = () => {
  gridRef.value?.commitProxy('reload')
}

const handleReset = () => {
  gridRef.value?.commitProxy('reload')
}

const gridRef = ref<VxeGridInstance>()
const gridOptions = reactive<VxeGridProps<GetProductionVersionModel>>({
  border: true,
  height: 'auto',
  align: null,
  columnConfig: {
    resizable: true
  },
  columns: [
    { type: 'seq', width: 50 },
    { field: 'woNo', title: '单据编号', minWidth: 200 },
    { field: 'productName', title: '部件名称', minWidth: 150 },
    { field: 'processName', title: '设备类型', minWidth: 150 },
    { field: 'versionNo', title: '版本号', minWidth: 100 },
    { field: 'orderStatus', title: '状态', minWidth: 100, slots: { default: 'orderStatus' } },
    { field: 'confirmUserName', title: '确认人', minWidth: 200 },
    { field: 'lastModifiedUserName', title: '操作人', minWidth: 100 },
    { field: 'lastModifiedTime', title: '最后更新时间', minWidth: 150 },
    {
      field: 'operation',
      title: '操作',
      align: 'center',
      fixed: 'right',
      width: 150,
      slots: {
        default: 'operation'
      }
    }
  ],
  pagerConfig: {
    enabled: true,
    pageSize: 10
  },
  proxyConfig: {
    ajax: {
      query: ({ page }) => {
        const quickSearchForm = gridHeaderRef.value?.quickSearchForm || {}
        const advancedSearchForm = gridHeaderRef.value?.advancedSearchForm || {}

        const projectID = basicListRef.value?.getActiveItem?.id
        return getProductionVersion({
          pageIndex: page.currentPage - 1, // 由于后端接口限制，首页从0开始
          pageSize: page.pageSize,
          ...quickSearchForm,
          ...advancedSearchForm,
          projectID
        })
      }
    }
  }
})

interface OrderStatusInfo {
  text: string
  type: string
}

const getOrderStatusInfo: ComputedRef<(status: number) => OrderStatusInfo> = computed(() => {
  const statusMap: { [key: number]: OrderStatusInfo } = {
    0: { text: '未确认', type: 'info' },
    1: { text: '已确认', type: 'success' },
    2: { text: '已作废', type: 'danger' }
  }

  return function (status: number) {
    return statusMap[status] || { text: '', color: '' }
  }
})

const handleConfirm = (row: GetProductionVersionModel) => {
  ElMessageBox.confirm(`是否确认单据编号"${row.woNo}",版本"${row.versionNo}"的数据项`, '警告', {
    confirmButtonText: '确定',
    cancelButtonText: '取消',
    type: 'warning'
  }).then(async () => {
    const updateData = {
      id: row.id,
      orderStatus: 1
    }
    const { data, message } = await updateProductionVersionStatus(updateData)

    if (data) {
      ElMessage.success('确认版本号成功')
    } else {
      ElMessage.error(message)
    }
    gridRef.value?.commitProxy('query')
  })
}
</script>

<style lang="scss" scoped>
.grid-container {
  height: 100%;
  padding: $margin $margin $margin 0;
}
</style>
