<template>
  <LayoutContainer :enableRightSide="false">
    <template #leftSide>
      <basic-tree ref="basicTreeRef" v-bind="treeOptions">
        <template #footer>
          <div style="margin: 0 auto">
            <el-checkbox v-model="showAllProject" label="显示所有项目" />
          </div>
        </template>
      </basic-tree>
    </template>

    <el-scrollbar>
      <div class="grid-container">
        <div class="box vxe-grid-container">
          <vxe-grid ref="gridWorkOrderRef" v-bind="gridWorkOrderOptions" v-on="gridEvents">
            <template #top>
              <GridHeader
                ref="gridHeaderWorkOrderRef"
                v-bind="workOrderHeaderOptions"
                @quickSearch="handleQuickSearch"
                @add="handleAdd"
                @advancedSearch="handleAdvancedSearch"
                @reset="handleReset"
                @importSuccess="handleImportSuccess"
              >
                <template #appendOperation>
                  <el-button size="large" type="primary" @click="handleBatchStart" plain
                    >批量开/完工</el-button
                  >
                </template>
              </GridHeader>
            </template>
            <template #orderSchedule="{ row }">
              <el-progress :stroke-width="12" :percentage="row.orderSchedule" />
            </template>
            <template #orderStatus="{ row }">
              <el-tag :type="getOrderStatusText(row.orderStatus).type">
                {{ getOrderStatusText(row.orderStatus).text }}</el-tag
              >
            </template>

            <template #operation="{ row }">
              <TableAction
                :actions="[
                  {
                    icon: 'edit',
                    tooltip: '编辑',
                    onClick: handleModify.bind(null, row),
                    ifShow: () => row.orderStatus === 0 || row.orderStatus === 1
                  }
                  // {
                  //   icon: 'start-wo-status',
                  //   tooltip: '开工',
                  //   onClick: handleWoStatus.bind(null, row, ChangeOrderStatus.Start),
                  //   ifShow: () => row.orderStatus === 0
                  // },

                  // {
                  //   icon: 'finish-wo-status',
                  //   tooltip: '完工',
                  //   onClick: handleWoStatus.bind(null, row, ChangeOrderStatus.Finish),
                  //   ifShow: () => row.orderStatus === 1
                  // },
                  // {
                  //   icon: 'close-wo-status',
                  //   tooltip: '关单',
                  //   onClick: handleCloseWoStatus.bind(null, row),
                  //   ifShow: () => row.orderStatus === 1
                  // },
                  // {
                  //   icon: 'cancle-wo-status',
                  //   tooltip: '取消',
                  //   onClick: handleWoStatus.bind(null, row, ChangeOrderStatus.Cancle),
                  //   ifShow: () => row.orderStatus === 0
                  // }
                ]"
                :dropDownActions="[
                  {
                    // icon: 'start-wo-status',
                    label: '开工',
                    onClick: handleWoStatus.bind(null, row, ChangeOrderStatus.Start),
                    ifShow: () => row.orderStatus === 0
                  },

                  {
                    // icon: 'finish-wo-status',
                    label: '完工',
                    onClick: handleWoStatus.bind(null, row, ChangeOrderStatus.Finish),
                    ifShow: () => row.orderStatus === 1
                  },
                  {
                    // icon: 'close-wo-status',
                    label: '关单',
                    onClick: handleCloseWoStatus.bind(null, row),
                    ifShow: () => row.orderStatus === 1
                  },
                  {
                    label: '反开工',
                    onClick: handleWoStatus.bind(null, row, ChangeOrderStatus.Unstart),
                    ifShow: () => row.orderStatus === 1
                  },
                  {
                    label: '反完工',
                    onClick: handleWoStatus.bind(null, row, ChangeOrderStatus.Unfinish),
                    ifShow: () => row.orderStatus === 2
                  },
                  {
                    label: '反关闭',
                    onClick: handleWoStatus.bind(null, row, ChangeOrderStatus.Unclose),
                    ifShow: () => row.orderStatus === 3
                  },
                  {
                    // icon: 'cancle-wo-status',
                    label: '取消',
                    onClick: handleWoStatus.bind(null, row, ChangeOrderStatus.Cancle),
                    ifShow: () => row.orderStatus === 0
                  },
                  {
                    // icon: 'copy',
                    label: '复制',
                    onClick: handleCopy.bind(null, row)
                  }
                ]"
              />
            </template>
          </vxe-grid>
        </div>

        <div class="box vxe-grid-container">
          <el-tabs v-model="activeName">
            <el-tab-pane label="生产计划" name="workPlan">
              <vxe-grid ref="gridWorkPlanRef" v-bind="gridWorkPlanOptions">
                <template #productionState="{ row }">
                  {{ formatProductionStateLabelFormat(row.productionState) }}
                </template>
              </vxe-grid>
            </el-tab-pane>

            <el-tab-pane label="工单数量" name="workNumber">
              <vxe-grid ref="workQuantityGridRef" v-bind="gridWorkQuantityOptions" />
            </el-tab-pane>
          </el-tabs>
        </div>
      </div>
    </el-scrollbar>

    <WorkOrderDialog @register="registerModal" @success="handleSuccess" />
    <BatchStartDialog @register="registerBatchStartModal" @success="handleBatchStartSuccess" />
  </LayoutContainer>
</template>

<script lang="tsx" setup>
import type { ComponentExposed } from 'vue-component-type-helpers'
import type { VxeGridInstance, VxeGridListeners, VxeGridProps } from 'vxe-table'
import type {
  GetWorkOrderModel,
  GetProductionPlanByWoModel,
  GetWorkOrderParams
} from '@/api/sys/model/workModel'
import type { GetDictionaryModel } from '@/api/sys/model/basicModel'
import type { GridHeaderProps } from '@/components/Table/types/gridHeader'
import type { TreeProps } from '@/components/Tree/types/tree'
import type { WorkOrderQuantity } from './types'

import { ref, reactive, computed, unref } from 'vue'
import { useModal } from '@/components/Modal/hooks/useModal'
import { useForm } from '@/components/Form/hooks/useForm'
import { isDef } from '@/utils/is'

import BasicTree from '@/components/Tree/BasicTree.vue'
import GridHeader from '@/components/Table/GridHeader.vue'
import TableAction from '@/components/Table/TableAction.vue'
import WorkOrderDialog from './components/WorkOrderDialog.vue'
import BatchStartDialog from './components/BatchStartDialog.vue'

import {
  getKeyValue,
  getProductionVersionSelect,
  getProductionProcessTopLevel,
  getManufactureDepartmentList
} from '@/api/sys/basic'
import {
  exportProductionWo,
  exportTemplate,
  getProductionPlanByWo,
  getProductionWo,
  updateProductionWoState
} from '@/api/sys/work'
import { getProjectAndProductName } from '@/api/sys/scheduling'

defineOptions({
  name: 'WorkOrder',
  inheritAttrs: false
})

enum ChangeOrderStatus {
  Start = 1,
  Finish = 2,
  Close = 3,
  Cancle = 4,
  Unstart = 5,
  Unfinish = 6,
  Unclose = 7
}

const listParams = reactive({
  projectID: '',
  orderProductName: '', // 设备名称
  orderNo: ''
})
const activeTreeNode = ref()

const showAllProject = ref(false)

const basicTreeRef = ref<InstanceType<typeof BasicTree>>()
// 列表配置
const treeOptions = reactive<TreeProps>({
  api: getProjectAndProductName,
  title: '项目列表',
  labelField: 'name',
  resultField: 'data',
  childrenField: 'productList',
  nodeKey: 'id',
  params: computed(() => ({ orderStatus: showAllProject.value ? 3 : 1 })),
  onSelect: async (data) => {
    if (data) {
      activeTreeNode.value = data

      if (data.isProject) {
        listParams.projectID = data.id
        listParams.orderNo = ''
        listParams.orderProductName = ''
        workOrderHeaderOptions.title = `生产工单 - [${data.label}]`
      } else {
        listParams.projectID = data.projectID
        listParams.orderNo = data.orderNo
        listParams.orderProductName = data.label
        workOrderHeaderOptions.title = `生产工单 - [${data.label}]`
      }
      gridWorkPlanRef.value?.remove()
      clearWorkQuantityTableData()

      const { data: options } = await getProductionVersionSelect({
        projectID: listParams.projectID
      })

      gridHeaderWorkOrderRef.value?.updateAdvancedSearchForm({
        field: 'versionID',
        componentProps: {
          options: options
        }
      })
      gridWorkOrderRef.value?.commitProxy('reload')
    } else {
      listParams.projectID = ''
      listParams.orderNo = ''
      listParams.orderProductName = ''
      workOrderHeaderOptions.title = `生产工单`
      gridWorkOrderRef.value?.remove()
      gridWorkPlanRef.value?.remove()
      clearWorkQuantityTableData()
    }
  },
  cancleHightlightCurrent: true
})
// 快查处理
const handleQuickSearch = () => {
  gridWorkOrderRef.value?.commitProxy('reload')
}
// 高级查询处理
const handleAdvancedSearch = () => {
  gridWorkOrderRef.value?.commitProxy('reload')
}
// 重置查询表单处理
const handleReset = () => {
  gridWorkOrderRef.value?.commitProxy('reload')
  gridWorkPlanRef.value?.remove()
}
// 导入成功处理
const handleImportSuccess = () => {
  basicTreeRef.value?.initialFetch()
  gridWorkOrderRef.value?.commitProxy('reload')
  gridWorkPlanRef.value?.remove()
}
const gridHeaderWorkOrderRef =
  ref<ComponentExposed<typeof GridHeader<GetWorkOrderParams, 'woNo'>>>()
const workOrderHeaderOptions = reactive<GridHeaderProps>({
  title: '生产工单',
  quickSearch: {
    singleSearch: {
      field: 'woNo',
      type: 'input',
      title: '单据编号/母件编码'
    },
    searchFormFields: { woNo: '' }
  },
  advancedSearch: {
    labelWidth: 120,
    fieldMapToTime: [
      ['dataOfEntry', ['startDataOfEntry', 'endDataOfEntry'], 'YYYY-MM-DD'],
      ['dateofBirth', ['startDateOfBirth', 'endDateOfBirth'], 'YYYY-MM-DD']
    ],
    schemas: [
      {
        field: 'departmentID',
        component: 'ApiSelect',
        label: '生产部门',
        componentProps: {
          api: getManufactureDepartmentList,
          resultField: 'data',
          labelField: 'name',
          valueField: 'id',
          filterable: true
        },
        colProps: {
          span: 8
        }
      },
      {
        field: 'productName',
        component: 'ElInput',
        label: '部件名称',
        colProps: {
          span: 8
        }
      },
      {
        field: 'processID',
        component: 'ApiSelect',
        label: '设备类型',
        componentProps: {
          api: getProductionProcessTopLevel,
          resultField: 'data.result',
          labelField: 'processType',
          valueField: 'id'
        },
        colProps: {
          span: 8
        }
      },
      {
        field: 'productionAddressID',
        component: 'ApiSelect',
        label: '生产场地',
        componentProps: {
          api: getKeyValue,
          labelField: 'value',
          valueField: 'id',
          resultField: 'data.result',
          params: {
            typeName: 'PositionAddress'
          },
          multiple: true
        },
        colProps: {
          span: 8
        }
      },
      {
        field: 'versionID',
        component: 'Select',
        label: '版本号',
        componentProps: {
          options: [],
          labelField: 'versionNo',
          valueField: 'id'
        },
        colProps: {
          span: 8
        }
      },
      {
        field: 'orderStatus',
        component: 'Select',
        label: '工单状态',
        defaultValue: [0, 1],
        componentProps: {
          options: [
            { label: '未开始', value: 0 },
            { label: '执行中', value: 1 },
            { label: '已完工', value: 2 },
            { label: '已关闭', value: 3 },
            { label: '已取消', value: 4 }
          ],
          multiple: true
        },
        colProps: {
          span: 8
        }
      },
      {
        field: 'isFinishOrderSchedule',
        component: 'Select',
        label: '工单进度',
        componentProps: {
          options: [
            { label: '未完成', value: false },
            { label: '已完成', value: true }
          ]
        },
        colProps: {
          span: 8
        }
      }
    ]
  },
  showExportButton: true,
  exportApi: exportProductionWo,
  exportParams: computed(() => {
    const quickSearchForm = gridHeaderWorkOrderRef.value?.quickSearchForm
    const advancedSearchForm = gridHeaderWorkOrderRef.value?.advancedSearchForm
    return { ...listParams, ...quickSearchForm, ...advancedSearchForm }
  }),
  showImportButton: true,
  exportTemplateApi: exportTemplate,
  importUrl: '/ProductionWo/ImportExcelData'
})
const gridWorkOrderRef = ref<VxeGridInstance>()
const gridWorkOrderOptions = reactive<VxeGridProps<GetWorkOrderModel>>({
  border: true,
  minHeight: '400px',
  maxHeight: '800px',
  align: null,
  columnConfig: {
    resizable: true
  },
  columns: [
    { type: 'seq', width: 50 },
    { field: 'moDocType', title: '业务类型', width: 120 },
    { field: 'projectName', title: '项目名称', width: 150 },
    { field: 'orderNo', title: '需求分类', width: 150 },
    { field: 'woNo', title: '单据编号', width: 200 },
    { field: 'materialNo', title: '母件编码', width: 200 },
    { field: 'productName', title: '部件名称', width: 150 },
    { field: 'productionOrderNumber', title: '订单数量', width: 100 },
    { field: 'departmentName', title: '部门名称', width: 100 },
    // { field: 'productionAddressName', title: '生产场地', width: 100 },
    { field: 'processType', title: '设备类型', width: 130 },
    { field: 'productionNodeName', title: '当前节点', width: 130 },
    { field: 'orderSchedule', title: '工单进度', width: 150, slots: { default: 'orderSchedule' } },
    { field: 'orderStatus', title: '工单状态', width: 100, slots: { default: 'orderStatus' } },
    // { field: 'frameNumber', title: '机架数量', width: 100 },
    // { field: 'locationNumber', title: '库位数量', width: 150 },
    // { field: 'chassisNumber', title: '机箱数量', width: 150 },

    // { field: 'employeeNo', title: '执行 PMC 工号', width: 130 },
    { field: 'priorityLevel', title: '优先级', width: 80 },
    { field: 'employeeName', title: 'PMC', width: 130 },
    { field: 'versionNo', title: '版本号', width: 100 },
    // { field: 'createTime', title: '创建时间', width: 150 },
    { field: 'lastModifiedUserName', title: '操作人', width: 150 },
    { field: 'lastModifiedTime', title: '最后修改时间', width: 150 },
    {
      field: 'operation',
      title: '操作',
      align: 'center',
      fixed: 'right',
      width: 120,
      slots: {
        default: 'operation'
      }
    }
  ],
  pagerConfig: {
    enabled: true
  },
  proxyConfig: {
    autoLoad: false,
    ajax: {
      query: ({ page }) => {
        const quickSearchForm = gridHeaderWorkOrderRef.value?.quickSearchForm
        const advancedSearchForm = gridHeaderWorkOrderRef.value?.advancedSearchForm

        return getProductionWo({
          pageIndex: page.currentPage - 1, // 由于后端接口限制，首页从0开始
          pageSize: page.pageSize,
          ...listParams,
          ...quickSearchForm,
          ...advancedSearchForm
        })
      }
    }
  }
})

const getOrderStatusText = computed((): ((status: number) => { text: string; type: string }) => {
  return function (status: number): { text: string; type: string } {
    switch (status) {
      case 0:
        return {
          text: '未开始',
          type: 'danger'
        }
      case 1:
        return {
          text: '执行中',
          type: ''
        }
      case 2:
        return {
          text: '已完工',
          type: 'success'
        }
      case 3:
        return {
          text: '已关闭',
          type: 'info'
        }
      case 4: {
        return {
          text: '已取消',
          type: 'info'
        }
      }
      default:
        return {
          text: '',
          type: ''
        }
    }
  }
})

const activeName = ref<string>('workPlan')

const gridEvents: VxeGridListeners<GetWorkOrderModel> = {
  cellClick({ row }) {
    workPlanHeaderOptions.title = `生产计划-[工单${row.woNo}]`
    gridWorkPlanRef.value?.commitProxy('reload')
    const { productNumberJson } = row
    const { tableData } = workQuantityGridRef.value?.getTableData() ?? {}

    if (isDef(tableData)) {
      const data = tableData.map((row) => {
        return {
          ...row,
          quantity: productNumberJson[row.field]
        }
      })
      workQuantityGridRef.value?.loadData(data)
    }
  }
}

const gridHeaderWorkPlanRef = ref<ComponentExposed<typeof GridHeader>>()
const workPlanHeaderOptions = reactive<GridHeaderProps>({
  title: '生产计划',
  quickSearch: {
    singleSearch: {
      field: 'woNo',
      type: 'input',
      title: '单据编号'
    },
    searchFormFields: { woNo: '' }
  },
  advancedSearch: {
    labelWidth: 120,
    fieldMapToTime: [
      ['dataOfEntry', ['startDataOfEntry', 'endDataOfEntry'], 'YYYY-MM-DD'],
      ['dateofBirth', ['startDateOfBirth', 'endDateOfBirth'], 'YYYY-MM-DD']
    ],
    schemas: [
      {
        field: 'employeeNo',
        component: 'ElInput',
        label: '员工编号',
        componentProps: {
          style: {
            width: '100%'
          }
        },
        colProps: {
          span: 8
        }
      }
    ]
  },
  showAdvancedSearchButton: false,
  showAddButton: false,
  showQuickSearchButton: false
})
const gridWorkPlanRef = ref<VxeGridInstance>()
const gridWorkPlanOptions = reactive<VxeGridProps<GetProductionPlanByWoModel>>({
  border: true,
  minHeight: '400px',
  maxHeight: '800px',
  align: null,
  columnConfig: {
    resizable: true
  },
  columns: [
    { type: 'seq', width: 50 },
    { field: 'productionNodeName', title: '生产节点' },
    // { field: 'departmentName', title: '部门名称' },
    { field: 'planFinishDate', title: '计划日期' },
    { field: 'productionAddressName', title: '生产场地' },
    {
      field: 'productionState',
      title: '状态',
      slots: { default: 'productionState' }
    },
    { field: 'materialState', title: '物料情况' }
    // { field: 'dataDescribe', title: '备注', width: 150 },
    // { field: 'description', title: '描述', width: 100 },
    // { field: 'createTime', title: '创建时间', width: 150 },
    // { field: 'lastModifiedTime', title: '上一次修改时间', width: 150 }
  ],
  pagerConfig: {
    enabled: false
  },
  proxyConfig: {
    autoLoad: false,
    ajax: {
      query: () => {
        const quickSearchForm = gridHeaderWorkPlanRef.value?.quickSearchForm
        const advancedSearchForm = gridHeaderWorkPlanRef.value?.advancedSearchForm
        const woID = gridWorkOrderRef.value?.getCurrentRecord().id

        return new Promise((resolve, reject) => {
          getProductionPlanByWo({
            woID,
            ...quickSearchForm,
            ...advancedSearchForm
          }).then((res) => {
            resolve(res.data)
          })
        })
      }
    }
  }
})

const productionStateList = ref<GetDictionaryModel[]>()
// 获取生产节点状态列表
const getProductionStateList = async () => {
  const { data } = await getKeyValue({
    typeName: 'ProductionNodeStatus'
  })

  productionStateList.value = data.result
}
getProductionStateList()

// 获取工单数量列表
const getWorkQuantityList = async () => {
  const { data: keyValueData } = await getKeyValue({ typeName: 'DeviceNumberType' })
  const workQuantityData = keyValueData.result.map((row) => {
    row.key = String(row.key)
    // 将字典表的大写转换为接口首字母小写
    const field = row.key.replace(row.key[0], row.key[0].toLowerCase())
    return {
      field: field,
      type: row.value,
      quantity: undefined,
      component: field === 'productionOrderNumber' ? 'inputNumber' : 'input'
    }
  })
  workQuantityGridRef.value?.loadData(workQuantityData)
}
getWorkQuantityList()

// 格式化生产状态显示
const formatProductionStateLabelFormat = (productionState: number) => {
  return unref(productionStateList)?.find((item) => item.key === productionState)?.value
}

const workQuantityGridRef = ref<VxeGridInstance<WorkOrderQuantity>>()
const gridWorkQuantityOptions = reactive<VxeGridProps<WorkOrderQuantity>>({
  border: true,
  height: '300px',
  align: null,
  columnConfig: {
    resizable: true
  },
  columns: [
    { type: 'seq', width: 50 },
    { field: 'field', title: '字段', visible: false },
    { field: 'type', title: '类型' },
    { field: 'quantity', title: '数量' }
  ],
  pagerConfig: {
    enabled: false
  }
})

const clearWorkQuantityTableData = () => {
  const { tableData } = workQuantityGridRef.value?.getTableData() ?? {}

  if (isDef(tableData)) {
    const data = tableData.map((row) => {
      return {
        ...row,
        quantity: undefined
      }
    })
    workQuantityGridRef.value?.loadData(data)
  }
}

const [registerModal, { openModal, setModalProps, closeModal }] = useModal()
// 复制
const handleCopy = (row: GetWorkOrderModel) => {
  openModal(true, {
    isCopy: true,
    row,
    projectID: listParams.projectID
  })
}
// 新增工单
const handleAdd = () => {
  if (!listParams.orderProductName) {
    return ElMessage.warning('请选择项目列表下的设备后再点击新增!')
  }
  openModal(true, {
    isUpdate: false,
    projectID: listParams.projectID,
    orderProductName: listParams.orderProductName,
    orderNo: listParams.orderNo
  })
}

const [
  registerBatchStartModal,
  { openModal: openBatchStartModal, closeModal: closeBatchStartModal }
] = useModal()
// 批量开/完工
const handleBatchStart = () => {
  openBatchStartModal(true, {
    projectID: listParams.projectID,
    orderNo: listParams.orderNo,
    orderProductName: listParams.orderProductName
  })
}
// 修改工单
const handleModify = (row: GetWorkOrderModel) => {
  openModal(true, {
    isUpdate: true,
    row,
    projectID: listParams.projectID
  })
}
// 处理更改工单状态
const handleWoStatus = async (row: GetWorkOrderModel, orderStatus: number) => {
  let operationText: string = ''
  switch (orderStatus) {
    case ChangeOrderStatus.Start:
      operationText = `是否确认开工名称为"${row.woNo}"的数据项?`
      break
    case ChangeOrderStatus.Finish:
      operationText = `是否确认完工名称为"${row.woNo}"的数据项?`
      break
    case ChangeOrderStatus.Close:
      operationText = `是否确认关单名称为"${row.woNo}"的数据项?`
      break
    case ChangeOrderStatus.Cancle:
      operationText = `是否确认取消名称为"${row.woNo}"的数据项?`
      break
    case ChangeOrderStatus.Unstart:
      operationText = `是否将单据编号"${row.woNo}"设置未开工状态?`
      break
    case ChangeOrderStatus.Unclose || ChangeOrderStatus.Unfinish:
      operationText = `是否将单据编号"${row.woNo}"设置执行状态?`
      break
    default:
      break
  }

  ElMessageBox.confirm(operationText, '提示', {
    confirmButtonText: '确定',
    cancelButtonText: '取消',
    type: 'info'
  })
    .then(async () => {
      const { status, message } = await updateProductionWoState({
        id: row.id,
        orderStatus
      })

      if (status) {
        ElMessage.success('修改工单状态成功')
        gridWorkOrderRef.value?.commitProxy('query')
      } else {
        // if (orderStatus === ChangeOrderStatus.Finish) {

        // ElMessageBox.confirm(`${row.woNo}工序未完成不能执行操作！`, '警告', {
        //     confirmButtonText: '关闭',
        //     showCancelButton: false,
        //     type: 'warning'
        //   })
        // } else {
        //   ElMessage.error(message)
        // }
        ElMessageBox.confirm(message, '警告', {
          confirmButtonText: '关闭',
          showCancelButton: false,
          type: 'warning'
        })
      }
    })
    .catch(() => {})
}

// 关单填写信息
const [registerForm, { getFieldsValue, validate }] = useForm({
  labelWidth: 100,
  schemas: [
    {
      field: 'closeWoReason',
      component: 'ElInput',
      label: '关闭原因',
      required: true,
      componentProps: {
        type: 'textarea'
      },
      colProps: {
        span: 23
      }
    }
  ]
})
// 处理关单操作
const handleCloseWoStatus = (row: GetWorkOrderModel) => {
  ElMessageBox({
    title: '关闭工单',
    showCancelButton: true,
    message: () => {
      return <basic-form onRegister={registerForm} />
    },
    beforeClose: async (action, instance, done) => {
      if (action === 'confirm') {
        await validate(async (isValid) => {
          const fieldsValue = getFieldsValue()

          if (isValid) {
            const loading = ElLoading.service({
              lock: true,
              text: 'Loading',
              background: 'rgba(0, 0, 0, 0.7)'
            })
            try {
              const { status, message } = await updateProductionWoState({
                id: row.id,
                orderStatus: ChangeOrderStatus.Close,
                ...fieldsValue
              })

              if (status) {
                ElMessage.success('关单成功')
                gridWorkOrderRef.value?.commitProxy('query')
              } else {
                ElMessageBox.confirm(message, '警告', {
                  confirmButtonText: '关闭',
                  showCancelButton: false,
                  type: 'warning'
                })
              }
              done()
            } catch (e: any) {
              ElMessage.error(e.message)
            } finally {
              loading.close()
            }
          }
        })
      }

      if (action === 'cancel') {
        done()
      }
    }
  })
}

const handleSuccess = () => {
  closeModal()
  gridWorkOrderRef.value?.commitProxy('query')
  gridWorkPlanRef.value?.remove()
  clearWorkQuantityTableData()
}
const handleBatchStartSuccess = () => {
  gridWorkOrderRef.value?.commitProxy('query')
  gridWorkPlanRef.value?.remove()
  clearWorkQuantityTableData()
}
</script>

<style lang="scss" scoped>
.basic-list-container {
  display: flex;
  overflow: hidden;
}
.grid-container {
  padding: $margin $margin $margin 0;
  .vxe-grid-container:first-child {
    margin-bottom: $margin;
  }
}
</style>
