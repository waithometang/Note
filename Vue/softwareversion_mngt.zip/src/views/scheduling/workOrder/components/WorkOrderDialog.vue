<template>
  <BasicModal
    width="70%"
    v-bind="$attrs"
    @register="registerModal"
    :title="getTitle"
    :showCancelBtn="false"
    :showConfirmBtn="false"
    top="5vh"
  >
    <BasicForm @register="registerForm" />

    <el-tabs v-model="activeName">
      <el-tab-pane label="生产节点" name="productionPlans">
        <vxe-grid ref="workPlanGridRef" v-bind="gridWorkPlanOptions">
          <template #productionNodeID="{ row }">
            {{ formatProductionNodeLabelFormat(row.productionNodeID) }}
          </template>
          <template #productionNodeID_edit="{ row }">
            <Select
              v-model="row.productionNodeID"
              :options="productionNodeList"
              labelField="productionNodeName"
              valueField="id"
            />
          </template>

          <template #planFinishDate="{ row }">
            {{ row.planFinishDate && $dayjs(row.planFinishDate).format('YYYY-MM-DD') }}
          </template>
          <template #planFinishDate_edit="{ row }">
            <el-date-picker v-model="row.planFinishDate" type="date" value-format="YYYY-MM-DD" />
          </template>

          <template #productionState="{ row }">
            {{ formatProductionStateLabelFormat(row.productionState) }}
          </template>
          <template #productionState_edit="{ row }">
            <Select
              v-model="row.productionState"
              :options="productionStateList"
              labelField="value"
              valueField="key"
            />
          </template>
          <template #materialState_edit="scope">
            <el-input v-model="scope.row.materialState" @input="updateRowStatus(scope)"></el-input>
          </template>

          <template #bottom>
            <TableAction
              style="margin-top: 16px"
              :actions="[
                {
                  icon: 'plus',
                  label: '添加节点',
                  onClick: handleAddNode.bind(null),
                  style: {
                    color: '#008cd6'
                  }
                }
              ]"
            ></TableAction>
          </template>

          <template #operation="{ row, rowIndex }">
            <TableAction
              :actions="[
                {
                  icon: 'move-up',
                  tooltip: '上移',
                  onClick: handleMoveUp.bind(null, row, rowIndex)
                },
                {
                  icon: 'move-down',
                  tooltip: '下移',
                  onClick: handleMoveDown.bind(null, row, rowIndex)
                },
                {
                  icon: 'edit-inline',
                  tooltip: '编辑',
                  onClick: handleModify.bind(null, row, workPlanGridRef),
                  ifShow: !hasActiveEditRow(row, workPlanGridRef)
                },
                {
                  icon: 'delete-inline',
                  tooltip: '删除',
                  onClick: handleDelete.bind(null, row, rowIndex),
                  ifShow: !hasActiveEditRow(row, workPlanGridRef)
                },
                {
                  icon: 'cancle',
                  tooltip: '取消',
                  onClick: handleCancle.bind(null, row, workPlanGridRef),
                  ifShow: hasActiveEditRow(row, workPlanGridRef)
                },
                {
                  icon: 'save',
                  tooltip: '保存',
                  onClick: handleConfirm.bind(null, workPlanGridRef),
                  ifShow: hasActiveEditRow(row, workPlanGridRef)
                }
              ]"
            ></TableAction>
          </template>
        </vxe-grid>
      </el-tab-pane>

      <el-tab-pane label="工单数量" name="workNumber">
        <vxe-grid ref="workQuantityGridRef" v-bind="gridWorkQuantityOptions">
          <template #quantity_edit="scope">
            <el-input
              v-if="scope.row.component === 'input'"
              v-model="scope.row.quantity"
              @change="updateQuantityRowStatus(scope)"
            />
            <el-input-number
              v-else-if="scope.row.component === 'inputNumber'"
              v-model="scope.row.quantity"
              :min="0"
              :max="9999"
              :tep="1"
              :stepStrictly="true"
              @change="updateQuantityRowStatus(scope)"
            />
          </template>

          <template #operation="{ row }">
            <TableAction
              :actions="[
                {
                  icon: 'edit-inline',
                  tooltip: '编辑',
                  onClick: handleModify.bind(null, row, workQuantityGridRef),
                  ifShow: !hasActiveEditRow(row, workQuantityGridRef)
                },
                {
                  icon: 'cancle',
                  tooltip: '取消',
                  onClick: handleCancle.bind(null, row, workQuantityGridRef),
                  ifShow: hasActiveEditRow(row, workQuantityGridRef)
                },
                {
                  icon: 'save',
                  tooltip: '保存',
                  onClick: handleConfirm.bind(null, workQuantityGridRef),
                  ifShow: hasActiveEditRow(row, workQuantityGridRef)
                }
              ]"
            ></TableAction>
          </template>
        </vxe-grid>
      </el-tab-pane>
      <!-- <el-tab-pane label="BOM明细" name="bom"
        >
      </el-tab-pane> -->
    </el-tabs>

    <template #appendFooter>
      <div class="footer-container">
        <el-button @click="closeModal" size="large">取消</el-button>
        <el-button v-if="isUpdate" type="primary" @click="handleSaveNewVersion" size="large"
          >保存新版本</el-button
        >
        <el-button type="primary" @click="handleSave" size="large">保存</el-button>
      </div>
    </template>
  </BasicModal>
</template>

<script lang="tsx" setup>
import type { VxeGridInstance, VxeGridProps } from 'vxe-table'
import type { GetProductionPlanByWoModel, ProductNumberJson } from '@/api/sys/model/workModel'
import type { ModalMethods } from '@/components/Modal/types'
import type { RenderCallbackParams } from '@/components/Form/types/form'
import type { GetDictionaryModel, GetProductionNodeModel } from '@/api/sys/model/basicModel'
import type { GetWorkOrderModel } from '@/api/sys/model/workModel'

import { computed, ref, unref, reactive } from 'vue'
import { cloneDeep } from 'lodash-es'

import BasicModal from '@/components/Modal/BasicModal.vue'
import BasicForm from '@/components/Form/BasicForm.vue'
import Select from '@/components/Form/components/Select.vue'

import { useModalInner } from '@/components/Modal/hooks/useModal'
import { useForm } from '@/components/Form/hooks/useForm'

import {
  getManufactureDepartmentList,
  getKeyValue,
  getKeyValueByClassify,
  getProductionNodeAll,
  getProductionProcessTopLevel
} from '@/api/sys/basic'
import {
  addProductionWo,
  getMODocType,
  getProductionPlanByWo,
  updateProductionWo
} from '@/api/sys/work'
import type { WorkOrderQuantity } from '../types'
import { isDef, isNumber } from '@/utils/is'

const emit = defineEmits<{
  register: [modalMethods: ModalMethods, uuid: number]
  success: [{ isUpdate: boolean }]
}>()
const isUpdate = ref<boolean>(false)
const isCopy = ref<boolean>(false)
const rowId = ref('')
const projectID = ref('')
const orderProductName = ref('')
const orderNo = ref('')

const activeName = ref('productionPlans')

const getTitle = computed(() =>
  unref(orderProductName) ? `【${unref(orderProductName)}】基本信息` : '基本信息'
)

const [registerModal, { closeModal, setModalProps }] = useModalInner(async (data) => {
  resetFields()
  setModalProps({ confirmLoading: false })
  activeName.value = 'productionPlans'
  // 数据初始化
  orderProductName.value = ''
  orderNo.value = ''
  workPlanGridRef.value?.remove()
  // 清空工单数量表格中的数量列
  clearWorkQuantityTableData()

  isUpdate.value = !!data?.isUpdate
  isCopy.value = !!data?.isCopy
  projectID.value = data.projectID || data.row.projectID
  // 获取所有生产节点
  const { data: productionNodeAll } = await getProductionNodeAll()
  productionNodeList.value = productionNodeAll

  const { data: keyValueData } = await getKeyValue({ typeName: 'DeviceNumberType' })
  const workQuantityData = keyValueData.result.map((row) => {
    row.key = String(row.key)

    const field = row.key.replace(row.key[0], row.key[0].toLowerCase())
    return {
      field: field,
      type: row.value,
      quantity: undefined,
      component: field === 'productionOrderNumber' ? 'inputNumber' : 'input'
    }
  })
  workQuantityGridRef.value?.loadData(workQuantityData)

  // 修改
  if (unref(isUpdate)) {
    rowId.value = data.row.id

    const { data: ProductionPlanData } = await getProductionPlanByWo({
      woID: unref(rowId)
    })

    const productionPlans = cloneDeep(ProductionPlanData)

    workPlanGridRef.value?.loadData(productionPlans)

    const { productNumberJson } = data.row as GetWorkOrderModel
    const { tableData } = workQuantityGridRef.value?.getTableData() ?? {}

    if (isDef(tableData)) {
      const data = tableData.map((row) => {
        return {
          ...row,
          quantity: productNumberJson[row.field]
        }
      })
      workQuantityGridRef.value?.loadData(data)
    }

    setFieldsValue({
      ...data.row
    })
  } else if (!unref(isUpdate) && !unref(isCopy)) {
    // 新增
    orderProductName.value = data.orderProductName
    orderNo.value = data.orderNo

    setFieldsValue({
      orderProductName: unref(orderProductName),
      orderNo: unref(orderNo)
    })

    const tableData = productionNodeAll.map((row) => ({
      productionNodeID: row.id,
      productionState: undefined,
      ...row
    }))

    workPlanGridRef.value?.loadData(tableData)
  } else if (unref(isCopy)) {
    // 复制
    rowId.value = data.row.id

    const { data: ProductionPlanData } = await getProductionPlanByWo({
      woID: unref(rowId)
    })

    const productionPlans = cloneDeep(ProductionPlanData)

    workPlanGridRef.value?.loadData(productionPlans)

    const { productNumberJson } = data.row as GetWorkOrderModel
    const { tableData } = workQuantityGridRef.value?.getTableData() ?? {}

    if (isDef(tableData)) {
      const data = tableData.map((row) => {
        return {
          ...row,
          quantity: productNumberJson[row.field]
        }
      })
      workQuantityGridRef.value?.loadData(data)
    }

    const formData = cloneDeep(data.row) as GetWorkOrderModel
    formData.woNo = formData.woNo + '-复制'
    formData.versionNo = ''

    setFieldsValue({
      ...formData
    })
  }
})

const [registerForm, { setFieldsValue, resetFields, getFieldsValue, validate }] = useForm({
  labelWidth: 120,
  schemas: [
    {
      field: 'moDocType',
      label: '业务类型',
      component: 'ApiSelect',
      defaultValue: '标准生产',
      dynamicDisabled() {
        return !!isUpdate.value
      },
      componentProps: {
        api: getMODocType,
        resultField: 'data',
        labelField: 'name',
        valueField: 'name'
      },
      colProps: {
        span: 8
      }
    },
    {
      field: 'orderNo',
      label: '需求分类',
      component: 'ElInput',
      componentProps: {
        disabled: true
      },
      colProps: {
        span: 8
      }
    },
    {
      field: 'orderProductName',
      label: '设备名称',
      component: 'ElInput',
      componentProps: {
        disabled: true
      },
      colProps: {
        span: 8
      }
    },
    {
      field: 'woNo',
      component: 'ElInput',
      label: '单据编号',
      dynamicDisabled: () => unref(isUpdate),
      componentProps: {},
      rules: [{ required: true, trigger: 'blur' }],
      colProps: {
        span: 8
      }
    },
    {
      field: 'materialNo',
      label: '母件编码',
      component: 'ElInput',
      componentProps: {},
      colProps: {
        span: 8
      }
    },
    {
      field: 'productName',
      label: '部件名称',
      required: true,
      component: 'ElInput',
      componentProps: {},
      colProps: {
        span: 8
      }
    },
    // {
    //   field: 'processID',
    //   component: 'ApiSelect',
    //   label: '设备类型',
    //   required: true,
    //   componentProps: {
    //     api: getProductionProcessTopLevel,
    //     resultField: 'data',
    //     labelField: 'processType',
    //     valueField: 'id'
    //   },
    //   colProps: {
    //     span: 8
    //   }
    // },
    {
      field: 'processID',
      component: 'ApiSelect',
      label: '设备类型',
      required: true,
      componentProps: {
        api: getProductionProcessTopLevel,
        resultField: 'data.result',
        labelField: 'processType',
        valueField: 'id'
      },
      colProps: {
        span: 8
      }
    },
    // {
    //   field: 'productionOrderNumber',
    //   component: 'ElInputNumber',
    //   label: '订单数量',
    //   required: true,
    //   defaultValue: 1,
    //   componentProps: {
    //     min: 1,
    //     max: 9999,
    //     step: 1,
    //     stepStrictly: true
    //   },
    //   colProps: {
    //     span: 8
    //   }
    // },

    // {
    //   field: 'frameNumber',
    //   component: 'ElInput',
    //   label: '机架数量',
    //   colProps: {
    //     span: 8
    //   }
    // },

    // {
    //   field: 'locationNumber',
    //   component: 'ElInput',
    //   label: '库位数量',
    //   colProps: {
    //     span: 8
    //   }
    // },
    // {
    //   field: 'chassisNumber',
    //   component: 'ElInput',
    //   label: '机箱数量',
    //   colProps: {
    //     span: 8
    //   }
    // },

    {
      field: 'departmentID',
      component: 'ApiSelect',
      label: '生产部门',
      required: true,
      componentProps: {
        api: getManufactureDepartmentList,
        resultField: 'data',
        labelField: 'name',
        valueField: 'id',
        filterable: true,
        props: {
          checkStrictly: true,
          emitPath: false
        }
      },
      colProps: {
        span: 8
      }
    },

    {
      field: 'productionAddressID',
      component: 'ApiSelect',
      label: '生产场地',
      required: true,
      componentProps: {
        api: getKeyValueByClassify,
        resultField: 'data',
        labelField: 'value',
        valueField: 'id',
        params: {
          typeName: 'PositionAddress'
        }
      },
      colProps: {
        span: 8
      }
    },
    {
      field: 'employeeID',
      component: 'PersonSelect',
      label: 'PMC',
      required: true,
      componentProps: {},
      colProps: {
        span: 8
      }
    },
    {
      field: 'priorityLevel',
      component: 'ElInputNumber',
      label: '优先级',
      required: true,
      defaultValue: 1,
      componentProps: {
        min: 1,
        max: 99,
        step: 1,
        stepStrictly: true
      },
      colProps: {
        span: 8
      }
    },
    {
      field: 'orderStatus',
      component: 'Select',
      label: '工单状态',
      dynamicDisabled: () => unref(isUpdate),
      rules: [{ required: true, trigger: 'change' }],
      defaultValue: 0,
      componentProps: {
        options: [
          { label: '未开始', value: 0 },
          { label: '执行中', value: 1 },
          { label: '已完工', value: 2 },
          { label: '已关闭', value: 3 },
          { label: '已取消', value: 4 }
        ]
      },
      colProps: {
        span: 8
      }
    },
    {
      field: 'versionNo',
      component: 'ElInput',
      label: '版本号',
      componentProps: { disabled: true },
      colProps: {
        span: 8
      }
    },
    {
      field: 'dataDescribe',
      label: '备注',
      component: 'ElInput',
      componentProps: {
        type: 'textarea'
      },
      colProps: {
        span: 16
      }
    }
  ]
})

const workPlanGridRef = ref<VxeGridInstance>()
const gridWorkPlanOptions = reactive<VxeGridProps<GetProductionPlanByWoModel>>({
  border: true,
  height: '350px',
  align: null,
  columnConfig: {
    resizable: true
  },
  keepSource: true,
  editConfig: {
    trigger: 'dblclick',
    mode: 'row',
    showStatus: true,
    autoClear: false,
    showUpdateStatus: true,
    showInsertStatus: true
  },
  editRules: {
    productionNodeID: [{ required: true, message: '请选择生产节点' }],
    planFinishDate: [{ required: true, message: '请选择计划日期' }],
    productionState: [{ required: true, message: '请选择生产节点状态' }]
  },
  columns: [
    { type: 'seq', width: 50 },
    {
      field: 'productionNodeID',
      title: '生产节点',
      editRender: {},
      slots: { default: 'productionNodeID', edit: 'productionNodeID_edit' }
    },
    // { field: 'sortNo', title: '排序号' },
    {
      field: 'planFinishDate',
      title: '计划日期',
      editRender: {},
      slots: { default: 'planFinishDate', edit: 'planFinishDate_edit' }
    },
    {
      field: 'productionState',
      title: '生产节点状态',
      editRender: {},
      slots: { default: 'productionState', edit: 'productionState_edit' }
    },
    {
      field: 'materialState',
      title: '物料情况',
      editRender: {},
      slots: { edit: 'materialState_edit' }
    },
    {
      field: 'operation',
      title: '操作',
      align: 'center',
      fixed: 'right',
      width: 150,
      slots: {
        default: 'operation'
      }
    }
  ],
  pagerConfig: {
    enabled: false,
    pageSize: 100
  },
  proxyConfig: {
    enabled: false
  }
})

const productionNodeList = ref<GetProductionNodeModel[]>([])

// 格式化生产节点显示
const formatProductionNodeLabelFormat = (productionNodeID: string) => {
  return productionNodeList.value.find((item) => item.id === productionNodeID)?.productionNodeName
}

const productionStateList = ref<GetDictionaryModel[]>()

const getProductionStateList = async () => {
  const { data } = await getKeyValue({
    typeName: 'ProductionNodeStatus'
  })

  productionStateList.value = data.result
}
getProductionStateList()

// 格式化生产状态显示
const formatProductionStateLabelFormat = (productionState: string) => {
  return unref(productionStateList)?.find((item) => item.key === productionState)?.value
}
// 判断是否编辑活跃行
const hasActiveEditRow = (row: GetProductionPlanByWoModel, $grid?: VxeGridInstance): boolean => {
  // const $grid = workPlanGridRef.value
  if ($grid) {
    return $grid.isEditByRow(row)
  }
  return false
}

// 更新行状态
const updateRowStatus = (params: any) => {
  const $grid = workPlanGridRef.value
  if ($grid) {
    return $grid.updateStatus(params)
  }
}

const handleAddNode = async () => {
  const $grid = workPlanGridRef.value
  if ($grid) {
    const { row: newRow } = await $grid.insertAt(
      {
        productionNodeID: '',
        planFinishDate: '',
        productionStateID: '',
        materialState: ''
      },
      -1
    )

    await $grid.setEditRow(newRow)
  }
}
// 上移
const handleMoveUp = (row: GetProductionPlanByWoModel, rowIndex: number) => {
  if (rowIndex === 0) {
    return
  }
  const lastRowIndex = rowIndex - 1
  const lastRowData = workPlanGridRef.value?.getData(lastRowIndex)
  const { tableData } = workPlanGridRef.value!.getTableData()
  tableData[lastRowIndex] = row
  tableData[rowIndex] = lastRowData
  workPlanGridRef.value?.loadData(tableData)
  ElMessage.success('上移数据成功')
}
// 下移
const handleMoveDown = (row: GetProductionPlanByWoModel, rowIndex: number) => {
  const { tableData } = workPlanGridRef.value!.getTableData()

  if (rowIndex === tableData.length - 1) {
    return
  }
  const nextRowIndex = rowIndex + 1
  const nextRowData = workPlanGridRef.value?.getData(nextRowIndex)

  tableData[nextRowIndex] = row
  tableData[rowIndex] = nextRowData
  workPlanGridRef.value?.loadData(tableData)
  ElMessage.success('下移数据成功')
}

// 修改
const handleModify = async (row: GetProductionPlanByWoModel, $grid?: VxeGridInstance) => {
  // const $grid = workPlanGridRef.value
  if ($grid) {
    const editRecord = $grid.getEditRecord()
    if (editRecord) {
      const { row } = editRecord
      await $grid.revertData(row)
    }

    $grid.setEditRow(row)
  }
}

// 删除
const handleDelete = (row: GetProductionPlanByWoModel, rowIndex: number) => {
  ElMessageBox.confirm(`是否删除序号为"${rowIndex + 1}"的数据项?`, '警告', {
    confirmButtonText: '确定',
    cancelButtonText: '取消',
    type: 'warning'
  })
    .then(async () => {
      workPlanGridRef.value?.remove(row)
    })
    .catch(() => {})
}

// 取消
const handleCancle = (row: GetProductionPlanByWoModel, $grid?: VxeGridInstance) => {
  // const $grid = workPlanGridRef.value
  if ($grid) {
    $grid.clearEdit().then(() => {
      // 还原行数据
      $grid.revertData(row)
    })
  }
}

const handleConfirm = async ($grid?: VxeGridInstance) => {
  // const $grid = workPlanGridRef.value
  if ($grid) {
    await $grid.clearEdit()
  }
}

const workQuantityGridRef = ref<VxeGridInstance<WorkOrderQuantity>>()
const gridWorkQuantityOptions = reactive<VxeGridProps<WorkOrderQuantity>>({
  border: true,
  height: '300px',
  align: null,
  keepSource: true,
  editConfig: {
    trigger: 'dblclick',
    mode: 'row',
    showStatus: true,
    autoClear: false,
    showUpdateStatus: true
  },
  editRules: {
    quantity: [
      {
        required: true,
        validator({ row, cellValue }) {
          if (row.field === 'productionOrderNumber') {
            if (cellValue === '' || cellValue === null || cellValue === undefined) {
              return Promise.reject(new Error('请输入订单数量'))
            } else if (isNumber(cellValue) && cellValue <= 0) {
              return Promise.reject(new Error('订单数量必须大于0'))
            }
          }
        }
      }
    ]
  },
  columnConfig: {
    resizable: true
  },
  columns: [
    { type: 'seq', width: 50 },
    { field: 'field', title: '字段', visible: false },
    { field: 'type', title: '类型' },
    {
      field: 'quantity',
      title: '数量',
      editRender: {},
      slots: {
        edit: 'quantity_edit'
        // default(scope) {
        //   if (scope.row.component === 'input') {
        //     return <el-input v-model={scope.row.quantity} />
        //   } else if (scope.row.component === 'inputNumber') {
        //     return (
        //       <el-input-number
        //         v-model={scope.row.quantity}
        //         min={0}
        //         max={9999}
        //         step={1}
        //         stepStrictly={true}
        //       />
        //     )
        //   }
        // }
      }
    },
    {
      field: 'operation',
      title: '操作',
      align: 'center',
      fixed: 'right',
      width: 150,
      slots: {
        default: 'operation'
      }
    }
  ],
  pagerConfig: {
    enabled: false
  }
  // data: [...cloneDeep(defaultWorkQuantityData)]
})

// 更新行状态
const updateQuantityRowStatus = (params: any) => {
  const $grid = workQuantityGridRef.value
  if ($grid) {
    return $grid.updateStatus(params)
  }
}

// 清空工单数量表格
const clearWorkQuantityTableData = () => {
  const { tableData } = workQuantityGridRef.value?.getTableData() ?? {}

  if (isDef(tableData)) {
    const data = tableData.map((row) => {
      return {
        ...row,
        quantity: undefined
      }
    })
    workQuantityGridRef.value?.loadData(data)
  }
}

// 保存新版本
const handleSaveNewVersion = () => {
  try {
    validate(async (isValid) => {
      if (isValid) {
        ElMessageBox.confirm('创建新版本后需要在计划版本模块里确认,是否继续？', '警告', {
          confirmButtonText: '确定',
          cancelButtonText: '取消',
          type: 'warning'
        }).then(async () => {
          const $grid = workPlanGridRef.value

          const errMap = await $grid?.validate(true)
          const workQuantityErrMap = await workQuantityGridRef.value?.validate()

          if (!errMap && !workQuantityErrMap && $grid) {
            const data = getFieldsValue() as GetWorkOrderModel
            const { tableData: productionPlans } = $grid.getTableData()
            const { tableData: workQuantityData } = workQuantityGridRef.value?.getTableData() ?? {}
            const productNumberJson = workQuantityData?.reduce(
              (acc, item) => {
                acc[item.field] = item.quantity
                return acc
              },
              {} as Record<keyof ProductNumberJson, any>
            )
            const addData = {
              ...data,
              productionPlans,
              productNumberJson,
              projectID: unref(projectID),
              isEdit: true
            }

            const { code, message } = await addProductionWo(addData)
            if (code === 200) {
              ElMessage.success('保存为新版本成功')
              emit('success', { isUpdate: false })
            } else {
              ElMessage.error(message)
            }
          } else {
            ElMessage.error('表格数据校验未通过,请检查')
          }
        })
      }
    })
  } catch (e: any) {
    console.log(e.message)
    ElMessage(e.message)
  }
}

// 保存
const handleSave = () => {
  try {
    validate(async (isValid) => {
      if (isValid) {
        const $grid = workPlanGridRef.value

        const errMap = await $grid?.validate(true)
        const workQuantityErrMap = await workQuantityGridRef.value?.validate()

        if (!errMap && !workQuantityErrMap && $grid) {
          await $grid.clearEdit()
          await workQuantityGridRef.value?.clearEdit()
          // 新增
          if (!unref(isUpdate) && !unref(isCopy)) {
            const data = getFieldsValue() as GetWorkOrderModel
            const { tableData: productionPlans } = $grid.getTableData()
            const { tableData: workQuantityData } = workQuantityGridRef.value?.getTableData() ?? {}
            const productNumberJson = workQuantityData?.reduce(
              (acc, item) => {
                acc[item.field] = item.quantity
                return acc
              },
              {} as Record<keyof ProductNumberJson, any>
            )

            const addData = {
              ...data,
              productionPlans,
              productNumberJson,
              projectID: unref(projectID),
              isEdit: false
            }

            const { code, message } = await addProductionWo(addData)
            if (code === 200) {
              ElMessage.success('新增成功')
              emit('success', { isUpdate: unref(isUpdate) })
            } else {
              ElMessage.error(message)
            }
          } else if (unref(isUpdate) && !unref(isCopy)) {
            const data = getFieldsValue() as Omit<GetWorkOrderModel, 'id'>
            const { tableData: productionPlans } = $grid.getTableData()
            const { tableData: workQuantityData } = workQuantityGridRef.value?.getTableData() ?? {}
            const productNumberJson = workQuantityData?.reduce(
              (acc, item) => {
                acc[item.field] = item.quantity
                return acc
              },
              {} as Record<keyof ProductNumberJson, any>
            )

            const updateData = {
              id: unref(rowId),
              ...data,
              productionPlans,
              productNumberJson,
              projectID: unref(projectID)
            }

            const { code, message } = await updateProductionWo(updateData)

            if (code === 200) {
              ElMessage.success('修改成功')
              emit('success', { isUpdate: unref(isUpdate) })
            } else {
              ElMessage.error(message)
            }
          } else if (unref(isCopy)) {
            const data = getFieldsValue() as GetWorkOrderModel
            const { tableData: productionPlans } = $grid.getTableData()
            const { tableData: workQuantityData } = workQuantityGridRef.value?.getTableData() ?? {}
            const productNumberJson = workQuantityData?.reduce(
              (acc, item) => {
                acc[item.field] = item.quantity
                return acc
              },
              {} as Record<keyof ProductNumberJson, any>
            )
            const addData = {
              ...data,
              productionPlans,
              productNumberJson,
              projectID: unref(projectID),
              isEdit: false
            }

            const { code, message } = await addProductionWo(addData)
            if (code === 200) {
              ElMessage.success('复制成功')
              emit('success', { isUpdate: unref(isUpdate) })
            } else {
              ElMessage.error(message)
            }
          }
        } else {
          ElMessage.error('表格数据校验未通过,请检查')
        }
      }
    })
  } catch (e: any) {
    console.log(e.message)
    ElMessage(e.message)
  }
}
</script>

<style lang="scss" scoped>
.footer-container {
  display: flex;
  justify-content: center;
}
</style>
