<template>
  <BasicModal
    width="70%"
    v-bind="$attrs"
    @register="registerModal"
    title="批量开工"
    :showCancelBtn="false"
    :showConfirmBtn="false"
    top="5vh"
  >
    <BasicForm @register="registerForm">
      <template #formFooter>
        <el-button style="margin-left: 8px" type="priamry" @click="handleSearch">查询</el-button>
      </template>
    </BasicForm>
    <vxe-grid ref="gridRef" v-bind="gridOptions"></vxe-grid>

    <template #appendFooter>
      <div class="footer-container">
        <el-button type="primary" @click="handleStart" size="large">开工</el-button>
        <el-button type="primary" @click="handleCompletion" size="large">完工</el-button>
      </div>
    </template>
  </BasicModal>
</template>

<script lang="tsx" setup>
import type { ModalMethods } from '@/components/Modal/types'
import type { VxeGridInstance, VxeGridProps } from 'vxe-table'
import type { GetWorkOrderModel, WoList } from '@/api/sys/model/workModel'
import type { GetProductionOrderByProjectIDModel } from '@/api/sys/model/schedulingModel'

import { ref, reactive, unref } from 'vue'
import { useModalInner } from '@/components/Modal/hooks/useModal'
import {
  getProductionWoListByStartStatus,
  getProductionWoByOrderNo,
  updateProductionWoStateMore
} from '@/api/sys/work'
import BasicForm from '@/components/Form/BasicForm.vue'
import { useForm } from '@/components/Form/hooks/useForm'
import { getDepartment, getGroupSelect, getProductionProjectSelect } from '@/api/sys/basic'
import { getProductionOrderByProjectID } from '@/api/sys/scheduling'
import type { SelectModel } from '@/api/model/baseModel'

const emit = defineEmits<{
  register: [modalMethods: ModalMethods, uuid: number]
  success: []
}>()
// const params = reactive({
//   orderNo: '',
//   projectID: ''
// })

const [registerModal, { closeModal, setModalProps }] = useModalInner(async (data) => {
  // params.orderNo = data.orderNo
  // params.projectID = data.projectID
  // setFieldsValue({ ...params })
  // const { data: resultData } = await getProductionWoByOrderNo(params)
  // updateSchema({
  //   field: 'woNo',
  //   componentProps: {
  //     options: resultData.woList
  //   }
  // })
  // updateSchema({
  //   field: 'productName',
  //   componentProps: {
  //     options: resultData.productNameList
  //   }
  // })
  // await setFieldsValue({
  //   productName: data.orderProductName
  // })
  // gridRef.value?.commitProxy('reload')
})

interface QueryData {
  projectID: string
  orderNo: string
  woNo: string
  orderStatus: number
}
const [registerForm, { setFieldsValue, resetFields, getFieldsValue, validate, updateSchema }] =
  useForm({
    labelWidth: 80,
    schemas: [
      {
        field: 'projectID',
        component: 'ApiSelect',
        label: '项目',
        componentProps({ formModel }) {
          return {
            api: getProductionProjectSelect,
            resultField: 'data.result',
            labelField: 'projectName',
            valueField: 'id',
            filterable: true,
            async onChange(value: string) {
              formModel.orderNo = undefined
              formModel.woNo = undefined
              let options: GetProductionOrderByProjectIDModel[] = []
              if (value) {
                const { data } = await getProductionOrderByProjectID({
                  ProjectID: value
                })

                options = data
              }

              updateSchema({
                field: 'orderNo',
                componentProps({ formModel }) {
                  return {
                    options: options,
                    labelField: 'orderNo',
                    valueField: 'orderNo',
                    filterable: true,
                    async onChange(value: string) {
                      formModel.woNo = undefined
                      let options: WoList[] = []
                      if (value) {
                        console.log(value)

                        const { data } = await getProductionWoByOrderNo({
                          orderNo: value,
                          projectID: formModel.projectID
                        })
                        options = data.woList
                      }

                      updateSchema({
                        field: 'woNo',
                        componentProps: {
                          options: options
                        }
                      })
                    }
                  }
                }
              })

              updateSchema({
                field: 'woNo',
                componentProps: {
                  options: []
                }
              })
            }
          }
        },
        colProps: {
          span: 5
        }
      },
      {
        field: 'orderNo',
        component: 'Select',
        label: '需求分类',
        componentProps({ formModel }) {
          return {
            options: [],
            labelField: 'orderNo',
            valueField: 'orderNo',
            filterable: true,
            async onChange(value: string) {
              formModel.woNo = undefined
              let options: WoList[] = []
              if (value) {
                const { data } = await getProductionWoByOrderNo({
                  orderNo: value,
                  projectID: formModel.projectID
                })
                options = data.woList
              }

              updateSchema({
                field: 'woNo',
                componentProps: {
                  options: options
                }
              })
            }
          }
        },
        colProps: {
          span: 5
        }
      },
      {
        field: 'woNo',
        component: 'Select',
        label: '单据编号',
        componentProps: {
          options: [],
          labelField: 'name',
          valueField: 'value',
          filterable: true
        },
        colProps: {
          span: 5
        }
      },
      {
        field: 'orderStatus',
        component: 'Select',
        label: '工单状态',
        defaultValue: 0,
        componentProps: {
          options: [
            { label: '待开工', value: 0 },
            { label: '待完工', value: 1 }
          ]
        },
        colProps: {
          span: 5
        }
      },
      {
        field: 'departmentID',
        component: 'ApiCascader',
        label: '部门',
        componentProps: ({ formModel, formActionType }) => {
          return {
            api: getDepartment,
            resultField: 'data.result',
            labelField: 'departmentName',
            valueField: 'id',
            childrenField: 'sonData',
            props: {
              checkStrictly: true,
              emitPath: false
            },
            async onChange(value: string) {
              let groupList: SelectModel[] = []
              formModel.groupID = undefined
              if (value) {
                const { data } = await getGroupSelect({ departmentID: value })

                groupList = data.result
              }

              const { updateSchema } = formActionType

              updateSchema({
                field: 'groupID',
                componentProps: {
                  options: groupList
                }
              })
            }
          }
        },
        colProps: {
          span: 5
        }
      },
      {
        field: 'groupID',
        component: 'Select',
        label: '班组',
        componentProps: {
          options: []
        },
        colProps: {
          span: 5
        }
      }
      // {
      //   field: 'productName',
      //   component: 'Select',
      //   label: '部件名称',
      //   componentProps: {
      //     options: [],
      //     labelField: 'name',
      //     valueField: 'value',
      //     filterable: true
      //   },
      //   colProps: {
      //     span: 6
      //   }
      // }
    ]
  })

const gridRef = ref<VxeGridInstance<GetWorkOrderModel>>()
const gridOptions = reactive<VxeGridProps<GetWorkOrderModel>>({
  border: true,
  height: '400px',
  align: null,
  checkboxConfig: {
    trigger: 'row'
  },
  columnConfig: {
    resizable: true
  },
  columns: [
    { type: 'checkbox', width: 50 },
    { type: 'seq', width: 50 },
    { field: 'moDocType', title: '业务类型', width: 120 },
    { field: 'projectName', title: '项目名称', width: 150 },
    { field: 'orderNo', title: '需求分类', width: 200 },
    { field: 'woNo', title: '单据编号', width: 200 },
    { field: 'materialNo', title: '母件编码', width: 200 },
    { field: 'productName', title: '部件名称', width: 150 },
    { field: 'departmentName', title: '生产部门', width: 100 },
    { field: 'processType', title: '设备类型', width: 130 },
    { field: 'productionNodeName', title: '当前节点', width: 130 },
    // {
    //   field: 'orderSchedule',
    //   title: '工单进度',
    //   width: 150,
    //   slots: {
    //     default({ row }) {
    //       return <el-progress stroke-width={12} percentage={row.orderSchedule} />
    //     }
    //   }
    // },
    { field: 'productionOrderNumber', title: '订单数量', width: 100 },
    { field: 'frameNumber', title: '机架数量', width: 100 },
    { field: 'locationNumber', title: '库位数量', width: 150 },
    { field: 'chassisNumber', title: '机箱数量', width: 150 },
    {
      field: 'orderStatus',
      title: '工单状态',
      width: 100,
      slots: {
        default({ row }) {
          return (
            <el-tag type={getOrderStatusText(row.orderStatus).type}>
              {getOrderStatusText(row.orderStatus).text}
            </el-tag>
          )
        }
      }
    },
    { field: 'employeeName', title: 'PMC', width: 130 }
  ],
  pagerConfig: {
    enabled: false
  },
  proxyConfig: {
    autoLoad: false,
    ajax: {
      query: () => {
        const queryData = getFieldsValue() as QueryData
        return new Promise((resolve, reject) => {
          getProductionWoListByStartStatus({
            ...queryData
          })
            .then(({ data }) => {
              resolve(data)
            })
            .catch((e) => {
              reject(e)
            })
        })
      }
    }
  }
})

function getOrderStatusText(status?: number): { text: string; type: string } {
  switch (status) {
    case 0:
      return {
        text: '未开始',
        type: 'danger'
      }
    case 1:
      return {
        text: '执行中',
        type: ''
      }
    case 2:
      return {
        text: '已完工',
        type: 'success'
      }
    case 3:
      return {
        text: '已关闭',
        type: 'info'
      }
    default:
      return {
        text: '',
        type: ''
      }
  }
}
const currentOrderStatus = ref<number>()
const handleSearch = () => {
  currentOrderStatus.value = getFieldsValue().orderStatus
  gridRef.value?.commitProxy('reload')
}
// 批量开工
const handleStart = async () => {
  if (unref(currentOrderStatus) !== 0) {
    return ElMessage.warning('请先查询待开工数据!')
  }
  const selectRecords = gridRef.value?.getCheckboxRecords()
  const selectRecordsLength = selectRecords?.length

  if (!selectRecordsLength) {
    return ElMessage.warning('未选择任何单据!')
  }
  ElMessageBox.confirm(`选择${selectRecordsLength}条单据，是否确认开工?`, '提示', {
    confirmButtonText: '确定',
    cancelButtonText: '取消',
    type: 'info'
  }).then(async () => {
    const data = selectRecords?.map((row) => ({
      id: row.id,
      orderStatus: 1
    }))

    try {
      await updateProductionWoStateMore({ updateProductionWoStateModel: data })
      ElMessage.success(`成功批量开工${data?.length}条工单!`)
      gridRef.value?.commitProxy('reload')
      emit('success')
    } catch (error: any) {
      ElMessage.error(error.message)
    }
  })
}
// 批量完工
const handleCompletion = async () => {
  if (unref(currentOrderStatus) !== 1) {
    return ElMessage.warning('请先查询待完工数据!')
  }
  const selectRecords = gridRef.value?.getCheckboxRecords()
  const selectRecordsLength = selectRecords?.length
  if (!selectRecordsLength) {
    return ElMessage.warning('未选择任何单据!')
  }

  ElMessageBox.confirm(`选择${selectRecordsLength}条单据，是否确认完工?`, '提示', {
    confirmButtonText: '确定',
    cancelButtonText: '取消',
    type: 'info'
  }).then(async () => {
    const data = selectRecords?.map((row) => ({
      id: row.id,
      orderStatus: 2
    }))

    try {
      await updateProductionWoStateMore({ updateProductionWoStateModel: data })
      ElMessage.success(`成功批量完工${data?.length}条工单!`)
      gridRef.value?.commitProxy('reload')
      emit('success')
    } catch (error: any) {
      ElMessage.error(error.message)
    }
  })
}
</script>

<style lang="scss" scoped>
.query-container {
  display: flex;
}
</style>
