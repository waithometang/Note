import type { ProductNumberJson } from '@/api/sys/model/workModel'

export interface WorkOrderQuantity {
  field: keyof ProductNumberJson
  type: string
  quantity?: string | number
  component?: string
}
