import type { WorkOrderQuantity } from './types'

export const defaultWorkQuantityData: WorkOrderQuantity[] = [
  {
    field: 'productionOrderNumber',
    type: '订单数量',
    quantity: undefined,
    component: 'inputNumber'
  },
  {
    field: 'chassisNumber',
    type: '机箱数量',
    quantity: undefined,
    component: 'input'
  },
  {
    field: 'frameNumber',
    type: '机架数量',
    quantity: undefined,
    component: 'input'
  },
  {
    field: 'locationNumber',
    type: '库位数量',
    quantity: undefined,
    component: 'input'
  },
  {
    field: 'wireNumber',
    type: '线材数量',
    quantity: undefined,
    component: 'input'
  }
]
