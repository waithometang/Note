<template>
  <el-scrollbar>
    <div class="page-container">
      <div class="grid-container box">
        <vxe-grid ref="gridRef" v-bind="gridOptions" v-on="gridEvents">
          <template #top>
            <GridHeader
              ref="gridHeaderRef"
              v-bind="headerOptions"
              @quickSearch="handleQuickSearch"
              @advancedSearch="handleAdvancedSearch"
              @reset="handleReset"
              @add="handleAdd"
            />
          </template>
          <template #operation="{ row }">
            <TableAction
              :actions="[
                {
                  icon: 'edit',
                  tooltip: '编辑',
                  onClick: handleModify.bind(null, row)
                },
                {
                  icon: 'delete',
                  tooltip: '删除',
                  onClick: handleDelete.bind(null, row)
                }
              ]"
            />
          </template>
        </vxe-grid>
      </div>
      <div class="grid-container box">
        <vxe-grid ref="gridOrderRef" v-bind="gridOrderOptions">
          <template #top>
            <GridHeader
              ref="gridOrderHeaderRef"
              v-bind="orderHeaderOptions"
              @quickSearch="handleOrderQuickSearch"
              @add="handleOrderAdd"
            />
          </template>
          <template #operation="{ row }">
            <TableAction
              :actions="[
                {
                  icon: 'edit',
                  tooltip: '编辑',
                  onClick: handleOrderModify.bind(null, row)
                },
                {
                  icon: 'delete',
                  tooltip: '删除',
                  onClick: handleOrderDelete.bind(null, row)
                }
              ]"
            />
          </template>
        </vxe-grid>
      </div>
    </div>
  </el-scrollbar>

  <PMDialog @register="registerModal" @success="handleSuccess" />
  <OrderDialog @register="registerOrderModal" @success="handleOrderSuccess" />
</template>

<script setup lang="ts">
import type { ComponentExposed } from 'vue-component-type-helpers'
import type { VxeGridInstance, VxeGridListeners, VxeGridProps } from 'vxe-table'
import type { GridHeaderProps } from '@/components/Table/types/gridHeader'
import type {
  GetProductionProjectModel,
  GetProductionProjectParams
} from '@/api/sys/model/basicModel'
import type {
  GetProductionOrderModel,
  GetProductionOrderParams
} from '@/api/sys/model/schedulingModel'

import { reactive, ref, computed } from 'vue'
import { deleteProductionProject, getProductionProject } from '@/api/sys/basic'
import {
  getProductionOrder,
  deleteProductionOrder,
  exportProductionProject,
  exportTemplate
} from '@/api/sys/scheduling'

import { useModal } from '@/components/Modal/hooks/useModal'

import GridHeader from '@/components/Table/GridHeader.vue'
import PMDialog from './components/PMDialog.vue'
import OrderDialog from './components/OrderDialog.vue'

defineOptions({
  name: 'PM',
  inheritAttrs: false
})

const gridHeaderRef =
  ref<ComponentExposed<typeof GridHeader<GetProductionProjectParams, 'projectName'>>>()

const headerOptions = reactive<GridHeaderProps>({
  title: '项目信息',
  quickSearch: {
    singleSearch: {
      field: 'projectName',
      type: 'input',
      title: '项目名称'
    },
    searchFormFields: { projectName: '' }
  },
  advancedSearch: {
    labelWidth: 120,
    schemas: [
      {
        field: 'orderStatus',
        label: '状态',
        component: 'Select',
        componentProps: {
          options: [
            { label: '启用', value: 1 },
            { label: '停用', value: 2 }
          ]
        },
        colProps: {
          span: 8
        }
      }
    ]
  },
  showExportButton: true,
  exportApi: exportProductionProject,
  exportParams: computed(() => {
    const advancedSearchForm = gridHeaderRef.value?.advancedSearchForm
    const quickSearchForm = gridHeaderRef.value?.quickSearchForm
    return { ...quickSearchForm, ...advancedSearchForm }
  })
})

const gridRef = ref<VxeGridInstance>()
const gridOptions = reactive<VxeGridProps<GetProductionProjectModel>>({
  border: true,
  height: '400px',
  align: null,
  columnConfig: {
    resizable: true
  },
  columns: [
    { type: 'seq', width: 50 },
    { field: 'projectName', title: '项目名称' },
    { field: 'dataDescribe', title: '项目描述' },
    {
      field: 'orderStatus',
      title: '状态',
      formatter({ cellValue }) {
        //项目状态（1：启用；2：停用；3：全部），默认传3或不传
        const type: any = {
          '1': '启用',
          '2': '停用',
          '3': '全部'
        }
        return type[String(cellValue)]
      }
    },
    { field: 'lastModifiedUserName', title: '操作人' },
    { field: 'lastModifiedTime', title: '最后更新时间' },
    {
      field: 'operation',
      title: '操作',
      align: 'center',
      fixed: 'right',
      width: 150,
      slots: {
        default: 'operation'
      }
    }
  ],
  pagerConfig: {
    enabled: true,
    pageSize: 20
  },
  proxyConfig: {
    ajax: {
      query: ({ page }) => {
        const quickSearchForm = gridHeaderRef.value?.quickSearchForm
        const advancedSearchForm = gridHeaderRef.value?.advancedSearchForm
        // 重置下表
        // orderHeaderOptions.title = `订单信息`
        // gridOrderRef.value?.loadData([])
        return getProductionProject({
          pageIndex: page.currentPage - 1, // 由于后端接口限制，首页从0开始
          pageSize: page.pageSize,
          ...quickSearchForm,
          ...advancedSearchForm
        })
      }
    }
  }
})

const handleQuickSearch = () => {
  gridRef.value?.commitProxy('reload')
}

const handleAdvancedSearch = () => {
  gridRef.value?.commitProxy('reload')
}

const handleReset = () => {
  gridRef.value?.commitProxy('reload')
}

const [registerModal, { openModal, closeModal }] = useModal()

const handleAdd = () => {
  openModal(true, {
    isUpdate: false
  })
}

const handleModify = (row: GetProductionProjectModel) => {
  openModal(true, {
    isUpdate: true,
    row
  })
}

const handleDelete = (row: GetProductionProjectModel) => {
  ElMessageBox.confirm(`是否删除名称为"${row.projectName}"的数据项`, '警告', {
    confirmButtonText: '确定',
    cancelButtonText: '取消',
    type: 'warning'
  }).then(() => {
    deleteProductionProject({ id: row.id }).then((res) => {
      if (res.code === 200) {
        ElMessage.success('删除')
        gridRef.value?.commitProxy('query')
      } else {
        ElMessage.error(res.message)
      }
    })
  })
}

const handleSuccess = () => {
  gridRef.value?.commitProxy('query')
  closeModal()
}

const gridEvents: VxeGridListeners<GetProductionProjectModel> = {
  cellClick({ row }) {
    projectID.value = row.id
    orderHeaderOptions.title = `订单信息 - [${row.projectName}]`
    gridOrderRef.value?.commitProxy('reload')
  }
}

const projectID = ref<string>('')

const gridOrderHeaderRef =
  ref<ComponentExposed<typeof GridHeader<GetProductionOrderParams, 'SearchKey'>>>()

const orderHeaderOptions = reactive<GridHeaderProps>({
  title: '订单信息',
  quickSearch: {
    singleSearch: {
      field: 'SearchKey',
      type: 'input',
      title: '需求分类/设备名称'
    },
    searchFormFields: { SearchKey: '' }
  },
  showAdvancedSearchButton: false,
  showImportButton: true,
  exportTemplateApi: exportTemplate,
  importUrl: '/ProductionProject/ImportExcelData'
})

const gridOrderRef = ref<VxeGridInstance>()
const gridOrderOptions = reactive<VxeGridProps<GetProductionOrderModel>>({
  border: true,
  height: '400px',
  align: null,
  columnConfig: {
    resizable: true
  },
  columns: [
    { type: 'seq', width: 50 },
    { field: 'orderNo', title: '需求分类' },
    { field: 'productName', title: '设备名称', minWidth: 150 },
    { field: 'orderNumber', title: '套数' },
    {
      field: 'orderStatus',
      title: '状态',
      formatter({ cellValue }) {
        //项目状态（1：启用；2：停用；3：全部），默认传3或不传
        const type: any = {
          '1': '启用',
          '2': '停用',
          '3': '全部'
        }
        return type[String(cellValue)]
      }
    },
    { field: 'lastModifiedUserName', title: '操作人' },
    { field: 'lastModifiedTime', title: '最后更新时间' },
    {
      field: 'operation',
      title: '操作',
      align: 'center',
      fixed: 'right',
      width: 150,
      slots: {
        default: 'operation'
      }
    }
  ],
  pagerConfig: {
    enabled: true,
    pageSize: 20
  },
  proxyConfig: {
    autoLoad: false,
    ajax: {
      query: ({ page }) => {
        const quickSearchForm = gridOrderHeaderRef.value?.quickSearchForm
        return getProductionOrder({
          pageIndex: page.currentPage - 1, // 由于后端接口限制，首页从0开始
          pageSize: page.pageSize,
          ...quickSearchForm,
          ProjectID: projectID.value
        })
      }
    }
  }
})

const handleOrderQuickSearch = () => {
  gridOrderRef.value?.commitProxy('reload')
}

const [registerOrderModal, { openModal: openOrderModal, closeModal: closeOrderModal }] = useModal()

const handleOrderAdd = () => {
  if (!projectID.value) {
    ElMessage.warning('请选择项目')
    return
  }
  openOrderModal(true, {
    isUpdate: false,
    projectID: projectID.value
  })
}

const handleOrderModify = (row: GetProductionOrderModel) => {
  openOrderModal(true, {
    isUpdate: true,
    row,
    projectID: projectID.value
  })
}

const handleOrderDelete = (row: GetProductionOrderModel) => {
  ElMessageBox.confirm(`是否删除名称为"${row.orderNo}"的数据项`, '警告', {
    confirmButtonText: '确定',
    cancelButtonText: '取消',
    type: 'warning'
  }).then(() => {
    deleteProductionOrder({ id: row.id }).then((res) => {
      if (res.code === 200) {
        ElMessage.success('删除成功')
        gridOrderRef.value?.commitProxy('query')
      } else {
        ElMessage.error(res.message)
      }
    })
  })
}

const handleOrderSuccess = () => {
  gridOrderRef.value?.commitProxy('query')
  closeOrderModal()
}
</script>

<style scoped lang="scss">
.page-container {
  display: flex;
  flex-direction: column;
  gap: $margin;
}
</style>
