<template>
  <BasicModal
    width="556px"
    v-bind="$attrs"
    @register="registerModal"
    :title="getTitle"
    destroy-on-close
    @confirm="handleSubmit"
  >
    <BasicForm @register="registerForm"> </BasicForm>
  </BasicModal>
</template>

<script setup lang="ts">
import type { ModalMethods } from '@/components/Modal/types'

import { ref, unref, computed } from 'vue'

import BasicModal from '@/components/Modal/BasicModal.vue'
import BasicForm from '@/components/Form/BasicForm.vue'

import { useModalInner } from '@/components/Modal/hooks/useModal'
import { useForm } from '@/components/Form/hooks/useForm'
import { getProductionProjectSelect } from '@/api/sys/basic'
import { addProductionOrder, updateProductionOrder } from '@/api/sys/scheduling'
import type {
  AddProductionOrderData,
  UpdateProductionOrderData
} from '@/api/sys/model/schedulingModel'

const emit = defineEmits<{
  register: [modalMethods: ModalMethods, uuid: number]
  success: [{ isUpdate: boolean }]
}>()
const isUpdate = ref<boolean>(false)

const rowId = ref<string>('')

const getTitle = computed(() => (!unref(isUpdate) ? '新增' : '修改'))

const [registerForm, { setFieldsValue, resetFields, getFieldsValue, validate }] = useForm({
  labelWidth: 86,
  schemas: [
    {
      field: 'projectID',
      component: 'ApiSelect',
      label: '项目名称',
      componentProps: {
        api: getProductionProjectSelect,
        resultField: 'data.result',
        labelField: 'projectName',
        valueField: 'id',
        disabled: true,
        params: { orderStatus: 3 }
      },
      colProps: { span: 16 }
    },
    {
      field: 'orderNo',
      component: 'ElInput',
      label: '需求分类',
      rules: [{ required: true, trigger: 'change' }],
      componentProps: {},
      colProps: { span: 24 }
    },
    {
      field: 'productName',
      component: 'ElInput',
      label: '设备名称',
      rules: [{ required: true, trigger: 'change' }],
      colProps: { span: 24 }
    },
    {
      field: 'orderNumber',
      component: 'ElInputNumber',
      label: '套数',
      defaultValue: 1,
      rules: [{ required: true, trigger: 'blur' }],
      componentProps: {
        min: 1,
        max: 9999,
        step: 1,
        stepStrictly: true
      },
      colProps: { span: 12 }
    },
    {
      field: 'orderStatus',
      component: 'ElSwitch',
      label: '状态',
      defaultValue: true,
      rules: [{ required: true, trigger: 'change' }]
      //   colProps: { span: 12 }
    }
  ]
})

const [registerModal, { setModalProps }] = useModalInner(async (data) => {
  resetFields()
  setModalProps({ confirmLoading: false })
  isUpdate.value = !!data?.isUpdate
  setFieldsValue({ projectID: data.projectID })
  if (unref(isUpdate)) {
    rowId.value = data.row.id
    setFieldsValue({ ...data.row, orderStatus: data.row.orderStatus === 1 ? true : false })
  }
})

// 提交
const handleSubmit = async () => {
  await validate()
  setModalProps({ confirmLoading: true })
  try {
    // 新增
    if (!unref(isUpdate)) {
      const formData = getFieldsValue() as AddProductionOrderData

      const data = {
        ...formData,
        orderStatus: formData.orderStatus ? 1 : 2
      }
      const { code, message } = await addProductionOrder(data)
      if (code === 200) {
        ElMessage.success('新增成功')
        emit('success', { isUpdate: unref(isUpdate) })
      } else {
        ElMessage.error(message)
      }
    } else {
      const formData = getFieldsValue() as Omit<UpdateProductionOrderData, 'id'>
      const data = {
        id: unref(rowId),
        ...formData,
        orderStatus: formData.orderStatus ? 1 : 2
      }
      const { code, message } = await updateProductionOrder(data)

      if (code === 200) {
        ElMessage.success('修改成功')
        emit('success', { isUpdate: unref(isUpdate) })
      } else {
        ElMessage.error(message)
      }
    }
  } catch (error: any) {
    ElMessage(error.message)
  } finally {
    setModalProps({ confirmLoading: false })
  }
}
</script>
<style lang="scss" scoped></style>
