<template>
  <BasicModal
    width="556px"
    v-bind="$attrs"
    @register="registerModal"
    :title="getTitle"
    @confirm="handleSubmit"
  >
    <BasicForm @register="registerForm"> </BasicForm>
  </BasicModal>
</template>

<script setup lang="ts">
import type {
  AddProductionProjectData,
  UpdateProductionProjectData
} from '@/api/sys/model/basicModel'
import type { ModalMethods } from '@/components/Modal/types'

import { ref, unref, computed } from 'vue'

import BasicModal from '@/components/Modal/BasicModal.vue'
import BasicForm from '@/components/Form/BasicForm.vue'

import { useModalInner } from '@/components/Modal/hooks/useModal'
import { useForm } from '@/components/Form/hooks/useForm'
import { addProductionProject, updateProductionProject } from '@/api/sys/basic'

const emit = defineEmits<{
  register: [modalMethods: ModalMethods, uuid: number]
  success: [{ isUpdate: boolean }]
}>()
const isUpdate = ref<boolean>(false)

const rowId = ref<string>('')

const getTitle = computed(() => (!unref(isUpdate) ? '新增' : '修改'))

const [registerForm, { setFieldsValue, resetFields, getFieldsValue, validate }] = useForm({
  labelWidth: 86,
  schemas: [
    {
      field: 'projectName',
      component: 'ElInput',
      rules: [{ required: true, trigger: 'blur' }],
      label: '项目名称'
    },
    {
      field: 'dataDescribe',
      component: 'ElInput',
      label: '项目描述',
      componentProps: {
        type: 'textarea'
      }
    },
    {
      field: 'orderStatus',
      component: 'ElSwitch',
      label: '状态',
      defaultValue: true,
      rules: [{ required: true, trigger: 'change' }]
    }
  ]
})

const [registerModal, { setModalProps }] = useModalInner(async (data) => {
  resetFields()
  setModalProps({ confirmLoading: false })
  isUpdate.value = !!data?.isUpdate

  if (unref(isUpdate)) {
    rowId.value = data.row.id
    setFieldsValue({ ...data.row, orderStatus: data.row.orderStatus === 1 ? true : false })
  }
})

// 提交
const handleSubmit = async () => {
  await validate()
  setModalProps({ confirmLoading: true })
  try {
    // 新增
    if (!unref(isUpdate)) {
      const formData = getFieldsValue() as AddProductionProjectData

      const data = {
        ...formData,
        orderStatus: formData.orderStatus ? 1 : 2
      }
      const { code, message } = await addProductionProject(data)
      if (code === 200) {
        ElMessage.success('新增成功')
        emit('success', { isUpdate: unref(isUpdate) })
      } else {
        ElMessage.error(message)
      }
    } else {
      const formData = getFieldsValue() as Omit<UpdateProductionProjectData, 'id'>
      const data = {
        id: unref(rowId),
        ...formData,
        orderStatus: formData.orderStatus ? 1 : 2
      }
      const { code, message } = await updateProductionProject(data)

      if (code === 200) {
        ElMessage.success('修改成功')
        emit('success', { isUpdate: unref(isUpdate) })
      } else {
        ElMessage.error(message)
      }
    }
  } catch (error: any) {
    ElMessage(error.message)
  } finally {
    setModalProps({ confirmLoading: false })
  }
}
</script>
<style lang="scss" scoped></style>
