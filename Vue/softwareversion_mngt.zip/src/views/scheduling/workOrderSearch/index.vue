<template>
  <LayoutContainer>
    <template #leftSide>
      <basic-tree class="basic-list-wrapper" ref="basicTreeRef" v-bind="treeOptions" />
    </template>

    <el-scrollbar>
      <div class="grid-container">
        <div class="box vxe-grid-container">
          <vxe-grid ref="gridWorkOrderRef" v-bind="gridWorkOrderOptions" v-on="gridEvents">
            <template #top>
              <GridHeader
                ref="gridHeaderWorkOrderRef"
                v-bind="workOrderHeaderOptions"
                v-on="workOrderHeaderEvents"
              />
            </template>
            <template #orderSchedule="{ row }">
              <el-progress :stroke-width="12" :percentage="row.orderSchedule" />
            </template>
            <template #orderStatus="{ row }">
              <el-tag :type="getOrderStatusText(row.orderStatus).type">
                {{ getOrderStatusText(row.orderStatus).text }}</el-tag
              >
            </template>

            <template #operation="{ row }">
              <TableAction
                :actions="[
                  {
                    icon: 'view',
                    tooltip: '查看',
                    onClick: handleView.bind(null, row)
                  }
                ]"
              />
            </template>
          </vxe-grid>
        </div>

        <div class="box vxe-grid-container">
          <el-tabs v-model="activeName">
            <el-tab-pane label="生产计划" name="workPlan">
              <vxe-grid ref="gridWorkPlanRef" v-bind="gridWorkPlanOptions">
                <template #productionState="{ row }">
                  {{ formatProductionStateLabelFormat(row.productionState) }}
                </template>
              </vxe-grid>
            </el-tab-pane>

            <el-tab-pane label="工单数量" name="workNumber">
              <vxe-grid ref="workQuantityGridRef" v-bind="gridWorkQuantityOptions" />
            </el-tab-pane>
          </el-tabs>
        </div>
      </div>
    </el-scrollbar>
    <WorkOrderDialog @register="registerModal" />
  </LayoutContainer>
</template>

<script lang="tsx" setup>
import type { ComponentExposed } from 'vue-component-type-helpers'
import type {
  GetProductionPlanByWoModel,
  GetWorkOrderModel,
  GetWorkOrderParams
} from '@/api/sys/model/workModel'
import type { TreeProps } from '@/components/Tree/types/tree'
import type { GridHeaderProps } from '@/components/Table/types/gridHeader'
import type { VxeGridInstance, VxeGridListeners, VxeGridProps } from 'vxe-table'
import type { GetDictionaryModel } from '@/api/sys/model/basicModel'
import type { SelectModel } from '@/api/model/baseModel'
import type { WorkOrderQuantity } from '../workOrder/types'

import { ref, reactive, computed, unref } from 'vue'
import { isDef } from '@/utils/is'
import { useModal } from '@/components/Modal/hooks/useModal'

import BasicTree from '@/components/Tree/BasicTree.vue'
import GridHeader from '@/components/Table/GridHeader.vue'
import WorkOrderDialog from './components/WorkOrderDialog.vue'

import {
  getKeyValue,
  getManufactureDepartment,
  getManufactureDepartmentList,
  getProductionProcessTopLevel,
  getGroupSelect,
  getProductionProjectSelect
} from '@/api/sys/basic'
import {
  exportProductionWo,
  exportTemplate,
  getProductionPlanByWo,
  getProductionWo
} from '@/api/sys/work'
import { getProductionWoAndProduct } from '@/api/sys/scheduling'

const listParams = reactive({
  departmentId: '',
  groupId: ''
})
const basicTreeRef = ref<InstanceType<typeof BasicTree>>()
// 列表配置
const treeOptions = reactive<TreeProps>({
  api: getManufactureDepartment,
  title: '部门列表',
  labelField: 'name',
  resultField: 'data',
  childrenField: 'children',
  nodeKey: 'id',
  accordion: true,
  formatter({ data }) {
    return (
      <div>
        {data.label}&nbsp;&nbsp;({data.childrenCount})
      </div>
    )
  },
  cancleHightlightCurrent: true,
  onSelect: async (data, node) => {
    if (data) {
      workOrderHeaderOptions.title = `[${data.label}]生产报工`

      if (data.isGroup) {
        listParams.departmentId = node.parent.data.id
        listParams.groupId = data.id
      } else {
        listParams.departmentId = data.id
        listParams.groupId = ''
      }
      gridWorkOrderRef.value?.commitProxy('reload')
    } else {
      workOrderHeaderOptions.title = `生产报工`
      listParams.departmentId = ''
      listParams.groupId = ''
      gridWorkOrderRef.value?.remove()
    }

    gridWorkPlanRef.value?.remove() // 清空工单计划数据
    clearWorkQuantityTableData() //清空工单数量数据
  }
})

const workOrderHeaderEvents = {
  quickSearch() {
    gridWorkOrderRef.value?.commitProxy('reload')
  },
  advancedSearch() {
    gridWorkOrderRef.value?.commitProxy('reload')
  },
  reset() {
    gridWorkOrderRef.value?.commitProxy('reload')
    gridWorkPlanRef.value?.remove()
  }
}

const gridHeaderWorkOrderRef =
  ref<ComponentExposed<typeof GridHeader<GetWorkOrderParams, 'woNo'>>>()

const workOrderHeaderOptions = reactive<GridHeaderProps>({
  title: '生产工单',
  quickSearch: {
    singleSearch: {
      field: 'woNo',
      type: 'input',
      title: '单据编号/母件编码'
    },
    searchFormFields: { woNo: '' }
  },
  advancedSearch: {
    labelWidth: 120,
    fieldMapToTime: [
      ['dataOfEntry', ['startDataOfEntry', 'endDataOfEntry'], 'YYYY-MM-DD'],
      ['dateofBirth', ['startDateOfBirth', 'endDateOfBirth'], 'YYYY-MM-DD']
    ],
    schemas: [
      {
        field: 'projectId',
        component: 'ApiSelect',
        label: '项目名称',
        componentProps: {
          filterable: true,
          api: getProductionProjectSelect,
          resultField: 'data.result',
          labelField: 'projectName',
          valueField: 'id'
        },
        colProps: {
          span: 8
        }
      },
      {
        field: 'orderNo',
        component: 'Select',
        label: '需求分类',
        componentProps: {
          filterable: true,
          labelField: 'name',
          valueField: 'value'
        },
        colProps: {
          span: 8
        }
      },
      {
        field: 'woNo',
        component: 'Select',
        label: '单据编号',
        componentProps: {
          filterable: true,
          labelField: 'name',
          valueField: 'value'
        },
        colProps: {
          span: 8
        }
      },
      {
        field: 'productName',
        component: 'Select',
        label: '部件名称',
        componentProps: {
          filterable: true,
          labelField: 'name',
          valueField: 'value'
        },
        colProps: {
          span: 8
        }
      },
      {
        field: 'processId',
        component: 'ApiSelect',
        label: '设备类型',
        componentProps: {
          api: getProductionProcessTopLevel,
          resultField: 'data.result',
          labelField: 'processType',
          valueField: 'id',
          filterable: true
        },
        colProps: {
          span: 8
        }
      },
      {
        field: 'departmentId',
        component: 'ApiSelect',
        label: '生产部门',
        componentProps({ formActionType, formModel }) {
          return {
            api: getManufactureDepartmentList,
            resultField: 'data',
            labelField: 'name',
            valueField: 'id',
            filterable: true,
            async onChange(value: string) {
              formModel.groupId = undefined

              let options: SelectModel[] = []
              if (!(value === '')) {
                const { data } = await getGroupSelect({ departmentID: value })
                options = data.result
              }

              const { updateSchema } = formActionType
              updateSchema({
                field: 'groupId',
                componentProps: {
                  options: options
                }
              })
            }
          }
        },
        colProps: {
          span: 8
        }
      },
      {
        field: 'groupId',
        component: 'Select',
        label: '所属组别',
        componentProps: {
          options: [],
          filterable: true
        },
        colProps: {
          span: 8
        }
      },
      {
        field: 'productionAddressId',
        component: 'ApiSelect',
        label: '生产场地',
        componentProps: {
          api: getKeyValue,
          labelField: 'value',
          valueField: 'id',
          resultField: 'data.result',
          params: {
            typeName: 'PositionAddress'
          },
          multiple: true
        },
        colProps: {
          span: 8
        }
      },
      {
        field: 'orderStatus',
        component: 'Select',
        label: '工单状态',
        componentProps: {
          options: [
            { label: '未开始', value: 0 },
            { label: '执行中', value: 1 },
            { label: '已完工', value: 2 },
            { label: '已关闭', value: 3 },
            { label: '已取消', value: 4 }
          ],
          multiple: true
        },
        colProps: {
          span: 8
        }
      }
    ]
  },
  showExportButton: true,
  exportApi: exportProductionWo,
  exportParams: computed(() => {
    const quickSearchForm = unref(gridHeaderWorkOrderRef.value?.quickSearchForm)
    const advancedSearchForm = unref(gridHeaderWorkOrderRef.value?.advancedSearchForm)
    const departmentId = advancedSearchForm?.departmentId ?? listParams.departmentId
    const groupId = advancedSearchForm?.groupId ?? listParams.groupId

    return { ...quickSearchForm, ...advancedSearchForm, departmentId, groupId }
  }),
  exportTemplateApi: exportTemplate,
  importUrl: '/ProductionWo/ImportExcelData',
  showAddButton: false
})
// 获取工单、需求分类、项目名称里诶包
const getProductionWoAndProductList = async () => {
  const { code, data } = await getProductionWoAndProduct()
  if (code === 200) {
    gridHeaderWorkOrderRef.value?.updateAdvancedSearchForm([
      { field: 'orderNo', componentProps: { options: data.orderList } },
      { field: 'woNo', componentProps: { options: data.woList } },
      { field: 'productName', componentProps: { options: data.productNameList } }
    ])
  }
}
getProductionWoAndProductList()

const gridWorkOrderRef = ref<VxeGridInstance>()
const gridWorkOrderOptions = reactive<VxeGridProps<GetWorkOrderModel>>({
  border: true,
  minHeight: '400px',
  maxHeight: '700px',
  align: null,
  columnConfig: {
    resizable: true
  },
  columns: [
    { type: 'seq', width: 50 },
    { field: 'projectName', title: '项目名称', width: 200 },
    { field: 'orderNo', title: '需求分类', width: 150 },
    { field: 'woNo', title: '单据编号', width: 200 },
    { field: 'materialNo', title: '母件编码', width: 200 },
    { field: 'productName', title: '部件名称', width: 150 },
    { field: 'productionOrderNumber', title: '订单数量', width: 100 },
    { field: 'departmentName', title: '部门名称', width: 100 },
    { field: 'processType', title: '设备类型', width: 130 },
    { field: 'productionNodeName', title: '当前节点', width: 130 },
    { field: 'orderSchedule', title: '工单进度', width: 150, slots: { default: 'orderSchedule' } },
    { field: 'orderStatus', title: '工单状态', width: 100, slots: { default: 'orderStatus' } },
    { field: 'priorityLevel', title: '优先级', width: 80 },
    { field: 'employeeName', title: 'PMC', width: 130 },
    { field: 'versionNo', title: '版本号', width: 100 },
    { field: 'lastModifiedUserName', title: '操作人', width: 150 },
    { field: 'lastModifiedTime', title: '最后修改时间', width: 150 },
    {
      field: 'operation',
      title: '操作',
      align: 'center',
      fixed: 'right',
      width: 150,
      slots: {
        default: 'operation'
      }
    }
  ],
  pagerConfig: {
    enabled: true
  },
  proxyConfig: {
    autoLoad: false,
    ajax: {
      query: ({ page }) => {
        const quickSearchForm = unref(gridHeaderWorkOrderRef.value?.quickSearchForm)
        const advancedSearchForm = unref(gridHeaderWorkOrderRef.value?.advancedSearchForm)

        const departmentId = advancedSearchForm?.departmentId ?? listParams.departmentId
        const groupId = advancedSearchForm?.groupId ?? listParams.groupId
        return getProductionWo({
          pageIndex: page.currentPage - 1, // 由于后端接口限制，首页从0开始
          pageSize: page.pageSize,
          ...quickSearchForm,
          ...advancedSearchForm,
          departmentId,
          groupId
        })
      }
    }
  }
})

const getOrderStatusText = computed((): ((status: number) => { text: string; type: string }) => {
  return function (status: number): { text: string; type: string } {
    switch (status) {
      case 0:
        return {
          text: '未开始',
          type: 'danger'
        }
      case 1:
        return {
          text: '执行中',
          type: ''
        }
      case 2:
        return {
          text: '已完工',
          type: 'success'
        }
      case 3:
        return {
          text: '已关闭',
          type: 'info'
        }
      case 4: {
        return {
          text: '已取消',
          type: 'info'
        }
      }
      default:
        return {
          text: '',
          type: ''
        }
    }
  }
})
const [registerModal, { openModal, setModalProps, closeModal }] = useModal()

const handleView = (row: GetWorkOrderModel) => {
  openModal(true, {
    isCopy: true,
    row
  })
}

const activeName = ref<string>('workPlan')

const gridEvents: VxeGridListeners<GetWorkOrderModel> = {
  cellClick({ row }) {
    workPlanHeaderOptions.title = `生产计划-[工单${row.woNo}]`
    gridWorkPlanRef.value?.commitProxy('reload')
    const { productNumberJson } = row
    const { tableData } = workQuantityGridRef.value?.getTableData() ?? {}

    if (isDef(tableData)) {
      const data = tableData.map((row) => {
        return {
          ...row,
          quantity: productNumberJson[row.field]
        }
      })
      workQuantityGridRef.value?.loadData(data)
    }
  }
}

const gridHeaderWorkPlanRef = ref<ComponentExposed<typeof GridHeader>>()
const workPlanHeaderOptions = reactive<GridHeaderProps>({
  title: '生产计划',
  quickSearch: {
    singleSearch: {
      field: 'woNo',
      type: 'input',
      title: '单据编号'
    },
    searchFormFields: { woNo: '' }
  },
  advancedSearch: {
    labelWidth: 120,
    fieldMapToTime: [
      ['dataOfEntry', ['startDataOfEntry', 'endDataOfEntry'], 'YYYY-MM-DD'],
      ['dateofBirth', ['startDateOfBirth', 'endDateOfBirth'], 'YYYY-MM-DD']
    ],
    schemas: [
      {
        field: 'employeeNo',
        component: 'ElInput',
        label: '员工编号',
        componentProps: {
          style: {
            width: '100%'
          }
        },
        colProps: {
          span: 8
        }
      }
    ]
  },
  showAdvancedSearchButton: false,
  showAddButton: false,
  showQuickSearchButton: false
})
const gridWorkPlanRef = ref<VxeGridInstance>()
const gridWorkPlanOptions = reactive<VxeGridProps<GetProductionPlanByWoModel>>({
  border: true,
  minHeight: '400px',
  maxHeight: '800px',
  align: null,
  columnConfig: {
    resizable: true
  },
  columns: [
    { type: 'seq', width: 50 },
    { field: 'productionNodeName', title: '生产节点' },
    { field: 'planFinishDate', title: '计划日期' },
    { field: 'productionAddressName', title: '生产场地' },
    {
      field: 'productionState',
      title: '状态',
      slots: { default: 'productionState' }
    },
    { field: 'materialState', title: '物料情况' }
  ],
  pagerConfig: {
    enabled: false
  },
  proxyConfig: {
    autoLoad: false,
    ajax: {
      query: () => {
        const quickSearchForm = gridHeaderWorkPlanRef.value?.quickSearchForm
        const advancedSearchForm = gridHeaderWorkPlanRef.value?.advancedSearchForm
        const woID = gridWorkOrderRef.value?.getCurrentRecord().id

        return new Promise((resolve, reject) => {
          getProductionPlanByWo({
            woID,
            ...quickSearchForm,
            ...advancedSearchForm
          }).then((res) => {
            resolve(res.data)
          })
        })
      }
    }
  }
})

const productionStateList = ref<GetDictionaryModel[]>()
// 获取生产节点状态列表
const getProductionStateList = async () => {
  const { data } = await getKeyValue({
    typeName: 'ProductionNodeStatus'
  })

  productionStateList.value = data.result
}
getProductionStateList()

// 获取工单数量列表
const getWorkQuantityList = async () => {
  const { data: keyValueData } = await getKeyValue({ typeName: 'DeviceNumberType' })
  const workQuantityData = keyValueData.result.map((row) => {
    row.key = String(row.key)
    // 将字典表的大写转换为接口首字母小写
    const field = row.key.replace(row.key[0], row.key[0].toLowerCase())
    return {
      field: field,
      type: row.value,
      quantity: undefined,
      component: field === 'productionOrderNumber' ? 'inputNumber' : 'input'
    }
  })
  workQuantityGridRef.value?.loadData(workQuantityData)
}
getWorkQuantityList()

// 格式化生产状态显示
const formatProductionStateLabelFormat = (productionState: number) => {
  return unref(productionStateList)?.find((item) => item.key === productionState)?.value
}

const workQuantityGridRef = ref<VxeGridInstance<WorkOrderQuantity>>()
const gridWorkQuantityOptions = reactive<VxeGridProps<WorkOrderQuantity>>({
  border: true,
  maxHeight: '800px',
  align: null,
  columnConfig: {
    resizable: true
  },
  columns: [
    { type: 'seq', width: 50 },
    { field: 'field', title: '字段', visible: false },
    { field: 'type', title: '类型' },
    { field: 'quantity', title: '数量' }
  ],
  pagerConfig: {
    enabled: false
  }
})

const clearWorkQuantityTableData = () => {
  const { tableData } = workQuantityGridRef.value?.getTableData() ?? {}

  if (isDef(tableData)) {
    const data = tableData.map((row) => {
      return {
        ...row,
        quantity: undefined
      }
    })
    workQuantityGridRef.value?.loadData(data)
  }
}
</script>

<style lang="scss" scoped>
.basic-list-container {
  display: flex;
  overflow: hidden;
}
.grid-container {
  padding: $margin $margin $margin 0;
  .vxe-grid-container:first-child {
    margin-bottom: $margin;
  }
}
</style>
