<template>
  <BasicModal
    width="556px"
    v-bind="$attrs"
    @register="registerModal"
    title="编辑"
    @confirm="handleSubmit"
  >
    <BasicForm @register="registerForm"></BasicForm>
  </BasicModal>
</template>

<script setup lang="ts">
import type { ModalMethods } from '@/components/Modal/types'
import type { UpdateAttendanceData } from '@/api/sys/model/workModel'
import { ref, unref } from 'vue'

import BasicModal from '@/components/Modal/BasicModal.vue'
import BasicForm from '@/components/Form/BasicForm.vue'

import { useModalInner } from '@/components/Modal/hooks/useModal'
import { useForm } from '@/components/Form/hooks/useForm'
import { updateAttendance } from '@/api/sys/work'
import { getKeyValue } from '@/api/sys/basic'

const emit = defineEmits<{
  register: [modalMethods: ModalMethods, uuid: number]
  success: []
}>()

const rowId = ref<string>('')

const attendanceStatusList = ref<{ label: string; value: number; disabled?: boolean }[]>([])
const getAttendanceStatusList = () => {
  getKeyValue({ typeName: 'AttendanceStatus' })
    .then(({ code, data }) => {
      if (code === 200) {
        attendanceStatusList.value = data.result.map((item) => {
          return { label: item.value, value: Number(item.key), disabled: Number(item.key) === 0 }
        })
      } else {
        attendanceStatusList.value = []
      }
    })
    .catch(() => (attendanceStatusList.value = []))
}

const [registerForm, { setFieldsValue, resetFields, getFieldsValue, validate, clearValidate }] =
  useForm({
    labelWidth: 86,
    schemas: [
      {
        field: 'employeeInfoID',
        component: 'ElInput',
        ifShow: false,
        label: '员工ID'
      },
      {
        field: 'employeeInfoName',
        component: 'ElInput',
        componentProps: {
          disabled: true
        },
        rules: [{ required: true, trigger: 'blur' }],
        label: '员工',
        colProps: {
          span: 13
        }
      },
      {
        field: 'transferStatus',
        component: 'ElInput',
        label: '借调状态',
        show: false
      },
      {
        field: 'groupID',
        component: 'ElInput',
        label: '班组id',
        show: false
      },

      {
        field: 'groupName',
        component: 'ElInput',
        label: '班组',
        componentProps: {
          disabled: true
        },
        labelWidth: '50px',
        colProps: {
          span: 11
        }
      },
      {
        field: 'attendanceDate',
        component: 'ElDatePicker',
        componentProps: {
          valueFormat: 'YYYY-MM-DD'
        },
        label: '日期',
        rules: [{ required: true, trigger: 'change' }],
        dynamicDisabled({ model }) {
          return model['orderStatus'] === 2
        },
        colProps: {
          span: 13
        }
      },
      {
        field: 'attendanceEndDate',
        component: 'ElDatePicker',
        componentProps: {
          valueFormat: 'YYYY-MM-DD'
        },
        label: '至',
        labelWidth: '35px',
        dynamicDisabled({ model }) {
          return model['orderStatus'] === 2
        },
        colProps: {
          span: 11
        }
      },
      {
        field: 'attendanceStatus',
        component: 'Select',
        componentProps: {
          options: attendanceStatusList
        },
        label: '考勤情况',
        rules: [{ required: true, trigger: 'change' }],
        dynamicDisabled({ model }) {
          return model['orderStatus'] === 2
        },
        colProps: {
          span: 12
        }
      },
      {
        field: 'dataDescribe',
        component: 'ElInput',
        label: '原因',
        // rules: [{ required: true, trigger: 'change' }],
        // ifShow({ model }) {
        //   return (
        //     model['attendanceStatus'] &&
        //     model['attendanceStatus'] !== 1 &&
        //     model['attendanceStatus'] !== 0
        //   )
        // },
        dynamicDisabled({ model }) {
          return model['orderStatus'] === 2
        },
        componentProps: {
          type: 'textarea',
          rows: 3
        }
      },
      {
        field: 'orderStatus',
        label: '状态',
        component: 'ElInput',
        ifShow: false
      }
    ]
  })

const [registerModal, { setModalProps }] = useModalInner(async (data) => {
  await resetFields()
  setModalProps({ confirmLoading: false })
  getAttendanceStatusList()
  rowId.value = data.row.id
  await setFieldsValue({ ...data.row, transferStatus: data.row.transferInStatus })

  clearValidate()
})

// 提交
const handleSubmit = async () => {
  await validate()

  setModalProps({ confirmLoading: true })

  try {
    const formData = getFieldsValue() as Omit<UpdateAttendanceData, 'id'>
    if (formData.attendanceStatus === 4) {
      await ElMessageBox.confirm('请确认是否提交以下员工为离职状态?', '提示', {
        type: 'warning'
      })
    }
    const data = {
      id: unref(rowId),
      ...formData,
      dataDescribe: formData.attendanceStatus === 1 ? '' : formData.dataDescribe
    }
    const { code, message } = await updateAttendance(data)

    if (code === 200) {
      ElMessage.success('修改成功')
      emit('success')
    } else {
      ElMessage.error(message)
    }
  } catch (error: any) {
    error !== 'cancel' && ElMessage(error.message)
  } finally {
    setModalProps({ confirmLoading: false })
  }
}
</script>
<style lang="scss" scoped></style>
