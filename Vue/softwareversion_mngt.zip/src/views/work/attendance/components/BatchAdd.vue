<template>
  <BasicModal
    width="720px"
    v-bind="$attrs"
    @register="registerModal"
    title="批量新增"
    @confirm="handleSubmit"
  >
    <BasicForm @register="registerForm" />
    <vxe-grid ref="gridRef" v-bind="gridOptions">
      <template #employeeName="{ row }">
        <div style="display: flex; align-items: center">
          <div>{{ row.employeeName }}</div>
          <el-tag
            v-if="row.transferInStatus === 1"
            type="warning"
            size="small"
            effect="plain"
            style="margin-left: 5px"
            >借调</el-tag
          >
        </div>
      </template>
      <template #operation="{ row }">
        <TableAction
          :actions="[
            {
              icon: 'delete',
              tooltip: '删除',
              onClick: handleDelete.bind(null, row)
            }
          ]"
        />
      </template>
      <template #bottom>
        <div style="margin-top: 10px; display: flex; justify-content: end">
          共 {{ total }} 条记录
        </div>
      </template>
    </vxe-grid>
  </BasicModal>
</template>

<script setup lang="ts">
import type { AddAttendanceData, GetAttendanceModel } from '@/api/sys/model/workModel'
import type { ModalMethods } from '@/components/Modal/types'
import type { VxeGridInstance, VxeGridProps } from 'vxe-table'
import type { GetEmployeeInfoByGroupIDModel } from '@/api/sys/model/basicModel'

import { ref, reactive } from 'vue'

import BasicModal from '@/components/Modal/BasicModal.vue'
import BasicForm from '@/components/Form/BasicForm.vue'

import { useModalInner } from '@/components/Modal/hooks/useModal'
import { useForm } from '@/components/Form/hooks/useForm'
import { getEmployeeInfoSelect, getKeyValue } from '@/api/sys/basic'
import { addAttendance } from '@/api/sys/work'
import dayjs from 'dayjs'

const emit = defineEmits<{
  register: [modalMethods: ModalMethods, uuid: number]
  success: [attendanceDate: string]
}>()

const total = ref(0)
const groupID = ref()

const attendanceStatusList = ref<{ label: string; value: number; disabled?: boolean }[]>([])
const getAttendanceStatusList = () => {
  getKeyValue({ typeName: 'AttendanceStatus' })
    .then(({ code, data }) => {
      if (code === 200) {
        attendanceStatusList.value = data.result.map((item) => {
          return { label: item.value, value: Number(item.key), disabled: Number(item.key) === 0 }
        })
      } else {
        attendanceStatusList.value = []
      }
    })
    .catch(() => (attendanceStatusList.value = []))
}

const [registerForm, { resetFields, getFieldsValue, setFieldsValue, clearValidate, validate }] =
  useForm({
    labelWidth: 86,
    schemas: [
      {
        field: 'attendanceDate',
        component: 'ElDatePicker',
        defaultValue: dayjs().format('YYYY-MM-DD'),
        rules: [{ required: true, trigger: 'change' }],
        componentProps: {
          // disabled: true,
          valueFormat: 'YYYY-MM-DD',
          onChange: (attendanceDate: string) => {
            getEmployeeList(groupID.value, attendanceDate)
          }
        },
        label: '日期'
      },
      {
        field: 'attendanceStatus',
        component: 'Select',
        defaultValue: 1,
        rules: [{ required: true, trigger: 'change' }],
        componentProps: {
          options: attendanceStatusList
        },
        label: '考勤情况'
      }
    ]
  })

const gridRef = ref<VxeGridInstance>()
const gridOptions = reactive<VxeGridProps<GetAttendanceModel>>({
  border: true,
  height: '350px',
  align: null,
  columnConfig: {
    resizable: true
  },
  columns: [
    { type: 'seq', width: 50 },
    { field: 'employeeName', title: '员工', width: 120, slots: { default: 'employeeName' } },
    { field: 'departmentName', title: '部门', width: 120 },
    { field: 'groupName', title: '组别', minWidth: 120 },
    {
      field: 'operation',
      title: '操作',
      align: 'center',
      fixed: 'right',
      width: 150,
      slots: {
        default: 'operation'
      }
    }
  ],
  pagerConfig: {
    enabled: false
  },
  data: []
})

const getEmployeeList = (groupID: string, attendanceDate: string) => {
  getEmployeeInfoSelect({
    groupID: groupID,
    requestDate: attendanceDate
  }).then(({ code, data }) => {
    if (code === 200) {
      total.value = data.total
      gridRef.value?.reloadData(data.result)
    }
  })
}

const [registerModal, { setModalProps }] = useModalInner(async (data) => {
  await resetFields()
  setModalProps({ confirmLoading: false })
  getAttendanceStatusList()
  gridRef.value?.reloadData([])
  groupID.value = data.groupID
  await setFieldsValue({ attendanceDate: data.attendanceDate })

  clearValidate()
})

const handleDelete = (row: GetEmployeeInfoByGroupIDModel) => {
  gridRef.value?.remove(row)
  total.value = gridRef.value!.getTableData().fullData.length
}

// 提交
const handleSubmit = async () => {
  await validate()
  setModalProps({ confirmLoading: true })
  try {
    // 新增
    const formData = getFieldsValue() as AddAttendanceData
    if (formData.attendanceStatus === 4) {
      await ElMessageBox.confirm('请确认是否提交以下员工为离职状态?', '提示', {
        type: 'warning'
      })
    }
    const tableData = gridRef.value!.getTableData().fullData
    const data = {
      ...formData,
      groupID: groupID.value,
      addDataModel: tableData.map((item) => {
        return { employeeInfoID: item.id, transferStatus: item.transferInStatus }
      })
    } as AddAttendanceData
    const { code, message } = await addAttendance(data)
    if (code === 200) {
      ElMessage.success('新增成功')
      emit('success', data.attendanceDate)
    } else {
      ElMessage.error(message)
    }
  } catch (error: any) {
    error !== 'cancel' && ElMessage(error.message)
  } finally {
    setModalProps({ confirmLoading: false })
  }
}
</script>
<style lang="scss" scoped></style>
