<template>
  <LayoutContainer>
    <template #leftSide>
      <basic-tree ref="basicTreeRef" v-bind="listOptions" />
    </template>

    <div class="grid-container">
      <vxe-grid class="box" ref="gridRef" v-bind="gridOptions">
        <template #top>
          <GridHeader ref="gridHeaderRef" v-bind="headerOptions" v-on="headerEvent">
            <template #appendOperation>
              <el-button size="large" type="warning" plain @click="handleBatchAdd"
                >批量新增</el-button
              >
              <el-button size="large" type="success" plain @click="handleAllConfirm"
                >整组确认</el-button
              >
            </template>
          </GridHeader>
        </template>
        <template #employeeInfoName="{ row }">
          <div style="display: flex; align-items: center">
            <div>{{ row.employeeInfoName }}</div>
            <el-tag
              v-if="row.transferInStatus === 1"
              type="warning"
              size="small"
              effect="plain"
              style="margin-left: 5px"
              >借调</el-tag
            >
          </div>
        </template>
        <template #attendanceStatus="{ row }">
          <el-tag
            :style="{
              color: getAttendanceStatusInfo(row.attendanceStatus).textColor,
              borderColor: getAttendanceStatusInfo(row.attendanceStatus).borderColor,
              backgroundColor: getAttendanceStatusInfo(row.attendanceStatus).backgroundColor
            }"
          >
            {{ getAttendanceStatusInfo(row.attendanceStatus).text }}
          </el-tag>
        </template>
        <template #orderStatus="{ row }">
          <el-tag :type="getConfirmStatusInfo(row.orderStatus).type">
            {{ getConfirmStatusInfo(row.orderStatus).text }}
          </el-tag>
        </template>
        <template #operation="{ row }">
          <TableAction
            :actions="[
              {
                tooltip: '确认',
                icon: 'finish-wo-status',
                ifShow: row.orderStatus !== 2,
                onClick: handleConfirm.bind(null, row)
              },
              {
                tooltip: '撤回',
                icon: 'undo',
                ifShow: row.orderStatus === 2,
                onClick: handleRevocation.bind(null, row)
              },
              {
                tooltip: '编辑',
                icon: 'edit',
                onClick: handleModify.bind(null, row)
              }
            ]"
          />
        </template>
      </vxe-grid>
    </div>

    <AttendanceDialog @register="registerModal" @success="handleSuccess" />
    <BatchAdd @register="registerBatchAddModal" @success="handleBatchAddSuccess" />
  </LayoutContainer>
</template>

<script setup lang="tsx">
import type { ComponentExposed } from 'vue-component-type-helpers'
import type { VxeGridInstance, VxeGridProps } from 'vxe-table'
import type { GridHeaderProps, GridHeaderEvent } from '@/components/Table/types/gridHeader'
import type { GetEmployeeInfoModel } from '@/api/sys/model/basicModel'
import type { TreeProps } from '@/components/Tree/types/tree'
import type { GetAttendanceModel, GetAttendanceParams } from '@/api/sys/model/workModel'

import { reactive, ref, computed } from 'vue'
import dayjs from 'dayjs'

import { getManufactureDepartment, getKeyValue } from '@/api/sys/basic'

import GridHeader from '@/components/Table/GridHeader.vue'
import TableAction from '@/components/Table/TableAction.vue'
import { useModal } from '@/components/Modal/hooks/useModal'
import { useForm } from '@/components/Form/hooks/useForm'
import AttendanceDialog from './components/AttendanceDialog.vue'
import BatchAdd from './components/BatchAdd.vue'

import {
  exportAttendance,
  getAttendance,
  updateAttendanceOrderStatus,
  updateAttendanceOrderStatusAll,
  updateAttendanceRevokeConfirm
} from '@/api/sys/work'
import { downloadByApi } from '@/utils/download'
import { dateShortcuts } from '@/constant'

defineOptions({
  name: 'Attendance',
  inheritAttrs: false
})

const basicTreeRef = ref()

// 列表配置
const listOptions = reactive<TreeProps>({
  api: getManufactureDepartment,
  title: '部门列表',
  labelField: 'name',
  resultField: 'data',
  childrenField: 'children',
  params: { departmentName: '制造中心' },
  nodeKey: 'id',
  onSelect: async (node) => {
    // await gridHeaderRef.value?.resetAdvancedSearchFormFields() // 重置高级查询
    handleNodeClick(node)
  },
  formatter({ node, data }) {
    return (
      <div>
        {node.label}&nbsp;&nbsp;({data.childrenCount})
      </div>
    )
  }
})

const handleNodeClick = async (node: { id: string; label: string; children?: [] }) => {
  if (node.children) {
    return
  }
  headerOptions.title = `[${node.label}] - 考勤登记`
  groupID.value = node.id
  groupName.value = node.label

  if (!groupID.value) {
    ElMessage.warning('请先选择组别')
    return
  }

  gridRef.value?.commitProxy('reload')
}

const getConfirmStatusInfo = computed(() => {
  const statusMap: { [key: number]: { text: string; type: string } } = {
    1: { text: '未确认', type: 'info' },
    2: { text: '已确认', type: 'success' }
  }

  return function (status: number) {
    return statusMap[status] || { text: '', color: '' }
  }
})

const attendanceStatusList = ref<any[]>([])
const getAttendanceStatusInfo = computed(() => {
  const statusMap: any = {}
  const tagTheme = {
    primary: { backgroundColor: '#ecf5ff', textColor: '#409eff', borderColor: '#d9ecff' },
    success: { backgroundColor: '#f0f9eb', textColor: '#67c23a', borderColor: '#e1f3d8' },
    warning: { backgroundColor: '#fdf6ec', textColor: '#e6a23c', borderColor: '#faecd8' },
    warningDeep: {
      backgroundColor: 'rgba(255, 141, 26, 0.1)',
      textColor: 'rgba(255, 141, 26, 1)',
      borderColor: 'rgba(255, 141, 26, 0.25)'
    },
    info: { backgroundColor: '#f4f4f5', textColor: '#909399', borderColor: '#e9e9eb' },
    danger: { backgroundColor: '#fef0f0', textColor: '#f56c6c', borderColor: '#fde2e2' },
    dangerDeep: {
      backgroundColor: 'rgba(212, 48, 48, 0.1)',
      textColor: 'rgba(212, 48, 48, 1)',
      borderColor: 'rgba(212, 48, 48, 0.25)'
    }
  }
  attendanceStatusList.value.forEach((item) => {
    if (item.value === 0) {
      statusMap[item.value] = {
        text: item.label,
        ...tagTheme['info']
      }
    } else if (item.value === 1) {
      statusMap[item.value] = {
        text: item.label,
        ...tagTheme['primary']
      }
    } else if (item.value === 2) {
      statusMap[item.value] = {
        text: item.label,
        ...tagTheme['warning']
      }
    } else if (item.value === 3) {
      statusMap[item.value] = {
        text: item.label,
        ...tagTheme['warning']
      }
    } else if (item.value === 4) {
      statusMap[item.value] = {
        text: item.label,
        ...tagTheme['warning']
      }
    } else if (item.value === 5) {
      statusMap[item.value] = {
        text: item.label,
        ...tagTheme['primary']
      }
    } else if (item.value === 6) {
      statusMap[item.value] = {
        text: item.label,
        ...tagTheme['warning']
      }
    } else if (item.value === 7) {
      statusMap[item.value] = {
        text: item.label,
        ...tagTheme['warning']
      }
    } else if (item.value === 8) {
      statusMap[item.value] = {
        text: item.label,
        ...tagTheme['warning']
      }
    }
  })

  return function (status: number) {
    return statusMap[status]
  }
})

const groupID = ref('')
const groupName = ref('')

const gridHeaderRef =
  ref<ComponentExposed<typeof GridHeader<GetAttendanceParams, 'EmployeeInfoNoAndName'>>>()

const [registerForm, { getFieldsValue, validate }] = useForm({
  labelWidth: 60,
  fieldMapToTime: [['AttendanceDate', ['AttendanceStartDate', 'AttendanceEndDate'], 'YYYY-MM-DD']],
  schemas: [
    {
      field: 'AttendanceDate',
      component: 'ElDatePicker',
      label: '日期',
      required: true,
      componentProps: {
        type: 'daterange',
        startPlaceholder: '开始日期',
        endPlaceholder: '结束日期',
        unlinkPanels: true,
        shortcuts: dateShortcuts,
        valueFormat: 'YYYY-MM-DD'
      },
      colProps: {
        span: 23
      }
    }
  ]
})
const headerOptions = reactive<GridHeaderProps>({
  title: '考勤登记',
  quickSearch: {
    singleSearch: {
      field: 'EmployeeInfoNoAndName',
      type: 'input',
      title: '工号/姓名'
    },
    searchFormFields: { EmployeeInfoNoAndName: '' }
  },
  showAddButton: false,
  advancedSearch: {
    labelWidth: 120,
    schemas: [
      {
        field: 'attendanceStatus',
        component: 'ApiSelect',
        label: '考勤情况',
        componentProps: {
          api: getKeyValue,
          resultField: 'data.result',
          labelField: 'value',
          valueField: 'key',
          params: { typeName: 'AttendanceStatus' },
          onOptionsChange(list: any) {
            attendanceStatusList.value = list
          }
        },
        colProps: {
          span: 8
        }
      },
      {
        field: 'orderStatus',
        component: 'Select',
        label: '状态',
        componentProps: {
          options: [
            { label: '未确认', value: 1 },
            { label: '已确认', value: 2 }
          ]
        },
        colProps: {
          span: 8
        }
      },
      {
        field: 'attendanceDate',
        component: 'ElDatePicker',
        label: '考勤日期',
        defaultValue: dayjs().format('YYYY-MM-DD'),
        componentProps: {
          valueFormat: 'YYYY-MM-DD'
        },
        colProps: {
          span: 8
        }
      },
      {
        field: 'positionClassifyID',
        component: 'ApiSelect',
        label: '工种',
        // defaultValue: [0, 1],
        componentProps: {
          api: getKeyValue,
          labelField: 'value',
          valueField: 'id',
          resultField: 'data.result',
          multiple: true,
          params: {
            typeName: 'PositionClassify'
          }
        },
        colProps: {
          span: 8
        }
      }
    ]
  },
  showExportButton: true,
  customExport: true
  // exportApi: exportAttendance,
  // exportParams: computed(() => {
  //   const advancedSearchForm = gridHeaderRef.value?.advancedSearchForm
  //   const quickSearchForm = gridHeaderRef.value?.quickSearchForm
  //   return { GroupID: groupID.value, ...quickSearchForm, ...advancedSearchForm }
  // })
})

const headerEvent: GridHeaderEvent<GetAttendanceParams, 'EmployeeInfoNoAndName'> = {
  quickSearch() {
    if (!groupID.value) {
      ElMessage.warning('请先选择组别')
      return
    }

    gridRef.value?.commitProxy('reload')
  },
  advancedSearch() {
    if (!groupID.value) {
      ElMessage.warning('请先选择组别')
      return
    }

    gridRef.value?.commitProxy('reload')
  },
  reset() {
    if (!groupID.value) {
      ElMessage.warning('请先选择组别')
      return
    }

    gridRef.value?.commitProxy('reload')
  },
  exportClick() {
    ElMessageBox({
      title: '导出',
      showCancelButton: true,
      message: () => {
        return <basic-form onRegister={registerForm} />
      },
      beforeClose: async (action, instance, done) => {
        if (action === 'confirm') {
          await validate(async (isValid) => {
            const fieldsValue = getFieldsValue()

            if (isValid) {
              const loading = ElLoading.service({
                lock: true,
                text: 'Loading',
                background: 'rgba(0, 0, 0, 0.7)'
              })
              try {
                await downloadByApi(exportAttendance, {
                  ...fieldsValue
                })
                ElMessage.success('导出成功')
                done()
              } catch (e: any) {
                ElMessage.error(e.message)
              } finally {
                loading.close()
              }
            }
          })
        }

        if (action === 'cancel') {
          done()
        }
      }
    })
  }
}

const gridRef = ref<VxeGridInstance>()
const gridOptions = reactive<VxeGridProps<GetEmployeeInfoModel>>({
  border: true,
  height: 'auto',
  align: null,
  columnConfig: {
    resizable: true
  },
  columns: [
    { type: 'seq', width: 50 },
    {
      field: 'attendanceDate',
      title: '日期',
      width: 120,
      formatter({ cellValue }) {
        return dayjs(cellValue).format('YYYY-MM-DD')
      }
    },
    { field: 'departmentName', title: '部门', width: 120 },
    { field: 'groupName', title: '组别', width: 120 },
    {
      field: 'employeeInfoName',
      title: '员工',
      width: 150,
      slots: { default: 'employeeInfoName' }
    },
    {
      field: 'attendanceStatus',
      title: '出勤情况',
      width: 100,
      slots: { default: 'attendanceStatus' }
    },
    { field: 'dataDescribe', title: '原因', minWidth: 150 },
    {
      field: 'orderStatus',
      title: '状态',
      width: 100,
      slots: { default: 'orderStatus' }
    },
    {
      field: 'operation',
      title: '操作',
      align: 'center',
      fixed: 'right',
      width: 150,
      slots: {
        default: 'operation'
      }
    }
  ],
  pagerConfig: {
    enabled: true,
    pageSize: 50
  },
  proxyConfig: {
    ajax: {
      query: ({ page }) => {
        if (!groupID.value) {
          return Promise.resolve([])
        }
        const quickSearchForm = gridHeaderRef.value?.quickSearchForm
        const advancedSearchForm = gridHeaderRef.value?.getAdvancedSearchForm()

        return getAttendance({
          pageIndex: page.currentPage - 1, // 由于后端接口限制，首页从0开始
          pageSize: page.pageSize,
          ...quickSearchForm,
          ...advancedSearchForm,
          GroupID: groupID.value
        })
      }
    }
  }
})

const [registerModal, { openModal, closeModal, setModalProps }] = useModal()

const [registerBatchAddModal, { openModal: openBatchAddModal, closeModal: closeBatchAddModal }] =
  useModal()

const handleBatchAdd = () => {
  if (!groupID.value) {
    ElMessage.warning('请先选择部门')
    return
  }
  const data = gridRef.value?.getTableData().fullData[0]
  if (!data) {
    ElMessage.warning('无数据')
    return
  }

  openBatchAddModal(true, { groupID: groupID.value, attendanceDate: data.attendanceDate })
}

const handleAllConfirm = () => {
  if (!groupID.value) {
    ElMessage.warning('请先选择部门')
    return
  }
  const data = gridRef.value?.getTableData().fullData[0]
  if (!data) {
    ElMessage.warning('无数据')
    return
  }

  ElMessageBox.confirm(
    `是否确认日期为【${dayjs(data.attendanceDate).format('YYYY-MM-DD')}】，组别为【${
      groupName.value
    }】的数据项`,
    '警告',
    {
      confirmButtonText: '确定',
      cancelButtonText: '取消',
      type: 'warning'
    }
  ).then(() => {
    updateAttendanceOrderStatusAll({
      groupID: groupID.value,
      attendanceDate: data.attendanceDate
    }).then(({ code, message }) => {
      if (code === 200) {
        gridRef.value?.commitProxy('query')
      } else {
        ElMessage.error(message)
      }
    })
  })
}

const handleModify = (row: GetAttendanceModel) => {
  openModal(true, { row })
  setModalProps({ showConfirmBtn: row.orderStatus !== 2 })
}

const handleConfirm = (row: GetAttendanceModel) => {
  ElMessageBox.confirm(`是否确认名称为"${row.employeeInfoName}"的数据项`, '警告', {
    confirmButtonText: '确定',
    cancelButtonText: '取消',
    type: 'warning'
  }).then(() => {
    updateAttendanceOrderStatus({ id: row.id }).then(({ code, data, message }) => {
      if (code === 200 && data) {
        gridRef.value?.commitProxy('query')
      } else {
        ElMessage.error(message)
      }
    })
  })
}

const handleRevocation = (row: GetAttendanceModel) => {
  ElMessageBox.confirm(`是否撤销名称为"${row.employeeInfoName}"的数据项`, '警告', {
    confirmButtonText: '确定',
    cancelButtonText: '取消',
    type: 'warning'
  }).then(() => {
    updateAttendanceRevokeConfirm({ id: row.id }).then(({ code, data, message }) => {
      if (code === 200 && data) {
        gridRef.value?.commitProxy('query')
      } else {
        ElMessage.error(message)
      }
    })
  })
}

const handleSuccess = () => {
  closeModal()
  gridRef.value?.commitProxy('query')
}

const handleBatchAddSuccess = async (attendanceDate: string) => {
  closeBatchAddModal()
  await gridHeaderRef.value?.setFieldsValue({ attendanceDate })
  gridRef.value?.commitProxy('query')
}
</script>

<style scoped lang="scss">
.grid-container {
  height: 100%;
  padding: $margin $margin $margin 0;
}
</style>
