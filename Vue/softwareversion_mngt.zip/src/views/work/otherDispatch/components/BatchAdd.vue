<template>
  <BasicModal
    width="1200px"
    v-bind="$attrs"
    @register="registerInnerModal"
    title="新增派工"
    @confirm="handleSubmit"
    @close="handleClose"
  >
    <vxe-grid ref="gridRef" v-bind="gridOptions">
      <template #employeeInfoID="{ row }">
        <div style="display: flex; align-items: center">
          <div>{{ row.employeeNo + '-' + row.employeeName }}</div>
          <el-tag
            v-if="row.transferInStatus === 1"
            type="warning"
            size="small"
            effect="plain"
            style="margin-left: 5px"
            >借调</el-tag
          >
        </div>
      </template>
      <template #employeeInfoID_edit="{ row }">
        <PersonSelect
          style="width: 100%"
          v-model="row.employeeInfoID"
          @confirm="
            (data: GetEmployeeInfoModel) => {
              row.employeeInfoName = data.employeeName
              row.groupName = data.groupName
            }
          "
          @clear="
            () => {
              row.employeeInfoName = ''
              row.groupName = ''
            }
          "
        ></PersonSelect>
      </template>
      <template #startDate_edit="{ row }">
        <el-date-picker
          style="width: 100%"
          v-model="row.startDate"
          type="date"
          format="YYYY-MM-DD"
          date-format="YYYY-MM-DD"
          value-format="YYYY-MM-DD"
        ></el-date-picker>
      </template>
      <template #workType_edit="{ row }">
        <Select style="width: 100%" v-model="row.workType" :options="workTypeOptions"></Select>
      </template>
      <template #dispatchingNumber_edit="{ row }">
        <el-input-number
          style="width: 100%"
          v-model="row.dispatchingNumber"
          :step="1"
          step-strictly
        ></el-input-number>
      </template>
      <template #workDescription_edit="{ row }">
        <el-input style="width: 100%" v-model="row.workDescription"></el-input>
      </template>
      <template #operation="{ row }">
        <TableAction
          :actions="[
            {
              icon: 'save',
              tooltip: '完成',
              ifShow: () => gridRef!.isEditByRow(row),
              onClick: handleComplete.bind(null)
            },
            {
              icon: 'edit',
              tooltip: '编辑',
              ifShow: () => !gridRef!.isEditByRow(row),
              onClick: handleEdit.bind(null, row)
            },
            {
              icon: 'delete',
              tooltip: '删除',
              onClick: handleDelete.bind(null, row)
            }
          ]"
        />
      </template>
      <template #bottom>
        <TableAction
          style="margin-top: 16px"
          :actions="[
            {
              icon: 'plus',
              label: '新增',
              onClick: handleAdd.bind(null),
              style: {
                color: '#008cd6'
              }
            }
          ]"
        ></TableAction>
        <div style="margin-top: 10px; display: flex; justify-content: end">
          共 {{ total }} 条记录
        </div>
      </template>
    </vxe-grid>
    <PersonSelectDialog
      @register="registerModal"
      @success="handleSuccess"
      append-to-body
      :multiple="true"
    ></PersonSelectDialog>
  </BasicModal>
</template>

<script setup lang="ts">
import type { AddDispatchingOtherData, DispatchingOtherEmployee } from '@/api/sys/model/workModel'
import type { ModalMethods } from '@/components/Modal/types'
import { dayjs } from 'element-plus'
import type { VxeGridInstance, VxeGridProps } from 'vxe-table'
import type { GetEmployeeInfoBySelectModel, GetEmployeeInfoModel } from '@/api/sys/model/basicModel'

import { ref, reactive, computed } from 'vue'

import BasicModal from '@/components/Modal/BasicModal.vue'
import PersonSelect from '@/components/Form/components/PersonSelect/index.vue'
import PersonSelectDialog from '@/components/Form/components/PersonSelect/PersonSelectDialog.vue'
import Select from '@/components/Form/components/Select.vue'

import { useModal } from '@/components/Modal/hooks/useModal'
import { useModalInner } from '@/components/Modal/hooks/useModal'
import { workTypeOptions } from '../data'
import { addDispatchingOther } from '@/api/sys/work'

interface RowModel extends DispatchingOtherEmployee {
  employeeName: string
  employeeNo: string
  groupName: string
  transferInStatus: number
}

const emit = defineEmits<{
  register: [modalMethods: ModalMethods, uuid: number]
  success: []
}>()

const total = computed(() => gridRef.value?.getTableData().fullData.length || 0)

const [registerModal, { openModal: openPersonSelectModal }] = useModal()

const gridRef = ref<VxeGridInstance>()
const gridOptions = reactive<VxeGridProps<RowModel>>({
  border: true,
  height: '500px',
  align: null,
  columnConfig: {
    resizable: true
  },
  editConfig: {
    trigger: 'dblclick',
    mode: 'row',
    autoClear: false
  },
  editRules: {
    employeeInfoID: [{ required: true, trigger: 'manual', content: '请选择作业者' }],
    startDate: [{ required: true, trigger: 'manual', content: '请选择计划开始日期' }],
    workType: [{ required: true, trigger: 'manual', content: '请选择工作类别' }],
    dispatchingNumber: [{ required: true, trigger: 'manual', content: '请输入派工数量' }]
  },
  columns: [
    { type: 'seq', width: 50 },
    { field: 'employeeName', visible: false },
    { field: 'employeeNo', visible: false },
    {
      field: 'employeeInfoID',
      title: '作业者',
      minWidth: 200,
      editRender: {},
      slots: { default: 'employeeInfoID', edit: 'employeeInfoID_edit' }
    },
    {
      field: 'groupName',
      title: '班组',
      minWidth: 120
    },
    {
      field: 'startDate',
      title: '计划开始日期',
      minWidth: 180,
      editRender: {},
      slots: { edit: 'startDate_edit' }
    },
    {
      field: 'workType',
      title: '工作类别',
      minWidth: 130,
      editRender: {},
      slots: { edit: 'workType_edit' },
      formatter({ cellValue }) {
        return workTypeOptions.find((item) => item.value === Number(cellValue))?.label || ''
      }
    },
    {
      field: 'dispatchingNumber',
      title: '派工数量',
      minWidth: 160,
      editRender: {},
      slots: { edit: 'dispatchingNumber_edit' }
    },
    {
      field: 'workDescription',
      title: '工作描述',
      minWidth: 240,
      editRender: {},
      slots: { edit: 'workDescription_edit' }
    },
    {
      field: 'operation',
      title: '操作',
      align: 'center',
      fixed: 'right',
      width: 150,
      slots: {
        default: 'operation'
      }
    }
  ],
  pagerConfig: {
    enabled: false
  },
  data: []
})

const [registerInnerModal, { setModalProps }] = useModalInner(async () => {
  setModalProps({ confirmLoading: false })
})

// 关闭清空表格
const handleClose = () => {
  gridRef.value?.loadData([])
}

const handleAdd = () => {
  openPersonSelectModal()
}

const handleDelete = (row: RowModel) => {
  gridRef.value?.remove(row)
}

const handleEdit = async (row: RowModel) => {
  gridRef.value?.setEditRow(row)
}

const handleComplete = async () => {
  gridRef.value?.clearEdit()
  //   const errMap = await gridRef.value?.validate(row)
  //   if (errMap) {
  //     return
  //   }
}

const handleSuccess = ({ res }: { res: GetEmployeeInfoBySelectModel[] }) => {
  if (res.length > 0) {
    const records = res.map((item) => {
      const data: RowModel = {
        employeeInfoID: item.id,
        employeeNo: item.employeeNo,
        employeeName: item.employeeName,
        groupName: item.groupName,
        transferInStatus: item.transferInStatus,
        startDate: dayjs().format('YYYY-MM-DD'),
        workType: workTypeOptions[0].value,
        dispatchingNumber: 0
      }
      return data
    })
    gridRef.value?.insertAt(records, -1)
  }
  total
}

// 提交
const handleSubmit = async () => {
  const errMap = await gridRef.value?.validate()
  if (errMap) {
    return
  }
  try {
    setModalProps({ confirmLoading: true })
    // 新增
    const tableData = gridRef.value?.getTableData().fullData as RowModel[]
    const data: AddDispatchingOtherData = {
      dispatchingOtherEmployees: tableData
    }
    const { code, message } = await addDispatchingOther(data)
    if (code === 200) {
      ElMessage.success('新增成功')
      emit('success')
    } else {
      ElMessage.error(message)
    }
  } catch (error: any) {
    ElMessage(error.message)
  } finally {
    setModalProps({ confirmLoading: false })
  }
}
</script>

<style scoped></style>
