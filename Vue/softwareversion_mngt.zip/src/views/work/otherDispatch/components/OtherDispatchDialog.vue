<template>
  <BasicModal
    width="567px"
    v-bind="$attrs"
    @register="registerModal"
    title="编辑"
    @confirm="handleSubmit"
  >
    <BasicForm @register="registerForm"> </BasicForm>
  </BasicModal>
</template>

<script lang="ts" setup>
import type { ModalMethods } from '@/components/Modal/types'

import BasicModal from '@/components/Modal/BasicModal.vue'
import { useModalInner } from '@/components/Modal/hooks/useModal'
import BasicForm from '@/components/Form/BasicForm.vue'
import { useForm } from '@/components/Form/hooks/useForm'
import { ref } from 'vue'
import { workTypeOptions } from '../data'
import { updateDispatchingOther } from '@/api/sys/work'
import type { UpdateDispatchingOtherData } from '@/api/sys/model/workModel'

const emit = defineEmits<{
  register: [modalMethods: ModalMethods, uuid: number]
  success: []
}>()

const rowID = ref<string>('')
const viewOnly = ref<boolean>(false)

const [registerModal, { closeModal, setModalProps }] = useModalInner(async (data) => {
  resetFields()
  rowID.value = data.row.id
  viewOnly.value = !!data.isUpdate && data.row.orderStatus !== 0
  setFieldsValue({ ...data.row })
  setModalProps({ confirmLoading: false })
})

const [registerForm, { resetFields, getFieldsValue, validate, setFieldsValue }] = useForm({
  labelWidth: 120,
  schemas: [
    {
      field: 'employeeName',
      component: 'ElInput',
      label: '作业者',
      componentProps: {
        disabled: true,
        style: { width: '60%' }
      },
      colProps: {
        span: 24
      }
    },
    {
      field: 'groupName',
      component: 'ElInput',
      label: '班组',
      componentProps: {
        disabled: true,
        style: { width: '60%' }
      },
      colProps: {
        span: 24
      }
    },
    {
      field: 'workType',
      component: 'Select',
      label: '工作类型',
      required: true,
      dynamicDisabled() {
        return viewOnly.value
      },
      componentProps: {
        options: workTypeOptions,
        style: { width: '60%' }
      },
      colProps: {
        span: 24
      }
    },
    {
      field: 'dispatchingNumber',
      component: 'ElInputNumber',
      label: '派工数量',
      required: true,
      dynamicDisabled() {
        return viewOnly.value
      },
      componentProps: { style: { width: '60%' } },
      colProps: {
        span: 24
      }
    },

    {
      field: 'startDate',
      component: 'ElDatePicker',
      label: '计划开始日期',
      required: true,
      dynamicDisabled() {
        return viewOnly.value
      },
      componentProps: { style: { width: '60%' } },
      colProps: {
        span: 24
      }
    },
    {
      field: 'workDescription',
      component: 'ElInput',
      label: '工作描述',
      dynamicDisabled() {
        return viewOnly.value
      },
      componentProps: { type: 'textarea', rows: 3 },
      colProps: {
        span: 24
      }
    }
  ]
})

// 提交
const handleSubmit = async () => {
  await validate()
  setModalProps({ confirmLoading: true })
  try {
    const data = {
      id: rowID.value,
      ...getFieldsValue()
    } as UpdateDispatchingOtherData
    const { code, message } = await updateDispatchingOther(data)
    if (code === 200) {
      ElMessage.success('修改成功')
      closeModal()
      emit('success')
    } else {
      ElMessage.error(message)
    }
  } catch (error: any) {
    ElMessage(error.message)
  } finally {
    setModalProps({ confirmLoading: false })
  }
}
</script>

<style lang="scss" scoped></style>
