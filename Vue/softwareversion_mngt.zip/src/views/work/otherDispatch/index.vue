<template>
  <LayoutContainer>
    <template #leftSide>
      <basic-tree class="basic-list-wrapper" ref="basicTreeRef" v-bind="treeOptions" />
    </template>
    <div class="grid-container">
      <vxe-grid class="box" ref="gridRef" v-bind="gridOptions">
        <template #top>
          <GridHeader
            ref="gridHeaderRef"
            v-bind="headerOptions"
            @quickSearch="handleQuickSearch"
            @advancedSearch="handleAdvancedSearch"
            @reset="handleReset"
            @add="handleBatchAdd"
          >
          </GridHeader>
        </template>
        <template #orderStatus="{ row }">
          <el-tag :type="getOrderStatusInfo(row.orderStatus).type">
            {{ getOrderStatusInfo(row.orderStatus).text }}
          </el-tag>
        </template>
        <template #operation="{ row }">
          <TableAction
            :actions="[
              {
                tooltip: '编辑',
                icon: 'edit',
                onClick: handleModify.bind(null, row)
              },
              {
                icon: 'finish-wo-status',
                tooltip: '完成',
                ifShow: row.orderStatus === 1,
                onClick: handleComplete.bind(null, row)
              },
              {
                tooltip: '删除',
                icon: 'delete',
                ifShow: row.orderStatus === 0,
                onClick: handleDelete.bind(null, row)
              }
            ]"
          />
        </template>
      </vxe-grid>
    </div>
  </LayoutContainer>
  <OtherDispatchDialog @register="registerModal" @success="handleSuccess" />
  <BatchAdd @register="registerBatchAddModal" @success="handleBatchAddSuccess" />
</template>

<script setup lang="tsx">
import type { ComponentExposed } from 'vue-component-type-helpers'
import type { VxeGridInstance, VxeGridProps } from 'vxe-table'
import type { GridHeaderProps } from '@/components/Table/types/gridHeader'
import type { GetDispatchingOtherParams, GetDispatchingOtherModel } from '@/api/sys/model/workModel'
import type { TreeProps } from '@/components/Tree/types/tree'

import { computed, reactive, ref } from 'vue'
import { getDepartment, getKeyValue, getManufactureDepartment } from '@/api/sys/basic'
import {
  deleteDispatchingOther,
  exportDispatchingOther,
  getDispatchingOther,
  updateDispatchingOtherCompleted
} from '@/api/sys/work'

import { useModal } from '@/components/Modal/hooks/useModal'

import GridHeader from '@/components/Table/GridHeader.vue'
import OtherDispatchDialog from './components/OtherDispatchDialog.vue'
import BatchAdd from './components/BatchAdd.vue'

import dayjs from 'dayjs'
import { dateShortcuts } from '@/constant'
import { orderStatusList } from './data'

defineOptions({
  name: 'OtherDispatch',
  inheritAttrs: false
})
const treeParams = reactive({
  departmentId: '',
  groupId: ''
})
// 列表配置
const treeOptions = reactive<TreeProps>({
  api: getManufactureDepartment,
  title: '部门列表',
  labelField: 'name',
  resultField: 'data',
  childrenField: 'children',
  nodeKey: 'id',
  accordion: true,
  formatter({ data }) {
    return (
      <div>
        {data.label}&nbsp;&nbsp;({data.childrenCount})
      </div>
    )
  },
  cancleHightlightCurrent: true,
  onSelect: async (data, node) => {
    if (data) {
      headerOptions.title = `[${data.label}]其他派工`

      if (data.isGroup) {
        treeParams.departmentId = node.parent.data.id
        treeParams.groupId = data.id
      } else {
        treeParams.departmentId = data.id
        treeParams.groupId = ''
      }
      gridRef.value?.commitProxy('reload')
    } else {
      headerOptions.title = `其他派工`
      treeParams.departmentId = ''
      treeParams.groupId = ''
      gridRef.value?.remove()
    }
  }
})

const gridHeaderRef =
  ref<ComponentExposed<typeof GridHeader<GetDispatchingOtherParams, 'searchKey'>>>()

// const getDepartmentList = async () => {
//   const { code, data } = await getDepartment()
//   if (code === 200) {
//     gridHeaderRef.value?.updateAdvancedSearchForm([
//       {
//         field: 'departmentID',
//         componentProps: { options: data.result }
//       }
//     ])
//   }
// }

// getDepartmentList()

const headerOptions = reactive<GridHeaderProps>({
  title: '其他派工',
  quickSearch: {
    singleSearch: {
      field: 'searchKey',
      type: 'input',
      title: '工号/姓名'
    },
    searchFormFields: { searchKey: '' }
  },
  advancedSearch: {
    labelWidth: 120,
    fieldMapToTime: [['dataOfDispatch', ['startDate', 'endDate'], 'YYYY-MM-DD']],
    schemas: [
      {
        field: 'workType',
        label: '工种类别',
        component: 'Select',
        // defaultValue: [0, 1],
        componentProps: {
          options: orderStatusList
          // multiple: true
        },
        colProps: {
          span: 8
        }
      },
      // {
      //   field: 'departmentID',
      //   label: '部门',
      //   component: 'ElCascader',
      //   componentProps: {
      //     options: [],
      //     props: {
      //       label: 'departmentName',
      //       value: 'id',
      //       children: 'sonData',
      //       checkStrictly: true,
      //       emitPath: false
      //     },
      //     async onChange(departmentID: string) {
      //       gridHeaderRef.value?.setFieldsValue({ groupID: '' })
      //       gridHeaderRef.value?.updateAdvancedSearchForm({
      //         field: 'groupID',
      //         componentProps: { options: [] }
      //       })

      //       if (departmentID) {
      //         const { code, data } = await getGroupSelect({ departmentID })
      //         if (code === 200) {
      //           gridHeaderRef.value?.updateAdvancedSearchForm({
      //             field: 'groupID',
      //             componentProps: { options: data.result }
      //           })
      //         }
      //       }
      //     }
      //   },
      //   colProps: {
      //     span: 8
      //   }
      // },
      // {
      //   field: 'groupID',
      //   label: '组别',
      //   component: 'Select',
      //   componentProps: {
      //     options: []
      //   },
      //   colProps: {
      //     span: 8
      //   }
      // },
      {
        field: 'orderStatusArray',
        label: '状态',
        component: 'Select',
        defaultValue: [0, 1],
        componentProps: {
          options: orderStatusList,
          multiple: true
        },
        colProps: {
          span: 8
        }
      },
      {
        field: 'dataOfDispatch',
        label: '计划开始日期',
        component: 'ElDatePicker',
        componentProps: {
          type: 'daterange',
          unlinkPanels: true,
          shortcuts: dateShortcuts,
          valueFormat: 'YYYY-MM-DD'
        },
        colProps: {
          span: 8
        }
      },
      {
        field: 'workDescription',
        label: '工作描述',
        component: 'ElInput',
        componentProps: {},
        colProps: {
          span: 8
        }
      },
      {
        field: 'positionClassifyID',
        component: 'ApiSelect',
        label: '工种',
        // defaultValue: [0, 1],
        componentProps: {
          api: getKeyValue,
          labelField: 'value',
          valueField: 'id',
          resultField: 'data.result',
          multiple: true,
          params: {
            typeName: 'PositionClassify'
          }
        },
        colProps: {
          span: 8
        }
      }
    ]
  },
  showExportButton: true,
  exportApi: exportDispatchingOther,
  exportParams: computed(() => {
    const advancedSearchForm = gridHeaderRef.value?.advancedSearchForm
    const quickSearchForm = gridHeaderRef.value?.quickSearchForm
    return { ...quickSearchForm, ...advancedSearchForm }
  })
})

const getOrderStatusInfo = computed(() => {
  const statusMap: { [key: number]: { text: string; type: string } } = {}
  orderStatusList.forEach((item) => {
    statusMap[item.value] = { text: item.label, type: item.type }
  })

  return function (status: number) {
    return statusMap[status] || { text: '', color: '' }
  }
})

const gridRef = ref<VxeGridInstance>()
const gridOptions = reactive<VxeGridProps<GetDispatchingOtherModel>>({
  border: true,
  height: 'auto',
  align: null,
  columnConfig: {
    resizable: true
  },
  columns: [
    { type: 'seq', width: 50 },
    {
      field: 'employeeName',
      title: '作业者',
      minWidth: 140,
      formatter({ row }) {
        return `${row.employeeNo}-${row.employeeName}`
      }
    },
    { field: 'groupName', title: '班组', minWidth: 140 },
    { field: 'workTypeName', title: '工作类型', minWidth: 100 },
    {
      field: 'startDate',
      title: '计划开始日期',
      minWidth: 120,
      formatter({ cellValue }) {
        return dayjs(cellValue).format('YYYY/MM/DD')
      }
    },
    { field: 'dispatchingNumber', title: '派工数量', minWidth: 90 },
    { field: 'workDescription', title: '工作描述', minWidth: 200 },
    { field: 'takeTime', title: '总用时', minWidth: 70 },
    {
      field: 'reportDate',
      title: '报工日期',
      minWidth: 160
      // formatter({ cellValue }) {
      //   return cellValue
      //   // return dayjs(cellValue).format('YYYY-MM-DD')
      // }
    },
    {
      field: 'orderStatus',
      title: '状态',
      width: 90,
      slots: { default: 'orderStatus' }
    },
    // { field: 'lastModifiedUserName', title: '操作人', minWidth: 90 },
    // { field: 'lastModifiedTime', title: '最后更新时间', minWidth: 150 },
    {
      field: 'operation',
      title: '操作',
      align: 'center',
      fixed: 'right',
      minWidth: 180,
      slots: {
        default: 'operation'
      }
    }
  ],
  pagerConfig: {
    enabled: true,
    pageSize: 20
  },
  proxyConfig: {
    ajax: {
      query: ({ page }) => {
        const quickSearchForm = gridHeaderRef.value?.quickSearchForm
        const advancedSearchForm = gridHeaderRef.value?.advancedSearchForm
        return getDispatchingOther({
          pageIndex: page.currentPage - 1, // 由于后端接口限制，首页从0开始
          pageSize: page.pageSize,
          ...treeParams,
          ...quickSearchForm,
          ...advancedSearchForm
        })
      }
    }
  }
})

const handleQuickSearch = () => {
  gridRef.value?.commitProxy('reload')
}

const handleAdvancedSearch = () => {
  gridRef.value?.commitProxy('reload')
}

const handleReset = () => {
  gridRef.value?.commitProxy('reload')
}

const [registerModal, { openModal, closeModal }] = useModal()

const handleModify = (row: GetDispatchingOtherModel) => {
  openModal(true, {
    isUpdate: true,
    row
  })
}

const handleSuccess = () => {
  gridRef.value?.commitProxy('query')
  closeModal()
}

const handleDelete = (row: GetDispatchingOtherModel) => {
  ElMessageBox.confirm(`是否删除名称为"${row.employeeName}"的数据项`, '警告', {
    confirmButtonText: '确定',
    cancelButtonText: '取消',
    type: 'warning'
  }).then(async () => {
    const { code, data, message } = await deleteDispatchingOther({
      id: row.id
    })
    if (code === 200 && data) {
      ElMessage.success('删除成功')
      gridRef.value?.commitProxy('query')
    } else {
      ElMessage.error(message)
    }
  })
}

const [registerBatchAddModal, { openModal: openBatchAddModal, closeModal: closeBatchAddModal }] =
  useModal()

const handleBatchAdd = () => {
  openBatchAddModal(true, {
    isUpdate: false
  })
}

const handleBatchAddSuccess = () => {
  gridRef.value?.commitProxy('query')
  closeBatchAddModal()
}

const handleComplete = (row: GetDispatchingOtherModel) => {
  const $grid = gridRef.value
  ElMessageBox.confirm(`注意：完成后该派工单将不能再报工，是否继续？`, '提示', {
    confirmButtonText: '确定',
    cancelButtonText: '取消',
    type: 'warning'
  }).then(() => {
    if ($grid) {
      updateDispatchingOtherCompleted({ id: row.id }).then(({ code, message }) => {
        if (code === 200) {
          $grid?.commitProxy('query')
        } else {
          ElMessage.error(message)
        }
      })
    }
  })
}
</script>

<style lang="scss" scoped>
.grid-container {
  height: 100%;
  padding: $margin $margin $margin 0;
}
</style>
