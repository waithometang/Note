<template>
  <vxe-grid ref="workReportGridRef" v-bind="workReportGridOptions">
    <template #top>
      <GridHeader
        ref="workReportGridHeaderRef"
        v-bind="workReportHeaderOptions"
        v-on="workReportHeaderEvent"
      />
    </template>
    <template #operation="{ row }">
      <TableAction
        :actions="[
          {
            icon: 'work-report',
            tooltip: '报工',
            onClick: handleWorkReport.bind(null, row),
            ifShow: !hasActiveEditRow(row, workReportGridRef) && row.id === '0'
          },
          {
            icon: 'edit-inline',
            tooltip: '编辑',
            onClick: handleWorkReport.bind(null, row),
            ifShow: !hasActiveEditRow(row, workReportGridRef) && row.id !== '0'
          },
          {
            icon: 'save',
            tooltip: '保存',
            onClick: handleConfirm.bind(null, row, workReportGridRef),
            ifShow: hasActiveEditRow(row, workReportGridRef)
          },
          {
            icon: 'cancle',
            tooltip: '取消',
            onClick: handleCancle.bind(null, row, workReportGridRef),
            ifShow: hasActiveEditRow(row, workReportGridRef)
          },
          {
            icon: 'finish-wo-status',
            tooltip: '组长确认',
            onClick: handleGroupLeaderConfirm.bind(null, row),
            ifShow: () => row.orderStatus === 1
          },
          {
            icon: 'close-wo-status',
            tooltip: '作废',
            onClick: handleCancel.bind(null, row),
            ifShow: function () {
              return [1, 2].includes(row.orderStatus)
            }
          }
        ]"
      />
    </template>

    <!-- <template #bottom>
      <TableAction
        style="margin-top: 16px"
        :actions="[
          {
            icon: 'plus',
            label: '新增行',
            onClick: handleAdd.bind(null),
            style: {
              color: '#008cd6'
            }
          }
        ]"
      ></TableAction>
    </template> -->
  </vxe-grid>

  <GroupLeaderConfirmDialog
    @register="registerGroupLeaderConfirmModal"
    @success="handleGroupLeaderConfirmSuccess"
  />
</template>

<script lang="tsx" setup>
import type { ComponentExposed } from 'vue-component-type-helpers'
import type { PropType } from 'vue'
import type { GetScheduleModel } from '@/api/sys/model/basicModel'
import type {
  GetReportWorkParams,
  GetOtherReportWorkModel,
  GetReportWorkEmployeeModel,
  GetEmployeeStatusModel,
  GetOtherReportWorkDetailModel,
  GetDispatchingOtherModel
} from '@/api/sys/model/workModel'
import type GridHeader from '@/components/Table/GridHeader.vue'
import type { GridHeaderEvent, GridHeaderProps } from '@/components/Table/types/gridHeader'
import type { VxeGridInstance, VxeGridProps } from 'vxe-table'

import { computed, reactive, ref, toRefs, watch, unref } from 'vue'
import dayjs from 'dayjs'
import { ElInput, ElInputNumber, ElTimePicker, ElTooltip } from 'element-plus'
import { isNumber } from '@/utils/is'
import Select from '@/components/Form/components/Select.vue'
import { useModal } from '@/components/Modal/hooks/useModal'
import GroupLeaderConfirmDialog from './GroupLeaderConfirmDialog.vue'

import { getScheduleSelectALL } from '@/api/sys/basic'
import {
  getOtherReportWork,
  getOtherReportWorkDetail,
  getReportWorkEmployee,
  updateOtherReportWorkState,
  getOtherReportWorkEmployeeStatus
} from '@/api/sys/work'
import { scheduleTypeOptions } from '@/views/work/workReport/data'
import { addOtherReportWork } from '@/api/sys/work'
import { updateOtherReportWork } from '@/api/sys/work'

const props = defineProps({
  activeRow: {
    type: Object as PropType<GetDispatchingOtherModel>,
    default: () => {
      return {}
    }
  },
  isConfirmStatus: {
    type: Boolean,
    default: false
  }
})
const { activeRow, isConfirmStatus } = toRefs(props)

// 作业班次
const scheduleOptions = ref<GetScheduleModel[]>([])
const getScheduleOptions = async () => {
  const { data } = await getScheduleSelectALL()
  scheduleOptions.value = data.result
}
getScheduleOptions()

// 派工单关联人员
const reportWorkEmployeeOptions = ref<GetReportWorkEmployeeModel[]>([])
const getReportWorkEmployeeOptions = async () => {
  const { data } = await getReportWorkEmployee({ dispatchingGroupID: unref(activeRow).id })
  reportWorkEmployeeOptions.value = data
}

// 处理休息时间改变
const handleRestTimeChange = (row: GetOtherReportWorkModel, restTime?: number) => {
  const { startTime, endTime, scheduleType } = row
  if (scheduleType === 2 && startTime && endTime) {
    if (isNumber(restTime)) {
      // 假设日期都为当前日期
      const currentDate = dayjs().format('YYYY-MM-DD')
      let startTime = dayjs(currentDate + ' ' + row.startTime)
      let endTime = dayjs(currentDate + ' ' + row.endTime)

      // 如果 endTime 小于 startTime，则表示跨天，需要加一天
      if (endTime.isBefore(startTime)) {
        endTime = endTime.add(1, 'day')
      }

      const takeTime = Number(
        (Math.abs(Number((startTime.diff(endTime, 'minute') / 60).toFixed(1))) - restTime).toFixed(
          1
        )
      )
      row.takeTime = takeTime
    } else {
      row.takeTime = 0
    }
  }
}

const getDispatchOrderStatusInfo = computed(() => {
  const statusMap: { [key: number]: { text: string; type: string } } = {
    0: { text: '未报工', type: 'error' },
    1: { text: '未确认', type: 'warning' },
    2: { text: '已确认', type: 'success' },
    4: { text: '无需报工', type: 'info' }
  }

  return function (status: number) {
    return statusMap[status] || { text: '', color: '' }
  }
})

const workReportGridRef = ref<VxeGridInstance>()
const workReportGridOptions = reactive<VxeGridProps<GetOtherReportWorkModel>>({
  border: true,
  height: '400px',
  align: null,
  keepSource: true,
  editConfig: {
    trigger: 'manual',
    mode: 'row',
    showStatus: true,
    autoClear: false,
    showUpdateStatus: true,
    showAsterisk: false // 是否显示必填字段的红色星号
  },
  editRules: {
    restTime: [{ required: true, content: '不能为空或小于0', type: 'number', min: 0 }],
    scheduleID: [
      {
        required: true,
        content: '请选择班次',
        validator({ row }) {
          if (row.scheduleType === 2) {
            if (!row.workTime) {
              return Promise.reject('请选择班次')
            }
          } else {
            if (!row.scheduleID) {
              return Promise.reject('请选择班次')
            }
          }
        }
      }
    ]
  },
  columnConfig: {
    resizable: true
  },
  columns: [
    { type: 'seq', width: 50 },
    {
      field: 'employeeInfoID',
      title: '作业者',
      minWidth: 150,
      slots: {
        default({ row }) {
          return (
            <div>
              {row.employeeNo}-{row.employeeName}
            </div>
          )
        }
      }
    },
    {
      field: 'orderStatus', //2：请假；3：休息；4：离职；6：缺勤；8：旷工 禁用其他配置项
      title: '状态',
      width: 180,
      headerAlign: 'center',
      slots: {
        default({ row }) {
          return (
            <div style="display: flex; align-items: center">
              {/* 借调状态 */}
              {row.transferInStatus === 1 && row.attendanceStatus === 1 && (
                <el-tag type="warning" size="small" effect="plain" style="margin-left: 5px">
                  {row.transferInStatusName}
                </el-tag>
              )}
              {/* 考勤状态 异常时显示 */}
              {[2, 3, 4, 6, 8].includes(row.attendanceStatus) && (
                <el-tag type="warning" size="small" effect="plain" style="margin-left: 5px">
                  {row.attendanceStatusName}
                </el-tag>
              )}
              {/* 报工单状态（0：未报工；1：未确认；2：已确认；4：无需报工）*/}
              {[1, 2, 4].includes(row.orderStatus) && (
                <el-tag
                  style="margin-left: 5px"
                  type={getDispatchOrderStatusInfo.value(row.orderStatus).type}
                >
                  {getDispatchOrderStatusInfo.value(row.orderStatus).text}
                </el-tag>
              )}
            </div>
          )
        }
      }
    },
    {
      field: 'finishCount',
      title: '报工数量',
      width: 150,
      editRender: {},
      slots: {
        edit({ row }) {
          return (
            <ElTooltip
              visible={workReportGridRef.value?.isEditByRow(row)}
              effect="dark"
              placement="top"
            >
              {{
                content: () => (
                  <>
                    派工数量 {reportWorkDetail.value?.dispatchingNumber},可填
                    {reportWorkDetail.value?.maxFinishCount}
                  </>
                ),
                default: () => (
                  <>
                    <ElInputNumber
                      style={'width: 100%'}
                      v-model={row.finishCount}
                      disabled={[2, 3, 4, 6, 8].includes(row.attendanceStatus)}
                      min={0}
                      max={999999}
                      step={0.1}
                      stepStrictly={true}
                    />
                  </>
                )
              }}
            </ElTooltip>
          )
        }
      }
    },
    {
      field: 'scheduleType',
      title: '班次类型',
      width: 120,
      editRender: {},
      slots: {
        default({ row }) {
          return scheduleTypeOptions.find((option) => option.value === row.scheduleType)?.label
        },
        edit({ row }) {
          return (
            <>
              <Select
                style={'width: 100%'}
                v-model={row.scheduleType}
                options={scheduleTypeOptions}
                onChange={() => {
                  row.scheduleID = undefined
                  row.workTime = undefined
                  row.restTime = 0
                  row.takeTime = 0
                }}
                disabled={[2, 3, 4, 6, 8].includes(row.attendanceStatus)}
              ></Select>
            </>
          )
        }
      }
    },
    {
      field: 'scheduleID',
      title: '作业班次',
      width: 250,
      editRender: {},
      slots: {
        default({ row }) {
          return (
            unref(scheduleOptions).find((option) => option.value === row.scheduleType)?.label ||
            row.startTime + '-' + row.endTime
          )
        },
        edit({ row }) {
          return (
            <>
              {row.scheduleType === 1 ? (
                <Select
                  style={'width: 100%'}
                  v-model={row.scheduleID}
                  options={scheduleOptions.value}
                  labelField={'scheduleTime'}
                  valueField={'id'}
                  onChange={(value: number, option: any) => {
                    if (option) {
                      row.takeTime = option.workTime
                      row.restTime = option.restTime
                    }
                  }}
                  slots={{
                    default: ({ option }: { option: any }) => {
                      return <>{option.scheduleTime}</>
                    }
                  }}
                  disabled={[2, 3, 4, 6, 8].includes(row.attendanceStatus)}
                ></Select>
              ) : (
                <div style="display:flex;align-items: center;">
                  <ElTimePicker
                    v-model={row.startTime}
                    style={'width: 150px;'}
                    format={'HH:mm'}
                    value-format={'HH:mm'}
                    onChange={(value: string) => {
                      /**
                       * 处理自定义班次计算
                       */
                      const { restTime } = row

                      // 假设日期都为当前日期
                      const currentDate = dayjs().format('YYYY-MM-DD')
                      const startTime = dayjs(currentDate + ' ' + row.startTime)
                      let endTime = dayjs(currentDate + ' ' + value)

                      if (row.startTime && row.endTime) {
                        // 如果 endTime 小于 startTime，则表示跨天，需要加一天
                        if (endTime.isBefore(startTime)) {
                          endTime = endTime.add(1, 'day')
                        }

                        if (isNumber(restTime)) {
                          const takeTime = Number(
                            (
                              Math.abs(
                                Number((startTime.diff(endTime, 'minute') / 60).toFixed(1))
                              ) - restTime
                            ).toFixed(1)
                          )
                          row.takeTime = takeTime
                        } else {
                          row.takeTime = undefined
                        }
                      }
                    }}
                    disabled={[2, 3, 4, 6, 8].includes(row.attendanceStatus)}
                  ></ElTimePicker>
                  -
                  <ElTimePicker
                    v-model={row.endTime}
                    style={'width: 150px;'}
                    format={'HH:mm'}
                    value-format={'HH:mm'}
                    onChange={(value: string) => {
                      /**
                       * 处理自定义班次计算
                       */
                      const { restTime } = row

                      // 假设日期都为当前日期
                      const currentDate = dayjs().format('YYYY-MM-DD')
                      const startTime = dayjs(currentDate + ' ' + row.startTime)
                      let endTime = dayjs(currentDate + ' ' + value)

                      // 如果 endTime 小于 startTime，则表示跨天，需要加一天
                      if (endTime.isBefore(startTime)) {
                        endTime = endTime.add(1, 'day')
                      }

                      if (row.startTime && row.endTime) {
                        if (isNumber(restTime)) {
                          const takeTime = Number(
                            (
                              Math.abs(
                                Number((startTime.diff(endTime, 'minute') / 60).toFixed(1))
                              ) - restTime
                            ).toFixed(1)
                          )
                          row.takeTime = takeTime
                        } else {
                          row.takeTime = undefined
                        }
                      }
                    }}
                    disabled={[2, 3, 4, 6, 8].includes(row.attendanceStatus)}
                  ></ElTimePicker>
                </div>
              )}
            </>
          )
        }
      }
    },
    {
      field: 'restTime',
      title: '休息用时(h)',
      width: 130,
      editRender: {},
      slots: {
        default({ row }) {
          return typeof row.restTime === 'number' ? `${row.restTime}h` : ''
        },
        edit({ row }) {
          return (
            <>
              <ElInputNumber
                style={'width: 100%'}
                v-model={row.restTime}
                disabled={row.scheduleType === 1 || [2, 3, 4, 6, 8].includes(row.attendanceStatus)}
                onChange={(value: number) => {
                  handleRestTimeChange(row, value)
                }}
              ></ElInputNumber>
            </>
          )
        }
      }
    },
    {
      field: 'takeTime',
      title: '作业用时(h)',
      width: 125,
      formatter({ cellValue }) {
        return typeof cellValue === 'number' ? `${cellValue}h` : ''
      }
    },
    {
      field: 'workDescription',
      title: '备注',
      width: 150,
      editRender: {},
      slots: {
        edit({ row }) {
          return <ElInput v-model={row.workDescription} />
        }
      }
    },
    { field: 'createUserName', title: '录入人', width: 100 },

    {
      field: 'operation',
      title: '操作',
      align: 'center',
      fixed: 'right',
      width: 200,
      slots: {
        default: 'operation'
      }
    }
  ],
  pagerConfig: {
    enabled: false,
    pageSize: 20
  },
  proxyConfig: {
    autoLoad: false,
    ajax: {
      query: () => {
        return new Promise((resovle) => {
          // const reportWorkTime =
          //   unref(workReportGridHeaderRef.value?.quickSearchForm)?.reportWorkTime || ''
          const dispatchingID = unref(activeRow)?.id || ''
          getOtherReportWork({
            pageIndex: 0,
            pageSize: 99999,
            reportWorkTime:
              unref(workReportGridHeaderRef.value?.quickSearchForm)?.reportWorkTime || '',
            dispatchingID: dispatchingID,
            isConfirmStatus: unref(isConfirmStatus)
          }).then((res) => {
            resovle(res.data)
          })
        })
      }
    }
  }
})

const workReportGridHeaderRef =
  ref<ComponentExposed<typeof GridHeader<GetReportWorkParams, 'reportWorkTime'>>>()

const workReportHeaderOptions = reactive<GridHeaderProps>({
  title: '其他报工',
  quickSearch: {
    singleSearch: {
      field: 'reportWorkTime',
      type: 'date',
      title: '报工时间',
      showTitle: true
    },
    searchFormFields: { reportWorkTime: dayjs().format('YYYY-MM-DD') }
  },
  // showAddButton: false,
  showAdvancedSearchButton: false
})

const workReportHeaderEvent: GridHeaderEvent = {
  quickSearch() {
    if (Object.keys(activeRow.value).length) {
      workReportGridRef.value?.commitProxy('reload')
    } else {
      ElMessage.warning('请选择其他派工')
    }
  },
  advancedSearch() {
    if (Object.keys(activeRow.value).length) {
      workReportGridRef.value?.commitProxy('reload')
    } else {
      ElMessage.warning('请选择其他派工')
    }
  },
  reset() {
    if (Object.keys(activeRow.value).length) {
      workReportGridRef.value?.commitProxy('reload')
    } else {
      ElMessage.warning('请选择其他派工')
    }
  },
  add() {
    if (Object.keys(activeRow.value).length) {
      handleAdd()
    } else {
      ElMessage.warning('请选择其他派工')
    }
  }
}

// 判断是否编辑活跃行
const hasActiveEditRow = (row: GetOtherReportWorkModel, $grid?: VxeGridInstance): boolean => {
  if ($grid) {
    return $grid.isEditByRow(row)
  }
  return false
}
// 保存
const handleConfirm = async (row: GetOtherReportWorkModel, $grid?: VxeGridInstance) => {
  // const $grid = workPlanGridRef.value
  const errMap = await $grid?.validate()
  if (errMap) {
    return
  }
  if ($grid) {
    const insertRecords = $grid.getInsertRecords()
    const updateRecords = $grid.getUpdateRecords()

    if (updateRecords.length === 0) {
      $grid.clearEdit()
    }

    // 后端逻辑让使用'0'判断是否为新增报工
    if ((row.id === '0' && updateRecords.length) || (!row.id && insertRecords.length)) {
      const addRow = insertRecords[0] || updateRecords[0]
      const { code, message } = await addOtherReportWork({
        ...addRow,
        reportWorkTime: unref(workReportGridHeaderRef.value?.quickSearchForm)?.reportWorkTime,
        dispatchingID: unref(activeRow).id
      })

      if (code === 200) {
        ElMessage.success('新增成功')
        await $grid.clearEdit()
        workReportGridRef.value?.commitProxy('reload')
      } else {
        ElMessage.error(message)
      }
    } else if (row.id !== '0' && updateRecords.length) {
      const updateRow = updateRecords[0]

      const { code, message } = await updateOtherReportWork({
        ...updateRow,
        reportWorkTime: unref(workReportGridHeaderRef.value?.quickSearchForm)?.reportWorkTime
      })

      if (code === 200) {
        ElMessage.success('修改成功')
        await $grid.clearEdit()
        workReportGridRef.value?.commitProxy('reload')
      } else {
        ElMessage.error(message)
      }
    }
  }
}
// 取消
const handleCancle = (row: GetOtherReportWorkModel, $grid?: VxeGridInstance) => {
  $grid?.commitProxy('reload')
}

const [registerGroupLeaderConfirmModal, { openModal: openGroupLeaderConfirmModal }] = useModal()
// 组长确认
const handleGroupLeaderConfirm = async (row: GetOtherReportWorkModel) => {
  openGroupLeaderConfirmModal(true, {
    row,
    isOtherReport: false
  })
}
// 组长确认成功回调
const handleGroupLeaderConfirmSuccess = () => {
  workReportGridRef.value?.commitProxy('reload')
}

// 作废
const handleCancel = (row: GetOtherReportWorkModel) => {
  ElMessageBox.confirm(
    `是否作废名称为"${row.employeeNo + '-' + row.employeeName}"的数据项?`,
    '警告',
    {
      confirmButtonText: '确定',
      cancelButtonText: '取消',
      type: 'warning'
    }
  )
    .then(async () => {
      const { status, message } = await updateOtherReportWorkState({
        id: row.id!,
        orderStatus: 3
      })
      if (status) {
        ElMessage.success('作废成功')
      } else {
        ElMessage.error(message)
      }
    })
    .catch(() => {})
    .finally(() => {
      workReportGridRef.value?.commitProxy('reload')
    })
}

// 新增报工单
const handleAdd = async () => {
  const $grid = workReportGridRef.value

  const insertRecords = $grid?.getInsertRecords()
  if (insertRecords?.length) {
    return
  }

  if ($grid) {
    const { row: newRow } = await $grid.insertAt(
      {
        isAdd: true,
        employeeInfoID: unref(activeRow).employeeInfoID,
        employeeNo: unref(activeRow).employeeNo,
        employeeName: unref(activeRow).employeeName,
        scheduleType: 1, // 正常班次
        attendanceStatus: unref(employeeStatus)?.attendanceStatus,
        attendanceStatusName: unref(employeeStatus)?.attendanceStatusName,
        transferInStatus: unref(employeeStatus)?.transferInStatus,
        transferInStatusName: unref(employeeStatus)?.transferInStatusName,
        finishCount: 0
      },
      -1
    )

    await $grid.setEditRow(newRow)

    // 获取其他报工统计详情数据
    const { data } = await getOtherReportWorkDetail({
      dispatchingID: unref(activeRow)?.id
    })
    reportWorkDetail.value = data
  }
}

const reportWorkDetail = ref<GetOtherReportWorkDetailModel>()
// 报工
const handleWorkReport = async (row: GetOtherReportWorkModel) => {
  const $grid = workReportGridRef.value
  if ($grid) {
    const editRecord = $grid.getEditRecord()
    if (editRecord) {
      const { row } = editRecord
      await $grid.revertData(row)
    }
    if (row.scheduleType === 2) {
      row.workTime = [
        dayjs().format('YYYY/MM/DD') + ' ' + row.startTime,
        dayjs().format('YYYY/MM/DD') + ' ' + row.endTime
      ]
    }
    $grid.setEditRow(row)
    const { data } = await getOtherReportWorkDetail({
      dispatchingID: unref(activeRow)?.id,
      reportWorkID: row.id
    })
    reportWorkDetail.value = data
  }
}

const employeeStatus = ref<GetEmployeeStatusModel>()
// 处理员工选择确定
const getEmployeeStatus = async (data: GetDispatchingOtherModel) => {
  const quickSearchForm = unref(workReportGridHeaderRef.value?.quickSearchForm)!
  const reportWorkTime = quickSearchForm.reportWorkTime ?? ''
  const { data: employeeStatusData } = await getOtherReportWorkEmployeeStatus({
    employeeInfoID: data.employeeInfoID,
    reportWorkTime: reportWorkTime
  })

  employeeStatus.value = employeeStatusData
}

const reloadData = async () => {
  await workReportGridRef.value?.commitProxy('reload')
}

const removeData = () => {
  workReportGridRef.value?.remove()
}

watch(activeRow, async (newActiveRow) => {
  await reloadData()

  const $grid = workReportGridRef.value

  if (newActiveRow) {
    getReportWorkEmployeeOptions()
    workReportHeaderOptions.title = `[${
      newActiveRow.employeeNo + '-' + newActiveRow.employeeName
    }]其他报工`
    getEmployeeStatus(newActiveRow)
    if ($grid) {
      const { tableData } = $grid.getTableData()
      if (tableData?.length === 0) {
        handleAdd()
      }
    }
  } else {
    workReportHeaderOptions.title = `其他报工`
    reportWorkDetail.value = undefined
  }
})

defineExpose({
  reloadData,
  removeData
})
</script>

<style lang="scss" scoped></style>
