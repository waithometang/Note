<template>
  <BasicModal
    width="40%"
    v-bind="$attrs"
    @register="registerModal"
    title="组长确认"
    @confirm="handleSubmit"
  >
    <BasicForm @register="registerForm" />
  </BasicModal>
</template>

<script lang="tsx" setup>
import type { ModalMethods } from '@/components/Modal/types'
import type { GetEmployeeInfoModel } from '@/api/sys/model/basicModel'

import { ref } from 'vue'

import { useForm } from '@/components/Form/hooks/useForm'
import { useModalInner } from '@/components/Modal/hooks/useModal'
import {
  addOtherReportWorkProductionPerformance,
  getPerformanceStandard,
  getProductionPerformanceByEmployee,
  updateDispatchingOtherCompleted
} from '@/api/sys/work'
import { unref } from 'vue'
import { error } from '@/utils/log'

import { OrderStatus } from './data'
import dayjs from 'dayjs'
const emit = defineEmits<{
  register: [modalMethods: ModalMethods, uuid: number]
  success: []
}>()

type FormData = {
  employeeInfoID: string
  performanceLevel: string
}

const rowId = ref('')
const reportWorkTime = ref('')
const performanceLevel = ref('')
const [registerModal, { closeModal, setModalProps, changeOkLoading }] = useModalInner(
  async (data) => {
    resetFields()
    setModalProps({ confirmLoading: false })
    rowId.value = data.row.id
    reportWorkTime.value = data.row.reportWorkTime

    const fieldValues = {
      ...data.row
      // performanceLevel: unref(performanceLevel)
    }

    if (fieldValues.performanceLevel === '') {
      delete fieldValues.performanceLevel
    }
    setFieldsValue(fieldValues)
  }
)

const [registerForm, { setFieldsValue, resetFields, getFieldsValue, validate, updateSchema }] =
  useForm({
    labelWidth: 120,
    schemas: [
      {
        field: 'employeeInfoID',
        component: 'PersonSelect',
        label: '作业者',
        componentProps: {
          disabled: true,
          formatter(data: GetEmployeeInfoModel) {
            return data.employeeNo + '-' + data.employeeName
          }
        },
        colProps: {
          span: 24
        }
      },
      {
        field: 'performanceLevel',
        component: 'ApiSelect',
        label: '绩效等级',
        defaultValue: 'A',
        componentProps({ formModel }) {
          return {
            api: getPerformanceStandard,
            resultField: 'data',
            labelField: 'performanceLevel',
            valueField: 'performanceLevel',
            // onOptionsChange(options: any) {
            //   if (options.length) {
            //     const firstValue = options[0].value
            //     formModel.performanceLevel = firstValue
            //     performanceLevel.value = firstValue
            //   }
            // },
            slots: {
              default({ option }: { option: any }) {
                return (
                  <>
                    <span style="float: left">{option.label}</span>
                    <span
                      style="
                    float: right;
                    color: #000;
                    font-size: 13px;
                  "
                    >
                      绩效分： {option.performanceMark}
                    </span>
                  </>
                )
              }
            }
          }
        },
        colProps: {
          span: 24
        }
      }
    ]
  })

/**
 * 检查指定员工和日期的绩效记录
 */
const checkProductionPerformance = async (formData: FormData) => {
  const { code, message, data } = await getProductionPerformanceByEmployee({
    employeeID: formData.employeeInfoID,
    assessmentTime: reportWorkTime.value
  })

  if (code === 200) {
    /**
     * 如接口返回id不等于0表示已存在数据，
     * 则显示确认框：{beAssessorName}在{assessmentTime：年月日}已由班组{groupName}填写绩效数据，是否覆盖?。
     * 选是则调用添加绩效接口
     */
    if (data.id !== '0') {
      const { beAssessorName, assessmentTime, groupName } = data
      try {
        await ElMessageBox.confirm(
          `${beAssessorName}在${dayjs(assessmentTime).format(
            'YYYY-MM-DD'
          )}已由班组【${groupName}】填写绩效数据，是否覆盖?`,
          '提示',
          {
            confirmButtonText: '确定',
            cancelButtonText: '取消',
            type: 'warning'
          }
        )
      } catch {
        return Promise.resolve(false)
      }
    }
    return Promise.resolve(true)
  } else {
    throw new Error(message)
  }
}

const handleSubmit = async () => {
  try {
    changeOkLoading(true)

    const bodyData = getFieldsValue() as FormData

    const flag = await checkProductionPerformance(bodyData)
    if (!flag) {
      return
    }

    const { status, message, data } = await addOtherReportWorkProductionPerformance({
      id: unref(rowId),
      ...bodyData
    })
    if (status) {
      ElMessage.success('组长确认成功')
      emit('success')
      closeModal()

      if (data.orderStatus === OrderStatus.complete) {
        ElMessageBox.confirm(`所有其他报工已完成,是否要结束该其他派工单?`, '警告', {
          confirmButtonText: '确定',
          cancelButtonText: '取消',
          type: 'warning'
        }).then(async () => {
          try {
            const { status, message } = await updateDispatchingOtherCompleted({ id: unref(rowId) })

            if (status) {
              ElMessage.success('结束其他派工单成功')
            } else {
              ElMessage.error(message)
            }
          } catch (err: any) {
            error(err.message)
            ElMessage.error(err.message)
          }
        })
      }
    } else {
      ElMessage.error(message)
    }
  } catch (error: any) {
    ElMessage(error.message)
  } finally {
    changeOkLoading(false)
  }
}
</script>

<style lang="scss" scoped></style>
