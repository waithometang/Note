
export const workTypeOptions = [
  { label: '培训', value: 4 },
  { label: '6S', value: 5 },
  { label: '其他', value: 6 }
]

export const orderStatusList = [
  { label: '未报工', value: 0, type: 'warning' },
  { label: '报工中', value: 1, type: '' },
  { label: '已完工', value: 2, type: 'info' }
]
