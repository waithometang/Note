<template>
  <LayoutContainer>
    <template #leftSide>
      <basic-tree class="basic-list-wrapper" ref="basicTreeRef" v-bind="treeOptions" />
    </template>
    <el-scrollbar class="table-wrapper">
      <div class="grid-container">
        <vxe-grid ref="gridRef" class="box" v-bind="gridOptions" v-on="gridEvents">
          <template #top>
            <GridHeader ref="gridHeaderRef" v-bind="headerOptions" v-on="headerEvent"> </GridHeader>
          </template>
        </vxe-grid>

        <div class="box child-grid-container">
          <OtherWorkReportGrid
            ref="otherWorkReportGridRef"
            :activeRow="activeRow"
            :isConfirmStatus="isConfirmStatus"
          />
        </div>
      </div>
    </el-scrollbar>
  </LayoutContainer>
</template>

<script lang="tsx" setup>
import type { ComponentExposed } from 'vue-component-type-helpers'
import type { GetDispatchingOtherParams, GetDispatchingOtherModel } from '@/api/sys/model/workModel'
import type { GridHeaderEvent, GridHeaderProps } from '@/components/Table/types/gridHeader'
import type { VxeGridInstance, VxeGridListeners, VxeGridProps } from 'vxe-table'
import type { TreeProps } from '@/components/Tree/types/tree'

import { reactive, ref, computed, unref } from 'vue'
import dayjs from 'dayjs'

import BasicTree from '@/components/Tree/BasicTree.vue'
import GridHeader from '@/components/Table/GridHeader.vue'
import OtherWorkReportGrid from './components/OtherWorkReportGrid.vue'

import { getKeyValue, getManufactureDepartment } from '@/api/sys/basic'
import { getDispatchingOther, exportOtherReportWork } from '@/api/sys/work'

import { orderStatusList } from './data'
import { dateShortcuts } from '@/constant'

defineOptions({
  name: 'OtherWorkReport',
  inheritAttrs: false
})

const treeParams = reactive({
  departmentId: '',
  groupId: ''
})
const basicTreeRef = ref<InstanceType<typeof BasicTree>>()
// 列表配置
const treeOptions = reactive<TreeProps>({
  api: getManufactureDepartment,
  title: '部门列表',
  labelField: 'name',
  resultField: 'data',
  childrenField: 'children',
  nodeKey: 'id',
  accordion: true,
  formatter({ data }) {
    return (
      <div>
        {data.label}&nbsp;&nbsp;({data.childrenCount})
      </div>
    )
  },
  cancleHightlightCurrent: true,
  onSelect: async (data, node) => {
    if (data) {
      headerOptions.title = `[${data.label}]其他派工`

      if (data.isGroup) {
        treeParams.departmentId = node.parent.data.id
        treeParams.groupId = data.id
      } else {
        treeParams.departmentId = data.id
        treeParams.groupId = ''
      }
      gridRef.value?.commitProxy('reload')
    } else {
      headerOptions.title = `其他派工`
      treeParams.departmentId = ''
      treeParams.groupId = ''
      gridRef.value?.remove()
    }

    otherWorkReportGridRef.value?.removeData()
  }
})

const gridHeaderRef =
  ref<ComponentExposed<typeof GridHeader<GetDispatchingOtherParams, 'searchKey'>>>()
const headerOptions = reactive<GridHeaderProps>({
  title: '其他派工',
  quickSearch: {
    singleSearch: {
      field: 'searchKey',
      type: 'input',
      title: '工号/姓名'
    },
    searchFormFields: { searchKey: '' }
  },
  advancedSearch: {
    labelWidth: 120,
    fieldMapToTime: [
      ['dateOfDispatch', ['startDate', 'endDate'], 'YYYY-MM-DD'],
      ['dateOfReport', ['reportStartDate', 'reportEndDate'], 'YYYY-MM-DD']
    ],
    schemas: [
      {
        field: 'orderStatusArray',
        label: '状态',
        component: 'Select',
        defaultValue: [0, 1],
        componentProps: {
          options: orderStatusList,
          multiple: true
        },
        colProps: {
          span: 8
        }
      },
      {
        field: 'dateOfDispatch',
        label: '计划开始日期',
        component: 'ElDatePicker',
        componentProps: {
          type: 'daterange',
          unlinkPanels: true,
          shortcuts: dateShortcuts,
          valueFormat: 'YYYY-MM-DD'
        },
        colProps: {
          span: 8
        }
      },
      {
        field: 'dateOfReport',
        label: '报工日期',
        component: 'ElDatePicker',
        componentProps: {
          type: 'daterange',
          unlinkPanels: true,
          shortcuts: dateShortcuts,
          valueFormat: 'YYYY-MM-DD'
        },
        colProps: {
          span: 8
        }
      },
      {
        field: 'positionClassifyID',
        component: 'ApiSelect',
        label: '工种',
        // defaultValue: [0, 1],
        componentProps: {
          api: getKeyValue,
          labelField: 'value',
          valueField: 'id',
          resultField: 'data.result',
          multiple: true,
          params: {
            typeName: 'PositionClassify'
          }
        },
        colProps: {
          span: 8
        }
      },
      {
        field: 'isConfirmStatus',
        component: 'ElCheckbox',
        label: '只显示未确认报工',
        labelWidth: 150,
        componentProps: {},
        colProps: {
          span: 8
        }
      }
    ]
  },
  showAddButton: false,
  showExportButton: true,
  exportApi: exportOtherReportWork,
  exportParams: computed(() => {
    const quickSearchForm = unref(gridHeaderRef.value?.quickSearchForm)
    const advancedSearchForm = unref(gridHeaderRef.value?.advancedSearchForm)
    const departmentId = advancedSearchForm?.departmentID ?? treeParams.departmentId
    const groupId = advancedSearchForm?.groupID ?? treeParams.groupId

    return { ...quickSearchForm, ...advancedSearchForm, departmentId, groupId }
  })
})

const getOrderStatusInfo = computed(() => {
  const statusMap: { [key: number]: { text: string; type: string } } = {}
  orderStatusList.forEach((item) => {
    statusMap[item.value] = { text: item.label, type: item.type }
  })

  return function (status: number) {
    return statusMap[status] || { text: '', color: '' }
  }
})

const headerEvent: GridHeaderEvent = {
  quickSearch() {
    gridRef.value?.commitProxy('reload')
    otherWorkReportGridRef.value?.removeData()
  },
  advancedSearch() {
    gridRef.value?.commitProxy('reload')
    otherWorkReportGridRef.value?.removeData()
  },
  reset() {
    gridRef.value?.commitProxy('reload')
    otherWorkReportGridRef.value?.removeData()
  }
}

const gridRef = ref<VxeGridInstance>()
const gridOptions = reactive<VxeGridProps<GetDispatchingOtherModel>>({
  border: true,
  height: '400px',
  align: null,
  columnConfig: {
    resizable: true
  },
  columns: [
    { type: 'seq', width: 50 },
    {
      field: 'employeeName',
      title: '作业者',
      minWidth: 140,
      formatter({ row }) {
        return `${row.employeeNo}-${row.employeeName}`
      }
    },
    { field: 'groupName', title: '班组', minWidth: 140 },
    { field: 'workTypeName', title: '工作类型', minWidth: 100 },
    {
      field: 'dispatchingNumber',
      title: '派工数量',
      minWidth: 90,
      headerAlign: 'center',
      align: 'right'
    },
    { field: 'workDescription', title: '工作描述', minWidth: 200 },
    {
      field: 'takeTime',
      title: '总用时',
      minWidth: 70,
      headerAlign: 'center',
      align: 'right'
    },
    {
      field: 'sumFinishCount',
      title: '总数量',
      minWidth: 70,
      headerAlign: 'center',
      align: 'right'
    },
    {
      field: 'startDate',
      title: '计划开始日期',
      minWidth: 100,
      formatter({ cellValue }) {
        return dayjs(cellValue).format('YYYY-MM-DD')
      }
    },
    {
      field: 'orderStatus',
      title: '状态',
      width: 90,
      slots: {
        default({ row }) {
          return (
            <>
              <el-tag type={getOrderStatusInfo.value(row.orderStatus).type}>
                {getOrderStatusInfo.value(row.orderStatus).text}
              </el-tag>
            </>
          )
        }
      }
    }
    // { field: 'lastModifiedUserName', title: '操作人', minWidth: 90 },
    // { field: 'lastModifiedTime', title: '最后更新时间', minWidth: 150 },
  ],
  pagerConfig: {
    enabled: true,
    pageSize: 20
  },
  proxyConfig: {
    autoLoad: false,
    ajax: {
      query: ({ page }) => {
        const quickSearchForm = unref(gridHeaderRef.value?.quickSearchForm)
        const advancedSearchForm = unref(gridHeaderRef.value?.advancedSearchForm)

        return getDispatchingOther({
          pageIndex: page.currentPage - 1, // 由于后端接口限制，首页从0开始
          pageSize: page.pageSize,
          ...treeParams,
          ...quickSearchForm,
          ...advancedSearchForm
        })
      }
    }
  }
})
const activeRow = computed<GetDispatchingOtherModel>(() => {
  return gridRef.value?.getCurrentRecord()
})
const isConfirmStatus = ref<boolean>()
const gridEvents: VxeGridListeners<GetDispatchingOtherModel> = {
  cellClick() {
    isConfirmStatus.value = unref(gridHeaderRef.value?.advancedSearchForm)?.isConfirmStatus
  }
}

const otherWorkReportGridRef = ref()
</script>

<style lang="scss" scoped>
.table-wrapper {
  flex: 1;

  .grid-container {
    margin: $margin $margin $margin 0;

    display: flex;
    flex-direction: column;
    .vxe-grid:last-child {
      margin-top: $margin;
    }

    .child-grid-container {
      margin-top: $margin;

      .tabs-container {
        position: relative;

        .report-time-container {
          z-index: 1;
          position: absolute;
          line-height: 40px;
          right: 20px;
          top: 0;
        }

        :deep(.el-tabs) {
          .el-tabs__header {
            .el-tabs__nav-wrap::after {
              height: 0;
            }
          }
        }
      }
    }
  }
}
</style>
