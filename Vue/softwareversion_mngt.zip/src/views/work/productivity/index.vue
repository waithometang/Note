<template>
  <LayoutContainer>
    <template #leftSide>
      <basic-tree class="basic-list-wrapper" ref="basicTreeRef" v-bind="treeOptions" />
    </template>

    <div class="view-grid-contianer">
      <vxe-grid class="box" ref="gridRef" v-bind="gridOptions">
        <template #top>
          <GridHeader ref="gridHeaderRef" v-bind="headerOptions" v-on="headerEvent" />
        </template>
        <template #operation="{ row }">
          <TableAction
            :actions="[
              {
                icon: 'edit',
                tooltip: '编辑',
                onClick: handleModify.bind(null, row)
              },
              {
                icon: 'delete',
                tooltip: '删除',
                onClick: handleDelete.bind(null, row)
              }
            ]"
          />
        </template>
      </vxe-grid>
    </div>
    <ProductivityDialog @register="registerModal" @success="handleSuccess" />
  </LayoutContainer>
</template>

<script lang="tsx" setup>
import type { ComponentExposed } from 'vue-component-type-helpers'
import type { TreeProps } from '@/components/Tree/types/tree'
import type {
  GetProductionPerformanceModel,
  GetProductionPerformanceParams
} from '@/api/sys/model/workModel'
import type { VxeGridInstance, VxeGridProps } from 'vxe-table'
import type { GridHeaderEvent, GridHeaderProps } from '@/components/Table/types/gridHeader'
import type { SelectModel } from '@/api/model/baseModel'

import { reactive, ref } from 'vue'
import dayjs from 'dayjs'
import { useModal } from '@/components/Modal/hooks/useModal'
import { error } from '@/utils/log'
import { useForm } from '@/components/Form/hooks/useForm'
import { downloadByApi } from '@/utils/download'

import BasicTree from '@/components/Tree/BasicTree.vue'
import GridHeader from '@/components/Table/GridHeader.vue'
import TableAction from '@/components/Table/TableAction.vue'
import ProductivityDialog from './components/ProductivityDialog.vue'

import {
  getGroupSelect,
  getKeyValue,
  getManufactureDepartment,
  getManufactureDepartmentList
} from '@/api/sys/basic'
import {
  deleteProductionPerformance,
  exportProductionPerformance,
  getPerformanceStandard,
  getProductionPerformance
} from '@/api/sys/work'
import { dateShortcuts } from '@/constant'

defineOptions({
  name: 'Productivity',
  inheritAttrs: false
})

const listParams = reactive({
  departmentID: '',
  groupID: ''
})
const basicTreeRef = ref<InstanceType<typeof BasicTree>>()
// 列表配置
const treeOptions = reactive<TreeProps>({
  api: getManufactureDepartment,
  title: '部门列表',
  labelField: 'name',
  resultField: 'data',
  childrenField: 'children',
  nodeKey: 'id',
  accordion: true,
  formatter({ data }) {
    return (
      <div>
        {data.label}&nbsp;&nbsp;({data.childrenCount})
      </div>
    )
  },
  cancleHightlightCurrent: true,
  onSelect: async (data, node) => {
    if (data) {
      headerOptions.title = `[${data.label}]生产绩效`

      if (data.isGroup) {
        listParams.departmentID = node.parent.data.id
        listParams.groupID = data.id
      } else {
        listParams.departmentID = data.id
        listParams.groupID = ''
      }
      gridRef.value?.commitProxy('reload')
    } else {
      headerOptions.title = `生产绩效`
      listParams.departmentID = ''
      listParams.groupID = ''
      gridRef.value?.remove()
    }
  }
})

const gridHeaderRef =
  ref<ComponentExposed<typeof GridHeader<GetProductionPerformanceParams, 'assessmentTime'>>>()

const headerOptions = reactive<GridHeaderProps>({
  title: '生产绩效',
  quickSearch: {
    fieldMapToTime: ['assessmentTime', ['assessmentBeginTime', 'assessmentEndTime'], 'YYYY-MM-DD'],
    singleSearch: {
      field: 'assessmentTime',
      type: 'date',
      title: '考核日期',
      componentProps: {
        type: 'daterange',
        unlinkPanels: true,
        shortcuts: dateShortcuts,
        valueFormat: 'YYYY-MM-DD'
      }
    },
    searchFormFields: {
      assessmentTime: [
        dayjs().subtract(1, 'day').format('YYYY-MM-DD'),
        dayjs().format('YYYY-MM-DD')
      ]
    }
  },
  advancedSearch: {
    labelWidth: 120,
    // fieldMapToTime: [
    //   ['assessmentTime', ['assessmentBeginTime', 'assessmentEndTime'], 'YYYY-MM-DD']
    // ],
    schemas: [
      {
        field: 'departmentID',
        component: 'ApiSelect',
        label: '生产部门',
        componentProps: ({ formModel, formActionType }) => {
          return {
            api: getManufactureDepartmentList,
            resultField: 'data',
            labelField: 'name',
            valueField: 'id',
            filterable: true,
            props: {
              checkStrictly: true,
              emitPath: false
            },
            async onChange(value: string) {
              let groupList: SelectModel[] = []
              formModel.groupID = undefined
              if (value) {
                const { data } = await getGroupSelect({ departmentID: value })

                groupList = data.result
              }

              const { updateSchema } = formActionType

              updateSchema({
                field: 'groupID',
                componentProps: {
                  options: groupList
                }
              })
            }
          }
        },
        colProps: {
          span: 8
        }
      },
      {
        field: 'groupID',
        component: 'Select',
        label: '所属组别',
        componentProps: {
          options: []
        },
        colProps: {
          span: 8
        }
      },
      {
        field: 'employeeID',
        component: 'PersonSelect',
        label: '考核员工',
        colProps: {
          span: 8
        }
      },
      // {
      //   field: 'assessmentTime',
      //   component: 'ElDatePicker',
      //   label: '考核时间',
      //   componentProps: {
      //     type: 'daterange'
      //   },
      //   colProps: {
      //     span: 8
      //   }
      // },
      {
        field: 'performanceLevel',
        component: 'ApiSelect',
        label: '绩效等级',
        componentProps: {
          api: getPerformanceStandard,
          resultField: 'data',
          labelField: 'performanceLevel',
          valueField: 'performanceLevel',
          filterable: true,
          slots: {
            default({ option }: { option: any }) {
              return (
                <>
                  <span style="float: left">{option.label}</span>
                  <span
                    style="
                    float: right;
                    color: var(--el-text-color-secondary);
                    font-size: 13px;
                  "
                  >
                    {option.performanceMark}
                  </span>
                </>
              )
            }
          },
          multiple: true
        },
        colProps: {
          span: 8
        }
      },
      {
        field: 'isShowNotAssessment',
        component: 'ElCheckbox',
        label: '只显示未评绩效',
        colProps: {
          span: 8
        }
      },
      {
        field: 'isAttendanceDuty',
        component: 'ElCheckbox',
        label: '只显示出勤员工',
        colProps: {
          span: 8
        }
      },
      {
        field: 'positionClassifyID',
        component: 'ApiSelect',
        label: '工种',
        // defaultValue: [0, 1],
        componentProps: {
          api: getKeyValue,
          labelField: 'value',
          valueField: 'id',
          resultField: 'data.result',
          multiple: true,
          params: {
            typeName: 'PositionClassify'
          }
        },
        colProps: {
          span: 8
        }
      }
    ]
  },
  showExportButton: true,
  customExport: true
  // exportApi: exportProductionPerformance
})

const [registerForm, { getFieldsValue, validate }] = useForm({
  labelWidth: 60,
  fieldMapToTime: [['assessmentTime', ['assessmentBeginTime', 'assessmentEndTime'], 'YYYY-MM-DD']],
  schemas: [
    {
      field: 'assessmentTime',
      component: 'ElDatePicker',
      label: '日期',
      required: true,
      componentProps: {
        type: 'daterange',
        startPlaceholder: '开始日期',
        endPlaceholder: '结束日期',
        unlinkPanels: true,
        shortcuts: dateShortcuts,
        valueFormat: 'YYYY-MM-DD'
      },
      colProps: {
        span: 23
      }
    }
  ]
})

const headerEvent: GridHeaderEvent = {
  quickSearch() {
    gridRef.value?.commitProxy('reload')
  },
  advancedSearch() {
    gridRef.value?.commitProxy('reload')
  },
  reset() {
    gridRef.value?.commitProxy('reload')
  },
  add() {
    openModal(true, {
      isUpdate: false
    })
  },
  exportClick() {
    ElMessageBox({
      title: '导出',
      showCancelButton: true,
      message: () => {
        return <basic-form onRegister={registerForm} />
      },
      beforeClose: async (action, instance, done) => {
        if (action === 'confirm') {
          await validate(async (isValid) => {
            const fieldsValue = getFieldsValue()

            if (isValid) {
              const loading = ElLoading.service({
                lock: true,
                text: 'Loading',
                background: 'rgba(0, 0, 0, 0.7)'
              })
              try {
                await downloadByApi(exportProductionPerformance, {
                  ...fieldsValue
                })
                ElMessage.success('导出成功')
                done()
              } catch (e: any) {
                ElMessage.error(e.message)
              } finally {
                loading.close()
              }
            }
          })
        }

        if (action === 'cancel') {
          done()
        }
      }
    })
  }
}
const attendanceStatus: Recordable<string> = {
  0: '未登记',
  1: '出勤',
  2: '请假',
  3: '休息',
  4: '离职',
  5: '支援',
  6: '缺勤',
  7: '出差',
  8: '旷工'
}
const gridRef = ref<VxeGridInstance>()
const gridOptions = reactive<VxeGridProps<GetProductionPerformanceModel>>({
  border: true,
  height: 'auto',
  align: null,
  columnConfig: {
    resizable: true
  },
  columns: [
    { type: 'seq', width: 50 },
    {
      field: 'assessmentTime',
      title: '考核时间',
      width: 130,
      formatter({ cellValue }) {
        return dayjs(cellValue).format('YYYY-MM-DD')
      }
    },
    { field: 'departmentName', title: '考核部门', minWidth: 100 },
    { field: 'groupName', title: '考核班组', minWidth: 130 },

    {
      field: 'beAssessorNo',
      // title: '被考核人工号',
      title: '被考核人',
      width: 130,
      slots: {
        default({ row }) {
          return (
            <>
              {row.beAssessorNo}-{row.beAssessorName}
            </>
          )
        }
      }
    },
    // { field: 'beAssessorName', title: '被考核人姓名', width: 130, },
    { field: 'performanceLevel', title: '绩效等级', width: 100 },
    { field: 'performanceMark', title: '绩效分数', width: 100 },
    { field: 'positionName', title: '岗位', width: 100 },
    {
      field: 'attendanceStatus',
      title: '出勤勤况',
      formatter({ cellValue }: { cellValue: number }) {
        return attendanceStatus[cellValue]
      },
      width: 100
    },
    { field: 'assessorName', title: '考核主管', width: 100 },
    { field: 'lastModifiedUserName', title: '操作人', width: 100 },
    { field: 'lastModifiedTime', title: '最后更新时间', width: 150 },
    {
      field: 'operation',
      title: '操作',
      align: 'center',
      fixed: 'right',
      width: 150,
      slots: {
        default: 'operation'
      }
    }
  ],
  pagerConfig: {
    enabled: true,
    pageSize: 20
  },
  proxyConfig: {
    autoLoad: false,
    ajax: {
      query: async ({ page }) => {
        const quickSearchForm = gridHeaderRef.value?.quickSearchForm
        const advancedSearchForm = gridHeaderRef.value?.advancedSearchForm
        const result = await getProductionPerformance({
          pageIndex: page.currentPage - 1, // 由于后端接口限制，首页从0开始
          pageSize: page.pageSize,
          ...listParams,
          ...quickSearchForm,
          ...advancedSearchForm
        })

        if (result.status) {
          return Promise.resolve(result)
        } else {
          ElMessage.error(result.message)
          return new Error(result.message)
        }
      }
    }
  }
})

const [registerModal, { openModal, setModalProps }] = useModal()

const handleModify = (row: GetProductionPerformanceModel) => {
  openModal(true, {
    isUpdate: true,
    row
  })
}

const handleDelete = (row: GetProductionPerformanceModel) => {
  ElMessageBox.confirm(`是否确认删除被考核人为"${row.beAssessorName}"的数据项?`, '警告', {
    confirmButtonText: '确定',
    cancelButtonText: '取消',
    type: 'warning'
  })
    .then(async () => {
      try {
        const id = row.id
        const { data, message } = await deleteProductionPerformance({ id })

        if (data) {
          ElMessage.success('删除成功')
        } else {
          ElMessage.error(message)
        }
      } catch (err: any) {
        error(err.message)
      }
    })
    .catch(() => {})
    .finally(() => {
      gridRef.value?.commitProxy('query')
    })
}
const handleSuccess = ({ isUpdate }: { isUpdate: boolean }) => {
  gridRef.value?.commitProxy('query')
}
</script>

<style lang="scss" scoped>
.view-grid-contianer {
  height: 100%;
  padding: $margin $margin $margin 0;
}
</style>
