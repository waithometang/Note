<template>
  <BasicModal
    width="70%"
    v-bind="$attrs"
    @register="registerModal"
    :title="getTitle"
    @confirm="handleSubmit"
  >
    <BasicForm @register="registerForm" />
  </BasicModal>
</template>

<script lang="tsx" setup>
import type { GetEmployeeInfoModel } from '@/api/sys/model/basicModel'
import type {
  AddProductionPerformanceData,
  UpdateProductionPerformanceData
} from '@/api/sys/model/workModel'
import type { ModalMethods } from '@/components/Modal/types'

import { computed, ref, unref } from 'vue'
import dayjs from 'dayjs'

import BasicModal from '@/components/Modal/BasicModal.vue'
import { useModalInner } from '@/components/Modal/hooks/useModal'
import BasicForm from '@/components/Form/BasicForm.vue'
import { useForm } from '@/components/Form/hooks/useForm'

import {
  addProductionPerformance,
  getPerformanceStandard,
  getProductionPerformanceByEmployee,
  updateProductionPerformance
} from '@/api/sys/work'

const emit = defineEmits<{
  register: [modalMethods: ModalMethods, uuid: number]
  success: [{ isUpdate: boolean }]
}>()

const isUpdate = ref<boolean>(false)
const rowId = ref('')
const performanceLevel = ref('')
const getTitle = computed(() => (!unref(isUpdate) ? '新增' : '修改'))

const [registerModal, { closeModal, setModalProps, changeOkLoading }] = useModalInner(
  async (data) => {
    resetFields()
    setModalProps({ confirmLoading: false })
    isUpdate.value = !!data?.isUpdate

    // 修改设置表单
    if (unref(isUpdate)) {
      rowId.value = data.row.id
      setFieldsValue({
        ...data.row
      })
    } else {
      setFieldsValue({
        ...data.row
        // performanceLevel: unref(performanceLevel)
      })
    }
  }
)

const [registerForm, { setFieldsValue, resetFields, getFieldsValue, validate, updateSchema }] =
  useForm({
    labelWidth: 120,
    schemas: [
      {
        field: 'assessmentTime',
        component: 'ElDatePicker',
        label: '日期',
        defaultValue: dayjs().format('YYYY-MM-DD'),
        dynamicDisabled() {
          return unref(isUpdate)
        },
        dynamicRules() {
          return unref(isUpdate)
            ? []
            : [{ required: true, trigger: 'change', message: '请选择日期' }]
        },
        componentProps({ formActionType }) {
          const { updateSchema } = formActionType
          return {
            type: 'date',
            valueFormat: 'YYYY-MM-DD',
            onChange(value: string) {
              updateSchema({
                field: 'beAssessorID',
                componentProps({ formActionType }) {
                  return {
                    onConfirm(data: GetEmployeeInfoModel) {
                      const { setFieldsValue } = formActionType
                      const { departmentName, groupName, groupLeaderName } = data
                      setFieldsValue({ departmentName, groupName, groupLeaderName })
                    },
                    attendanceDate: value
                  }
                }
              })
            }
          }
        },
        colProps: {
          span: 8
        }
      },

      {
        field: 'performanceLevel',
        component: 'ApiSelect',
        label: '绩效等级',
        rules: [{ required: true, trigger: 'blur' }],
        defaultValue: 'A',
        componentProps: {
          api: getPerformanceStandard,
          resultField: 'data',
          labelField: 'performanceLevel',
          valueField: 'performanceLevel',
          onOptionsChange(options: Array<any>) {
            // if (options.length) {
            //   performanceLevel.value = options[0].value
            //   setFieldsValue({ performanceLevel: unref(performanceLevel) })
            // }
          },
          slots: {
            default({ option }: { option: any }) {
              return (
                <>
                  <span style="float: left">{option.label}</span>
                  <span
                    style="
                    float: right;
                    color: #000;
                    font-size: 13px;
                  "
                  >
                    绩效分：{option.performanceMark}
                  </span>
                </>
              )
            }
          }
        },
        colProps: {
          span: 8
        }
      },
      {
        field: 'beAssessorID',
        component: 'PersonSelect',
        label: '考核员工',
        rules: [{ required: true, trigger: 'change' }],
        dynamicDisabled() {
          return unref(isUpdate)
        },
        componentProps({ formActionType }) {
          return {
            onConfirm(data: GetEmployeeInfoModel) {
              const { setFieldsValue } = formActionType
              const { departmentName, groupName, groupLeaderName } = data
              setFieldsValue({ departmentName, groupName, groupLeaderName })
            },
            attendanceDate: dayjs().format('YYYY-MM-DD')
          }
        },
        colProps: {
          span: 8
        }
      },
      {
        field: 'departmentName',
        component: 'ElInput',
        label: '生产部门',
        componentProps: {
          disabled: true
        },
        colProps: {
          span: 8
        }
      },
      {
        field: 'groupName',
        component: 'ElInput',
        label: '班组',
        componentProps: {
          disabled: true
        },
        colProps: {
          span: 8
        }
      },
      {
        field: 'groupLeaderName',
        component: 'ElInput',
        label: '班组长',
        componentProps: {
          disabled: true
        },
        colProps: {
          span: 8
        }
      },
      {
        field: 'dataDescribe',
        component: 'ElInput',
        label: '备注',
        componentProps: {
          type: 'textarea'
        },
        colProps: {
          span: 24
        }
      }
    ]
  })

/**
 * 检查指定员工和日期的绩效记录
 */
const checkProductionPerformance = async (formData: AddProductionPerformanceData) => {
  const { code, message, data } = await getProductionPerformanceByEmployee({
    employeeID: formData.beAssessorID,
    assessmentTime: formData.assessmentTime
  })

  if (code === 200) {
    /**
     * 如接口返回id不等于0表示已存在数据，
     * 则显示确认框：{beAssessorName}在{assessmentTime：年月日}已由班组{groupName}填写绩效数据，是否覆盖?。
     * 选是则调用添加绩效接口
     */
    if (data.id !== '0') {
      const { beAssessorName, assessmentTime, groupName } = data
      try {
        await ElMessageBox.confirm(
          `${beAssessorName}在${dayjs(assessmentTime).format(
            'YYYY-MM-DD'
          )}已由班组【${groupName}】填写绩效数据，是否覆盖?`,
          '提示',
          {
            confirmButtonText: '确定',
            cancelButtonText: '取消',
            type: 'warning'
          }
        )
      } catch {
        return Promise.resolve(false)
      }
    }
    return Promise.resolve(true)
  } else {
    throw new Error(message)
  }
}

// 提交
const handleSubmit = async () => {
  changeOkLoading(true)

  try {
    validate(async (isValid) => {
      if (isValid) {
        // 新增
        if (!unref(isUpdate)) {
          const data = getFieldsValue() as AddProductionPerformanceData
          const flag = await checkProductionPerformance(data)
          if (!flag) {
            return
          }
          const { code, message } = await addProductionPerformance(data)
          if (code === 200) {
            ElMessage.success('新增成功')
            emit('success', { isUpdate: unref(isUpdate) })
            closeModal()
          } else {
            ElMessage.error(message)
          }
        } else {
          const formData = getFieldsValue() as Omit<UpdateProductionPerformanceData, 'id'>

          const data = {
            id: unref(rowId),
            ...formData
          }

          const { code, message } = await updateProductionPerformance(data)
          if (code === 200) {
            ElMessage.success('修改成功')

            emit('success', { isUpdate: unref(isUpdate) })
            closeModal()
          } else {
            ElMessage.error(message)
          }
        }
      }
    })
  } catch (error: any) {
    ElMessage(error.message)
  } finally {
    changeOkLoading(false)
  }
}
</script>

<style lang="scss" scoped></style>
