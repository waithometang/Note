<template>
  <BasicModal
    width="70%"
    v-bind="$attrs"
    @register="registerModal"
    title="查看"
    :show-confirm-btn="false"
  >
    <BasicForm @register="registerForm"> </BasicForm>
  </BasicModal>
</template>

<script setup lang="ts">
import BasicModal from '@/components/Modal/BasicModal.vue'
import BasicForm from '@/components/Form/BasicForm.vue'

import { useModalInner } from '@/components/Modal/hooks/useModal'
import { useForm } from '@/components/Form/hooks/useForm'

const [registerForm, { setFieldsValue }] = useForm({
  labelWidth: 120,
  schemas: [
    {
      field: 'employeeInfoName',
      component: 'ElInput',
      label: '借调员工',
      componentProps: {
        disabled: true
      },
      colProps: {
        span: 8
      }
    },
    {
      field: 'departmentName',
      component: 'ElInput',
      label: '原部门',
      componentProps: {
        disabled: true
      },
      colProps: {
        span: 8
      }
    },
    {
      field: 'groupName',
      component: 'ElInput',
      label: '原班组',
      componentProps: { disabled: true },
      colProps: {
        span: 8
      }
    },
    {
      field: 'transferDepartmentName',
      component: 'ElInput',
      label: '借调部门',
      componentProps: {
        disabled: true
      },
      colProps: {
        span: 8
      }
    },
    {
      field: 'transferLeaderName',
      component: 'ElInput',
      label: '借调班组长',
      componentProps: {
        disabled: true
      },
      colProps: {
        span: 8
      }
    },
    {
      field: 'transferGroupName',
      component: 'ElInput',
      label: '借调班组',
      componentProps: {
        disabled: true
      },
      colProps: {
        span: 8
      }
    },
    {
      field: 'transferBeginTime',
      component: 'ElDatePicker',
      label: '借调开始',
      componentProps: {
        disabled: true,
        type: 'datetime',
        valueFormat: 'YYYY-MM-DD HH:mm',
        dateFormat: 'YYYY-MM-DD',
        timeFormat: 'HH:mm'
      },
      colProps: {
        span: 8
      }
    },
    {
      field: 'transferEndTime',
      component: 'ElDatePicker',
      label: '借调结束',
      componentProps: {
        disabled: true,
        type: 'datetime',
        valueFormat: 'YYYY-MM-DD HH:mm',
        dateFormat: 'YYYY-MM-DD',
        timeFormat: 'HH:mm'
      },
      colProps: {
        span: 8
      }
    },
    {
      field: 'transferHours',
      component: 'ElInput',
      label: '小时',
      ifShow: false,
      componentProps: {
        disabled: true
      },
      colProps: {
        span: 8
      }
    },
    {
      field: 'dataDescribe',
      component: 'ElInput',
      label: '借调原因',
      componentProps: {
        disabled: true,
        type: 'textarea'
      }
    }
  ]
})

const [registerModal] = useModalInner(async (data) => {
  await setFieldsValue({ ...data.row })
})
</script>
<style lang="scss" scoped></style>
