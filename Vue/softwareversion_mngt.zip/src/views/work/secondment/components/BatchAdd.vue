<template>
  <BasicModal
    width="1200px"
    v-bind="$attrs"
    @register="registerInnerModal"
    title="批量新增"
    @confirm="handleSubmit"
    @close="handleClose"
  >
    <vxe-grid ref="gridRef" v-bind="gridOptions">
      <!-- <template #employeeInfoName="{ row }">
        <div style="display: flex; align-items: center">
          <div>{{ row.employeeName }}</div>
          <el-tag
            v-if="row.transferInStatus === 1"
            type="warning"
            size="small"
            effect="plain"
            style="margin-left: 5px"
            >借调</el-tag
          >
        </div>
      </template> -->
      <template #transferDepartmentID_edit="{ row }">
        <ApiCascader
          v-model="row.transferDepartmentID"
          ref="apiCascaderRef"
          :api="getDepartment"
          resultField="data.result"
          labelField="departmentName"
          valueField="id"
          childrenField="sonData"
          :show-all-levels="false"
          :props="cascaderProps"
          @change="
            () => {
              row.transferDepartmentName =
                apiCascaderRef?.cascaderRef?.getCheckedNodes(false)?.[0].label || ''
            }
          "
        ></ApiCascader>
      </template>
      <template #transferLeaderID_edit="{ row }">
        <PersonSelect
          style="width: 100%"
          v-model="row.transferLeaderID"
          :employeeName="row.transferLeaderName"
          :departmentID="row.transferDepartmentID"
          @confirm="
            (data: GetEmployeeInfoModel) => {
              row.transferLeaderName = data.employeeName
              row.transferGroupID = data.groupID
              row.transferGroupName = data.groupName
            }
          "
          @clear="
            () => {
              row.transferLeaderName = ''
              row.transferGroupID = ''
              row.transferGroupName = ''
            }
          "
        ></PersonSelect>
      </template>
      <template #transferTime="{ row }">
        <div v-if="row.transferTime">{{ row.transferTime[0] }} - {{ row.transferTime[1] }}</div>
      </template>
      <template #transferTime_edit="{ row }">
        <el-date-picker
          style="width: 100%"
          v-model="row.transferTime"
          type="datetimerange"
          format="YYYY-MM-DD HH:mm"
          date-format="YYYY-MM-DD"
          time-format="HH:mm"
          value-format="YYYY-MM-DD HH:mm"
        ></el-date-picker>
      </template>
      <template #dataDescribe_edit="{ row }">
        <el-input style="width: 100%" v-model="row.dataDescribe"></el-input>
      </template>
      <template #operation="{ row }">
        <TableAction
          :actions="[
            {
              icon: 'edit',
              tooltip: '编辑',
              ifShow: () => !gridRef!.isEditByRow(row),
              onClick: handleEdit.bind(null, row)
            },
            {
              icon: 'save',
              tooltip: '完成',
              ifShow: () => gridRef!.isEditByRow(row),
              onClick: handleComplete.bind(null)
            },
            {
              icon: 'delete',
              tooltip: '删除',
              onClick: handleDelete.bind(null, row)
            }
          ]"
        />
      </template>
      <template #bottom>
        <TableAction
          style="margin-top: 16px"
          :actions="[
            {
              icon: 'plus',
              label: '新增',
              onClick: handleAdd.bind(null),
              style: {
                color: '#008cd6'
              }
            }
          ]"
        ></TableAction>
        <div style="margin-top: 10px; display: flex; justify-content: end">
          共 {{ total }} 条记录
        </div>
      </template>
    </vxe-grid>
    <PersonSelectDialog
      @register="registerModal"
      @success="handleSuccess"
      append-to-body
      :multiple="true"
    ></PersonSelectDialog>
  </BasicModal>
</template>

<script setup lang="ts">
import type {
  ADDEmployeeTransferData,
  EmployeeTransferList,
  GetEmployeeTransferModel
} from '@/api/sys/model/workModel'
import type { ModalMethods } from '@/components/Modal/types'
import type { CascaderProps } from 'element-plus'
import type { VxeGridInstance, VxeGridProps } from 'vxe-table'
import type { GetEmployeeInfoBySelectModel, GetEmployeeInfoModel } from '@/api/sys/model/basicModel'

import { ref, reactive, computed } from 'vue'

import BasicModal from '@/components/Modal/BasicModal.vue'
import PersonSelect from '@/components/Form/components/PersonSelect/index.vue'
import PersonSelectDialog from '@/components/Form/components/PersonSelect/PersonSelectDialog.vue'
import ApiCascader from '@/components/Form/components/ApiCascader.vue'

import { useModal } from '@/components/Modal/hooks/useModal'
import { useModalInner } from '@/components/Modal/hooks/useModal'
import { getDepartment } from '@/api/sys/basic'
import { addEmployeeTransfer } from '@/api/sys/work'

const emit = defineEmits<{
  register: [modalMethods: ModalMethods, uuid: number]
  success: []
}>()

const total = computed(() => gridRef.value?.getTableData().fullData.length || 0)
const apiCascaderRef = ref<InstanceType<typeof ApiCascader>>()
const cascaderProps: CascaderProps = {
  checkStrictly: true,
  emitPath: false
}

const [registerModal, { openModal: openPersonSelectModal }] = useModal()

const gridRef = ref<VxeGridInstance>()
const gridOptions = reactive<VxeGridProps<GetEmployeeTransferModel>>({
  border: true,
  height: '500px',
  align: null,
  columnConfig: {
    resizable: true
  },
  //   keepSource: true,
  editConfig: {
    trigger: 'dblclick',
    mode: 'row',
    autoClear: false
    // showStatus: true,
    // showUpdateStatus: true,
    // showInsertStatus: true
  },
  editRules: {
    transferDepartmentID: [{ required: true, trigger: 'manual', content: '请选择借调部门' }],
    transferLeaderID: [{ required: true, trigger: 'manual', content: '请选择借调班组长' }],
    transferTime: [{ required: true, trigger: 'manual', content: '请输入借调起止时间' }],
    dataDescribe: [{ required: true, trigger: 'manual', content: '请输入借调原因' }],
  },
  columns: [
    { type: 'seq', width: 50 },
    { field: 'id', title: '借调员工ID', width: 120, visible: false },
    {
      field: 'employeeName',
      title: '借调员工',
      width: 120
    },
    { field: 'departmentID', title: '原部门ID', width: 120, visible: false },
    {
      field: 'departmentName',
      title: '原部门',
      width: 120,
      formatter({ cellValue, row }) {
        return cellValue ? cellValue : row.departmentID
      }
    },
    { field: 'groupID', title: '原班组ID', minWidth: 120, visible: false },
    {
      field: 'groupName',
      title: '原班组',
      minWidth: 120,
      formatter({ cellValue, row }) {
        return cellValue ? cellValue : row.groupID
      }
    },
    { field: 'transferDepartmentName', visible: false },
    {
      field: 'transferDepartmentID',
      title: '借调部门',
      minWidth: 200,
      editRender: {},
      slots: { edit: 'transferDepartmentID_edit' },
      formatter({ row }) {
        return row.transferDepartmentName || ''
      }
    },
    { field: 'transferLeaderName', visible: false },
    {
      field: 'transferLeaderID',
      title: '借调班组长',
      minWidth: 200,
      editRender: {},
      slots: { edit: 'transferLeaderID_edit' },
      formatter({ row }) {
        return row.transferLeaderName || ''
      }
    },
    { field: 'transferGroupID', title: '借调班组ID', minWidth: 120, visible: false },
    { field: 'transferGroupName', title: '借调班组', minWidth: 120 },
    {
      field: 'transferTime',
      title: '借调起止时间',
      minWidth: 350,
      editRender: {},
      slots: { default: 'transferTime', edit: 'transferTime_edit' }
    },
    {
      field: 'dataDescribe',
      title: '借调原因',
      minWidth: 240,
      editRender: {},
      slots: { edit: 'dataDescribe_edit' }
    },
    {
      field: 'operation',
      title: '操作',
      align: 'center',
      fixed: 'right',
      width: 150,
      slots: {
        default: 'operation'
      }
    }
  ],
  pagerConfig: {
    enabled: false
  },
  data: []
})

const [registerInnerModal, { setModalProps }] = useModalInner(async () => {
  setModalProps({ confirmLoading: false })
})

// 关闭清空表格
const handleClose = () => {
  gridRef.value?.loadData([])
}

const handleAdd = () => {
  openPersonSelectModal()
}

const handleDelete = (row: EmployeeTransferList) => {
  gridRef.value?.remove(row)
}

const handleEdit = async (row: EmployeeTransferList) => {
  gridRef.value?.setEditRow(row)
}

const handleComplete = async () => {
  gridRef.value?.clearEdit()
  //   const errMap = await gridRef.value?.validate(row)
  //   if (errMap) {
  //     return
  //   }
}

const handleSuccess = ({ res }: { res: GetEmployeeInfoBySelectModel[] }) => {
  if (res.length > 0) {
    // const data:ADDEmployeeTransferData = {employeeTransferList:[{}]}
    // const inserData = res.map((item) => (item.employeeInfoID = item.id))
    gridRef.value?.insertAt(res, -1)
  }
  total
}

// 提交
const handleSubmit = async () => {
  const errMap = await gridRef.value?.validate()
  if (errMap) {
    return
  }
  try {
    setModalProps({ confirmLoading: true })
    // 新增
    const tableData = gridRef.value?.getTableData().fullData as any[]
    const data: ADDEmployeeTransferData = {
      employeeTransferList: tableData.map((item) => {
        return {
          ...item,
          employeeInfoID: item.id,
          transferBeginTime: item.transferTime[0],
          transferEndTime: item.transferTime[1]
        }
      })
    }
    const { code, message } = await addEmployeeTransfer(data)
    if (code === 200) {
      ElMessage.success('新增成功')
      emit('success')
    } else {
      ElMessage.error(message)
    }
  } catch (error: any) {
    ElMessage(error.message)
  } finally {
    setModalProps({ confirmLoading: false })
  }
}
</script>

<style scoped></style>
