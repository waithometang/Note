<template>
  <BasicModal
    width="70%"
    v-bind="$attrs"
    @register="registerModal"
    :title="getTitle"
    @confirm="handleSubmit"
  >
    <BasicForm @register="registerForm"> </BasicForm>
  </BasicModal>
</template>

<script setup lang="ts">
import type { GetEmployeeInfoModel } from '@/api/sys/model/basicModel'
import type {
  ADDEmployeeTransferData,
  EmployeeTransferList,
  UpdateEmployeeTransfer
} from '@/api/sys/model/workModel'
import type { ModalMethods } from '@/components/Modal/types'

import { ref, unref, computed } from 'vue'

import BasicModal from '@/components/Modal/BasicModal.vue'
import BasicForm from '@/components/Form/BasicForm.vue'

import { useModalInner } from '@/components/Modal/hooks/useModal'
import { useForm } from '@/components/Form/hooks/useForm'
import { getDepartment } from '@/api/sys/basic'
import { addEmployeeTransfer, updateEmployeeTransfer } from '@/api/sys/work'
import dayjs from 'dayjs'
import { round } from 'xe-utils'

const emit = defineEmits<{
  register: [modalMethods: ModalMethods, uuid: number]
  success: [{ isUpdate: boolean }]
}>()
const isUpdate = ref<boolean>(false)

const rowId = ref<string>('')

const getTitle = computed(() => (!unref(isUpdate) ? '新增' : '修改'))

const [
  registerForm,
  { setFieldsValue, resetFields, getFieldsValue, validate, updateSchema, clearValidate }
] = useForm({
  labelWidth: 120,
  schemas: [
    {
      field: 'employeeInfoID',
      component: 'PersonSelect',
      rules: [{ required: true, trigger: 'change' }],
      label: '借调员工',
      componentProps: {
        async onConfirm(res: any) {
          if (res) {
            setFieldsValue({
              departmentID: res.departmentID,
              departmentName: res.departmentName,
              groupID: res.groupID,
              groupName: res.groupName
            })
          }
        }
      },
      colProps: {
        span: 8
      }
    },
    {
      field: 'departmentID',
      component: 'ElInput',
      label: '原部门ID',
      ifShow: false
    },
    {
      field: 'departmentName',
      component: 'ElInput',
      label: '原部门',
      componentProps: {
        disabled: true
      },
      colProps: {
        span: 8
      }
    },
    {
      field: 'groupID',
      component: 'ElInput',
      rules: [{ required: true, trigger: 'blur' }],
      label: '原班组ID',
      ifShow: false
    },
    {
      field: 'groupName',
      component: 'ElInput',
      label: '原班组',
      componentProps: {
        disabled: true
      },
      colProps: {
        span: 8
      }
    },
    {
      field: 'transferDepartmentID',
      component: 'ApiCascader',
      rules: [{ required: true, trigger: 'change' }],
      label: '借调部门',
      componentProps: {
        api: getDepartment,
        resultField: 'data.result',
        labelField: 'departmentName',
        valueField: 'id',
        childrenField: 'sonData',
        props: {
          checkStrictly: true,
          emitPath: false
        },
        async onChange(departmentID: string) {
          await updateSchema({ field: 'transferLeaderID', componentProps: { departmentID } })
        }
      },
      colProps: {
        span: 8
      }
    },
    {
      field: 'transferLeaderID',
      component: 'PersonSelect',
      label: '借调班组长',
      rules: [{ required: true, trigger: 'change' }],
      componentProps: {
        onClear() {
          setFieldsValue({ transferGroupName: '', transferGroupID: '' })
        },
        onConfirm(row: GetEmployeeInfoModel) {
          setFieldsValue({ transferGroupName: row.groupName, transferGroupID: row.groupID })
        }
      },
      colProps: {
        span: 8
      }
    },
    {
      field: 'transferGroupName',
      component: 'ElInput',
      label: '借调班组',
      componentProps: {
        disabled: true
      },
      colProps: {
        span: 8
      }
    },
    {
      field: 'transferGroupID',
      component: 'ElInput',
      label: '借调班组',
      ifShow: false
    },
    {
      field: 'transferBeginTime',
      component: 'ElDatePicker',
      label: '借调开始',
      rules: [{ required: true, trigger: 'change' }],
      componentProps: {
        type: 'datetime',
        format: 'YYYY-MM-DD HH:mm',
        valueFormat: 'YYYY-MM-DD HH:mm',
        dateFormat: 'YYYY-MM-DD',
        timeFormat: 'HH:mm',
        onChange(transferBeginTime: string) {
          const transferEndTime = getFieldsValue().transferEndTime
          const start = dayjs(transferBeginTime)
          const end = dayjs(transferEndTime)
          const hours = end.diff(start, 'hour', true)
          setFieldsValue({ transferHours: round(hours, 1) })
        }
      },
      colProps: {
        span: 8
      }
    },
    {
      field: 'transferEndTime',
      component: 'ElDatePicker',
      label: '借调结束',
      rules: [{ required: true, trigger: 'change' }],
      componentProps: {
        type: 'datetime',
        format: 'YYYY-MM-DD HH:mm',
        valueFormat: 'YYYY-MM-DD HH:mm',
        dateFormat: 'YYYY-MM-DD',
        timeFormat: 'HH:mm',
        onChange(transferEndTime: string) {
          const transferBeginTime = getFieldsValue().transferBeginTime
          const start = dayjs(transferBeginTime)
          const end = dayjs(transferEndTime)
          const hours = end.diff(start, 'hour', true)
          setFieldsValue({ transferHours: round(hours, 1) })
        }
      },
      colProps: {
        span: 8
      }
    },
    {
      field: 'transferHours',
      component: 'ElInput',
      label: '小时',
      ifShow: false,
      rules: [
        {
          required: false,
          trigger: 'blur',
          validator(rule, value, cb) {
            if (value <= 0) {
              cb('小时不能小于或等于0')
            } else {
              cb()
            }
          }
        }
      ],
      componentProps: {
        disabled: true
      },
      colProps: {
        span: 8
      }
    },
    {
      field: 'dataDescribe',
      component: 'ElInput',
      label: '借调原因',
      rules: [{ required: true, trigger: 'blur' }],
      componentProps: {
        type: 'textarea'
      }
    }
  ]
})

const [registerModal, { setModalProps }] = useModalInner(async (data) => {
  await updateSchema([{ field: 'transferLeaderID', componentProps: { departmentID: '' } }])
  await resetFields()

  setModalProps({ confirmLoading: false })
  isUpdate.value = !!data?.isUpdate

  if (unref(isUpdate)) {
    rowId.value = data.row.id
    await setFieldsValue({ ...data.row })
  }
  clearValidate()
})

// 提交
const handleSubmit = async () => {
  await validate()
  setModalProps({ confirmLoading: true })
  try {
    // 新增
    if (!unref(isUpdate)) {
      const formData = getFieldsValue() as EmployeeTransferList

      const data: ADDEmployeeTransferData = {
        employeeTransferList: [
          {
            ...formData
          }
        ]
      }

      const { code, message } = await addEmployeeTransfer(data)
      if (code === 200) {
        ElMessage.success('新增成功')
        emit('success', { isUpdate: unref(isUpdate) })
      } else {
        ElMessage.error(message)
      }
    } else {
      const formData = getFieldsValue() as Omit<UpdateEmployeeTransfer, 'id'>
      const data = {
        id: unref(rowId),
        ...formData
      }
      const { code, message } = await updateEmployeeTransfer(data)

      if (code === 200) {
        ElMessage.success('修改成功')
        emit('success', { isUpdate: unref(isUpdate) })
      } else {
        ElMessage.error(message)
      }
    }
  } catch (error: any) {
    ElMessage(error.message)
  } finally {
    setModalProps({ confirmLoading: false })
  }
}
</script>
<style lang="scss" scoped></style>
