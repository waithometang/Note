<template>
  <div class="page-container">
    <vxe-grid class="box" ref="gridRef" v-bind="gridOptions">
      <template #top>
        <GridHeader
          ref="gridHeaderRef"
          v-bind="headerOptions"
          @quickSearch="handleQuickSearch"
          @advancedSearch="handleAdvancedSearch"
          @reset="handleReset"
          @add="handleAdd"
        >
          <template #appendOperation>
            <el-button size="large" type="warning" plain @click="handleBatchAdd"
              >批量新增</el-button
            >
          </template>
        </GridHeader>
      </template>
      <template #orderStatus="{ row }">
        <el-tag :type="getOrderStatusInfo(row.orderStatus).type">
          {{ getOrderStatusInfo(row.orderStatus).text }}
        </el-tag>
      </template>
      <template #operation="{ row }">
        <TableAction
          :actions="[
            {
              tooltip: '结束',
              ifShow: row.orderStatus !== 0,
              icon: 'finish-end',
              onClick: handleFinish.bind(null, row)
            },
            {
              tooltip: '查看',
              ifShow: row.orderStatus !== 0,
              icon: 'more-view',
              onClick: handleReview.bind(null, row)
            },
            {
              tooltip: '确认',
              icon: 'finish-wo-status',
              ifShow: row.orderStatus === 0,
              onClick: handleConfirm.bind(null, row)
            },
            {
              tooltip: '编辑',
              icon: 'edit',
              ifShow: row.orderStatus === 0,
              onClick: handleModify.bind(null, row)
            },
            {
              tooltip: '作废',
              icon: 'close-wo-status',
              ifShow: row.orderStatus === 0,
              onClick: handleVoid.bind(null, row)
            }
          ]"
        />
      </template>
    </vxe-grid>
  </div>
  <SecondmentDialog @register="registerModal" @success="handleSuccess" />
  <ReviewDialog @register="registerReviewModal" @success="handleSuccess" />
  <BatchAdd @register="registerBatchAddModal" @success="handleBatchAddSuccess" />
</template>

<script setup lang="ts">
import type { ComponentExposed } from 'vue-component-type-helpers'
import type { VxeGridInstance, VxeGridProps } from 'vxe-table'
import type { GridHeaderProps } from '@/components/Table/types/gridHeader'
import type { GetEmployeeTransferModel, GetEmployeeTransferParams } from '@/api/sys/model/workModel'

import { computed, reactive, ref } from 'vue'
import {
  getManufactureDepartmentList,
  getGroupSelect,
  getDepartment,
  getKeyValue
} from '@/api/sys/basic'
import {
  getEmployeeTransfer,
  updateEmployeeTransferConfirm,
  exportEmployeeTransfer
} from '@/api/sys/work'

import { useModal } from '@/components/Modal/hooks/useModal'

import GridHeader from '@/components/Table/GridHeader.vue'
import SecondmentDialog from './components/SecondmentDialog.vue'
import ReviewDialog from './components/ReviewDialog.vue'
import BatchAdd from './components/BatchAdd.vue'
import dayjs from 'dayjs'
import { dateShortcuts } from '@/constant'
defineOptions({
  name: 'Secondment',
  inheritAttrs: false
})

const gridHeaderRef =
  ref<ComponentExposed<typeof GridHeader<GetEmployeeTransferParams, 'EmployeeInfoNoAndName'>>>()

const getManufactureDepartmentOptions = async () => {
  const { code, data } = await getManufactureDepartmentList()
  if (code === 200) {
    gridHeaderRef.value?.updateAdvancedSearchForm([
      {
        field: 'DepartmentID',
        componentProps: { options: data }
      }
    ])
  }
}

const getDepartmentOptions = async () => {
  const { code, data } = await getDepartment()
  if (code === 200) {
    gridHeaderRef.value?.updateAdvancedSearchForm([
      {
        field: 'TransferDepartmentID',
        componentProps: { options: data.result }
      }
    ])
  }
}
getManufactureDepartmentOptions()
getDepartmentOptions()

const headerOptions = reactive<GridHeaderProps>({
  title: '人员借调管理',
  quickSearch: {
    singleSearch: {
      field: 'EmployeeInfoNoAndName',
      type: 'input',
      title: '工号/姓名'
    },
    searchFormFields: { EmployeeInfoNoAndName: '' }
  },
  advancedSearch: {
    labelWidth: 120,
    fieldMapToTime: [['dataOfTransfer', ['TransferBeginTime', 'TransferEndTime'], 'YYYY-MM-DD']],
    schemas: [
      {
        field: 'DepartmentID',
        label: '原部门',
        component: 'Select',
        componentProps: {
          labelField: 'name',
          valueField: 'id',
          async onChange(departmentID: string) {
            gridHeaderRef.value?.setFieldsValue({ TransferGroupID: '' })
            gridHeaderRef.value?.updateAdvancedSearchForm({
              field: 'GroupID',
              componentProps: { options: [] }
            })
            gridHeaderRef.value?.updateAdvancedSearchForm({
              field: 'EmployeeInfoID',
              componentProps: { departmentID }
            })
            if (departmentID) {
              const { code, data } = await getGroupSelect({ departmentID })
              if (code === 200) {
                gridHeaderRef.value?.updateAdvancedSearchForm({
                  field: 'GroupID',
                  componentProps: { options: data.result }
                })
              }
            }
          }
        },
        colProps: {
          span: 8
        }
      },
      {
        field: 'GroupID',
        label: '原班组',
        component: 'Select',
        componentProps: {
          options: [],
          onChange(groupID: string) {
            gridHeaderRef.value?.updateAdvancedSearchForm({
              field: 'EmployeeInfoID',
              componentProps: { groupID }
            })
          }
        },
        colProps: {
          span: 8
        }
      },
      {
        field: 'EmployeeInfoID',
        component: 'PersonSelect',
        label: '借调员工',
        componentProps: {},
        colProps: {
          span: 8
        }
      },
      {
        field: 'TransferDepartmentID',
        label: '借调部门',
        component: 'ElCascader',
        componentProps: {
          // labelField: 'name',
          // valueField: 'id',
          options: [],
          props: {
            label: 'departmentName',
            value: 'id',
            children: 'sonData',
            checkStrictly: true,
            emitPath: false
          },
          async onChange(departmentID: string) {
            gridHeaderRef.value?.setFieldsValue({ TransferGroupID: '' })
            gridHeaderRef.value?.updateAdvancedSearchForm({
              field: 'TransferGroupID',
              componentProps: { options: [] }
            })
            gridHeaderRef.value?.updateAdvancedSearchForm({
              field: 'TransferLeaderID',
              componentProps: { departmentID }
            })
            if (departmentID) {
              const { code, data } = await getGroupSelect({ departmentID })
              if (code === 200) {
                gridHeaderRef.value?.updateAdvancedSearchForm({
                  field: 'TransferGroupID',
                  componentProps: { options: data.result }
                })
              }
            }
          }
        },
        colProps: {
          span: 8
        }
      },
      {
        field: 'TransferGroupID',
        label: '借调班组',
        component: 'Select',
        componentProps: {
          options: [],
          onChange(groupID: string) {
            gridHeaderRef.value?.updateAdvancedSearchForm({
              field: 'TransferLeaderID',
              componentProps: { groupID }
            })
          }
        },
        colProps: {
          span: 8
        }
      },
      {
        field: 'TransferLeaderID',
        component: 'PersonSelect',
        label: '借调班组长',
        componentProps: {},
        colProps: {
          span: 8
        }
      },
      {
        field: 'OrderStatus',
        label: '状态',
        component: 'Select',
        defaultValue: [0, 1],
        componentProps: {
          options: [
            { label: '未确认', value: 0 },
            { label: '借调中', value: 1 },
            { label: '已结束', value: 2 },
            { label: '已作废', value: 3 }
          ],
          multiple: true
        },
        colProps: {
          span: 8
        }
      },
      {
        field: 'dataOfTransfer',
        label: '借调时间',
        component: 'ElDatePicker',
        componentProps: {
          type: 'daterange',
          unlinkPanels: true,
          shortcuts: dateShortcuts,
          valueFormat: 'YYYY-MM-DD'
        },
        colProps: {
          span: 8
        }
      },
      {
        field: 'positionClassifyID',
        component: 'ApiSelect',
        label: '工种',
        // defaultValue: [0, 1],
        componentProps: {
          api: getKeyValue,
          labelField: 'value',
          valueField: 'id',
          resultField: 'data.result',
          multiple: true,
          params: {
            typeName: 'PositionClassify'
          }
        },
        colProps: {
          span: 8
        }
      }
    ]
  },
  showExportButton: true,
  exportApi: exportEmployeeTransfer,
  exportParams: computed(() => {
    const advancedSearchForm = gridHeaderRef.value?.advancedSearchForm
    const quickSearchForm = gridHeaderRef.value?.quickSearchForm
    return { ...quickSearchForm, ...advancedSearchForm }
  })
})

const getOrderStatusInfo = computed(() => {
  const statusMap: { [key: number]: { text: string; type: string } } = {
    0: { text: '未确认', type: 'warning' },
    1: { text: '借调中', type: '' },
    2: { text: '已结束', type: 'danger' },
    3: { text: '已作废', type: 'info' }
  }

  return function (status: number) {
    return statusMap[status] || { text: '', color: '' }
  }
})

const gridRef = ref<VxeGridInstance>()
const gridOptions = reactive<VxeGridProps<GetEmployeeTransferModel>>({
  border: true,
  height: 'auto',
  align: null,
  columnConfig: {
    resizable: true
  },
  columns: [
    { type: 'seq', width: 50 },
    { field: 'employeeInfoName', title: '借调员工', width: 100 },
    { field: 'departmentName', title: '原部门', minWidth: 150 },
    { field: 'groupName', title: '原班组', minWidth: 150 },
    { field: 'transferDepartmentName', title: '借调部门', minWidth: 150 },
    { field: 'transferGroupName', title: '借调班组', minWidth: 150 },
    {
      field: 'transferBeginAndEndTime',
      title: '借调起止时间',
      width: 260,
      formatter({ row }) {
        return `${dayjs(row.transferBeginTime).format('YYYY-MM-DD HH:mm')} - ${dayjs(
          row.transferEndTime
        ).format('YYYY-MM-DD HH:mm')}`
      }
    },
    // { field: 'transferHours', title: '小时', width: 60 },
    { field: 'transferLeaderName', title: '借调班组长', width: 100 },
    { field: 'dataDescribe', title: '借调原因', width: 120 },
    {
      field: 'orderStatus',
      title: '状态',
      width: 90,
      slots: { default: 'orderStatus' }
    },
    { field: 'lastModifiedUserName', title: '操作人', width: 90 },
    { field: 'lastModifiedTime', title: '最后更新时间', width: 150 },
    {
      field: 'operation',
      title: '操作',
      align: 'center',
      fixed: 'right',
      width: 180,
      slots: {
        default: 'operation'
      }
    }
  ],
  pagerConfig: {
    enabled: true,
    pageSize: 20
  },
  proxyConfig: {
    ajax: {
      query: ({ page }) => {
        const quickSearchForm = gridHeaderRef.value?.quickSearchForm
        const advancedSearchForm = gridHeaderRef.value?.advancedSearchForm
        return getEmployeeTransfer({
          pageIndex: page.currentPage - 1, // 由于后端接口限制，首页从0开始
          pageSize: page.pageSize,
          ...quickSearchForm,
          ...advancedSearchForm
        })
      }
    }
  }
})

const handleQuickSearch = () => {
  gridRef.value?.commitProxy('reload')
}

const handleAdvancedSearch = () => {
  gridRef.value?.commitProxy('reload')
}

const handleReset = () => {
  gridRef.value?.commitProxy('reload')
}

const [registerModal, { openModal, closeModal }] = useModal()
const [registerReviewModal, { openModal: openReviewModal }] = useModal()

const handleAdd = () => {
  openModal(true, {
    isUpdate: false
  })
}

const handleReview = (row: GetEmployeeTransferModel) => {
  openReviewModal(true, {
    row
  })
}

const handleConfirm = async (row: GetEmployeeTransferModel) => {
  ElMessageBox.confirm(`是否确认名称为"${row.employeeInfoName}"的数据项`, '警告', {
    confirmButtonText: '确定',
    cancelButtonText: '取消',
    type: 'warning'
  }).then(async () => {
    const { code, data, message } = await updateEmployeeTransferConfirm({
      id: row.id,
      orderStatus: 1
    })
    if (code === 200 && data) {
      ElMessage.success('确认')
      gridRef.value?.commitProxy('query')
    } else {
      ElMessage.error(message)
    }
  })
}

const handleModify = (row: GetEmployeeTransferModel) => {
  openModal(true, {
    isUpdate: true,
    row
  })
}

const handleVoid = (row: GetEmployeeTransferModel) => {
  ElMessageBox.confirm(`是否作废名称为"${row.employeeInfoName}"的数据项`, '警告', {
    confirmButtonText: '确定',
    cancelButtonText: '取消',
    type: 'warning'
  }).then(async () => {
    const { code, data, message } = await updateEmployeeTransferConfirm({
      id: row.id,
      orderStatus: 3
    })
    if (code === 200 && data) {
      ElMessage.success('作废')
      gridRef.value?.commitProxy('query')
    } else {
      ElMessage.error(message)
    }
  })
}

const handleFinish = (row: GetEmployeeTransferModel) => {
  ElMessageBox.confirm(`是否结束名称为"${row.employeeInfoName}"的数据项`, '警告', {
    confirmButtonText: '确定',
    cancelButtonText: '取消',
    type: 'warning'
  }).then(async () => {
    const { code, data, message } = await updateEmployeeTransferConfirm({
      id: row.id,
      orderStatus: 2
    })
    if (code === 200 && data) {
      ElMessage.success('作废')
      gridRef.value?.commitProxy('query')
    } else {
      ElMessage.error(message)
    }
  })
}

const handleSuccess = () => {
  gridRef.value?.commitProxy('query')
  closeModal()
}

const [registerBatchAddModal, { openModal: openBatchAddModal, closeModal: closeBatchAddModal }] =
  useModal()

const handleBatchAdd = () => {
  openBatchAddModal()
}
const handleBatchAddSuccess = async () => {
  closeBatchAddModal()
  gridRef.value?.commitProxy('query')
}
</script>

<style scoped></style>
