<template>
  <div class="page-container">
    <vxe-grid class="box" ref="gridRef" v-bind="gridOptions">
      <template #top>
        <GridHeader
          ref="gridHeaderRef"
          v-bind="headerOptions"
          @quickSearch="handleQuickSearch"
          @advancedSearch="handleAdvancedSearch"
          @add="handleAdd"
          @reset="handleReset"
        />
      </template>
      <template #orderStatus="{ row }">
        <el-tag :type="getOrderStatusInfo(row.orderStatus).type">
          {{ getOrderStatusInfo(row.orderStatus).text }}
        </el-tag>
      </template>
      <template #operation="{ row }">
        <TableAction
          :actions="[
            {
              icon: 'edit',
              tooltip: '编辑',
              onClick: handleModify.bind(null, row)
            },
            {
              icon: 'delete',
              tooltip: '删除',
              onClick: handleDelete.bind(null, row)
            }
          ]"
        />
      </template>
    </vxe-grid>
  </div>
  <HonorListDialog @register="registerModal" @success="handleSuccess" />
</template>

<script setup lang="ts">
import type { ComponentExposed } from 'vue-component-type-helpers'
import type { VxeGridInstance, VxeGridProps } from 'vxe-table'
import type { GridHeaderProps } from '@/components/Table/types/gridHeader'
import type { GetHonorRollModel, GetHonorRollParams } from '@/api/sys/model/workModel'

import { reactive, ref, computed } from 'vue'
import { useModal } from '@/components/Modal/hooks/useModal'

import GridHeader from '@/components/Table/GridHeader.vue'
import HonorListDialog from './components/HonorListDialog.vue'
import { deleteHonorRoll, getHonorRoll } from '@/api/sys/work'
defineOptions({
  name: 'HonorList',
  inheritAttrs: false
})

const getOrderStatusInfo = computed(() => {
  const statusMap: { [key: number]: { text: string; type: string } } = {
    1: { text: '已启用', type: 'success' },
    2: { text: '已停用', type: 'danger' }
  }

  return function (status: number) {
    return statusMap[status] || { text: '', color: '' }
  }
})

const gridHeaderRef =
  ref<ComponentExposed<typeof GridHeader<GetHonorRollParams, 'searchKey'>>>()

const headerOptions = reactive<GridHeaderProps>({
  title: '荣誉榜',
  quickSearch: {
    singleSearch: {
      field: 'searchKey',
      type: 'input',
      title: '员工名称'
    },
    searchFormFields: { searchKey: '' }
  },
  advancedSearch: {
    labelWidth: 90,
    schemas: [
      {
        field: 'orderStatus',
        component: 'Select',
        label: '状态',
        componentProps: {
          options: [
            { label: '启用', value: 1 },
            { label: '停用', value: 2 }
          ]
        },
        colProps: {
          span: 8
        }
      }
    ]
  }
})

const gridRef = ref<VxeGridInstance>()
const gridOptions = reactive<VxeGridProps<GetHonorRollModel>>({
  border: true,
  height: 'auto',
  align: null,
  columnConfig: {
    resizable: true
  },
  columns: [
    { type: 'seq', width: 50 },
    {
      field: 'honorType',
      title: '类型',
      width: 100,
      formatter({ cellValue }) {
        const option: { [key: string]: string } = { '1': '荣誉榜', '2': '提升榜' }
        return option[cellValue]
      }
    },
    { field: 'departmentName', title: '部门', width: 150 },
    { field: 'employeeName', title: '姓名', width: 120 },
    { field: 'dataDescribe', title: '事迹', minWidth: 200 },
    {
      field: 'orderStatus',
      title: '状态',
      width: 100,
      slots: { default: 'orderStatus' }
    },
    { field: 'lastModifiedUserName', title: '操作人', width: 120 },
    { field: 'lastModifiedTime', title: '最后更新时间', width: 150 },
    {
      field: 'operation',
      title: '操作',
      align: 'center',
      fixed: 'right',
      width: 150,
      slots: {
        default: 'operation'
      }
    }
  ],
  pagerConfig: {
    enabled: true,
    pageSize: 20
  },
  proxyConfig: {
    ajax: {
      query: ({ page }) => {
        const quickSearchForm = gridHeaderRef.value?.quickSearchForm
        const advancedSearchForm = gridHeaderRef.value?.advancedSearchForm
        return getHonorRoll({
          pageIndex: page.currentPage - 1, // 由于后端接口限制，首页从0开始
          pageSize: page.pageSize,
          ...quickSearchForm,
          ...advancedSearchForm
        })
      }
    }
  }
})

const handleQuickSearch = () => {
  gridRef.value?.commitProxy('reload')
}

const handleAdvancedSearch = () => {
  gridRef.value?.commitProxy('reload')
}

const handleReset = () => {
  gridRef.value?.commitProxy('reload')
}

const [registerModal, { openModal, closeModal }] = useModal()

const handleAdd = () => {
  openModal(true, {
    isUpdate: false
  })
}

const handleModify = (row: GetHonorRollModel) => {
  openModal(true, {
    isUpdate: true,
    row
  })
}

const handleDelete = (row: GetHonorRollModel) => {
  ElMessageBox.confirm(`是否删除名称为"${row.employeeName}"的数据项`, '警告', {
    confirmButtonText: '确定',
    cancelButtonText: '取消',
    type: 'warning'
  }).then(() => {
    deleteHonorRoll({ id: row.id }).then((res) => {
      if (res.code === 200) {
        ElMessage.success('删除成功')
        gridRef.value?.commitProxy('query')
      } else {
        ElMessage.error(res.message)
      }
    })
  })
}

const handleSuccess = () => {
  gridRef.value?.commitProxy('query')
  closeModal()
}
</script>

<style scoped></style>
