<template>
  <BasicModal
    width="556px"
    v-bind="$attrs"
    @register="registerModal"
    :title="getTitle"
    @confirm="handleSubmit"
  >
    <BasicForm @register="registerForm">
      <template #imageUrl>
        <el-upload
          v-model:file-list="fileList"
          ref="uploadRef"
          name="picture"
          action="/api/HonorRoll/ImportHonorImage"
          list-type="picture-card"
          accept=".jpg,.jpeg,.png"
          :headers="{ Authorization: userStore.token }"
          :limit="1"
          :on-exceed="handleExceed"
          :before-upload="beforeAvatarUpload"
          :on-success="handleAvatarSuccess"
          :on-preview="handlePreview"
          :on-error="handleError"
        >
          <el-button type="primary">点击上传</el-button>
          <template #tip>
            <div class="el-upload__tip">只能上传jpg/png文件,且不超过3MB</div>
          </template>
        </el-upload>
      </template>
    </BasicForm>
  </BasicModal>
  <el-dialog v-model="dialogVisible">
    <img style="display: block; margin: 0 auto" :src="dialogImageUrl" />
  </el-dialog>
</template>

<script setup lang="ts">
import type { AddHonorRollData, UpdateHonorRollData } from '@/api/sys/model/workModel'
import type { ModalMethods } from '@/components/Modal/types'
import {
  genFileId,
  type ElUpload,
  type UploadProps,
  type UploadRawFile,
  type UploadUserFile
} from 'element-plus'

import { ref, unref, computed } from 'vue'

import BasicModal from '@/components/Modal/BasicModal.vue'
import BasicForm from '@/components/Form/BasicForm.vue'

import { useModalInner } from '@/components/Modal/hooks/useModal'
import { useForm } from '@/components/Form/hooks/useForm'
import { addHonorRoll, updateHonorRoll } from '@/api/sys/work'
import type { GetEmployeeInfoModel } from '@/api/sys/model/basicModel'
import useUserStore from '@/stores/user'
import { watchEffect } from 'vue'

const emit = defineEmits<{
  register: [modalMethods: ModalMethods, uuid: number]
  success: [{ isUpdate: boolean }]
}>()
const isUpdate = ref<boolean>(false)

const rowId = ref<string>('')

const getTitle = computed(() => (!unref(isUpdate) ? '新增' : '修改'))

const userStore = useUserStore()

const [registerForm, { setFieldsValue, resetFields, getFieldsValue, validate, clearValidate }] =
  useForm({
    labelWidth: 86,
    schemas: [
      {
        field: 'honorType',
        component: 'Select',
        label: '类型',
        rules: [{ required: true, trigger: 'change' }],
        componentProps: {
          options: [
            { label: '荣誉榜', value: 1 },
            { label: '提升榜', value: 2 }
          ]
        },
        colProps: { span: 14 }
      },
      {
        field: 'employeeID',
        component: 'PersonSelect',
        label: '姓名',
        rules: [{ required: true, trigger: 'change' }],
        componentProps: {
          onConfirm: (row: GetEmployeeInfoModel) => {
            setFieldsValue({
              departmentName: row.departmentName,
              departmentID: row.departmentID,
              employeeName: row.employeeName
            })
          }
        },
        colProps: { span: 14 }
      },
      {
        field: 'orderStatus',
        component: 'ElSwitch',
        label: '状态',
        rules: [{ required: true, trigger: 'blur' }]
      },
      {
        field: 'dataDescribe',
        component: 'ElInput',
        label: '事迹',
        rules: [{ required: true, trigger: 'blur' }],
        componentProps: {
          type: 'textarea',
          rows: 3
        }
      },
      {
        field: 'imageUrl',
        component: 'ElInput',
        label: '图片展示',
        // defaultValue: '123',
        // rules: [{ required: true, trigger: 'blur' }],
        slot: 'imageUrl'
      },
      {
        field: 'departmentName',
        component: 'ElInput',
        label: '部门名称',
        ifShow: false
      },
      {
        field: 'employeeName',
        component: 'ElInput',
        label: '员工名称',
        ifShow: false
      },
      {
        field: 'departmentID',
        component: 'ElInput',
        label: '部门ID',
        ifShow: false
      }
    ]
  })

const uploadRef = ref<InstanceType<typeof ElUpload>>()
const fileList = ref<UploadUserFile[]>([])

watchEffect(() => {
  setFieldsValue({ imageUrl: fileList.value[0]?.url })
})

const handleExceed: UploadProps['onExceed'] = (files) => {
  uploadRef.value!.clearFiles()
  const file = files[0] as UploadRawFile
  file.uid = genFileId()
  uploadRef.value!.handleStart(file)
  uploadRef.value!.submit()
}

const beforeAvatarUpload: UploadProps['beforeUpload'] = (rawFile) => {
  if (!['image/jpeg', 'image/jpg', 'image/png'].includes(rawFile.type)) {
    ElMessage.error('图片必须是 jpg | jpeg | png 其中一种')
    return false
  } else if (rawFile.size / 1024 / 1024 > 3) {
    ElMessage.error('图片尺寸不能超过3MB!')
    return false
  }
  setModalProps({ confirmLoading: true })
  return true
}

const handleAvatarSuccess: UploadProps['onSuccess'] = (response) => {
  const { status, data, message } = response
  if (status) {
    setFieldsValue({ imageUrl: data.fileName })
    setModalProps({ confirmLoading: false })
  } else {
    ElMessage.error(message)
  }
}
const handleError: UploadProps['onError'] = (error) => {
  ElMessage.error(error.message)
  setFieldsValue({ imageUrl: '' })
  setModalProps({ confirmLoading: false })
}

const dialogImageUrl = ref('')
const dialogVisible = ref(false)

const handlePreview: UploadProps['onPreview'] = (uploadFile) => {
  dialogImageUrl.value = uploadFile.url!
  dialogVisible.value = true
}

const [registerModal, { setModalProps }] = useModalInner(async (data) => {
  await resetFields()
  setModalProps({ confirmLoading: false })
  isUpdate.value = !!data?.isUpdate
  fileList.value = []

  if (unref(isUpdate)) {
    rowId.value = data.row.id
    await setFieldsValue({ ...data.row, orderStatus: data.row.orderStatus === 1 })
    if (data.row.imageUrl) {
      const arr = data.row.imageUrl.split('\\')
      fileList.value.push({ name: arr[arr.length - 1], url: data.row.imageUrl })
    }
  }
  clearValidate()
})

// 提交
const handleSubmit = async () => {
  await validate()
  setModalProps({ confirmLoading: true })
  try {
    // 新增
    if (!unref(isUpdate)) {
      const formData = getFieldsValue()

      const data = {
        ...formData,
        orderStatus: formData.orderStatus ? 1 : 2
      } as AddHonorRollData
      const { code, message } = await addHonorRoll(data)
      if (code === 200) {
        ElMessage.success('新增成功')
        emit('success', { isUpdate: unref(isUpdate) })
      } else {
        ElMessage.error(message)
      }
    } else {
      const formData = getFieldsValue()
      const data = {
        id: unref(rowId),
        ...formData,
        orderStatus: formData.orderStatus ? 1 : 2
      } as UpdateHonorRollData
      const { code, message } = await updateHonorRoll(data)

      if (code === 200) {
        ElMessage.success('修改成功')
        emit('success', { isUpdate: unref(isUpdate) })
      } else {
        ElMessage.error(message)
      }
    }
  } catch (error: any) {
    ElMessage(error.message)
  } finally {
    setModalProps({ confirmLoading: false })
  }
}
</script>
<style lang="scss" scoped></style>
