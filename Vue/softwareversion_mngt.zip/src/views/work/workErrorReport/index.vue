<template>
  <LayoutContainer>
    <template #leftSide>
      <basic-tree ref="basicListRef" v-bind="treeOptions" />
    </template>

    <div class="grid-container">
      <vxe-grid class="box" ref="workErrorReportGridRef" v-bind="gridWorkErrorReportOptions">
        <template #top>
          <GridHeader
            ref="gridHeaderErrorReportRef"
            v-bind="workErrorReportHeaderOptions"
            v-on="workErrorReportHeaderEvent"
          />
        </template>

        <template #operation="{ row, rowIndex }">
          <TableAction
            :actions="[
              {
                icon: 'edit',
                tooltip: '编辑',
                onClick: handleModify.bind(null, row)
              },
              // {
              //   icon: 'finish-wo-status',
              //   tooltip: '完成',
              //   onClick: handleFinish.bind(null, row, rowIndex)
              // },
              // {
              //   label: '处理',
              //   onClick: handleResolve.bind(null, row, rowIndex)
              // },
              {
                icon: 'cancle-wo-status',
                tooltip: '删除',
                onClick: handleDelete.bind(null, row, rowIndex)
              }
            ]"
          />
        </template>
      </vxe-grid>
    </div>

    <WorkErrorReportDialog @register="registerModal" @success="handleSuccess" />
  </LayoutContainer>
</template>

<script lang="tsx" setup>
import type { ComponentExposed } from 'vue-component-type-helpers'
import type { TreeProps } from '@/components/Tree/types/tree'
import type { VxeGridInstance, VxeGridListeners, VxeGridProps } from 'vxe-table'
import type { GetExceptionRecordModel, GetExceptionRecordParams } from '@/api/sys/model/workModel'
import type { GridHeaderEvent, GridHeaderProps } from '@/components/Table/types/gridHeader'
import type { GetProductionOrderByProjectIDModel } from '@/api/sys/model/schedulingModel'
import type { WoList } from '@/api/sys/model/workModel'
import type { SelectModel } from '@/api/model/baseModel'

import { reactive, ref, unref, computed } from 'vue'
import dayjs from 'dayjs'

import BasicTree from '@/components/Tree/BasicTree.vue'
import GridHeader from '@/components/Table/GridHeader.vue'
import TableAction from '@/components/Table/TableAction.vue'
import WorkErrorReportDialog from './components/WorkErrorReportDialog.vue'

import { useModal } from '@/components/Modal/hooks/useModal'
import { useForm } from '@/components/Form/hooks/useForm'
import { error } from '@/utils/log'
import { downloadByApi } from '@/utils/download'

import {
  getKeyValue,
  getManufactureDepartment,
  getManufactureDepartmentList,
  getGroupSelect,
  getProductionProjectSelect
} from '@/api/sys/basic'
import {
  getExceptionRecord,
  deleteExceptionRecord,
  updateExceptionRecordProcessingState,
  exportExceptionRecord,
  getProductionWoByOrderNo
} from '@/api/sys/work'
import { getProductionOrderByProjectID } from '@/api/sys/scheduling'
import { dateShortcuts } from '@/constant'

defineOptions({
  name: 'workErrorReport',
  inheritAttrs: false
})

const basicListRef = ref<InstanceType<typeof BasicTree>>()

const treeParams = reactive({
  departmentID: '',
  groupID: ''
})
// 列表配置
const treeOptions = reactive<TreeProps>({
  api: getManufactureDepartment,
  title: '部门列表',
  labelField: 'name',
  resultField: 'data',
  childrenField: 'children',
  nodeKey: 'id',
  accordion: true,
  cancleHightlightCurrent: true,
  formatter({ data }) {
    return (
      <div>
        {data.label}&nbsp;&nbsp;({data.childrenCount})
      </div>
    )
  },
  onSelect: async (data, node) => {
    workErrorReportGridRef.value?.remove()
    if (data) {
      workErrorReportHeaderOptions.title = `[${data.label}]生产异常反馈`

      if (data.isGroup) {
        treeParams.departmentID = node.parent.data.id
        treeParams.groupID = data.id
      } else {
        treeParams.departmentID = data.id
        treeParams.groupID = ''
      }
      workErrorReportGridRef.value?.commitProxy('reload')
    } else {
      workErrorReportHeaderOptions.title = `生产异常反馈`
      treeParams.departmentID = ''
      treeParams.groupID = ''
      workErrorReportGridRef.value?.remove()
    }
  }
})

const [registerForm, { getFieldsValue, validate }] = useForm({
  labelWidth: 60,
  fieldMapToTime: [['ExceptionTime', ['ExceptionStartTime', 'ExceptionEndTime'], 'YYYY-MM-DD']],
  schemas: [
    {
      field: 'ExceptionTime',
      component: 'ElDatePicker',
      label: '日期',
      required: true,
      componentProps: {
        type: 'daterange',
        startPlaceholder: '开始日期',
        endPlaceholder: '结束日期',
        unlinkPanels: true,
        shortcuts: dateShortcuts,
        valueFormat: 'YYYY-MM-DD'
      },
      colProps: {
        span: 23
      }
    }
  ]
})

const gridHeaderErrorReportRef =
  ref<
    ComponentExposed<
      typeof GridHeader<GetExceptionRecordParams, 'execptionStartTime' | 'execptionEndTime'>
    >
  >()
const workErrorReportHeaderOptions = reactive<GridHeaderProps>({
  title: '异常反馈',
  quickSearch: {
    singleSearch: {
      field: 'execptionTime',
      type: 'date',
      title: '异常时间',
      componentProps: {
        type: 'daterange',
        unlinkPanels: true,
        shortcuts: dateShortcuts,
        valueFormat: 'YYYY-MM-DD'
      }
    },
    searchFormFields: {
      execptionTime: [dayjs().subtract(7, 'day').format('YYYY-MM-DD'), dayjs().format('YYYY-MM-DD')]
    },
    fieldMapToTime: ['execptionTime', ['execptionStartTime', 'execptionEndTime'], 'YYYY-MM-DD']
  },
  advancedSearch: {
    labelWidth: 120,
    fieldMapToTime: [
      ['dataOfEntry', ['startDataOfEntry', 'endDataOfEntry'], 'YYYY-MM-DD'],
      ['dateofBirth', ['startDateOfBirth', 'endDateOfBirth'], 'YYYY-MM-DD']
    ],
    schemas: [
      {
        field: 'projectID',
        component: 'ApiSelect',
        label: '项目',
        componentProps({ formModel }) {
          return {
            api: getProductionProjectSelect,
            resultField: 'data.result',
            labelField: 'projectName',
            valueField: 'id',
            filterable: true,
            async onChange(value: string) {
              formModel.orderNo = undefined
              formModel.woNo = undefined
              let options: GetProductionOrderByProjectIDModel[] = []
              if (value) {
                const { data } = await getProductionOrderByProjectID({
                  ProjectID: value
                })

                options = data
              }

              unref(gridHeaderErrorReportRef)?.updateAdvancedSearchForm({
                field: 'orderNo',
                componentProps({ formModel }) {
                  return {
                    options: options,
                    labelField: 'orderNo',
                    valueField: 'orderNo',
                    filterable: true,
                    async onChange(value: string) {
                      formModel.WoNo = undefined
                      let options: WoList[] = []
                      if (value) {
                        const { data } = await getProductionWoByOrderNo({
                          orderNo: value,
                          projectID: formModel.projectID
                        })
                        options = data.woList
                      }

                      unref(gridHeaderErrorReportRef)?.updateAdvancedSearchForm({
                        field: 'woNo',
                        componentProps: {
                          options: options
                        }
                      })
                    }
                  }
                }
              })

              unref(gridHeaderErrorReportRef)?.updateAdvancedSearchForm({
                field: 'woNo',
                componentProps: {
                  options: []
                }
              })
            }
          }
        },
        colProps: {
          span: 8
        }
      },
      {
        field: 'orderNo',
        component: 'Select',
        label: '需求分类',
        componentProps({ formModel }) {
          return {
            options: [],
            labelField: 'orderNo',
            valueField: 'orderNo',
            filterable: true,
            async onChange(value: string) {
              formModel.woNo = undefined
              let options: WoList[] = []
              if (value) {
                const { data } = await getProductionWoByOrderNo({
                  orderNo: value,
                  projectID: formModel.projectID
                })
                options = data.woList
              }

              unref(gridHeaderErrorReportRef)?.updateAdvancedSearchForm({
                field: 'woNo',
                componentProps: {
                  options: options
                }
              })
            }
          }
        },
        colProps: {
          span: 8
        }
      },
      {
        field: 'woNo',
        component: 'Select',
        label: '单据编号',
        componentProps: {
          options: [],
          labelField: 'name',
          valueField: 'value',
          filterable: true
        },
        colProps: {
          span: 8
        }
      },
      {
        field: 'departmentID',
        component: 'ApiSelect',
        label: '生产部门',
        componentProps({ formActionType, formModel }) {
          return {
            api: getManufactureDepartmentList,
            resultField: 'data',
            labelField: 'name',
            valueField: 'id',
            filterable: true,
            async onChange(value: string) {
              formModel.groupID = undefined

              let options: SelectModel[] = []
              if (!(value === '')) {
                const { data } = await getGroupSelect({ departmentID: value })
                options = data.result
              }

              const { updateSchema } = formActionType
              updateSchema({
                field: 'groupID',
                componentProps: {
                  options: options
                }
              })
            }
          }
        },
        colProps: {
          span: 8
        }
      },
      {
        field: 'groupID',
        component: 'Select',
        label: '所属组别',
        componentProps: {
          options: [],
          filterable: true
        },
        colProps: {
          span: 8
        }
      },
      {
        field: 'execptionTime',
        label: '日期',
        component: 'ElDatePicker',
        required: true,
        componentProps: {
          type: 'date'
        },
        colProps: {
          span: 8
        }
      },
      {
        field: 'exceptionTypeID',
        component: 'ApiSelect',
        label: '异常类型',
        required: true,
        componentProps: {
          api: getKeyValue,
          resultField: 'data.result',
          labelField: 'value',
          valueField: 'id',
          params: {
            typeName: 'ProductionExceptionRecord'
          }
        },
        colProps: {
          span: 8
        }
      },
      {
        field: 'ProcessingState',
        component: 'Select',
        label: '处理状态',
        defaultValue: [0, 1],
        componentProps: {
          filterable: true,
          options: [
            { label: '未处理', value: 0 },
            { label: '处理中', value: 1 },
            { label: '已处理', value: 2 },
            { label: '全部', value: 3 }
          ],
          multiple: true
        },
        colProps: {
          span: 8
        }
      }
    ]
  },
  showExportButton: true,
  customExport: true
})

// 查询指定工单下的生产异常反馈
const queryWorkErrorReport = () => {
  workErrorReportGridRef.value?.commitProxy('reload')
}

const workErrorReportHeaderEvent: GridHeaderEvent = {
  quickSearch() {
    queryWorkErrorReport()
  },
  advancedSearch() {
    queryWorkErrorReport()
  },
  reset() {
    queryWorkErrorReport()
  },
  add() {
    openModal(true, {
      isUpdate: false
    })
  },
  exportClick() {
    ElMessageBox({
      title: '导出',
      showCancelButton: true,
      message: () => {
        return <basic-form onRegister={registerForm} />
      },
      beforeClose: async (action, instance, done) => {
        if (action === 'confirm') {
          await validate(async (isValid) => {
            const fieldsValue = getFieldsValue()

            if (isValid) {
              const loading = ElLoading.service({
                lock: true,
                text: 'Loading',
                background: 'rgba(0, 0, 0, 0.7)'
              })
              try {
                await downloadByApi(exportExceptionRecord, {
                  ...fieldsValue
                })
                ElMessage.success('导出成功')
                done()
              } catch (e: any) {
                ElMessage.error(e.message)
              } finally {
                loading.close()
              }
            }
          })
        }

        if (action === 'cancel') {
          done()
        }
      }
    })
  }
}

const workErrorReportGridRef = ref<VxeGridInstance>()
const gridWorkErrorReportOptions = reactive<VxeGridProps<GetExceptionRecordModel>>({
  border: true,
  align: null,
  height: 'auto',
  columnConfig: {
    resizable: true
  },
  columns: [
    { type: 'seq', width: 50 },
    { field: 'departmentName', title: '生产部门', width: 150 },
    {
      field: 'execptionTime',
      title: '日期',
      width: 150,
      formatter: ({ row }) => {
        return dayjs(row.execptionTime).format('YYYY-MM-DD')
      }
    },
    { field: 'projectName', title: '项目名称', width: 200 },
    { field: 'materialNo', title: '母件编码', width: 200 },
    {
      field: 'exceptionWorkTime',
      title: '异常工时(h)',
      width: 130,
      formatter({ cellValue }) {
        return typeof cellValue === 'number' ? `${cellValue}h` : ''
      }
    },
    { field: 'exceptionTypeName', title: '异常类型', width: 100 },
    { field: 'exceptionNumber', title: '异常数量', width: 100 },
    {
      field: 'processingState',
      title: '处理状态',
      width: 100,
      formatter({ cellValue }) {
        const item = processingStateList.find((item) => item.value === cellValue)

        return item ? item.label : cellValue
      }
    },
    { field: 'exceptionDescription', title: '异常描述', width: 200 },
    { field: 'processingMode', title: '处理方式', width: 200 },
    { field: 'dutyEmployeeName', title: '责任人', width: 100 },
    { field: 'lastModifiedUserName', title: '操作人', width: 100 },
    { field: 'lastModifiedTime', title: '最后更新时间', width: 150 },
    {
      field: 'operation',
      title: '操作',
      align: 'center',
      fixed: 'right',
      width: 100,
      slots: {
        default: 'operation'
      }
    }
  ],
  pagerConfig: {
    enabled: true
  },
  proxyConfig: {
    autoLoad: false,
    ajax: {
      query: ({ page }) => {
        const quickSearchForm = gridHeaderErrorReportRef.value?.quickSearchForm
        const advancedSearchForm = gridHeaderErrorReportRef.value?.advancedSearchForm

        return getExceptionRecord({
          pageIndex: page.currentPage - 1, // 由于后端接口限制，首页从0开始
          pageSize: page.pageSize,
          ...treeParams,
          ...quickSearchForm,
          ...advancedSearchForm
        })
      }
    }
  }
})
const processingStateList = [
  { label: '未处理', value: 0 },
  { label: '处理中', value: 1 },
  { label: '已处理', value: 2 }
]

const [registerModal, { openModal, setModalProps, closeModal }] = useModal()

// 修改异常反馈
const handleModify = (row: GetExceptionRecordModel) => {
  openModal(true, {
    isUpdate: true,
    row
  })
}
// 删除异常反馈
const handleDelete = (row: GetExceptionRecordModel, rowIndex: number) => {
  ElMessageBox.confirm(`是否确认删除序号为"${rowIndex + 1}"的数据项?`, '警告', {
    confirmButtonText: '确定',
    cancelButtonText: '取消',
    type: 'warning'
  })
    .then(async () => {
      try {
        const id = row.id
        const { data, message } = await deleteExceptionRecord({ id })

        if (data) {
          ElMessage.success('删除成功')
        } else {
          ElMessage.error(message)
        }
      } catch (err: any) {
        error(err.message)
      }
    })
    .catch(() => {})
    .finally(() => {
      workErrorReportGridRef.value?.commitProxy('query')
    })
}

// 完成异常反馈
const handleFinish = (row: GetExceptionRecordModel, rowIndex: number) => {
  if (row.exceptionDescription === '' || row.processingMode === '') {
    ElMessageBox.confirm(`请填写完整的异常反馈信息`, '警告', {
      confirmButtonText: '去填写',
      cancelButtonText: '取消',
      type: 'warning'
    })
      .then(async () => {
        try {
          openModal(true, {
            isFinish: true,
            isUpdate: true,
            row
          })
        } catch (err: any) {
          error(err.message)
        }
      })
      .catch(() => {})
  } else {
    ElMessageBox.confirm(`是否确认完成序号为"${rowIndex + 1}"的数据项?`, '警告', {
      confirmButtonText: '确定',
      cancelButtonText: '取消',
      type: 'warning'
    })
      .then(async () => {
        try {
          const { data, message } = await updateExceptionRecordProcessingState({
            id: row.id,
            processingState: 2
          })

          if (data) {
            ElMessage.success('完成反馈成功')
            workErrorReportGridRef.value?.commitProxy('query')
          } else {
            ElMessage.error(message)
          }
        } catch (err: any) {
          error(err.message)
        }
      })
      .catch(() => {})
  }
}

// 处理异常反馈
// const handleResolve = (row: GetExceptionRecordModel, rowIndex: number) => {
//   ElMessageBox.confirm(`是否确认处理序号为"${rowIndex + 1}"的数据项?`, '警告', {
//     confirmButtonText: '确定',
//     cancelButtonText: '取消',
//     type: 'warning'
//   })
//     .then(async () => {
//       try {
//         const { data, message } = await updateExceptionRecordProcessingState({
//           id: row.id,
//           processingState: 1
//         })

//         if (data) {
//           ElMessage.success('处理异常反馈成功')
//           workErrorReportGridRef.value?.commitProxy('query')
//         } else {
//           ElMessage.error(message)
//         }
//       } catch (err: any) {
//         error(err.message)
//       }
//     })
//     .catch(() => {})
// }

// 弹框确认成功
const handleSuccess = ({ isUpdate }: { isUpdate: boolean }) => {
  closeModal()

  workErrorReportGridRef.value?.commitProxy('query')
}
</script>

<style lang="scss" scoped>
.grid-container {
  height: 100%;
  padding: $margin $margin $margin 0;
}
</style>
