<template>
  <BasicModal
    width="70%"
    v-bind="$attrs"
    @register="registerModal"
    :title="getTitle"
    @confirm="handleSubmit"
  >
    <BasicForm @register="registerForm"> </BasicForm>
  </BasicModal>
</template>

<script lang="tsx" setup>
import type { ModalMethods } from '@/components/Modal/types'
import type { AddExceptionRecordData, UpdateExceptionRecordData } from '@/api/sys/model/workModel'

import { computed, ref, unref } from 'vue'
import dayjs from 'dayjs'

import BasicModal from '@/components/Modal/BasicModal.vue'
import { useModalInner } from '@/components/Modal/hooks/useModal'
import BasicForm from '@/components/Form/BasicForm.vue'
import { useForm } from '@/components/Form/hooks/useForm'
import { processingStateOptions } from './data'

import {
  getKeyValue,
  getManufactureDepartmentList,
  getGroupLeader,
  getDepartment,
  getProductionProjectSelect
} from '@/api/sys/basic'
import { addExceptionRecord, updateExceptionRecord } from '@/api/sys/work'
import {
  getProductionOrderByProjectID,
  getProductionProjectAppointData
} from '@/api/sys/scheduling'
import { removeNullProperties } from '@/utils'

const emit = defineEmits<{
  register: [modalMethods: ModalMethods, uuid: number]
  success: [{ isUpdate: boolean }]
}>()

const isUpdate = ref<boolean>(false)
const isFinish = ref<boolean>(false)
const rowId = ref('')
const [registerModal, { closeModal, setModalProps, changeOkLoading }] = useModalInner(
  async (data) => {
    resetFields()
    setModalProps({ confirmLoading: false })

    isUpdate.value = !!data?.isUpdate
    isFinish.value = !!data?.isFinish

    // 修改或者完工完善表单
    if (unref(isUpdate)) {
      rowId.value = data.row.id
      await setFieldsValue({
        ...data.row
      })

      await updateSchema({
        field: 'employeeInfoID',
        componentProps: {
          data: {
            value: data.row.employeeID,
            label: `${data.row.employeeNo}-${data.row.employeeName}`
          }
        }
      })
    }

    if (unref(isFinish)) {
      validate()
    }
  }
)

const getTitle = computed(() => (!unref(isUpdate) ? '新增' : '修改'))

const [registerForm, { setFieldsValue, resetFields, getFieldsValue, validate, updateSchema }] =
  useForm({
    labelWidth: 120,
    schemas: [
      // {
      //   field: 'woNo',
      //   component: 'Text',
      //   label: '单据编号',
      //   componentProps: {},
      //   colProps: {
      //     span: 8
      //   }
      // },
      // {
      //   field: 'productName',
      //   component: 'Text',
      //   label: '部件名称',
      //   colProps: {
      //     span: 8
      //   }
      // },
      // {
      //   field: 'processType',
      //   component: 'Text',
      //   label: '设备类型',
      //   componentProps: {},
      //   colProps: {
      //     span: 8
      //   }
      // },
      // {
      //   field: 'divider',
      //   label: '',
      //   component: 'ElDivider',
      //   componentProps: {}
      // },
      {
        field: 'departmentID',
        component: 'ApiSelect',
        label: '生产部门',
        required: true,
        componentProps({ formActionType, formModel }) {
          const { updateSchema } = formActionType
          return {
            api: getManufactureDepartmentList,
            resultField: 'data',
            labelField: 'name',
            valueField: 'id',
            filterable: true,
            async onChange(value: string) {
              formModel.groupEmployeeInfoID = undefined
              const { data } = await getGroupLeader({ departmentID: value })
              updateSchema({
                field: 'groupEmployeeInfoID',
                componentProps: {
                  options: data.result
                }
              })
            }
          }
        },
        colProps: {
          span: 8
        }
      },
      {
        field: 'groupEmployeeInfoID',
        component: 'Select',
        label: '班组长',
        required: true,
        componentProps: {
          labelField: 'leaderInfo',
          valueField: 'leaderID',
          filterable: true
        },
        colProps: {
          span: 8
        }
      },
      {
        field: 'execptionTime',
        label: '日期',
        defaultValue: dayjs().format('YYYY-MM-DD'),
        component: 'ElDatePicker',
        required: true,
        componentProps: {
          type: 'date'
        },
        colProps: {
          span: 8
        }
      },
      {
        field: 'exceptionTypeID',
        component: 'ApiSelect',
        label: '异常类型',
        required: true,
        componentProps: {
          api: getKeyValue,
          resultField: 'data.result',
          labelField: 'value',
          valueField: 'id',
          params: {
            typeName: 'ProductionExceptionRecord'
          }
        },
        colProps: {
          span: 8
        }
      },
      {
        field: 'exceptionWorkTime',
        component: 'ElInputNumber',
        label: '异常工时',
        required: true,
        defaultValue: 0.1,
        componentProps: {
          min: 0.1,
          max: 9999,
          step: 0.1
        },
        colProps: {
          span: 8
        }
      },
      {
        field: 'exceptionNumber',
        component: 'ElInputNumber',
        label: '异常数量',
        required: true,
        defaultValue: 0,
        componentProps: {
          min: 0,
          max: 9999,
          step: 1
        },
        colProps: {
          span: 8
        }
      },

      {
        field: 'projectID',
        component: 'ApiSelect',
        label: '关联项目',
        required: true,
        componentProps({ formActionType }) {
          const { updateSchema } = formActionType
          return {
            filterable: true,
            api: getProductionProjectSelect,
            resultField: 'data.result',
            labelField: 'projectName',
            valueField: 'id',
            async onChange(value: string) {
              const { data } = await getProductionOrderByProjectID({ ProjectID: value })
              updateSchema({
                field: 'orderNo',
                componentProps({ formModel, formActionType }) {
                  const { updateSchema } = formActionType
                  return {
                    options: data,
                    filterable: true,
                    labelField: 'orderNo',
                    valueField: 'orderNo',
                    async onChange(value: string) {
                      const { data } = await getProductionProjectAppointData({
                        projectID: formModel.projectID,
                        orderNo: value
                      })
                      updateSchema({
                        field: 'woNo',
                        componentProps: {
                          options: data.result
                        }
                      })
                    }
                  }
                }
              })
            }
          }
        },
        colProps: {
          span: 8
        }
      },
      {
        field: 'orderNo',
        component: 'Select',
        label: '需求分类',
        required: true,
        componentProps({ formModel, formActionType }) {
          const { updateSchema } = formActionType
          return {
            filterable: true,
            labelField: 'orderNo',
            valueField: 'orderNo',
            async onChange(value: string) {
              const { data } = await getProductionProjectAppointData({
                projectID: formModel.projectID,
                orderNo: value
              })
              updateSchema({
                field: 'woNo',
                componentProps: {
                  options: data.result
                }
              })
            }
          }
        },
        colProps: {
          span: 8
        }
      },
      {
        field: 'woNo',
        component: 'Select',
        label: '单据编号',
        required: true,
        componentProps: {
          filterable: true,
          labelField: 'woNo',
          valueField: 'woNo'
        },
        colProps: {
          span: 8
        }
      },

      {
        field: 'exceptionDescription',
        component: 'ElInput',
        label: '异常描述',
        dynamicRules({ model }) {
          // 完工与已处理状态需要录入
          if (unref(isFinish) || model.processingState === 2) {
            return [{ required: true, trigger: 'blur', message: '请输入异常描述' }]
          } else {
            return []
          }
        },
        componentProps: {
          type: 'textarea'
        },
        colProps: {
          span: 24
        }
      },
      {
        field: 'processingMode',
        component: 'ElInput',
        label: '处理方式',
        componentProps: {
          type: 'textarea'
        },
        dynamicRules({ model }) {
          if (unref(isFinish) || model.processingState === 2) {
            return [{ required: true, trigger: 'blur', message: '请输入处理方式' }]
          } else {
            return []
          }
        },
        colProps: {
          span: 24
        }
      },
      {
        field: 'dutyID',
        component: 'ApiCascader',
        label: '责任部门',
        rules: [{ required: true, trigger: 'change' }],
        componentProps: {
          api: getDepartment,
          resultField: 'data.result',
          labelField: 'departmentName',
          valueField: 'id',
          childrenField: 'sonData',
          props: {
            checkStrictly: true,
            emitPath: false
          }
        },
        colProps: {
          span: 8
        }
      },
      {
        field: 'dutyEmployeeName',
        component: 'ElInput',
        label: '责任人',
        rules: [{ required: true, trigger: 'change' }],
        colProps: {
          span: 8
        }
      },
      {
        field: 'processingState',
        component: 'Select',
        label: '状态',
        rules: [{ required: true, trigger: 'change' }],
        defaultValue: 0,
        componentProps: {
          options: processingStateOptions
        },
        colProps: {
          span: 8
        }
      }
      // {
      //   field: 'employeeInfoID',
      //   component: 'PersonSelect',
      //   label: '责任人',
      //   required: true,
      //   rules: [{ required: true, trigger: 'change' }],
      //   componentProps: {},
      //   colProps: {
      //     span: 8
      //   }
      // }
    ]
  })

// 提交
const handleSubmit = async () => {
  try {
    changeOkLoading(true)
    validate(async (isValid) => {
      if (isValid) {
        // 新增
        if (!unref(isUpdate)) {
          const data = getFieldsValue() as AddExceptionRecordData

          const addData = {
            ...data
          }
          const { code, message } = await addExceptionRecord(addData)
          if (code === 200) {
            ElMessage.success('新增成功')
            emit('success', { isUpdate: unref(isUpdate) })
          } else {
            ElMessage.error(message)
          }
        } else {
          const formData = getFieldsValue() as Omit<UpdateExceptionRecordData, 'id'>

          const data = {
            id: unref(rowId),
            ...formData
          }
          // 删除所有值为空的属性
          removeNullProperties(data)

          const { code, message } = await updateExceptionRecord(data)
          if (code === 200) {
            ElMessage.success('修改成功')
            emit('success', { isUpdate: unref(isUpdate) })
          } else {
            ElMessage.error(message)
          }
        }
      }
    })
  } catch (error: any) {
    ElMessage(error.message)
  } finally {
    changeOkLoading(false)
  }
}
</script>

<style lang="scss" scoped></style>
