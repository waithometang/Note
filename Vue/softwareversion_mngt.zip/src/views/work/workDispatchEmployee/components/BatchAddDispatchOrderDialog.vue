<template>
  <BasicModal
    top="5%"
    width="1200px"
    v-bind="$attrs"
    @register="registerModal"
    :title="getTitle"
    @confirm="handleSubmit"
    @close="gridRef?.clearEdit()"
  >
    <BasicForm @register="registerWorkOrderForm" />
    <el-divider content-position="left">
      <div style="font-weight: 700">本次派工</div>
    </el-divider>
    <vxe-grid ref="gridRef" v-bind="gridOptions" @edit-actived="handleEditActived">
      <template #employeeInfoID="{ row }">
        <div style="display: flex; align-items: center">
          <div>{{ row.employeeInfoName }}</div>
          <el-tag
            v-if="row.transferInStatus === 1"
            type="warning"
            size="small"
            effect="plain"
            style="margin-left: 5px"
            >借调</el-tag
          >
        </div>
      </template>
      <template #employeeInfoID_edit="{ row }">
        <PersonSelect
          v-model="row.employeeInfoID"
          :employeeName="row.employeeInfoName"
          :departmentID="workOrder?.departmentID"
          :groupID="workOrder?.groupID"
          @confirm="(data: GetEmployeeInfoModel) => handlePersonConfirm(data, row)"
          @clear="row.employeeInfoName = ''"
        ></PersonSelect>
      </template>
      <template #dispatchingNumber_edit="{ row }">
        <el-tooltip
          effect="dark"
          :content="'最大可填' + (row.residualDispatchingNumber || 0)"
          placement="right"
          :visible="gridRef?.isEditByRow(row)"
          ><el-input-number
            v-model="row.dispatchingNumber"
            :min="0"
            :max="row.residualDispatchingNumber"
            :step="0.1"
            :stepStrictly="true"
          ></el-input-number
        ></el-tooltip>
      </template>
      <template #startDate_edit="{ row }">
        <el-date-picker v-model="row.startDate" value-format="YYYY-MM-DD"></el-date-picker>
      </template>
      <template #operation="{ row }">
        <TableAction
          :actions="[
            {
              icon: 'edit',
              tooltip: '编辑',
              ifShow: !hasActiveEditRow(row),
              onClick: handleEdit.bind(null, row)
            },
            {
              icon: 'save',
              tooltip: '完成',
              ifShow: hasActiveEditRow(row),
              onClick: handleComplete.bind(null)
            },
            {
              icon: 'delete',
              tooltip: '删除',
              onClick: handleDelete.bind(null, row)
            }
          ]"
        />
      </template>
      <template #bottom>
        <div style="display: flex; justify-content: space-between; margin-top: 10px">
          <TableAction
            :actions="[
              {
                icon: 'plus',
                label: '新增',
                onClick: handleAdd.bind(null),
                style: {
                  color: '#008cd6'
                }
              },
              {
                label: '最大分配',
                onClick: handleMaxAllot.bind(null),
                style: {
                  color: '#008cd6'
                }
              }
            ]"
          ></TableAction>
          <div style="text-align: right; padding-right: 10px">
            共{{ gridRef?.getTableData().fullData.length }}条记录
          </div>
        </div>
      </template>
    </vxe-grid>
  </BasicModal>
</template>

<script setup lang="tsx">
import type { ModalMethods } from '@/components/Modal/types'
import type { VxeGridEvents, VxeGridInstance, VxeGridProps } from 'vxe-table'

import { ref, reactive, computed } from 'vue'

import BasicModal from '@/components/Modal/BasicModal.vue'
import BasicForm from '@/components/Form/BasicForm.vue'
import TableAction from '@/components/Table/TableAction.vue'
import PersonSelect from '@/components/Form/components/PersonSelect/index.vue'

import { useModalInner } from '@/components/Modal/hooks/useModal'
import { useForm } from '@/components/Form/hooks/useForm'
import { addDispatchingEmployee, getDispatchingEmployee } from '@/api/sys/work'
import type { DispatchingEmployee, GetDispatchingGroupWoModel } from '@/api/sys/model/workModel'
import dayjs from 'dayjs'
import type { GetEmployeeInfoModel } from '@/api/sys/model/basicModel'
import { getEmployeeInfoSelect } from '@/api/sys/basic'
import { round, floor } from 'xe-utils'

const emit = defineEmits<{
  register: [modalMethods: ModalMethods, uuid: number]
  success: []
}>()

const getTitle = '新增'

const workOrder = ref<GetDispatchingGroupWoModel>()

const isTotalDispatch = computed(() => {
  return workOrder.value?.dispatchingMehtod === 1
})

const getDispatchingEmployeeList = async () => {
  const { code, data } = await getDispatchingEmployee({
    DispatchingGroupID: workOrder.value!.id!,
    pageIndex: 0,
    pageSize: 9999
  })
  if (code === 200) {
    const tableData = gridRef.value!.getTableData().tableData
    if (isTotalDispatch.value) {
      tableData.forEach((row) => {
        const res = data.result.find((item) => item.employeeInfoID === row.employeeInfoID)
        if (res) {
          row.dispatchedNumberTip = res.dispatchingNumber
        } else {
          row.dispatchedNumberTip = 0
        }
      })

      gridRef.value?.showColumn('dispatchedNumberTip')
      gridRef.value?.hideColumn('dispatchingNumberTip')
    } else {
      tableData.forEach((row) => {
        const res = data.result.filter((item) => item.employeeInfoID === row.employeeInfoID)
        if (res.length > 0) {
          const dispatched = res.reduce((acc, cur) => acc + cur.dispatchingNumber, 0)
          row.dispatchingNumberTip = `${dispatched}/${res[0].leftDispatchingCount}/${workOrder.value?.dispatchingNumber}`
        } else {
          row.dispatchingNumberTip = `${0}/${workOrder.value?.dispatchingNumber}/${workOrder.value
            ?.dispatchingNumber}`
        }
        const leftDispatchingCount = row.dispatchingNumberTip.split('/')[1]
        row.residualDispatchingNumber = leftDispatchingCount || 0
      })
      gridRef.value?.showColumn('dispatchingNumberTip')
      gridRef.value?.hideColumn('dispatchedNumberTip')
    }
  }
}

const [registerModal, { setModalProps, changeOkLoading }] = useModalInner(async (data) => {
  await resetWorkOrderFields()
  await gridRef.value?.loadData([])
  gridOptions.loading = true
  setModalProps({ confirmLoading: false })
  workOrder.value = data.workOrder

  await setFieldsWorkOrderValue({
    ...data.workOrder,
    startDate: dayjs(data.workOrder.startDate).format('YYYY-MM-DD')
  })

  // 批量添加人员
  const {
    code,
    data: res,
    message
  } = await getEmployeeInfoSelect({
    groupID: workOrder.value!.groupID!,
    requestDate: workOrder.value!.startDate
  })
  if (code === 200) {
    res.result.forEach((item) => {
      gridRef.value?.insertAt(
        {
          employeeInfoID: item.id,
          employeeInfoName: item.employeeName,
          transferInStatus: item.transferInStatus,
          dispatchingNumber: 0, //输入框的值
          startDate: dayjs().format('YYYY-MM-DD'),
          residualDispatchingNumber: 0 //输入框提示的值
        },
        -1
      )
    })
  } else {
    ElMessage.error(message)
  }

  await getDispatchingEmployeeList() // 查询员工组内派工情况
  gridOptions.loading = false
})

const [
  registerWorkOrderForm,
  { resetFields: resetWorkOrderFields, setFieldsValue: setFieldsWorkOrderValue }
] = useForm({
  labelWidth: 120,
  schemas: [
    {
      field: 'woNo',
      component: 'ElInput',
      label: '单据编号',
      componentProps: { disabled: true },
      colProps: {
        span: 8
      }
    },
    {
      field: 'productName',
      component: 'ElInput',
      label: '部件名称',
      componentProps: { disabled: true },
      colProps: {
        span: 8
      }
    },
    {
      field: 'processName',
      component: 'ElInput',
      label: '设备类型',
      componentProps: { disabled: true },
      colProps: {
        span: 8
      }
    },
    {
      field: 'groupName',
      component: 'ElInput',
      label: '班组',
      componentProps: { disabled: true },
      colProps: {
        span: 8
      }
    },
    {
      field: 'leaderName',
      component: 'ElInput',
      label: '班组长',
      componentProps: { disabled: true },
      colProps: {
        span: 8
      }
    },
    {
      field: 'sonProcessName',
      component: 'ElInput',
      label: '工序任务',
      componentProps: { disabled: true },
      colProps: {
        span: 8
      }
    },
    {
      field: 'dispatchingNumber',
      component: 'ElInput',
      label: '车间派工数量',
      componentProps: { disabled: true },
      colProps: {
        span: 8
      }
    },
    {
      field: 'leftDispatchingCount',
      component: 'ElInput',
      label: '剩余数量',
      componentProps: { disabled: true },
      ifShow() {
        return isTotalDispatch.value
      },
      colProps: {
        span: 8
      }
    },
    {
      field: 'startDate',
      component: 'ElInput',
      label: '计划开始日期',
      componentProps: { disabled: true },
      colProps: {
        span: 8
      }
    }
  ]
})

const gridRef = ref<VxeGridInstance>()
const gridOptions = reactive<VxeGridProps<DispatchingEmployee>>({
  border: true,
  height: '400px',
  columnConfig: {
    resizable: true
  },
  keepSource: true,
  editConfig: {
    trigger: 'dblclick',
    mode: 'row',
    // showStatus: true,
    autoClear: false
    // showUpdateStatus: true,
    // showInsertStatus: true
  },
  editRules: {
    employeeInfoID: [
      {
        required: true,
        content: '请选择人员',
        type: 'string',
        trigger: 'manual'
      }
    ],
    dispatchingNumber: [
      {
        required: true,
        content: '请输入派工数量且大于0',
        trigger: 'manual',
        type: 'number',
        min: 0.1
      }
    ],
    startDate: [
      {
        required: true,
        content: '请输入计划开始日期',
        type: 'string',
        trigger: 'manual',
        validator({ cellValue, row }) {
          return new Promise((res, rej) => {
            if (!cellValue) {
              rej(new Error('请输入计划开始日期'))
            }
            const tableData = gridRef.value?.getTableData().fullData || []
            const filterData = tableData.filter(
              (item) => item.employeeInfoID === row.employeeInfoID
            )
            if (filterData.length > 1) {
              if (filterData.filter((item) => item.startDate === cellValue).length > 1) {
                rej(new Error('员工重复派工'))
              }
            }
            res()
          })
        }
      }
    ]
  },
  columns: [
    { type: 'checkbox', width: 50 },
    {
      field: 'employeeInfoID',
      title: '作业者',
      editRender: {},
      slots: { edit: 'employeeInfoID_edit', default: 'employeeInfoID' }
    },
    {
      field: 'employeeInfoName',
      title: '作业者名称',
      visible: false
    },
    {
      field: 'transferInStatus',
      title: '是否借调',
      visible: false
    },
    {
      field: 'dispatchedNumberTip',
      title: '已派工数量',
      visible: true
    },
    {
      field: 'dispatchingNumberTip',
      title: '已/未/总派工数量',
      visible: true
    },
    {
      field: 'dispatchingNumber',
      title: '派工数量',
      editRender: {},
      slots: { edit: 'dispatchingNumber_edit' }
    },
    {
      field: 'startDate',
      title: '计划开始日期',
      editRender: {},
      slots: { edit: 'startDate_edit' }
    },
    {
      field: 'operation',
      title: '操作',
      align: 'center',
      fixed: 'right',
      width: 150,
      slots: {
        default: 'operation'
      }
    }
  ],
  data: []
})

const handlePersonConfirm = (data: GetEmployeeInfoModel, row: DispatchingEmployee) => {
  row.employeeInfoName = data.employeeName
}

const handleEditActived: VxeGridEvents.EditActived = async ({ row }) => {
  if (isTotalDispatch.value) {
    filterResidual(row)
  }
}

// 计算剩余派工数量
const filterResidual = (row: any) => {
  const filertList = gridRef.value?.getTableData().fullData.filter((item) => item !== row)

  // const filertList = tableData?.filter((item) => item.processID === row.processID)

  // const countProportion = filertList?.reduce((count, cur) => count + cur.proportion, 0)
  const countDispatchingNumber = filertList?.reduce(
    (count, cur) => count + cur.dispatchingNumber,
    0
  )

  row.residualDispatchingNumber = round(
    workOrder.value!.leftDispatchingCount - countDispatchingNumber,
    1
  )
}

// 判断是否编辑活跃行
const hasActiveEditRow = (row: any): boolean => {
  const $grid = gridRef.value
  if ($grid) {
    return $grid.isEditByRow(row)
  }
  return false
}

const handleEdit = (row: any) => {
  gridRef.value?.setEditRow(row)
}

const handleComplete = () => {
  gridRef.value?.clearEdit()
}

const handleDelete = (row: any) => {
  gridRef.value?.remove(row)
}

const handleAdd = () => {
  gridRef.value?.insertAt(
    {
      employeeInfoID: '',
      employeeInfoName: '',
      dispatchingNumber: 0,
      startDate: dayjs().format('YYYY-MM-DD'),
      residualDispatchingNumber: 0
    },
    -1
  )
}

const handleMaxAllot = async () => {
  const selectData = gridRef.value!.getCheckboxRecords()
  const hasSelect = selectData.length > 0
  if (!hasSelect) {
    ElMessage.warning('请选择需要分配的人员')
    return
  }
  const tableData = selectData
  // const tableData = hasSelect ? selectData : gridRef.value!.getTableData().tableData
  const len = tableData.length
  const leftDispatchingCount = workOrder.value!.leftDispatchingCount
  if (isTotalDispatch.value) {
    const avg = floor(leftDispatchingCount / len, 1)
    tableData.forEach(async (row, index) => {
      row.dispatchingNumber = avg

      if (index === len - 1) {
        row.dispatchingNumber = round(row.dispatchingNumber + leftDispatchingCount - avg * len, 1)
      }
    })
  } else {
    tableData.forEach(async (row) => {
      const leftDispatchingCount = row.dispatchingNumberTip.split('/')[1]
      row.residualDispatchingNumber = leftDispatchingCount || 0
      row.dispatchingNumber = leftDispatchingCount || 0
    })
  }
}

// 提交
const handleSubmit = async () => {
  await gridRef.value?.clearEdit()
  const tableData = gridRef.value?.getCheckboxRecords() as DispatchingEmployee[]
  const errMap = await gridRef.value?.validate(tableData)
  if (tableData.length === 0) {
    ElMessage.warning('请选择需要新增的行数据')
    return
  }
  if (errMap) {
    return
  }

  changeOkLoading(true)
  try {
    // 新增
    const formData = {
      dispatchingEmployees: tableData,
      woNo: workOrder.value!.woNo!,
      dispatchingGroupID: workOrder.value!.id
    }

    const { code, data, message } = await addDispatchingEmployee(formData)
    if (code === 200 && data) {
      emit('success')
      ElMessage.success('新增成功')
    } else {
      ElMessage.error(message)
    }
  } catch (error: any) {
    ElMessage.error(error.message)
  } finally {
    changeOkLoading(false)
  }
}
</script>

<style scoped></style>
