<template>
  <BasicModal
    width="70%"
    v-bind="$attrs"
    @register="registerModal"
    :title="getTitle"
    @confirm="handleSubmit"
  >
    <BasicForm @register="registerWorkOrderForm" />
    <el-divider content-position="left">
      <div style="font-weight: 700">本次派工</div>
    </el-divider>
    <BasicForm @register="registerForm"> </BasicForm>
  </BasicModal>
</template>

<script setup lang="tsx">
import type { ModalMethods } from '@/components/Modal/types'

import { ref, computed } from 'vue'

import BasicModal from '@/components/Modal/BasicModal.vue'
import BasicForm from '@/components/Form/BasicForm.vue'

import { useModalInner } from '@/components/Modal/hooks/useModal'
import { useForm } from '@/components/Form/hooks/useForm'
import { transferDispatchingEmployee, updateDispatchingEmployee } from '@/api/sys/work'
import type {
  GetDispatchingGroupWoModel,
  TransferDispatchingEmployeeData,
  UpdateDispatchingEmployeeData
} from '@/api/sys/model/workModel'
import dayjs from 'dayjs'
import { round } from 'lodash-es'

const emit = defineEmits<{
  register: [modalMethods: ModalMethods, uuid: number]
  success: [{ isUpdate?: boolean }]
}>()

const rowId = ref('')

const isUpdate = ref(false)

const orderStatus = ref(0)

const getTitle = computed(() => {
  return isUpdate.value ? '修改' : '转交'
})

const workOrder = ref<GetDispatchingGroupWoModel>()
const maxDispatchNumber = ref(0)
const isTotalDispatch = computed(() => {
  return workOrder.value?.dispatchingMehtod === 1
})

const [registerModal, { setModalProps, changeOkLoading }] = useModalInner(async (data) => {
  await resetFields()
  await resetWorkOrderFields()
  setModalProps({ confirmLoading: false })
  workOrder.value = data.workOrder
  isUpdate.value = !!data.isUpdate
  orderStatus.value = data.row.orderStatus
  if (isTotalDispatch.value) {
    workOrder.value &&
      (maxDispatchNumber.value = round(
        workOrder.value.leftDispatchingCount + data.row.dispatchingNumber,
        1
      ))
  } else {
    maxDispatchNumber.value = round(data.row.leftDispatchingCount + data.row.dispatchingNumber, 1)
  }

  await setFieldsWorkOrderValue({
    ...data.workOrder,
    startDate: dayjs(data.workOrder.startDate).format('YYYY-MM-DD'),
    leftDispatchingCount: isTotalDispatch.value
      ? data.workOrder.leftDispatchingCount
      : data.row.leftDispatchingCount
  })

  await updateSchema({
    field: 'employeeInfoID',
    label: isUpdate.value ? '作业者' : '转交员工',
    componentProps: {
      departmentID: data.workOrder.departmentID,
      groupID: data.workOrder.groupID,
      attendanceDate: data.row.startDate
    }
  })

  rowId.value = data.row.id

  if (isUpdate.value) {
    await setFieldsValue({ ...data.row })
  } else {
    await setFieldsValue({
      ...data.row,
      employeeInfoID: void 0,
      startDate: dayjs().format('YYYY-MM-DD')
    })
  }

  clearValidate()
})

const [
  registerWorkOrderForm,
  { resetFields: resetWorkOrderFields, setFieldsValue: setFieldsWorkOrderValue }
] = useForm({
  labelWidth: 120,
  schemas: [
    {
      field: 'woNo',
      component: 'ElInput',
      label: '单据编号',
      componentProps: { disabled: true },
      colProps: {
        span: 8
      }
    },
    {
      field: 'productName',
      component: 'ElInput',
      label: '部件名称',
      componentProps: { disabled: true },
      colProps: {
        span: 8
      }
    },
    {
      field: 'processName',
      component: 'ElInput',
      label: '设备类型',
      componentProps: { disabled: true },
      colProps: {
        span: 8
      }
    },
    {
      field: 'groupName',
      component: 'ElInput',
      label: '班组',
      componentProps: { disabled: true },
      colProps: {
        span: 8
      }
    },
    {
      field: 'leaderName',
      component: 'ElInput',
      label: '班组长',
      componentProps: { disabled: true },
      colProps: {
        span: 8
      }
    },
    {
      field: 'sonProcessName',
      component: 'ElInput',
      label: '工序任务',
      componentProps: { disabled: true },
      colProps: {
        span: 8
      }
    },
    {
      field: 'dispatchingNumber',
      component: 'ElInput',
      label: '车间派工数量',
      componentProps: { disabled: true },
      colProps: {
        span: 8
      }
    },
    {
      field: 'leftDispatchingCount',
      component: 'ElInput',
      label: '剩余数量',
      ifShow() {
        return isUpdate.value
      },
      componentProps: { disabled: true },
      colProps: {
        span: 8
      }
    },
    {
      field: 'startDate',
      component: 'ElInput',
      label: '计划开始日期',
      componentProps: { disabled: true },
      colProps: {
        span: 8
      }
    }
  ]
})

const [
  registerForm,
  { resetFields, getFieldsValue, updateSchema, setFieldsValue, validate, clearValidate }
] = useForm({
  labelWidth: 120,
  schemas: [
    {
      field: 'employeeInfoID',
      component: 'PersonSelect',
      label: '作业者',
      rules: [{ required: true, trigger: 'change' }],
      dynamicDisabled() {
        return orderStatus.value === 2 || (orderStatus.value === 1 && isUpdate.value)
      },
      colProps: {
        span: 8
      }
    },
    {
      field: 'dispatchingNumber',
      component: 'ElInputNumber',
      label: '派工数量',
      defaultValue: 1,
      rules: [
        {
          required: true,
          trigger: 'blur'
          // validator(_rule, value, cb) {
          //   if (value > workOrder.value!.leftDispatchingCount) {
          //     cb('派工数量不能大于剩余数量')
          //   }
          //   cb()
          // }
        }
      ],
      render({ model, field }) {
        return (
          <div style="display:flex;gap:8px">
            <el-input-number
              v-model={model[field]}
              min={0}
              step={0.1}
              stepStrictly={true}
              disabled={orderStatus.value === 2}
            ></el-input-number>
            <div style="color:#aaa;font-size:14px">最大可填{maxDispatchNumber.value}</div>
          </div>
        )
      },
      colProps: {
        span: 8
      }
    },
    {
      field: 'startDate',
      component: 'ElDatePicker',
      label: '计划开始日期',
      defaultValue: dayjs().add(1, 'day').format('YYYY-MM-DD'),
      rules: [{ required: true, trigger: 'change' }],
      dynamicDisabled() {
        return orderStatus.value === 2
      },
      componentProps: {
        valueFormat: 'YYYY-MM-DD'
      },
      colProps: {
        span: 8
      }
    },
    {
      field: 'finishCount',
      component: 'ElInput',
      label: '完成数量',
      componentProps: { disabled: true, style: { width: '30%' } },
      colProps: {
        span: 8
      }
    },
    {
      field: 'takeTime',
      component: 'ElInput',
      label: '总用时',
      componentProps: { disabled: true },
      render({ model, field }) {
        return (
          <div style="display:flex;gap:8px">
            <el-input style="width:30%" v-model={model[field]} disabled={true}></el-input>
            <div>H</div>
          </div>
        )
      },
      colProps: {
        span: 8
      }
    },
    {
      field: 'finishPercent',
      component: 'ElInput',
      label: '完成比率',
      componentProps: { disabled: true },
      render({ model, field }) {
        return (
          <div style="display:flex;gap:8px">
            <el-input style="width:30%" v-model={model[field]} disabled={true}></el-input>
            <div>%</div>
          </div>
        )
      },
      colProps: {
        span: 8
      }
    }
  ]
})

// 提交
const handleSubmit = async () => {
  await validate()
  changeOkLoading(true)
  try {
    // 编辑
    if (isUpdate.value) {
      const formData = {
        ...getFieldsValue(),
        id: rowId.value,
        dispatchingGroupID: workOrder.value!.id
      } as UpdateDispatchingEmployeeData
      const { code, data, message } = await updateDispatchingEmployee(formData)
      if (code === 200 && data) {
        emit('success', { isUpdate: true })
        ElMessage.success('修改成功')
      } else {
        ElMessage.error(message)
      }
    } else {
      const formData = {
        ...getFieldsValue(),
        id: rowId.value
      } as TransferDispatchingEmployeeData
      const { code, data, message } = await transferDispatchingEmployee(formData)
      if (code === 200 && data) {
        emit('success', { isUpdate: false })
        ElMessage.success('转交成功')
      } else {
        ElMessage.error(message)
      }
    }
  } catch (error: any) {
    ElMessage.error(error.message)
  } finally {
    changeOkLoading(false)
  }
}
</script>

<style scoped></style>
