<template>
  <LayoutContainer>
    <template #leftSide>
      <basic-tree ref="basicTreeRef" v-bind="listOptions" />
    </template>

    <el-scrollbar class="grid-container">
      <div class="box vxe-grid-container">
        <vxe-grid ref="gridWorkOrderGroupRef" v-bind="gridWorkOrderGroupOptions" v-on="gridEvents">
          <template #top>
            <GridHeader
              ref="gridHeaderWorkOrderGroupRef"
              v-bind="WorkOrderGroupHeaderOptions"
              @quickSearch="handleQuickSearch"
              @advancedSearch="handleAdvancedSearch"
              @reset="handleReset"
              @export-click="exportClick"
            >
              <template #prependOperation>
                <el-checkbox
                  style="margin-right: 20px"
                  v-model="showNoDispatch"
                  label="只显示未派工单"
                  size="large"
                  @change="handleQuickSearch"
                />
              </template>
            </GridHeader>
          </template>
          <template #finishPercent="{ row }">
            <el-progress
              :stroke-width="12"
              :percentage="row.finishPercent"
              :status="row.finishPercent == 100 ? 'success' : ''"
            />
          </template>
          <template #orderStatus="{ row }">
            <el-tag :type="getGroupOrderStatusInfo(row.orderStatus).type">
              {{ getGroupOrderStatusInfo(row.orderStatus).text }}
            </el-tag>
          </template>
        </vxe-grid>
      </div>
      <div class="box vxe-grid-container">
        <vxe-grid ref="gridDispatchEmployeeRef" v-bind="gridWorkDispatchEmployeeOptions">
          <template #top>
            <GridHeader
              ref="gridHeaderWorkDispatchEmployeeRef"
              v-bind="workDispatchEmployeeHeaderOptions"
              @quickSearch="handleDispatchEmployeeQuickSearch"
              @add="handleAdd"
              @advancedSearch="handleDispatchEmployeeAdvancedSearch"
              @reset="handleDispatchEmployeeReset"
            >
            </GridHeader>
          </template>
          <template #employee="{ row }">
            <div style="display: flex; align-items: center">
              <div>{{ row.employeeNo + '-' + row.employeeName }}</div>
              <el-tag
                v-if="row.transferInStatus === 1"
                type="warning"
                size="small"
                effect="plain"
                style="margin-left: 5px"
                >借调</el-tag
              >
            </div>
          </template>
          <template #orderStatus="{ row }">
            <el-tag :type="getDispatchEmployeeOrderStatusInfo(row.orderStatus).type">
              {{ getDispatchEmployeeOrderStatusInfo(row.orderStatus).text }}
            </el-tag>
          </template>
          <template #operation="{ row }">
            <TableAction
              :actions="[
                {
                  icon: 'edit',
                  tooltip: '编辑',
                  onClick: handleEdit.bind(null, row)
                },
                {
                  icon: 'delivery',
                  tooltip: '转交',
                  ifShow: row.orderStatus === 1,
                  onClick: handleDelivery.bind(null, row)
                },
                {
                  icon: 'delete',
                  tooltip: '删除',
                  ifShow: row.orderStatus !== 2,
                  onClick: handleDelete.bind(null, row)
                }
              ]"
            />
          </template>
        </vxe-grid>
      </div>
    </el-scrollbar>
    <AddDispatchOrderDialog @register="registerAddModal" @success="handleAddSuccess" />
    <DispatchOrderDialog @register="registerModal" @success="handleSuccess" />
  </LayoutContainer>
</template>

<script lang="tsx" setup>
import type { ComponentExposed } from 'vue-component-type-helpers'
import type { VxeGridInstance, VxeGridListeners, VxeGridProps } from 'vxe-table'
import type {
  GetDispatchingGroupWoModel,
  GetDispatchingEmployeeWoModel,
  GetDispatchingEmployeeParams,
  GetDispatchingGroupWoParams
} from '@/api/sys/model/workModel'
import type { GridHeaderProps } from '@/components/Table/types/gridHeader'
import type { TreeProps } from '@/components/Tree/types/tree'

import { ref, reactive, computed } from 'vue'

import BasicTree from '@/components/Tree/BasicTree.vue'
import GridHeader from '@/components/Table/GridHeader.vue'
import TableAction from '@/components/Table/TableAction.vue'

import DispatchOrderDialog from './components/DispatchOrderDialog.vue'
import AddDispatchOrderDialog from './components/BatchAddDispatchOrderDialog.vue'

import {
  getProductionProcessTopLevel,
  getManufactureDepartment,
  getProductionProcessChildren,
  getManufactureDepartmentList,
  getGroupSelect
} from '@/api/sys/basic'
import {
  deleteDispatchingEmployee,
  getDispatchingGroupWo,
  getDispatchingEmployee,
  exportDispatchingEmployee,
  exportDispatchingScheduling
} from '@/api/sys/work'

import { useModal } from '@/components/Modal/hooks/useModal'
import dayjs from 'dayjs'
import { downloadByApi } from '@/utils/download'
import { useForm } from '@/components/Form/hooks/useForm'
import { dateShortcuts } from '@/constant'
import { exportTypeList, EXPORT_TYPE, orderStatusList, orderStatusListGroup } from './data'

const getGroupOrderStatusInfo = computed(() => {
  const statusMap: { [key: number]: { text: string; type: string } } = {}

  orderStatusList.forEach(({ label, value, type }) => {
    statusMap[value] = { text: label, type }
  })

  return function (status: number) {
    return statusMap[status] || { text: '', color: '' }
  }
})

const getDispatchEmployeeOrderStatusInfo = computed(() => {
  const statusMap: { [key: number]: { text: string; type: string } } = {}
  orderStatusListGroup.forEach(({ label, value, type }) => {
    statusMap[value] = { text: label, type }
  })

  return function (status: number) {
    return statusMap[status] || { text: '', color: '' }
  }
})

defineOptions({
  name: 'WorkDispatch',
  inheritAttrs: false
})

const basicTreeRef = ref<InstanceType<typeof BasicTree>>()

const dispatchingGroupID = ref('') // 车间派工id

const showNoDispatch = ref(false)

// 列表配置
const listOptions = reactive<TreeProps>({
  api: getManufactureDepartment,
  title: '部门列表',
  labelField: 'name',
  resultField: 'data',
  childrenField: 'children',
  params: { departmentName: '制造中心' },
  nodeKey: 'id',
  cancleHightlightCurrent: true,
  onSelect: async (node) => {
    console.log(node)
    // await gridHeaderWorkOrderGroupRef.value?.resetAdvancedSearchFormFields()
    // await gridHeaderWorkDispatchEmployeeRef.value?.resetAdvancedSearchFormFields()
    dispatchingGroupID.value = ''
    if (!node) {
      departmentID.value = ''
      groupID.value = ''
      WorkOrderGroupHeaderOptions.title = `车间派工单`
      workDispatchEmployeeHeaderOptions.title = `组内派工`
      await gridWorkOrderGroupRef.value?.loadData([])
      await gridDispatchEmployeeRef.value?.loadData([])
      return
    }
    if (node.isGroup) {
      departmentID.value = ''
      groupID.value = node.id
    } else {
      groupID.value = ''
      departmentID.value = node.id
    }
    WorkOrderGroupHeaderOptions.title = `[${node.label}] - 车间派工单`
    workDispatchEmployeeHeaderOptions.title = `组内派工`
    await gridDispatchEmployeeRef.value?.loadData([])
    gridWorkOrderGroupRef.value?.commitProxy('reload')
  },
  formatter({ node, data }) {
    return (
      <div>
        {node.label}&nbsp;&nbsp;({data.childrenCount})
      </div>
    )
  }
})

const departmentID = ref('')
const groupID = ref('')

const handleQuickSearch = async () => {
  // await gridHeaderWorkDispatchEmployeeRef.value?.resetAdvancedSearchFormFields()
  workDispatchEmployeeHeaderOptions.title = `组内派工`
  await gridDispatchEmployeeRef.value?.loadData([])
  gridWorkOrderGroupRef.value?.commitProxy('reload')
}

const handleAdvancedSearch = async () => {
  // await gridHeaderWorkDispatchEmployeeRef.value?.resetAdvancedSearchFormFields()
  workDispatchEmployeeHeaderOptions.title = `组内派工`
  await gridDispatchEmployeeRef.value?.loadData([])
  gridWorkOrderGroupRef.value?.commitProxy('reload')
}

const handleReset = async () => {
  // await gridHeaderWorkDispatchEmployeeRef.value?.resetAdvancedSearchFormFields()
  workDispatchEmployeeHeaderOptions.title = `组内派工`
  await gridDispatchEmployeeRef.value?.loadData([])

  gridWorkOrderGroupRef.value?.commitProxy('reload')
}

const handleDispatchEmployeeQuickSearch = () => {
  if (!woData.value) {
    ElMessage.warning('请先选择车间派工单')
    return
  }
  gridDispatchEmployeeRef.value?.commitProxy('reload')
}

const handleDispatchEmployeeAdvancedSearch = () => {
  if (!woData.value) {
    ElMessage.warning('请先选择车间派工单')
    return
  }
  gridDispatchEmployeeRef.value?.commitProxy('reload')
}

const handleDispatchEmployeeReset = () => {
  if (!woData.value) {
    ElMessage.warning('请先选择车间派工单')
    return
  }
  gridDispatchEmployeeRef.value?.commitProxy('reload')
}

const gridHeaderWorkOrderGroupRef =
  ref<ComponentExposed<typeof GridHeader<GetDispatchingGroupWoParams, 'woNo'>>>()
const WorkOrderGroupHeaderOptions = reactive<GridHeaderProps>({
  title: '车间派工单',
  showAddButton: false,
  quickSearch: {
    singleSearch: {
      field: 'woNo',
      type: 'input',
      title: '单据编号'
    },
    searchFormFields: { woNo: '' }
  },
  advancedSearch: {
    labelWidth: 120,
    fieldMapToTime: [['dateOfStartandEnd', ['StartDate', 'EndDate'], 'YYYY-MM-DD']],
    schemas: [
      {
        field: 'ProcessID',
        component: 'ApiSelect',
        label: '设备类型',
        componentProps: {
          api: getProductionProcessTopLevel,
          resultField: 'data.result',
          labelField: 'processType',
          valueField: 'id',
          async onChange(processTypeID: string): Promise<void> {
            await gridHeaderWorkOrderGroupRef.value?.setFieldsValue({ SonProcessID: '' })
            if (processTypeID) {
              getProductionProcessChildren({ processTypeID }).then(({ code, data }) => {
                if (code === 200) {
                  gridHeaderWorkOrderGroupRef.value?.updateAdvancedSearchForm({
                    field: 'SonProcessID',
                    componentProps: { options: data.result }
                  })
                }
              })
            } else {
              gridHeaderWorkOrderGroupRef.value?.updateAdvancedSearchForm({
                field: 'SonProcessID',
                componentProps: { options: [] }
              })
            }
          }
        },
        colProps: {
          span: 8
        }
      },
      {
        field: 'SonProcessID',
        component: 'Select',
        label: '工序任务',
        componentProps: {
          options: [],
          resultField: 'data.result',
          labelField: 'processType',
          valueField: 'id'
        },
        colProps: {
          span: 8
        }
      },
      {
        field: 'orderStatus',
        component: 'Select',
        label: '状态',
        defaultValue: [0, 1],
        componentProps: {
          options: orderStatusList,
          multiple: true
        },
        colProps: {
          span: 8
        }
      },
      {
        field: 'dateOfStartandEnd',
        component: 'ElDatePicker',
        label: '计划开始日期',
        componentProps: {
          type: 'daterange',
          unlinkPanels: true,
          shortcuts: dateShortcuts,
          valueFormat: 'YYYY-MM-DD'
        },
        colProps: {
          span: 8
        }
      }
    ]
  },
  showExportButton: true,
  customExport: true
})

const [registerForm, { getFieldsValue, validate, updateSchema, setFieldsValue }] = useForm({
  labelWidth: 100,
  // fieldMapToTime: [
  //   ['DispatchingDate', ['DispatchingStartDate', 'DispatchingEndDate'], 'YYYY-MM-DD']
  // ],
  schemas: [
    {
      field: 'exportType',
      component: 'Select',
      label: '导出类型',
      required: true,
      defaultValue: EXPORT_TYPE.DISPATCHING_EMPLOYEE_TYPE,
      componentProps: {
        clearable: false,
        options: exportTypeList,
        async onChange(value: number) {
          setFieldsValue({
            DispatchingDate: void 0
          })
          if (value === EXPORT_TYPE.DISPATCHING_SCHEDULING_TYPE) {
            await updateSchema({
              field: 'DispatchingDate',
              componentProps: { type: 'date', shortcuts: [] }
            })
            setFieldsValue({ DispatchingDate: dayjs().format('YYYY-MM-DD') })
          } else if (value === EXPORT_TYPE.DISPATCHING_EMPLOYEE_TYPE) {
            updateSchema({
              field: 'DispatchingDate',
              componentProps: {
                type: 'daterange',
                startPlaceholder: '开始日期',
                endPlaceholder: '结束日期',
                unlinkPanels: true,
                shortcuts: dateShortcuts,
                valueFormat: 'YYYY-MM-DD'
              }
            })
          }
        }
      },
      colProps: {
        span: 23
      }
    },
    {
      field: 'DispatchingDate',
      component: 'ElDatePicker',
      label: '日期',
      required: true,
      componentProps: {
        type: 'daterange',
        startPlaceholder: '开始日期',
        endPlaceholder: '结束日期',
        unlinkPanels: true,
        shortcuts: dateShortcuts,
        valueFormat: 'YYYY-MM-DD'
      },
      colProps: {
        span: 23
      }
    },
    {
      field: 'DepartmentID',
      component: 'ApiSelect',
      label: '部门',
      required: true,
      ifShow({ model }) {
        return model['exportType'] !== EXPORT_TYPE.DISPATCHING_EMPLOYEE_TYPE
      },
      componentProps: {
        api: getManufactureDepartmentList,
        resultField: 'data',
        labelField: 'name',
        valueField: 'id',
        async onChange(departmentID: string) {
          await setFieldsValue({ GroupID: void 0 })
          await updateSchema({ field: 'GroupID', componentProps: { options: [] } })

          if (departmentID) {
            getGroupSelect({ departmentID }).then(({ code, data }) => {
              if (code === 200) {
                updateSchema({ field: 'GroupID', componentProps: { options: data.result } })
              }
            })
          }
        }
      },
      colProps: {
        span: 23
      }
    },
    {
      field: 'GroupID',
      component: 'Select',
      label: '组别',
      required: true,
      ifShow({ model }) {
        return model['exportType'] !== EXPORT_TYPE.DISPATCHING_EMPLOYEE_TYPE
      },
      componentProps: {
        options: []
      },
      colProps: {
        span: 23
      }
    }
  ]
})

const exportClick = () => {
  ElMessageBox({
    title: '导出',
    showCancelButton: true,
    message: () => {
      return <basic-form onRegister={registerForm} />
    },
    beforeClose: async (action, instance, done) => {
      if (action === 'confirm') {
        await validate(async (isValid) => {
          const fieldsValue = getFieldsValue()
          console.log(fieldsValue)

          if (isValid) {
            const loading = ElLoading.service({
              lock: true,
              text: 'Loading',
              background: 'rgba(0, 0, 0, 0.7)'
            })
            try {
              if (fieldsValue.exportType === EXPORT_TYPE.DISPATCHING_EMPLOYEE_TYPE) {
                await downloadByApi(exportDispatchingEmployee, {
                  DispatchingEndDate: fieldsValue.DispatchingDate[1],
                  DispatchingStartDate: fieldsValue.DispatchingDate[0]
                })
              } else if (fieldsValue.exportType === EXPORT_TYPE.DISPATCHING_SCHEDULING_TYPE) {
                await downloadByApi(exportDispatchingScheduling, {
                  DepartmentID: fieldsValue.DepartmentID,
                  GroupID: fieldsValue.GroupID,
                  SchedulingDate: fieldsValue.DispatchingDate
                })
              }

              ElMessage.success('导出成功')
              done()
            } catch (e: any) {
              ElMessage.error(e.message)
            } finally {
              loading.close()
            }
          }
        })
      }

      if (action === 'cancel') {
        done()
      }
    }
  })
}

const gridWorkOrderGroupRef = ref<VxeGridInstance>()
const gridWorkOrderGroupOptions = reactive<VxeGridProps<GetDispatchingGroupWoModel>>({
  border: true,
  minHeight: '400px',
  maxHeight: '800px',
  align: null,
  columnConfig: {
    resizable: true
  },
  // sortConfig: {
  //   trigger: 'cell'
  // }, // 排序触发的方式
  columns: [
    { type: 'seq', width: 50 },
    { field: 'projectName', title: '项目名称', minWidth: 150 },
    { field: 'sonProcessName', title: '工序任务', width: 150 },
    { field: 'woNo', title: '单据编号', width: 180 },
    { field: 'materialNo', title: '母件编码', width: 180 },
    { field: 'productName', title: '部件名称', width: 210 },
    { field: 'departmentName', title: '部门名称', width: 130 },
    {
      field: 'startDate',
      title: '计划开始日期',
      width: 120,
      formatter({ cellValue }) {
        return dayjs(cellValue).format('YYYY-MM-DD')
      },
      sortable: true,
      sortType: 'string'
    },
    {
      field: 'dispatchingNumber',
      title: '派工数量',
      width: 110,
      sortable: true,
      sortType: 'number'
    },
    {
      field: 'leftDispatchingCount',
      title: '未派数量',
      width: 110,
      sortable: true,
      sortType: 'number'
    },
    // { field: 'standardWorkHour', title: '标准工时(h)', width: 120 },
    {
      field: 'finishPercent',
      title: '完成进度',
      width: 200,
      slots: { default: 'finishPercent' },
      sortable: true,
      sortType: 'number'
    },
    { field: 'leaderName', title: '班组长', minWidth: 100 },
    { field: 'orderStatus', title: '状态', slots: { default: 'orderStatus' }, width: 100 }
  ],
  pagerConfig: {
    enabled: true
  },
  proxyConfig: {
    autoLoad: false,
    ajax: {
      query: ({ page }) => {
        const quickSearchForm = gridHeaderWorkOrderGroupRef.value?.quickSearchForm
        const advancedSearchForm = gridHeaderWorkOrderGroupRef.value?.advancedSearchForm

        return getDispatchingGroupWo({
          pageIndex: page.currentPage - 1, // 由于后端接口限制，首页从0开始
          pageSize: page.pageSize,
          DepartmentID: departmentID.value,
          GroupID: groupID.value,
          ...quickSearchForm,
          ...advancedSearchForm,
          IsShowNotDispatching: showNoDispatch.value
        })
      }
    }
  }
})

const woData = computed<GetDispatchingGroupWoModel>(
  () => gridWorkOrderGroupRef.value?.getCurrentRecord()
) // 车间派工单

const gridEvents: VxeGridListeners<GetDispatchingGroupWoModel> = {
  async cellClick(data) {
    // await gridHeaderWorkDispatchEmployeeRef.value?.resetAdvancedSearchFormFields()
    workDispatchEmployeeHeaderOptions.title = `[${data.row.sonProcessName}] - 组内派工`
    dispatchingGroupID.value = data.row.id
    gridDispatchEmployeeRef.value?.commitProxy('reload')
  }
}

const gridHeaderWorkDispatchEmployeeRef =
  ref<ComponentExposed<typeof GridHeader<GetDispatchingEmployeeParams, 'SearchKey'>>>()
const workDispatchEmployeeHeaderOptions = reactive<GridHeaderProps>({
  title: '组内派工',
  quickSearch: {
    singleSearch: {
      field: 'SearchKey',
      type: 'input',
      title: '工号/姓名'
    },
    searchFormFields: { SearchKey: '' }
  },
  advancedSearch: {
    labelWidth: 120,
    schemas: [
      {
        field: 'OrderStatus',
        label: '状态',
        component: 'Select',
        componentProps: {
          options: orderStatusListGroup
        },
        colProps: { span: 8 }
      }
    ]
  }
})

const gridDispatchEmployeeRef = ref<VxeGridInstance>()
const gridWorkDispatchEmployeeOptions = reactive<VxeGridProps<GetDispatchingEmployeeWoModel>>({
  border: true,
  minHeight: '400px',
  maxHeight: '800px',
  align: null,
  columnConfig: {
    resizable: true
  },
  columns: [
    { type: 'seq', width: 50 },
    {
      field: 'employee',
      title: '作业者',
      width: 180,
      slots: { default: 'employee' }
    },
    {
      field: 'employeeNo',
      title: '工号',
      width: 100,
      visible: false
    },
    {
      field: 'employeeName',
      title: '姓名',
      // slots: { default: 'employeeName' },
      width: 150,
      visible: false
    },
    { field: 'groupName', title: '班组', width: 200 },
    { field: 'dispatchingNumber', title: '派工数量', width: 100 },
    { field: 'finishCount', title: '完成数量', width: 100 },
    {
      field: 'takeTime',
      title: '总用时',
      width: 100,
      formatter({ cellValue }) {
        return `${cellValue}H`
      }
    },
    {
      field: 'finishPercent',
      title: '完成比率',
      width: 100,
      formatter({ cellValue }) {
        return `${cellValue}%`
      }
    },
    {
      field: 'sumFinishCount',
      title: '完成比率',
      visible: false
    },
    {
      field: 'startDate',
      title: '计划开始日期',
      formatter({ cellValue }) {
        return dayjs(cellValue).format('YYYY-MM-DD')
      },
      width: 120
    },
    { field: 'orderStatus', title: '状态', slots: { default: 'orderStatus' }, width: 100 },
    {
      field: 'operation',
      title: '操作',
      align: 'center',
      fixed: 'right',
      slots: {
        default: 'operation'
      },
      minWidth: 150
    }
  ],
  pagerConfig: {
    enabled: true
  },
  proxyConfig: {
    autoLoad: false,
    ajax: {
      query: ({ page }) => {
        const quickSearchForm = gridHeaderWorkDispatchEmployeeRef.value?.quickSearchForm
        const advancedSearchForm = gridHeaderWorkDispatchEmployeeRef.value?.advancedSearchForm
        const DispatchingGroupID = woData.value.id
        return getDispatchingEmployee({
          pageIndex: page.currentPage - 1, // 由于后端接口限制，首页从0开始
          pageSize: page.pageSize,
          DispatchingGroupID,
          ...quickSearchForm,
          ...advancedSearchForm
        })
      }
    }
  }
})

const [registerAddModal, { openModal: openAddModal, closeModal: closeAddModal }] = useModal()

const [registerModal, { openModal, closeModal }] = useModal()

const handleSuccess = async () => {
  await gridWorkOrderGroupRef.value?.commitProxy('query')
  const row = gridWorkOrderGroupRef.value
    ?.getTableData()
    .fullData.filter((item) => item.id === dispatchingGroupID.value)[0]

  await gridWorkOrderGroupRef.value?.setCurrentRow(row)
  gridDispatchEmployeeRef.value?.commitProxy('query')
  closeModal()
}

const handleAdd = () => {
  if (!woData.value) {
    ElMessage.warning('请先选择车间派工单')
    return
  }
  openAddModal(true, { workOrder: woData.value })
}

const handleAddSuccess = async () => {
  await gridWorkOrderGroupRef.value?.commitProxy('query')
  const row = gridWorkOrderGroupRef.value
    ?.getTableData()
    .fullData.filter((item) => item.id === dispatchingGroupID.value)[0]

  await gridWorkOrderGroupRef.value?.setCurrentRow(row)
  gridDispatchEmployeeRef.value?.commitProxy('query')
  closeAddModal()
}

const handleEdit = async (row: GetDispatchingEmployeeWoModel) => {
  openModal(true, { row, workOrder: woData.value, isUpdate: true })
}

const handleDelivery = (row: GetDispatchingEmployeeWoModel) => {
  openModal(true, { row, workOrder: woData.value, isUpdate: false })
}

const handleDelete = (row: GetDispatchingEmployeeWoModel) => {
  ElMessageBox.confirm(`是否删除名称为"${row.employeeNo}-${row.employeeName}"的数据项`, '警告', {
    confirmButtonText: '确定',
    cancelButtonText: '取消',
    type: 'warning'
  }).then(() => {
    deleteDispatchingEmployee({ id: row.id }).then(async ({ code, data, message }) => {
      if (code === 200 && data) {
        await gridWorkOrderGroupRef.value?.commitProxy('query')
        const row = gridWorkOrderGroupRef.value
          ?.getTableData()
          .fullData.filter((item) => item.id === dispatchingGroupID.value)[0]

        await gridWorkOrderGroupRef.value?.setCurrentRow(row)
        gridDispatchEmployeeRef.value?.commitProxy('query')
      } else {
        ElMessage.error(message)
      }
    })
  })
}
</script>

<style lang="scss" scoped>
.grid-container {
  flex: 1;

  display: flex;
  flex-direction: column;
  .vxe-grid-container {
    margin: $margin $margin $margin 0;
  }
}
.el-input-number {
  width: auto;
}
</style>
