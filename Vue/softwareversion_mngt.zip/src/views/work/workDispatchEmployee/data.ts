export enum EXPORT_TYPE {
  DISPATCHING_EMPLOYEE_TYPE = 1,
  DISPATCHING_SCHEDULING_TYPE = 2
}

export const exportTypeList = [
  { label: '组内派工', value: EXPORT_TYPE.DISPATCHING_EMPLOYEE_TYPE },
  { label: '计划人员安排表', value: EXPORT_TYPE.DISPATCHING_SCHEDULING_TYPE }
]

export const orderStatusList = [
  { label: '未报工', value: 0, type: 'info' },
  { label: '已报工', value: 1, type: '' },
  { label: '已完工', value: 2, type: 'success' }
]
export const orderStatusListGroup = [
  { label: '未报工', value: 0, type: 'info' },
  { label: '报工中', value: 1, type: '' },
  { label: '已完工', value: 2, type: 'success' }
]
