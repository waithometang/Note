<template>
  <LayoutContainer>
    <template #leftSide>
      <basic-tree ref="basicTreeRef" v-bind="listOptions">
        <template #footer>
          <div style="margin: 0 auto">
            <el-checkbox v-model="showAllProject" label="显示所有项目" />
          </div>
        </template>
      </basic-tree>
    </template>
    <el-scrollbar class="grid-container">
      <div class="box vxe-grid-container">
        <vxe-grid ref="gridWorkOrderRef" v-bind="gridWorkOrderOptions" v-on="gridEvents">
          <template #top>
            <GridHeader
              ref="gridHeaderWorkOrderRef"
              v-bind="WorkOrderHeaderOptions"
              @quickSearch="handleQuickSearch"
              @advancedSearch="handleAdvancedSearch"
              @reset="handleReset"
              @export-click="exportClick"
            >
              <template #prependOperation>
                <el-checkbox
                  style="margin-right: 20px"
                  v-model="showNoDispatch"
                  label="只显示未派工单"
                  size="large"
                  @change="handleQuickSearch"
                />
              </template>
            </GridHeader>
          </template>
          <template #orderSchedule="{ row }">
            <el-progress
              :stroke-width="12"
              :percentage="row.orderSchedule"
              :status="row.orderSchedule == 100 ? 'success' : ''"
            />
          </template>
          <template #orderStatus="{ row }">
            <el-tag :type="getOrderStatusInfo(row.orderStatus).type">
              {{ getOrderStatusInfo(row.orderStatus).text }}
            </el-tag>
          </template>
        </vxe-grid>
      </div>
      <div class="box vxe-grid-container">
        <vxe-grid ref="gridDispatchRef" v-bind="gridWorkDispatchOptions">
          <template #top>
            <GridHeader
              ref="gridHeaderWorkDispatchRef"
              v-bind="workDispatchHeaderOptions"
              @quickSearch="handleDispatchQuickSearch"
              @add="handleAdd"
              @advancedSearch="handleDispatchAdvancedSearch"
              @reset="handleDispatchReset"
              ><template #appendOperation>
                <el-button size="large" type="warning" plain @click="handleBatchAdd"
                  >批量新增</el-button
                >
              </template>
            </GridHeader>
          </template>
          <template #orderStatus="{ row }">
            <el-tag :type="getDispatchOrderStatusInfo(row.orderStatus).type">
              {{ getDispatchOrderStatusInfo(row.orderStatus).text }}
            </el-tag>
          </template>
          <template #operation="{ row }">
            <TableAction
              :actions="[
                {
                  icon: 'finish-wo-status',
                  tooltip: '完成',
                  ifShow: row.orderStatus !== 2,
                  onClick: handleComplete.bind(null, row)
                },
                {
                  icon: 'copy',
                  tooltip: '复制',
                  ifShow: row.orderStatus !== 2,
                  onClick: handleCopy.bind(null, row)
                },
                {
                  icon: 'edit',
                  tooltip: '编辑',
                  onClick: handleEdit.bind(null, row)
                },
                {
                  icon: 'delete',
                  tooltip: '删除',
                  ifShow: row.orderStatus == 0 || row.orderStatus !== 2,
                  onClick: handleDelete.bind(null, row)
                }
              ]"
            />
          </template>
        </vxe-grid>
      </div>
    </el-scrollbar>

    <CopyDispatchOrderDialog @register="registerCopyModal" @success="handleCopySuccess" />
    <DispatchOrderDialog @register="registerModal" @success="handleSuccess" />
    <BatchAdd @register="registerBatchAddModal" @success="handleBatchAddSuccess" />
  </LayoutContainer>
</template>

<script lang="tsx" setup>
import type { ComponentExposed } from 'vue-component-type-helpers'
import type { VxeGridInstance, VxeGridListeners, VxeGridProps } from 'vxe-table'
import type {
  GetWorkOrderModel,
  GetDispatchingGroupModel,
  GetWorkDispatchingWoParams,
  GetDispatchingGroupParams
} from '@/api/sys/model/workModel'
import type { GridHeaderProps } from '@/components/Table/types/gridHeader'
import type { TreeProps } from '@/components/Tree/types/tree'

import { ref, reactive, computed } from 'vue'

import BasicTree from '@/components/Tree/BasicTree.vue'
import GridHeader from '@/components/Table/GridHeader.vue'
import TableAction from '@/components/Table/TableAction.vue'

import CopyDispatchOrderDialog from './components/CopyDispatchOrderDialog.vue'
import DispatchOrderDialog from './components/DispatchOrderDialog.vue'
import BatchAdd from './components/BatchAdd.vue'

import {
  getKeyValue,
  getManufactureDepartmentList,
  getProductionProcessTopLevel
} from '@/api/sys/basic'
import {
  deleteDispatchingGroup,
  getDispatchingGroup,
  getDispatchingWo,
  exportDispatchingGroup,
  updateDispatchingGroupCompleted
} from '@/api/sys/work'
import { getProjectAndProductName } from '@/api/sys/scheduling'

import { useModal } from '@/components/Modal/hooks/useModal'
import dayjs from 'dayjs'
import { useForm } from '@/components/Form/hooks/useForm'
import { downloadByApi } from '@/utils/download'
import { dateShortcuts } from '@/constant'

const getOrderStatusInfo = computed(() => {
  const statusMap: { [key: number]: { text: string; type: string } } = {
    0: { text: '未开始', type: 'info' },
    1: { text: '执行中', type: '' },
    2: { text: '已完工', type: 'success' },
    3: { text: '已关闭', type: 'error' },
    4: { text: '已取消', type: 'warning' }
  }

  return function (status: number) {
    return statusMap[status] || { text: '', color: '' }
  }
})

const getDispatchOrderStatusInfo = computed(() => {
  const statusMap: { [key: number]: { text: string; type: string } } = {
    0: { text: '未报工', type: 'info' },
    1: { text: '报工中', type: '' },
    2: { text: '已完成', type: 'success' }
  }

  return function (status: number) {
    return statusMap[status] || { text: '', color: '' }
  }
})

defineOptions({
  name: 'WorkDispatch',
  inheritAttrs: false
})

const basicTreeRef = ref<InstanceType<typeof BasicTree>>()

// 列表活跃项改变
const handleChange = async () => {
  // await gridHeaderWorkOrderRef.value?.resetAdvancedSearchFormFields()
  await gridWorkOrderRef.value?.commitProxy('reload')

  // await gridHeaderWorkDispatchRef.value?.resetAdvancedSearchFormFields()
  workDispatchHeaderOptions.title = `车间派工`
  await gridDispatchRef.value?.loadData([])
}

const listParams = reactive({
  projectID: '',
  orderNo: ''
})

const showAllProject = ref(false)
const showNoDispatch = ref(false)

// 列表配置
const listOptions = reactive<TreeProps>({
  api: getProjectAndProductName,
  title: '项目列表',
  labelField: 'name',
  resultField: 'data',
  childrenField: 'productList',
  nodeKey: 'id',
  cancleHightlightCurrent: true, // 开启可取消选中树节点功能
  params: computed(() => ({ orderStatus: showAllProject.value ? 3 : 1 })),
  onSelect: async (node) => {
    if (!node) {
      listParams.projectID = ''
      listParams.orderNo = ''
      WorkOrderHeaderOptions.title = `生产工单`
      workDispatchHeaderOptions.title = `车间派工`
      await gridWorkOrderRef.value?.loadData([])
      await gridDispatchRef.value?.loadData([])
      return
    }
    if (node.isProject) {
      listParams.projectID = node.id
      listParams.orderNo = ''
      WorkOrderHeaderOptions.title = `生产工单 - [${node.label}]`
    } else {
      listParams.projectID = node.projectID
      listParams.orderNo = node.orderNo
      WorkOrderHeaderOptions.title = `生产工单 - [${node.label}]`
    }
    await handleChange()
  }
})

// watch(showAllProject, (val) => {
//   basicTreeRef.value!.treeRef!.filter(val)
// })

const handleQuickSearch = async () => {
  // await gridHeaderWorkDispatchRef.value?.resetAdvancedSearchFormFields()
  workDispatchHeaderOptions.title = `车间派工`
  await gridDispatchRef.value?.loadData([])
  gridWorkOrderRef.value?.commitProxy('reload')
}

const handleAdvancedSearch = async () => {
  // await gridHeaderWorkDispatchRef.value?.resetAdvancedSearchFormFields()
  workDispatchHeaderOptions.title = `车间派工`
  await gridDispatchRef.value?.loadData([])
  gridWorkOrderRef.value?.commitProxy('reload')
}

const handleReset = async () => {
  // await gridHeaderWorkDispatchRef.value?.resetAdvancedSearchFormFields()
  workDispatchHeaderOptions.title = `车间派工`
  await gridDispatchRef.value?.loadData([])
  gridWorkOrderRef.value?.commitProxy('reload')
}

const handleDispatchQuickSearch = () => {
  if (!woData.value) {
    ElMessage.warning('请先选择生产工单')
    return
  }
  gridDispatchRef.value?.commitProxy('reload')
}

const handleDispatchAdvancedSearch = () => {
  if (!woData.value) {
    ElMessage.warning('请先选择生产工单')
    return
  }
  gridDispatchRef.value?.commitProxy('reload')
}

const handleDispatchReset = () => {
  if (!woData.value) {
    ElMessage.warning('请先选择生产工单')
    return
  }
  gridDispatchRef.value?.commitProxy('reload')
}

const gridHeaderWorkOrderRef =
  ref<ComponentExposed<typeof GridHeader<GetWorkDispatchingWoParams, 'woNo'>>>()
const WorkOrderHeaderOptions = reactive<GridHeaderProps>({
  title: '生产工单',
  showAddButton: false,
  quickSearch: {
    singleSearch: {
      field: 'woNo',
      type: 'input',
      title: '需求分类/单据编号/母件编码'
    },
    searchFormFields: { woNo: '' }
  },
  advancedSearch: {
    labelWidth: 120,
    schemas: [
      {
        field: 'departmentID',
        component: 'ApiSelect',
        label: '部门',
        componentProps: {
          api: getManufactureDepartmentList,
          resultField: 'data',
          labelField: 'name',
          valueField: 'id'
        },
        colProps: {
          span: 8
        }
      },
      {
        field: 'processID',
        component: 'ApiSelect',
        label: '设备类型',
        componentProps: {
          api: getProductionProcessTopLevel,
          resultField: 'data.result',
          labelField: 'processType',
          valueField: 'id'
        },
        colProps: {
          span: 8
        }
      },
      {
        field: 'productName',
        component: 'ElInput',
        label: '部件名称',
        colProps: {
          span: 8
        }
      },
      {
        field: 'productionAddressID',
        component: 'ApiSelect',
        label: '生产场地',
        componentProps: {
          multiple: true,
          api: getKeyValue,
          resultField: 'data.result',
          labelField: 'key',
          valueField: 'id',
          params: { typeName: 'PositionAddress' }
        },
        colProps: {
          span: 8
        }
      },
      {
        field: 'orderStatus',
        component: 'Select',
        defaultValue: [0, 1],
        label: '状态',
        componentProps: {
          options: [
            { label: '未开始', value: 0 },
            { label: '执行中', value: 1 },
            { label: '已完工', value: 2 },
            { label: '已关闭', value: 3 },
            { label: '已取消', value: 4 }
          ],
          multiple: true
        },
        colProps: {
          span: 8
        }
      },
      {
        field: 'isFinishOrderSchedule',
        component: 'Select',
        label: '工单进度',
        componentProps: {
          options: [
            { label: '未完成', value: false },
            { label: '已完成', value: true }
          ]
        },
        colProps: {
          span: 8
        }
      }
    ]
  },
  showExportButton: true,
  customExport: true
  // exportApi: exportDispatchingGroup,
  // exportBefore() {
  //   const flag =
  //     listParams.projectID !== '' ||
  //     unref(gridHeaderWorkOrderRef.value?.quickSearchForm)?.woNo !== '' ||
  //     false
  //   if (!flag) {
  //     ElMessage.warning('请先选择项目列表或输入单据编号')
  //   }
  //   return flag
  // },
  // exportParams: computed(() => {
  //   const advancedSearchForm = gridHeaderWorkOrderRef.value?.advancedSearchForm
  //   const quickSearchForm = gridHeaderWorkOrderRef.value?.quickSearchForm
  //   return { ...listParams, ...quickSearchForm, ...advancedSearchForm }
  // })
})

const [registerForm, { getFieldsValue, validate }] = useForm({
  labelWidth: 60,
  fieldMapToTime: [
    ['DispatchingDate', ['DispatchingStartDate', 'DispatchingEndDate'], 'YYYY-MM-DD']
  ],
  schemas: [
    {
      field: 'DispatchingDate',
      component: 'ElDatePicker',
      label: '日期',
      required: true,
      componentProps: {
        type: 'daterange',
        startPlaceholder: '开始日期',
        endPlaceholder: '结束日期',
        unlinkPanels: true,
        shortcuts: dateShortcuts,
        valueFormat: 'YYYY-MM-DD'
      },
      colProps: {
        span: 23
      }
    }
  ]
})

const exportClick = () => {
  ElMessageBox({
    title: '导出',
    showCancelButton: true,
    message: () => {
      return <basic-form onRegister={registerForm} />
    },
    beforeClose: async (action, instance, done) => {
      if (action === 'confirm') {
        await validate(async (isValid) => {
          const fieldsValue = getFieldsValue()

          if (isValid) {
            const loading = ElLoading.service({
              lock: true,
              text: 'Loading',
              background: 'rgba(0, 0, 0, 0.7)'
            })
            try {
              await downloadByApi(exportDispatchingGroup, {
                ...fieldsValue
              })
              ElMessage.success('导出成功')
              done()
            } catch (e: any) {
              ElMessage.error(e.message)
            } finally {
              loading.close()
            }
          }
        })
      }

      if (action === 'cancel') {
        done()
      }
    }
  })
}

const gridWorkOrderRef = ref<VxeGridInstance>()
const gridWorkOrderOptions = reactive<VxeGridProps<GetWorkOrderModel>>({
  border: true,
  minHeight: '400px',
  maxHeight: '800px',
  align: null,
  columnConfig: {
    resizable: true
  },
  // sortConfig: {
  //   trigger: 'cell'
  // }, // 排序触发的方式
  columns: [
    { type: 'seq', width: 50 },
    // { field: 'priorityLevel', title: '优先级别', width: 90, align: 'center' },
    { field: 'projectName', title: '项目名称', minWidth: 150 },
    { field: 'orderNo', title: '需求分类', minWidth: 150 },
    { field: 'woNo', title: '单据编号', minWidth: 180 },
    { field: 'materialNo', title: '母件编码', minWidth: 180 },
    { field: 'productName', title: '部件名称', width: 200 },
    { field: 'departmentName', title: '生产部门', width: 150 },
    // { field: 'orderProductName', title: '设备名称', width: 200 },
    { field: 'processType', title: '设备类型', width: 120 },
    { field: 'productionOrderNumber', title: '订单数量', width: 90 },
    { field: 'frameNumber', title: '机架数量', width: 90 },
    { field: 'locationNumber', title: '库位数量', width: 90 },
    { field: 'chassisNumber', title: '机箱数量', width: 90 },
    { field: 'wireNumber', title: '线束数量', width: 90 },
    { field: 'pcbaNumber', title: 'PCBA数量', width: 100 },
    {
      field: 'orderSchedule',
      title: '工单进度',
      width: 180,
      slots: { default: 'orderSchedule' },
      fixed: 'right',
      align: 'center',
      sortable: true,
      sortType: 'number'
    },
    {
      field: 'orderStatus',
      title: '状态',
      slots: { default: 'orderStatus' },
      width: 100,
      fixed: 'right',
      align: 'center'
    }
  ],
  pagerConfig: {
    enabled: true
  },
  proxyConfig: {
    autoLoad: false,
    ajax: {
      query: ({ page }) => {
        const quickSearchForm = gridHeaderWorkOrderRef.value?.quickSearchForm
        const advancedSearchForm = gridHeaderWorkOrderRef.value?.advancedSearchForm
        return getDispatchingWo({
          pageIndex: page.currentPage - 1, // 由于后端接口限制，首页从0开始
          pageSize: page.pageSize,
          ...listParams,
          ...quickSearchForm,
          ...advancedSearchForm,
          isShowNotDispatching: showNoDispatch.value
        })
      }
    }
  }
})

const woData = computed<GetWorkOrderModel>(() => gridWorkOrderRef.value?.getCurrentRecord()) // 生产工单

const gridEvents: VxeGridListeners<GetWorkOrderModel> = {
  async cellClick(data) {
    // await gridHeaderWorkDispatchRef.value?.resetAdvancedSearchFormFields()
    workDispatchHeaderOptions.title = `车间派工 - [${data.row.woNo}]`
    gridDispatchRef.value?.commitProxy('query')
  }
}

const gridHeaderWorkDispatchRef =
  ref<ComponentExposed<typeof GridHeader<GetDispatchingGroupParams, 'SearchKey'>>>()
const workDispatchHeaderOptions = reactive<GridHeaderProps>({
  title: '车间派工',
  quickSearch: {
    singleSearch: {
      field: 'SearchKey',
      type: 'input',
      title: '工序任务/班组'
    },
    searchFormFields: { SearchKey: '' }
  },
  advancedSearch: {
    labelWidth: 120,
    schemas: [
      {
        field: 'OrderStatus',
        label: '状态',
        component: 'Select',
        componentProps: {
          options: [
            { label: '未报工', value: 0 },
            { label: '报工中', value: 1 },
            { label: '已完成', value: 2 }
          ]
        },
        colProps: { span: 8 }
      }
    ]
  }
})

const gridDispatchRef = ref<VxeGridInstance>()
const gridWorkDispatchOptions = reactive<VxeGridProps<GetDispatchingGroupModel>>({
  border: true,
  minHeight: '400px',
  maxHeight: '800px',
  align: null,
  columnConfig: {
    resizable: true
  },
  columns: [
    { type: 'seq', width: 50 },
    {
      field: 'sonProcessName',
      title: '工序任务',
      minWidth: 100
    },
    {
      field: 'proportion',
      title: '派工比例',
      width: 100,
      formatter({ cellValue }) {
        return `${cellValue}%`
      }
    },
    {
      field: 'dispatchingNumber',
      title: '派工数量',
      width: 100
    },
    {
      field: 'standardWorkHour',
      title: '标准工时',
      width: 120,
      formatter({ cellValue }) {
        return cellValue ? `${cellValue}H` : ''
      }
    },
    { field: 'groupName', title: '班组', width: 120 },
    { field: 'leaderName', title: '班组长', width: 100 },
    {
      field: 'startDate',
      title: '计划开始日期',
      width: 120,
      formatter({ cellValue }) {
        return dayjs(cellValue).format('YYYY-MM-DD')
      }
    },
    // { field: 'finishPercent', title: '完成进度', minWidth: 180, slots: { default: 'finishPercent' } },
    { field: 'orderStatus', title: '状态', width: 100, slots: { default: 'orderStatus' } },
    // { field: 'departmentName', title: '生产部门', width: 150 },
    {
      field: 'operation',
      title: '操作',
      align: 'center',
      fixed: 'right',
      minWidth: 180,
      slots: {
        default: 'operation'
      }
    }
  ],
  pagerConfig: {
    enabled: true
  },
  proxyConfig: {
    autoLoad: false,
    ajax: {
      query: ({ page }) => {
        const quickSearchForm = gridHeaderWorkDispatchRef.value?.quickSearchForm
        const advancedSearchForm = gridHeaderWorkDispatchRef.value?.advancedSearchForm
        const WoNo = woData.value.woNo
        return getDispatchingGroup({
          pageIndex: page.currentPage - 1, // 由于后端接口限制，首页从0开始
          pageSize: page.pageSize,
          WoNo,
          ...quickSearchForm,
          ...advancedSearchForm
        })
      }
    }
  }
})

const [registerCopyModal, { openModal: openCopyModal, closeModal: closeCopyModal }] = useModal()

const handleCopySuccess = () => {
  gridDispatchRef.value?.commitProxy('query')
  closeCopyModal()
}

const [registerModal, { openModal, closeModal }] = useModal()

const handleSuccess = () => {
  gridDispatchRef.value?.commitProxy('query')
  closeModal()
}

const handleAdd = () => {
  if (!woData.value) {
    ElMessage.warning('请先选择生产工单')
    return
  }
  openModal(true, { workOrder: woData.value })
}

const handleComplete = (row: GetDispatchingGroupModel) => {
  const $grid = gridDispatchRef.value
  ElMessageBox.confirm(
    `注意：完成后该工序任务"${row.sonProcessName}"不能再报工，是否继续？`,
    '提示',
    {
      confirmButtonText: '确定',
      cancelButtonText: '取消',
      type: 'warning'
    }
  ).then(() => {
    if ($grid) {
      updateDispatchingGroupCompleted({ id: row.id }).then(({ code, message }) => {
        if (code === 200) {
          $grid?.commitProxy('query')
        } else {
          ElMessage.error(message)
        }
      })
    }
  })
}

const handleCopy = (row: GetDispatchingGroupModel) => {
  openCopyModal(true, {
    workOrder: woData.value,
    row,
    projectID: listParams.projectID
  })
}

const handleEdit = async (row: GetDispatchingGroupModel) => {
  openModal(true, { row, workOrder: woData.value, isUpdate: true, projectID: listParams.projectID })
}

const handleDelete = (row: GetDispatchingGroupModel) => {
  const $grid = gridDispatchRef.value
  ElMessageBox.confirm(`是否删除名称为"${row.sonProcessName}"的数据项`, '警告', {
    confirmButtonText: '确定',
    cancelButtonText: '取消',
    type: 'warning'
  }).then(() => {
    if ($grid) {
      deleteDispatchingGroup({ id: row.id! }).then(({ code, message }) => {
        if (code === 200) {
          $grid?.commitProxy('query')
        } else {
          ElMessage.error(message)
        }
      })
    }
  })
}

const [registerBatchAddModal, { openModal: openBatchAddModal, closeModal: closeBatchAddModal }] =
  useModal()
const handleBatchAdd = () => {
  if (!woData.value) {
    ElMessage.warning('请先选择生产工单')
    return
  }
  openBatchAddModal(true, { workOrder: woData.value })
}
const handleBatchAddSuccess = async () => {
  closeBatchAddModal()
  gridDispatchRef.value?.commitProxy('query')
}
</script>

<style lang="scss" scoped>
.grid-container {
  flex: 1;

  display: flex;
  flex-direction: column;
  .vxe-grid-container {
    margin: $margin $margin $margin 0;
  }
}
.el-input-number {
  width: auto;
}
</style>
