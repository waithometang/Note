<template>
  <BasicModal
    width="70%"
    v-bind="$attrs"
    @register="registerModal"
    :title="getTitle"
    @confirm="handleSubmit"
    @close="handleClose"
  >
    <BasicForm @register="registerWorkOrderForm" />
    <el-divider content-position="left">
      <div style="font-weight: 700">本次派工</div>
    </el-divider>
    <BasicForm @register="registerForm" />
  </BasicModal>
</template>

<script setup lang="tsx">
import type { ModalMethods } from '@/components/Modal/types'
import type {
  AddDispatchingGroupData,
  AddDispatchingGroupList,
  GetWorkOrderModel,
  UpdateDispatchingGroupData
} from '@/api/sys/model/workModel'

import { ref, computed, unref, watch } from 'vue'

import BasicModal from '@/components/Modal/BasicModal.vue'
import BasicForm from '@/components/Form/BasicForm.vue'

import { useModalInner } from '@/components/Modal/hooks/useModal'
import { useForm } from '@/components/Form/hooks/useForm'
import {
  getGroupSelect,
  getProductionProcessChildren,
  getProductionProcessTopLevel
} from '@/api/sys/basic'
import {
  addDispatchingGroup,
  getDispatchingGroupByDate,
  updateDispatchingGroup,
  getDispatchingGroupProportion
} from '@/api/sys/work'
import dayjs from 'dayjs'
import type { GetProductionProcessChildrenParams } from '@/api/sys/model/basicModel'
import { getStandardWorkTimeByProcessID } from '@/api/sys/scheduling'
import { ceil, round } from 'lodash-es'

const emit = defineEmits<{
  register: [modalMethods: ModalMethods, uuid: number]
  success: [{ isUpdate: boolean }]
}>()

const isUpdate = ref<boolean>(false)

const getTitle = computed(() => (!unref(isUpdate) ? '新增' : '修改'))

const rowId = ref('')

const workOrder = ref<GetWorkOrderModel>()
const standardWorkTimeList = ref<any[]>([])

const [registerModal, { setModalProps, changeOkLoading }] = useModalInner(async (data) => {
  await resetFields()
  await resetWorkOrderFields()

  setModalProps({ confirmLoading: false })
  isUpdate.value = !!data?.isUpdate
  workOrder.value = data.workOrder

  await getShowNumberKeys(workOrder.value!.processID)

  await setFieldsWorkOrderValue({ ...data.workOrder })

  await getProcessList({
    processTypeID: data.workOrder.processID,
    standardWorkTimeProjectID: data.workOrder.projectID,
    standardWorkTimeProductName: data.workOrder.productName
  })
  await getGroupList(data.workOrder.departmentID)

  if (unref(isUpdate)) {
    rowData.value = data.row
    rowData.value!.woID = workOrder.value!.id
    await setFieldsValue({ processID: data.row.sonProcessID })
    rowId.value = data.row.id
  } else {
    const { code, data: res } = await getStandardWorkTimeByProcessID({
      projectID: data.workOrder.projectID,
      productName: data.workOrder.productName,
      orderNo: data.workOrder.orderNo
    })
    if (code === 200) {
      standardWorkTimeList.value = res.result
    }
  }

  clearValidate()
})

const getProcessList = async (params: GetProductionProcessChildrenParams) => {
  const { data } = await getProductionProcessChildren(params)
  await updateSchema({ field: 'processID', componentProps: { options: data.result } })
}

const getGroupList = async (departmentID: string) => {
  const { data } = await getGroupSelect({
    departmentID
  })
  await updateSchema({ field: 'groupID', componentProps: { options: data.result } })
}

const showNumberKeys = ref<string[]>([])
const getShowNumberKeys = async (processID: string) => {
  const { code, data } = await getProductionProcessTopLevel({ processID })
  if (code === 200) {
    showNumberKeys.value = data.result.map((item) =>
      lowercaseFirstLetter(item.deviceNumberTypeKey!)
    )
  }
}

//将字符串首字母变小写
function lowercaseFirstLetter(str: string) {
  return str.charAt(0).toLowerCase() + str.slice(1)
}

const maxProportion = ref(0) // 最大可输入派工比率
const maxDispatchingNumber = ref(0) // 最大可输入派工数量
const sumDispatchingNumber = ref(0)
const rowData = ref<Partial<AddDispatchingGroupList>>({})

watch(
  () => maxDispatchingNumber.value,
  (newVal) => {
    //编辑时计算 最大可派比例
    if (isUpdate.value && showNumberKeys.value.length > 0 && newVal) {
      console.log(getFieldsWorkOrderValue()[showNumberKeys.value[0]])
      const key = showNumberKeys.value[0] || 'productionOrderNumber' // 关联的数量

      maxProportion.value = ceil((newVal / getFieldsWorkOrderValue()[key]) * 100)
    }
  }
)

const [
  registerWorkOrderForm,
  {
    resetFields: resetWorkOrderFields,
    setFieldsValue: setFieldsWorkOrderValue,
    getFieldsValue: getFieldsWorkOrderValue
  }
] = useForm({
  labelWidth: 120,
  schemas: [
    {
      field: 'projectID',
      component: 'ElInput',
      label: '项目iD',
      ifShow: false,
      colProps: {
        span: 8
      }
    },
    {
      field: 'processID',
      component: 'ElInput',
      label: '设备类型iD',
      ifShow: false,
      colProps: {
        span: 8
      }
    },
    {
      field: 'orderNo',
      component: 'ElInput',
      label: '需求分类',
      componentProps: { disabled: true },
      colProps: {
        span: 8
      }
    },
    {
      field: 'woNo',
      component: 'ElInput',
      label: '单据编号',
      componentProps: { disabled: true },
      colProps: {
        span: 8
      }
    },
    {
      field: 'productName',
      component: 'ElInput',
      label: '部件名称',
      componentProps: { disabled: true },
      colProps: {
        span: 8
      }
    },
    {
      field: 'processType',
      component: 'ElInput',
      label: '设备类型',
      componentProps: { disabled: true },
      ifShow: false,
      colProps: {
        span: 8
      }
    },
    {
      field: 'departmentName',
      component: 'ElInput',
      label: '生产部门',
      componentProps: { disabled: true },
      colProps: {
        span: 8
      }
    },
    {
      field: 'departmentID',
      component: 'ElInput',
      label: '生产部门ID',
      componentProps: { disabled: true },
      ifShow: false
    },
    {
      field: 'productionAddressName',
      component: 'ElInput',
      label: '生产场地',
      componentProps: { disabled: true },
      colProps: {
        span: 8
      }
    },
    {
      field: 'employeeName',
      component: 'ElInput',
      label: 'PMC',
      ifShow: false,
      componentProps: { disabled: true },
      colProps: {
        span: 8
      }
    },
    {
      field: 'productionOrderNumber',
      component: 'ElInput',
      label: '订单数量',
      componentProps: { disabled: true },
      colProps: {
        span: 8
      }
    },
    {
      field: 'chassisNumber',
      component: 'ElInput',
      label: '机箱数量',
      componentProps: { disabled: true },
      ifShow({ model, field }) {
        return showNumberKeys.value.includes(field)
        // return model[field] !== '/' || showNumberKeys.value.includes(field)
      },
      colProps: {
        span: 8
      }
    },
    {
      field: 'frameNumber',
      component: 'ElInput',
      label: '机架数量',
      componentProps: { disabled: true },
      ifShow({ model, field }) {
        return showNumberKeys.value.includes(field)
        // return model[field] !== '/' || showNumberKeys.value.includes(field)
      },
      colProps: {
        span: 8
      }
    },
    {
      field: 'locationNumber',
      component: 'ElInput',
      label: '库位数量',
      componentProps: { disabled: true },
      ifShow({ model, field }) {
        return showNumberKeys.value.includes(field)
        // return model[field] !== '/' || showNumberKeys.value.includes(field)
      },
      colProps: {
        span: 8
      }
    },
    {
      field: 'wireNumber',
      component: 'ElInput',
      label: '线束数量',
      componentProps: { disabled: true },
      ifShow({ model, field }) {
        return showNumberKeys.value.includes(field)
        // return model[field] !== '/' || showNumberKeys.value.includes(field)
      },
      colProps: {
        span: 8
      }
    },
    {
      field: 'pcbaNumber',
      component: 'ElInput',
      label: 'PCBA数量',
      componentProps: { disabled: true },
      ifShow({ model, field }) {
        return showNumberKeys.value.includes(field)
        // return model[field] !== '/' || showNumberKeys.value.includes(field)
      },
      colProps: {
        span: 8
      }
    }
  ]
})

const [
  registerForm,
  { resetFields, getFieldsValue, updateSchema, setFieldsValue, validate, clearValidate }
] = useForm({
  labelWidth: 120,
  schemas: [
    {
      field: 'processID',
      component: 'Select',
      label: '工序任务',
      rules: [{ required: true, trigger: 'change' }],
      componentProps: {
        options: [],
        valueField: 'id',
        labelField: 'processType',
        async onChange(processID: string, row: any) {
          if (row) {
            setFieldsValue({
              standardWorkHour: standardWorkTimeList.value.filter(
                (item) => item.processID === processID
              )[0]?.standardWorkHour
            })
          }
          if (processID) {
            const { code, data: res } = await getDispatchingGroupProportion({
              woNo: workOrder.value!.woNo,
              sonProcessID: processID
            })
            if (code === 200) {
              sumDispatchingNumber.value = res.sumDispatchingNumber
              if (!isUpdate.value) {
                rowData.value!.dataDescribe = res.dataDescribe
              }
              if (isUpdate.value) {
                // maxProportion.value = rowData.value!.proportion! + res.maxProportion
                maxDispatchingNumber.value =
                  rowData.value!.dispatchingNumber! +
                  (res.maxDispatchingNumber === null ? 9999 : res.maxDispatchingNumber)
              } else {
                maxProportion.value = res.maxProportion
                maxDispatchingNumber.value =
                  res.maxDispatchingNumber === null ? 9999 : res.maxDispatchingNumber
              }
              await setFieldsValue({ ...rowData.value })
            }
          }
        }
      },
      colProps: {
        span: 8
      }
    },
    {
      field: 'dispatchingNumber',
      component: 'ElInputNumber',
      label: '派工数量',
      defaultValue: 1,
      rules: [{ required: true, trigger: 'blur' }],
      componentProps: {
        min: 1,
        max: 9999,
        step: 1,
        stepStrictly: true
      },
      render({ model, field }) {
        return (
          <div style="display:flex;gap:8px">
            <el-input-number
              v-model={model[field]}
              min={0}
              max={maxDispatchingNumber.value}
              step={1}
              stepStrictly={true}
              onChange={() => {
                const num = (model[field] / sumDispatchingNumber.value) * 100
                setFieldsValue({
                  proportion: num < 1 && num > 0.01 ? 1 : ceil(num)
                })
              }}
            ></el-input-number>
            <div style="color:#aaa;font-size:14px">最大可填{maxDispatchingNumber.value}</div>
          </div>
        )
      },
      colProps: {
        span: 8
      }
    },
    {
      field: 'proportion',
      component: 'ElInputNumber',
      label: '单工序派工比例',
      labelWidth: '150px',
      defaultValue: 0,
      rules: [
        {
          required: true,
          trigger: 'blur',
          type: 'number',
          min: 1,
          message: '单工序派工比例不能小于1'
        }
      ],
      render({ model, field }) {
        return (
          <div style="display:flex;gap:8px">
            <el-input-number
              v-model={model[field]}
              min={0}
              max={maxProportion.value}
              step={1}
              stepStrictly={true}
              onChange={() => {
                setFieldsValue({
                  dispatchingNumber: round((model[field] / 100) * sumDispatchingNumber.value)
                })
              }}
            ></el-input-number>
            <div>%</div>
            <div style="color:#aaa;font-size:14px">最大可填{maxProportion.value}%</div>
          </div>
        )
      },
      colProps: {
        span: 8
      }
    },
    {
      field: 'standardWorkHour',
      component: 'ElInput',
      label: '标准工时',
      defaultValue: 0,
      render({ model, field }) {
        return (
          <div style="display:flex;gap:8px;width:50%">
            <el-input v-model={model[field]} disabled={true}></el-input>
            <div>H</div>
          </div>
        )
      },
      colProps: {
        span: 8
      }
    },
    {
      field: 'groupID',
      component: 'Select',
      label: '班组',
      rules: [{ required: true, trigger: 'change' }],
      componentProps: {
        options: [],
        class: 'groupNameInput',
        onChange(value: string, row: any) {
          if (row) {
            setFieldsValue({ leaderName: row.employeeName })
          }
        }
      },
      colProps: {
        span: 8
      }
    },
    {
      field: 'leaderName',
      component: 'ElInput',
      label: '班组长',
      labelWidth: '150px',
      componentProps: {
        disabled: true
      },
      colProps: {
        span: 8
      }
    },
    {
      field: 'startDate',
      component: 'ElDatePicker',
      label: '计划开始日期',
      defaultValue: dayjs().format('YYYY-MM-DD'),
      rules: [{ required: true, trigger: 'change' }],
      componentProps: {
        valueFormat: 'YYYY-MM-DD'
      },
      colProps: {
        span: 8
      }
    },
    {
      field: 'dataDescribe',
      component: 'ElInput',
      label: '工作描述',
      componentProps: { type: 'textarea' },
      colProps: {
        span: 16
      }
    }
  ]
})

// 提交
const handleSubmit = async () => {
  await validate()
  try {
    changeOkLoading(true)
    if (!unref(isUpdate)) {
      // 新增
      const formData = getFieldsValue() as AddDispatchingGroupList

      const res = await getDispatchingGroupByDate({
        WoNo: workOrder.value!.woNo,
        StartDate: formData.startDate,
        GroupID: formData.groupID
      })
      if (res.code === 200) {
        if (res.data.length > 0) {
          const name = document.querySelector('.groupNameInput input') as HTMLInputElement
          ElMessageBox.confirm(
            `已存在名称为"${name.value}"的派工记录，请确认是否继续添加？`,
            '警告',
            {
              confirmButtonText: '确定',
              cancelButtonText: '取消',
              type: 'warning'
            }
          )
            .then(async () => {
              await copyRequest(formData)
            })
            .finally(() => changeOkLoading(false))
        } else {
          await copyRequest(formData)
        }
      } else {
        ElMessage.error(res.message)
      }
    } else {
      const formData = {
        ...(getFieldsValue() as UpdateDispatchingGroupData),
        woID: workOrder.value!.id,
        id: rowId.value
      }

      const { code, data, message } = await updateDispatchingGroup(formData)
      if (code === 200 && data) {
        emit('success', { isUpdate: true })
      } else {
        ElMessage.error(message)
      }
    }
  } catch (error: any) {
    ElMessage.error(error.message)
  } finally {
    changeOkLoading(false)
  }
}

const copyRequest = async (formData: Omit<AddDispatchingGroupList, 'woID'>) => {
  const addData: AddDispatchingGroupData = {
    dataDescribe: formData.dataDescribe,
    AddDispatchingGroupList: [{ woID: workOrder.value!.id, ...formData }]
  }
  try {
    const { code, data, message } = await addDispatchingGroup(addData)
    if (code === 200 && data) {
      emit('success', { isUpdate: false })
    } else {
      ElMessage.error(message)
    }
  } finally {
    changeOkLoading(false)
  }
}
const handleClose = () => {
  maxProportion.value = 0
  sumDispatchingNumber.value = 0
  maxDispatchingNumber.value = 0
}
</script>

<style scoped></style>
