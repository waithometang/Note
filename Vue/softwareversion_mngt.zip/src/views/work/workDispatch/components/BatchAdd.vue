<template>
  <BasicModal
    width="1200px"
    top="3%"
    v-bind="$attrs"
    @register="registerInnerModal"
    title="批量新增"
    @confirm="handleSubmit"
    @close="handleClose"
  >
    <BasicForm @register="registerWorkOrderForm" />
    <vxe-grid ref="gridRef" v-bind="gridOptions" @edit-actived="handleEditActived">
      <template #processID_edit="{ row }">
        <Select
          v-model="row.processID"
          :options="processList"
          value-field="id"
          label-field="processType"
          @change="
            async (processID: string, data: any) => {
              // 重置派工数量和比例
              row.proportion = 0
              row.dispatchingNumber = 0
              row.maxProportion = 0
              row.sumDispatchingNumber = 0
              row.maxDispatchingNumber = 0
              // 过滤
              row.standardWorkHour = standardWorkTimeList.filter(
                (item) => item.processID === processID
              )[0]?.standardWorkHour
              // 获取新增派工单时查询剩余最大可填进度比重
              if (processID) {
                const { code, data: res } = await getDispatchingGroupProportion({
                  woNo: workOrder!.woNo,
                  sonProcessID: processID
                })
                if (code === 200) {
                  row.maxProportion = res.maxProportion
                  row.sumDispatchingNumber = res.sumDispatchingNumber
                  row.maxDispatchingNumber =
                    res.maxDispatchingNumber === null ? 9999 : res.maxDispatchingNumber
                  filterResidual(row)
                  // 设置下拉框可选disabled
                  // processList.forEach((item: any) => {
                  //   const hasProcess = tableData?.find((row) => row.processID === item.id)
                  //   // if (hasProcess) {
                  //   //   item.disabled = true
                  //   // } else {
                  //   //   item.disabled = false
                  //   // }
                  // })
                }
              }
              // 非编辑状态下显示的值
              if (data) {
                row.processName = data.label
              }
            }
          "
        ></Select>
      </template>
      <template #proportion_edit="{ row }">
        <el-tooltip
          effect="dark"
          :content="'最大可填' + (row.residualProportion || 0) + '%'"
          placement="bottom"
          :visible="gridRef?.isEditByRow(row)"
          ><el-input-number
            style="width: 100%"
            v-model="row.proportion"
            :min="0"
            :max="row.residualProportion"
            :step="1"
            stepStrictly
            @change="
              (proportion: number) => {
                row.dispatchingNumber = round((proportion / 100) * row.sumDispatchingNumber)
              }
            "
          ></el-input-number
        ></el-tooltip>
      </template>
      <template #dispatchingNumber_edit="{ row }">
        <el-tooltip
          effect="dark"
          :content="'最大可填' + (row.residualDispatchingNumber || 0)"
          placement="bottom"
          :visible="gridRef?.isEditByRow(row)"
          ><el-input-number
            style="width: 100%"
            v-model="row.dispatchingNumber"
            :min="0"
            :max="row.residualDispatchingNumber"
            :step="1"
            stepStrictly
            @change="
              (dispatchingNumber: number) => {
                const num = (dispatchingNumber / row.sumDispatchingNumber) * 100
                row.proportion = num < 1 && num > 0.01 ? 1 : ceil(num)
              }
            "
          ></el-input-number>
        </el-tooltip>
      </template>
      <template #groupID_edit="{ row }">
        <Select
          v-model="row.groupID"
          :options="groupList"
          @change="
            (value: string, data: any) => {
              if (data) {
                row.groupName = data.label
                row.leaderName = data.employeeName
              }
            }
          "
        ></Select>
      </template>
      <template #startDate_edit="{ row }">
        <el-date-picker
          style="width: 100%"
          v-model="row.startDate"
          type="date"
          format="YYYY-MM-DD"
          date-format="YYYY-MM-DD"
          value-format="YYYY-MM-DD"
        ></el-date-picker>
      </template>
      <template #dataDescribe_edit="{ row }">
        <el-input style="width: 100%" v-model="row.dataDescribe"></el-input>
      </template>
      <template #operation="{ row }">
        <TableAction
          :actions="[
            {
              icon: 'edit',
              tooltip: '编辑',
              ifShow: () => !gridRef!.isEditByRow(row),
              onClick: handleEdit.bind(null, row)
            },
            {
              icon: 'save',
              tooltip: '完成',
              ifShow: () => gridRef!.isEditByRow(row),
              onClick: handleComplete.bind(null, row)
            },
            {
              icon: 'delete',
              tooltip: '删除',
              onClick: handleDelete.bind(null, row)
            }
          ]"
        />
      </template>
      <template #bottom>
        <div style="display: flex; margin-top: 16px">
          <TableAction
            :actions="[
              {
                icon: 'plus',
                label: '新增',
                onClick: handleAdd.bind(null),
                style: {
                  color: '#008cd6'
                }
              },
              {
                label: '最大分配',
                onClick: handleMaxAllot.bind(null),
                style: {
                  color: '#008cd6'
                }
              }
            ]"
          />
        </div>
        <div style="margin-top: 10px; display: flex; justify-content: end">
          共 {{ total }} 条记录
        </div>
      </template>
    </vxe-grid>
  </BasicModal>
</template>

<script setup lang="ts">
import type {
  AddDispatchingGroupData,
  AddDispatchingGroupList,
  GetWorkOrderModel
} from '@/api/sys/model/workModel'
import { dayjs } from 'element-plus'
import type { VxeGridEvents, VxeGridInstance, VxeGridProps } from 'vxe-table'
import type {
  GetProductionProcessChildrenParams,
  GetProductionProcessModel
} from '@/api/sys/model/basicModel'
import type { ModalMethods } from '@/components/Modal/types'

import { ref, reactive, computed } from 'vue'

import BasicForm from '@/components/Form/BasicForm.vue'
import BasicModal from '@/components/Modal/BasicModal.vue'
import Select from '@/components/Form/components/Select.vue'

import { useModalInner } from '@/components/Modal/hooks/useModal'
import {
  getGroupSelect,
  getProductionProcessChildren,
  getProductionProcessTopLevel
} from '@/api/sys/basic'
import {
  addDispatchingGroup,
  getDispatchingGroupByDate,
  getDispatchingGroupProportion
} from '@/api/sys/work'
import { useForm } from '@/components/Form/hooks/useForm'
import { getStandardWorkTimeByProcessID } from '@/api/sys/scheduling'
import { round, ceil } from 'lodash-es'

const emit = defineEmits<{
  register: [modalMethods: ModalMethods, uuid: number]
  success: []
}>()

const total = computed(() => {
  return gridRef.value?.getTableData().fullData.length || 0
})

const processList = ref<GetProductionProcessModel[]>([])
const groupList = ref()
const standardWorkTimeList = ref<any[]>([])

const getProcessList = async (params: GetProductionProcessChildrenParams) => {
  const { data, code } = await getProductionProcessChildren(params)
  if (code === 200) {
    processList.value = data.result.filter((item) => item.dataStatus !== 2)
  } else {
    processList.value = []
  }
}

const getGroupList = async (departmentID: string) => {
  const { data, code } = await getGroupSelect({ departmentID })
  if (code === 200) {
    groupList.value = data.result
  } else {
    groupList.value = []
  }
}

const showNumberKeys = ref<string[]>([])
const getShowNumberKeys = async (processID: string) => {
  const { code, data } = await getProductionProcessTopLevel({ processID })
  if (code === 200) {
    showNumberKeys.value = data.result.map((item) =>
      lowercaseFirstLetter(item.deviceNumberTypeKey!)
    )
    console.log(showNumberKeys.value)
  }
}

//将字符串首字母变小写
function lowercaseFirstLetter(str: string) {
  return str.charAt(0).toLowerCase() + str.slice(1)
}

const gridRef = ref<VxeGridInstance>()
const gridOptions = reactive<VxeGridProps<AddDispatchingGroupList>>({
  border: true,
  height: '500px',
  align: null,
  columnConfig: {
    resizable: true
  },
  loading: false,
  //   keepSource: true,
  editConfig: {
    trigger: 'dblclick',
    mode: 'row',
    autoClear: false
    // showStatus: true,
    // showUpdateStatus: true,
    // showInsertStatus: true
  },
  editRules: {
    processID: [{ required: true, message: '请选择工序任务' }],
    proportion: [{ required: true, message: '请输入派工比例' }],
    dispatchingNumber: [{ required: true, message: '请输入派工数量' }],
    groupID: [{ required: true, message: '请选择班组' }],
    startDate: [{ required: true, message: '请选择计划开始日期' }]
  },
  columns: [
    { type: 'checkbox', width: 50 },
    { field: 'processName', title: '工序任务ID', width: 120, visible: false },
    {
      field: 'processID',
      title: '工序任务',
      width: 200,
      editRender: {},
      slots: { edit: 'processID_edit' },
      formatter({ row }) {
        return row.processName || ''
      }
    },
    {
      field: 'proportion',
      title: '派工比例(%)',
      editRender: { defaultValue: 0 },
      slots: { edit: 'proportion_edit' },
      minWidth: 150
    },
    {
      field: 'dispatchingNumber',
      title: '派工数量',
      minWidth: 150,
      editRender: { defaultValue: 0 },
      slots: { edit: 'dispatchingNumber_edit' }
    },
    { field: 'transferDepartmentName', visible: false },
    {
      field: 'standardWorkHour',
      title: '标准工时',
      minWidth: 100,
      formatter({ cellValue }) {
        return cellValue ? cellValue + 'H' : ''
      }
    },
    { field: 'groupName', visible: false },
    {
      field: 'groupID',
      title: '班组',
      minWidth: 200,
      editRender: {},
      slots: { edit: 'groupID_edit' },
      formatter({ row }) {
        return row.groupName || ''
      }
    },
    {
      field: 'startDate',
      title: '计划开始日期',
      minWidth: 160,
      editRender: { defaultValue: dayjs().format('YYYY-MM-DD') },
      slots: { edit: 'startDate_edit' }
    },
    {
      field: 'leaderName',
      title: '班组长',
      minWidth: 120
    },
    {
      field: 'operation',
      title: '操作',
      align: 'center',
      fixed: 'right',
      width: 150,
      slots: {
        default: 'operation'
      }
    }
  ],
  pagerConfig: {
    enabled: false
  },
  data: []
})

const workOrder = ref<GetWorkOrderModel>()

const [
  registerWorkOrderForm,
  { resetFields: resetWorkOrderFields, setFieldsValue: setFieldsWorkOrderValue }
] = useForm({
  labelWidth: 120,
  schemas: [
    {
      field: 'projectID',
      component: 'ElInput',
      label: '项目iD',
      ifShow: false,
      colProps: {
        span: 8
      }
    },
    {
      field: 'processID',
      component: 'ElInput',
      label: '设备类型iD',
      ifShow: false,
      colProps: {
        span: 8
      }
    },
    {
      field: 'orderNo',
      component: 'ElInput',
      label: '需求分类',
      componentProps: { disabled: true },
      colProps: {
        span: 8
      }
    },
    {
      field: 'woNo',
      component: 'ElInput',
      label: '单据编号',
      componentProps: { disabled: true },
      colProps: {
        span: 8
      }
    },
    {
      field: 'productName',
      component: 'ElInput',
      label: '部件名称',
      componentProps: { disabled: true },
      colProps: {
        span: 8
      }
    },
    {
      field: 'processType',
      component: 'ElInput',
      label: '设备类型',
      componentProps: { disabled: true },
      ifShow: false,
      colProps: {
        span: 8
      }
    },
    {
      field: 'departmentName',
      component: 'ElInput',
      label: '生产部门',
      componentProps: { disabled: true },
      colProps: {
        span: 8
      }
    },
    {
      field: 'departmentID',
      component: 'ElInput',
      label: '生产部门ID',
      componentProps: { disabled: true },
      ifShow: false
    },
    {
      field: 'productionAddressName',
      component: 'ElInput',
      label: '生产场地',
      componentProps: { disabled: true },
      colProps: {
        span: 8
      }
    },
    {
      field: 'employeeName',
      component: 'ElInput',
      label: 'PMC',
      ifShow: false,
      componentProps: { disabled: true },
      colProps: {
        span: 8
      }
    },
    {
      field: 'productionOrderNumber',
      component: 'ElInput',
      label: '订单数量',
      componentProps: { disabled: true },
      colProps: {
        span: 8
      }
    },
    {
      field: 'chassisNumber',
      component: 'ElInput',
      label: '机箱数量',
      componentProps: { disabled: true },
      ifShow({ model, field }) {
        return showNumberKeys.value.includes(field)
        // return model[field] !== '/' || showNumberKeys.value.includes(field)
      },
      colProps: {
        span: 8
      }
    },
    {
      field: 'frameNumber',
      component: 'ElInput',
      label: '机架数量',
      componentProps: { disabled: true },
      ifShow({ model, field }) {
        return showNumberKeys.value.includes(field)
        // return model[field] !== '/' || showNumberKeys.value.includes(field)
      },
      colProps: {
        span: 8
      }
    },
    {
      field: 'locationNumber',
      component: 'ElInput',
      label: '库位数量',
      componentProps: { disabled: true },
      ifShow({ model, field }) {
        return showNumberKeys.value.includes(field)
        // return model[field] !== '/' || showNumberKeys.value.includes(field)
      },
      colProps: {
        span: 8
      }
    },
    {
      field: 'wireNumber',
      component: 'ElInput',
      label: '线束数量',
      componentProps: { disabled: true },
      ifShow({ model, field }) {
        return showNumberKeys.value.includes(field)
        // return model[field] !== '/' || showNumberKeys.value.includes(field)
      },
      colProps: {
        span: 8
      }
    },
    {
      field: 'pcbaNumber',
      component: 'ElInput',
      label: 'PCBA数量',
      componentProps: { disabled: true },
      ifShow({ model, field }) {
        return showNumberKeys.value.includes(field)
        // return model[field] !== '/' || showNumberKeys.value.includes(field)
      },
      colProps: {
        span: 8
      }
    }
  ]
})

const [registerInnerModal, { setModalProps }] = useModalInner(async (data) => {
  gridOptions.loading = true
  await resetWorkOrderFields()
  setModalProps({ confirmLoading: false })
  workOrder.value = data.workOrder
  await setFieldsWorkOrderValue({ ...data.workOrder })
  await getProcessList({
    processTypeID: data.workOrder.processID,
    standardWorkTimeProjectID: data.workOrder.projectID,
    standardWorkTimeProductName: data.workOrder.productName
  })
  await getGroupList(data.workOrder.departmentID)
  await getShowNumberKeys(workOrder.value!.processID)
  //获取标准工时
  const { code, data: res } = await getStandardWorkTimeByProcessID({
    projectID: data.workOrder.projectID,
    productName: data.workOrder.productName,
    orderNo: data.workOrder.orderNo
  })
  if (code === 200) {
    standardWorkTimeList.value = res.result
  }
  //批量添加工序任务
  for (const item of processList.value) {
    // const { code, data: res } = await getDispatchingGroupProportion({
    //   woNo: workOrder.value!.woNo,
    //   sonProcessID: item.id
    // })
    if (code === 200) {
      await gridRef.value?.insertAt(
        {
          processID: item.id,
          processName: item.processType,
          // maxProportion: res.maxProportion,
          // sumDispatchingNumber: res.sumDispatchingNumber,
          // maxDispatchingNumber: res.maxDispatchingNumber === null ? 9999 : res.maxDispatchingNumber,
          standardWorkHour: standardWorkTimeList.value.find(
            (standardWorkTime) => standardWorkTime.processID === item.id
          )?.standardWorkHour
        },
        -1
      )
      // filterResidual(row)
    }
  }
  gridOptions.loading = false
})

const getRowDispatchingGroupProportion = async (row: any) => {
  if (
    row.processID &&
    typeof row.maxProportion !== 'number' &&
    typeof row.sumDispatchingNumber !== 'number' &&
    typeof row.maxDispatchingNumber !== 'number'
  ) {
    const {
      code,
      data: res,
      message
    } = await getDispatchingGroupProportion({
      woNo: workOrder.value!.woNo,
      sonProcessID: row.processID
    })
    if (code === 200) {
      row.maxProportion = res.maxProportion
      row.sumDispatchingNumber = res.sumDispatchingNumber
      row.maxDispatchingNumber = res.maxDispatchingNumber === null ? 9999 : res.maxDispatchingNumber
    } else {
      ElMessage.error('查询剩余派工数量和比例失败' + message)
    }
  }
}

// 关闭清空表格
const handleClose = () => {
  gridRef.value?.loadData([])
}

const handleAdd = () => {
  gridRef.value?.insertAt({}, -1)
}

const handleMaxAllot = () => {
  const tableData = gridRef.value!.getTableData().tableData
  tableData.forEach(async (row) => {
    await getRowDispatchingGroupProportion(row)
    filterResidual(row)
    row.dispatchingNumber = row.residualDispatchingNumber
    row.proportion = row.residualProportion
  })
}

const handleDelete = async (row: AddDispatchingGroupList) => {
  await gridRef.value?.clearEdit()
  gridRef.value?.remove(row)
}

const handleEdit = async (row: AddDispatchingGroupList) => {
  gridRef.value?.setEditRow(row)
}

const handleEditActived: VxeGridEvents.EditActived = async ({ row }) => {
  await getRowDispatchingGroupProportion(row)
  filterResidual(row)
}

// 计算剩余派工数量和派工比例
const filterResidual = (row: any) => {
  const tableData = gridRef.value?.getTableData().fullData.filter((item) => item !== row)

  const filertList = tableData?.filter((item) => item.processID === row.processID)

  const countProportion = filertList?.reduce((count, cur) => count + cur.proportion, 0)
  const countDispatchingNumber = filertList?.reduce(
    (count, cur) => count + cur.dispatchingNumber,
    0
  )

  row.residualProportion = row.maxProportion - countProportion
  row.residualDispatchingNumber = row.maxDispatchingNumber - countDispatchingNumber
}

const handleComplete = async (row: AddDispatchingGroupList) => {
  const errMap = await gridRef.value?.validate(row)
  if (errMap) {
    return
  }
  const res = await getDispatchingGroupByDate({
    WoNo: workOrder.value!.woNo,
    StartDate: row.startDate,
    GroupID: row.groupID
  })
  if (res.code === 200) {
    if (res.data.length > 0) {
      ElMessageBox.confirm(
        `已存在名称为"${row.processName}"的派工记录，请确认是否继续添加？`,
        '警告',
        {
          confirmButtonText: '确定',
          cancelButtonText: '取消',
          type: 'warning'
        }
      ).then(async () => {
        gridRef.value?.clearEdit()
      })
    } else {
      gridRef.value?.clearEdit()
    }
  } else {
    ElMessage.error(res.message)
  }
}

// 提交
const handleSubmit = async () => {
  const tableData = gridRef.value?.getCheckboxRecords() as AddDispatchingGroupList[]
  const errMap = await gridRef.value?.validate(tableData)

  if (tableData.length === 0) {
    ElMessage.warning('请选择需要新增的行数据')
    return
  }
  if (errMap) {
    return
  }
  try {
    setModalProps({ confirmLoading: true })
    // 新增
    // const tableData = gridRef.value?.getTableData().fullData as AddDispatchingGroupList[]
    const data: AddDispatchingGroupData = {
      AddDispatchingGroupList: tableData.map((item) => {
        return {
          ...item,
          woID: workOrder.value!.id
        }
      })
    }
    const { code, message } = await addDispatchingGroup(data)
    if (code === 200) {
      ElMessage.success('新增成功')
      emit('success')
    } else {
      ElMessage.error(message)
    }
  } catch (error: any) {
    ElMessage(error.message)
  } finally {
    setModalProps({ confirmLoading: false })
  }
}
</script>

<style scoped></style>
