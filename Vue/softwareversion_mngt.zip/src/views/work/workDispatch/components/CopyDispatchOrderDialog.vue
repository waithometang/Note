<template>
  <BasicModal
    width="70%"
    v-bind="$attrs"
    @register="registerModal"
    title="复制"
    @confirm="handleSubmit"
    @close="handleClose"
  >
    <BasicForm @register="registerForm" />
  </BasicModal>
</template>

<script setup lang="tsx">
import type { ModalMethods } from '@/components/Modal/types'

import { ref } from 'vue'

import BasicModal from '@/components/Modal/BasicModal.vue'
import BasicForm from '@/components/Form/BasicForm.vue'

import { useModalInner } from '@/components/Modal/hooks/useModal'
import { useForm } from '@/components/Form/hooks/useForm'
import type {
  AddDispatchingGroupData,
  AddDispatchingGroupList,
  GetWorkOrderModel
} from '@/api/sys/model/workModel'
import {
  addDispatchingGroup,
  getDispatchingGroupByDate,
  getDispatchingGroupProportion
} from '@/api/sys/work'
import { getGroupSelect, getProductionProcessChildren } from '@/api/sys/basic'
import type { GetProductionProcessChildrenParams } from '@/api/sys/model/basicModel'
import { ceil, round } from 'lodash-es'

const emit = defineEmits<{
  register: [modalMethods: ModalMethods, uuid: number]
  success: []
}>()

const workOrder = ref<GetWorkOrderModel>()

const getProcessList = async (params: GetProductionProcessChildrenParams) => {
  const { data } = await getProductionProcessChildren(params)
  await updateSchema({ field: 'processID', componentProps: { options: data.result } })
}

const getGroupList = async (departmentID: string) => {
  const { data } = await getGroupSelect({
    departmentID
  })
  await updateSchema([{ field: 'groupID', componentProps: { options: data.result } }])
}

const maxProportion = ref(0) // 最大可输入进度
const maxDispatchingNumber = ref(0) // 最大可输入派工数量
const sumDispatchingNumber = ref(0)

const [registerModal, { setModalProps, changeOkLoading }] = useModalInner(async (data) => {
  resetFields()
  setModalProps({ confirmLoading: false })

  workOrder.value = data.workOrder

  await getProcessList({
    processTypeID: data.workOrder.processID,
    standardWorkTimeProjectID: data.projectID,
    standardWorkTimeProductName: data.workOrder.productName
  })
  await getGroupList(data.workOrder.departmentID)

  await setFieldsValue({
    processType: workOrder.value?.processType,
    ...data.row,
    processID: data.row.sonProcessID
  })

  clearValidate()
})

const [
  registerForm,
  { setFieldsValue, resetFields, getFieldsValue, updateSchema, validate, clearValidate }
] = useForm({
  labelWidth: 120,
  schemas: [
    {
      field: 'projectID',
      component: 'ElInput',
      label: '项目',
      componentProps: { disabled: true },
      colProps: {
        span: 8
      }
    },
    {
      field: 'orderNo',
      component: 'ElInput',
      label: '需求分类',
      componentProps: { disabled: true },
      colProps: {
        span: 8
      }
    },
    {
      field: 'woNo',
      component: 'ElInput',
      label: '单据编号',
      componentProps: { disabled: true },
      colProps: {
        span: 8
      }
    },
    {
      field: 'productName',
      component: 'ElInput',
      label: '部件名称',
      componentProps: { disabled: true },
      colProps: {
        span: 8
      }
    },
    {
      field: 'processID',
      component: 'Select',
      label: '工序任务',
      rules: [{ required: true, trigger: 'change' }],
      componentProps: {
        options: [],
        labelField: 'processType',
        valueField: 'id',
        disabled: true,
        async onChange(processID: string) {
          if (processID) {
            const { code, data: res } = await getDispatchingGroupProportion({
              woNo: workOrder.value!.woNo,
              sonProcessID: processID
            })
            if (code === 200) {
              maxProportion.value = res.maxProportion
              sumDispatchingNumber.value = res.sumDispatchingNumber
              maxDispatchingNumber.value =
                res.maxDispatchingNumber === null ? 9999 : res.maxDispatchingNumber
            }
          }
        }
      },
      colProps: {
        span: 8
      }
    },
    {
      field: 'groupName',
      component: 'ElInput',
      label: '班组',
      componentProps: {
        options: [],
        disabled: true
      },
      colProps: {
        span: 8
      }
    },
    {
      field: 'xx',
      component: 'ElInput',
      label: '',
      labelWidth: '0',
      render() {
        return <el-divider content-position="left">目标项目</el-divider>
      },
      colProps: {
        span: 24
      }
    },
    {
      field: 'groupID',
      component: 'Select',
      label: '班组',
      componentProps: {
        options: [],
        class: 'groupNameInput',
        onChange(_groupID: string, row: any) {
          if (row) {
            setFieldsValue({ leaderID: row.leaderID, leaderName: row.employeeName })
          }
        }
      },
      colProps: {
        span: 8
      }
    },
    // {
    //   field: 'processID',
    //   component: 'Select',
    //   label: '工序任务',
    //   rules: [{ required: true, trigger: 'change' }],
    //   componentProps: {
    //     options: [],
    //     labelField: 'processType',
    //     valueField: 'id'
    //   },
    //   colProps: {
    //     span: 8
    //   }
    // },
    {
      field: 'dispatchingNumber',
      component: 'ElInputNumber',
      label: '派工数量',
      defaultValue: 1,
      rules: [{ required: true, trigger: 'blur' }],
      render({ model, field }) {
        return (
          <div style="display:flex;gap:8px">
            <el-input-number
              v-model={model[field]}
              min={0}
              max={maxDispatchingNumber.value}
              step={1}
              stepStrictly={true}
              onChange={() => {
                const num = (model[field] / sumDispatchingNumber.value) * 100
                setFieldsValue({
                  proportion: num < 1 && num > 0.01 ? 1 : ceil(num)
                })
              }}
            ></el-input-number>
            <div style="color:#aaa;font-size:14px">最大可填{maxDispatchingNumber.value}</div>
          </div>
        )
      },
      colProps: {
        span: 8
      }
    },
    {
      field: 'proportion',
      component: 'ElInputNumber',
      label: '派工比例',
      defaultValue: 0,
      rules: [
        {
          required: true,
          trigger: 'blur',
          type: 'number',
          min: 1,
          message: '派工比例不能小于1'
        }
      ],
      render({ model, field }) {
        return (
          <div style="display:flex;gap:8px">
            <el-input-number
              v-model={model[field]}
              min={0}
              max={maxProportion.value}
              step={1}
              stepStrictly={true}
              onChange={() => {
                setFieldsValue({
                  dispatchingNumber: round((model[field] / 100) * sumDispatchingNumber.value)
                })
              }}
            ></el-input-number>
            <div>%</div>
            <div style="color:#aaa;font-size:14px">最大可填{maxProportion.value}%</div>
          </div>
        )
      },
      colProps: {
        span: 8
      }
    },
    {
      field: 'leaderID',
      component: 'ElInput',
      label: '班组长',
      componentProps: {
        disabled: true
      },
      ifShow: false,
      colProps: {
        span: 8
      }
    },
    {
      field: 'leaderName',
      component: 'ElInput',
      label: '班组长',
      componentProps: {
        disabled: true
      },
      colProps: {
        span: 8
      }
    },
    {
      field: 'startDate',
      component: 'ElDatePicker',
      label: '计划开始日期',
      rules: [{ required: true, trigger: 'change' }],
      componentProps: {
        valueFormat: 'YYYY-MM-DD'
      },
      colProps: {
        span: 8
      }
    }
  ]
})

// 提交
const handleSubmit = async () => {
  await validate()
  try {
    changeOkLoading(true)

    // 新增
    const formData = getFieldsValue() as Omit<AddDispatchingGroupList, 'woID'>

    const res = await getDispatchingGroupByDate({
      WoNo: workOrder.value!.woNo,
      StartDate: formData.startDate,
      GroupID: formData.groupID
    })
    if (res.code === 200) {
      if (res.data.length > 0) {
        const name = document.querySelector('.groupNameInput input') as HTMLInputElement

        ElMessageBox.confirm(
          `已存在名称为"${name.value}"的派工记录，请确认是否继续添加？`,
          '警告',
          {
            confirmButtonText: '确定',
            cancelButtonText: '取消',
            type: 'warning'
          }
        )
          .then(async () => {
            await copyRequest(formData)
          })
          .finally(() => changeOkLoading(false))
      } else {
        await copyRequest(formData)
      }
    } else {
      ElMessage.error(res.message)
    }
  } catch (error: any) {
    ElMessage.error(error.message)
  } finally {
    changeOkLoading(false)
  }
}

const copyRequest = async (formData: Omit<AddDispatchingGroupList, 'woID'>) => {
  const addData: AddDispatchingGroupData = {
    AddDispatchingGroupList: [{ woID: workOrder.value!.id, ...formData }]
  }
  try {
    const { code, data, message } = await addDispatchingGroup(addData)
    if (code === 200 && data) {
      emit('success')
    } else {
      ElMessage.error(message)
    }
  } finally {
    changeOkLoading(false)
  }
}
const handleClose = () => {
  maxProportion.value = 0
  sumDispatchingNumber.value = 0
  maxDispatchingNumber.value = 0
}
</script>

<style scoped></style>
