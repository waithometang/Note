export const orderStatusOptions = [
  { label: '未报工', value: 0, type: 'warning' },
  { label: '报工中', value: 1, type: '' },
  { label: '已完成', value: 2, type: 'success' },
  { label: '未派工', value: 3, type: 'info' }
]
