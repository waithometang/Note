export const workReportworkTypeOptions = [
  { label: '正常工时', value: 1 },
  { label: '设计变更', value: 2 },
  { label: '来料不良', value: 3 }
]

export const otherReportWorkTypeOptions = [
  { label: '培训', value: 4 },
  { label: '6S', value: 5 },
  { label: '其他', value: 6 }
]

export const scheduleTypeOptions = [
  { label: '正常班次', value: 1 },
  { label: '其他班次', value: 2 }
]

export const attendanceStatusMap: Recordable<string> = {
  1: '出勤',
  2: '请假',
  3: '休息',
  4: '离职',
  5: '支援',
  6: '缺勤',
  7: '出差',
  8: '旷工'
}

export const orderStatusOptions = [
  { label: '未报工', value: 0, type: 'danger', tagType: 'info' },
  { label: '报工中', value: 1, type: 'warning', tagType: '' },
  { label: '已完工', value: 2, type: 'success', tagType: 'success' }
]

export enum EXPORT_TYPE {
  WORK_REPORT_TYPE = 1,
  PLAN_ACTUAL_ACHIEVEMENT_TYPE = 2
}

export const exportTypeList = [
  { label: '生产报工', value: EXPORT_TYPE.WORK_REPORT_TYPE },
  { label: '计划实际达成表', value: EXPORT_TYPE.PLAN_ACTUAL_ACHIEVEMENT_TYPE }
]
