<template>
  <vxe-grid ref="workReportGridRef" v-bind="workReportGridOptions">
    <template #top>
      <GridHeader
        ref="workReportGridHeaderRef"
        v-bind="workReportHeaderOptions"
        v-on="workReportHeaderEvent"
      />
    </template>
    <template #operation="{ row }">
      <TableAction
        :actions="[
          {
            icon: 'work-report',
            tooltip: '报工',
            onClick: handleWorkReport.bind(null, row),
            ifShow: !hasActiveEditRow(row, workReportGridRef) && row.id === '0'
          },
          {
            icon: 'edit-inline',
            tooltip: '编辑',
            onClick: handleWorkReport.bind(null, row),
            ifShow: !hasActiveEditRow(row, workReportGridRef) && row.id !== '0'
          },
          {
            icon: 'save',
            tooltip: '保存',
            onClick: handleConfirm.bind(null, row, workReportGridRef),
            ifShow: hasActiveEditRow(row, workReportGridRef)
          },
          {
            icon: 'cancle',
            tooltip: '取消',
            onClick: handleCancle.bind(null, row, workReportGridRef),
            ifShow: hasActiveEditRow(row, workReportGridRef)
          },
          {
            icon: 'finish-wo-status',
            tooltip: '组长确认',
            onClick: handleGroupLeaderConfirm.bind(null, row),
            ifShow: () => row.orderStatus === 1
          },
          {
            icon: 'close-wo-status',
            tooltip: '作废',
            onClick: handleCancel.bind(null, row),
            ifShow: function () {
              return [1, 2].includes(row.orderStatus)
            }
          }
        ]"
      />
    </template>

    <!-- <template #bottom>
      <TableAction
        style="margin-top: 16px"
        :actions="[
          {
            icon: 'plus',
            label: '新增行',
            onClick: handleAdd.bind(null),
            style: {
              color: '#008cd6'
            }
          }
        ]"
      ></TableAction>
    </template> -->
  </vxe-grid>

  <GroupLeaderConfirmDialog
    @register="registerGroupLeaderConfirmModal"
    @success="handleGroupLeaderConfirmSuccess"
  />
</template>

<script lang="tsx" setup>
import type { ComponentExposed } from 'vue-component-type-helpers'
import type { GetScheduleModel } from '@/api/sys/model/basicModel'
import type {
  GetReportWorkParams,
  GetReportWorkModel,
  GetReportWorkEmployeeModel,
  GetReportWorkProjectDetailModel,
  GetReportWorkDetailModel
} from '@/api/sys/model/workModel'
import type GridHeader from '@/components/Table/GridHeader.vue'
import type { GridHeaderEvent, GridHeaderProps } from '@/components/Table/types/gridHeader'
import type { VxeGridInstance, VxeGridProps } from 'vxe-table'

import { computed, reactive, ref, toRefs, watch, unref } from 'vue'
import dayjs from 'dayjs'
import { ElInputNumber, ElTimePicker, ElTooltip } from 'element-plus'
import { isDef, isNumber } from '@/utils/is'
import Select from '@/components/Form/components/Select.vue'
import { useModal } from '@/components/Modal/hooks/useModal'
import GroupLeaderConfirmDialog from './GroupLeaderConfirmDialog.vue'
import { attendanceStatusMap, scheduleTypeOptions, workReportworkTypeOptions } from '../data'

import { getScheduleSelectALL } from '@/api/sys/basic'
import {
  addReportWork,
  getReportWork,
  getReportWorkDetail,
  getReportWorkEmployee,
  getReportWorkProjectDetail,
  updateReportWork,
  updateReportWorkState
} from '@/api/sys/work'

const props = defineProps({
  activeRow: {
    type: Object,
    default: () => {
      return {}
    }
  },
  isConfirmStatus: {
    type: Boolean,
    default: false
  }
})
const { activeRow, isConfirmStatus } = toRefs(props)

// 作业班次
const scheduleOptions = ref<GetScheduleModel[]>([])
const getScheduleOptions = async () => {
  const { data } = await getScheduleSelectALL()
  scheduleOptions.value = data.result
}
getScheduleOptions()

// 派工单关联人员
const reportWorkEmployeeOptions = ref<GetReportWorkEmployeeModel[]>([])
const getReportWorkEmployeeOptions = async () => {
  const { data } = await getReportWorkEmployee({ dispatchingGroupID: unref(activeRow).id })
  reportWorkEmployeeOptions.value = data
}
// 员工对应的派工单信息
const projectDetailOptions = ref<GetReportWorkProjectDetailModel[]>([])
const getReportWorkProjectDetailOptions = async (id: string) => {
  const dispatchingGroupID = unref(activeRow)?.id
  if (isDef(dispatchingGroupID)) {
    const { data } = await getReportWorkProjectDetail({
      dispatchingGroupID: dispatchingGroupID,
      employeeInfoID: id
    })
    projectDetailOptions.value = data
  }
}

// 处理休息时间改变
const handleRestTimeChange = (row: GetReportWorkModel, restTime?: number) => {
  const { startTime, endTime, scheduleType } = row
  if (scheduleType === 2 && startTime && endTime) {
    if (isNumber(restTime)) {
      // 假设日期都为当前日期
      const currentDate = dayjs().format('YYYY-MM-DD')
      let startTime = dayjs(currentDate + ' ' + row.startTime)
      let endTime = dayjs(currentDate + ' ' + row.endTime)

      // 如果 endTime 小于 startTime，则表示跨天，需要加一天
      if (endTime.isBefore(startTime)) {
        endTime = endTime.add(1, 'day')
      }

      const takeTime = Number(
        (Math.abs(Number((startTime.diff(endTime, 'minute') / 60).toFixed(1))) - restTime).toFixed(
          1
        )
      )
      row.takeTime = takeTime
    } else {
      row.takeTime = 0
    }
  }
}

const getDispatchOrderStatusInfo = computed(() => {
  const statusMap: { [key: number]: { text: string; type: string } } = {
    0: { text: '未报工', type: 'error' },
    1: { text: '未确认', type: 'warning' },
    2: { text: '已确认', type: 'success' },
    4: { text: '无需报工', type: 'info' }
  }

  return function (status: number) {
    return statusMap[status] || { text: '', color: '' }
  }
})

const workReportGridRef = ref<VxeGridInstance>()
const workReportGridOptions = reactive<VxeGridProps<GetReportWorkModel>>({
  border: true,
  height: '400px',
  align: null,
  keepSource: true,
  editConfig: {
    trigger: 'manual',
    mode: 'row',
    showStatus: true,
    autoClear: false,
    showUpdateStatus: true
  },
  columnConfig: {
    resizable: true
  },
  columns: [
    { type: 'seq', width: 50 },
    {
      field: 'employeeInfoID',
      title: '作业者',
      minWidth: 150,
      editRender: {},
      slots: {
        default({ row }) {
          return (
            <div>
              {row.employeeNo}-{row.employeeName}
            </div>
          )
        },
        edit({ row }) {
          return !row.id ? (
            <Select
              style={'width: 100%'}
              v-model={row.employeeInfoID}
              options={reportWorkEmployeeOptions.value}
              labelField={'employeeName'}
              valueField={'id'}
              onChange={(id: string) => {
                if (id) {
                  getReportWorkProjectDetailOptions(id)
                }
              }}
            >
              {{
                default: ({ option }: { option: any }) => (
                  <>
                    <span style="float: left">{option.employeeNo}</span>
                    <span
                      style="
                      float: right;
                      font-size: 13px;
                    "
                    >
                      {option.employeeName}
                    </span>
                  </>
                )
              }}
            </Select>
          ) : (
            <>
              {row.employeeNo}-{row.employeeName}
            </>
          )
        }
      }
    },
    {
      field: 'orderStatus', //2：请假；3：休息；4：离职；6：缺勤；7出差；8：旷工 禁用其他配置项
      title: '状态',
      width: 180,
      slots: {
        default({ row }) {
          return (
            <div style="display: flex; align-items: center">
              {/* 借调状态 */}
              {row.transferInStatus === 1 && row.attendanceStatus === 1 && (
                <el-tag type="warning" size="small" effect="plain" style="margin-left: 5px">
                  {row.transferInStatusName}
                </el-tag>
              )}
              {/* 考勤状态 异常时显示 */}
              {[2, 3, 4, 6, 7, 8].includes(row.attendanceStatus) && (
                <el-tag type="warning" size="small" effect="plain" style="margin-left: 5px">
                  {attendanceStatusMap[row.attendanceStatus]}
                </el-tag>
              )}
              {/* 报工单状态（0：未报工；1：未确认；2：已确认；4：无需报工）*/}
              {[1, 2, 4].includes(row.orderStatus) && (
                <el-tag
                  style="margin-left: 5px"
                  type={getDispatchOrderStatusInfo.value(row.orderStatus).type}
                >
                  {getDispatchOrderStatusInfo.value(row.orderStatus).text}
                </el-tag>
              )}
            </div>
          )
          // return (
          //   <div style="display: flex; align-items: center">
          //     {row.transferInStatus === 1 && (
          //       <el-tag type="warning" size="small" effect="plain" style="margin-left: 5px">
          //         借调
          //       </el-tag>
          //     )}

          //     {[2, 3, 4, 6, 8].includes(row.attendanceStatus) && (
          //       <el-tag type="warning" size="small" effect="plain" style="margin-left: 5px">
          //         {attendanceStatusMap[row.attendanceStatus]}
          //       </el-tag>
          //     )}
          //   </div>
          // )
        }
      }
    },
    {
      field: 'workType',
      title: '工作类别',
      width: 150,
      editRender: {},
      slots: {
        default({ row }) {
          return workReportworkTypeOptions.find((option) => option.value === row.workType)?.label
        },
        edit({ row }) {
          return (
            <Select
              style={'width: 100%'}
              v-model={row.workType}
              options={workReportworkTypeOptions}
              disabled={[2, 3, 4, 6, 8].includes(row.attendanceStatus)}
            ></Select>
          )
        }
      }
    },
    {
      field: 'dispatchingEmployeeID',
      title: '派工单',
      width: 330,
      editRender: {},
      slots: {
        default({ row }) {
          if (!row?.isAdd) {
            return row.dispatchingEmployeeInfo
          } else {
            return unref(projectDetailOptions).find(
              (option) => option.dispatchingEmployeeID === row.dispatchingEmployeeID
            )?.dispatchingEmployeeInfo
          }
        },
        edit({ row }) {
          return (
            <Select
              style={'width: 100%'}
              disabled={[2, 3, 4, 6, 8].includes(row.attendanceStatus)}
              v-model={row.dispatchingEmployeeID}
              options={projectDetailOptions.value}
              labelField={'dispatchingEmployeeInfo'}
              valueField={'dispatchingEmployeeID'}
              onChange={async (dispatchingGroupID: string) => {
                if (isDef(dispatchingGroupID)) {
                  const { data } = await getReportWorkDetail({
                    dispatchingEmployeeID: row.dispatchingEmployeeID,
                    employeeInfoID: row.employeeInfoID
                  })
                  reportWorkDetail.value = data
                } else {
                  reportWorkDetail.value = undefined
                }
              }}
            ></Select>
          )
        }
      }
    },
    {
      field: 'finishCount',
      title: '报工数量',
      width: 150,
      editRender: {},
      slots: {
        edit({ row }) {
          return (
            <ElTooltip
              visible={workReportGridRef.value?.isEditByRow(row)}
              effect="dark"
              placement="top"
            >
              {{
                content: () => (
                  <>
                    派工数量 {reportWorkDetail.value?.dispatchingNumber},可填
                    {reportWorkDetail.value?.maxFinishCount}
                  </>
                ),
                default: () => (
                  <>
                    <ElInputNumber
                      style={'width: 100%'}
                      v-model={row.finishCount}
                      disabled={[2, 3, 4, 6, 8].includes(row.attendanceStatus)}
                      min={0}
                      max={9999}
                      step={0.1}
                      stepStrictly={true}
                      onChange={(value: number) => {
                        const finishCount = value
                        const dispatchingNumber = reportWorkDetail.value?.dispatchingNumber!
                        if (dispatchingNumber > 0) {
                          let finishPercent = Number(
                            ((finishCount / dispatchingNumber) * 100).toFixed(1)
                          )
                          if (reportWorkDetail.value?.maxFinishPercent) {
                            if (finishPercent > reportWorkDetail.value?.maxFinishPercent) {
                              finishPercent = reportWorkDetail.value?.maxFinishPercent
                            }

                            row.finishPercent = finishPercent
                          }
                        }
                      }}
                    />
                  </>
                )
              }}
            </ElTooltip>
          )
        }
      }
    },
    {
      field: 'finishPercent',
      title: '完成率',
      width: 150,
      editRender: {},
      slots: {
        default({ row }) {
          return row.finishPercent + '%'
        },
        edit({ row }) {
          return (
            <>
              <ElTooltip
                visible={workReportGridRef.value?.isEditByRow(row)}
                effect="dark"
                placement="top"
              >
                {{
                  content: () => <>最大可填 {reportWorkDetail.value?.maxFinishPercent}%</>,
                  default: () => (
                    <>
                      <ElInputNumber
                        style={'width: calc(100% - 20px)'}
                        v-model={row.finishPercent}
                        disabled={[2, 3, 4, 6, 8].includes(row.attendanceStatus)}
                        min={0}
                        max={reportWorkDetail.value?.maxFinishPercent}
                        step={1}
                        stepStrictly={true}
                      ></ElInputNumber>
                      %
                    </>
                  )
                }}
              </ElTooltip>
            </>
          )
        }
      }
    },
    {
      field: 'scheduleType',
      title: '班次类型',
      width: 120,
      editRender: {},
      slots: {
        default({ row }) {
          return scheduleTypeOptions.find((option) => option.value === row.scheduleType)?.label
        },
        edit({ row }) {
          return (
            <>
              <Select
                style={'width: 100%'}
                v-model={row.scheduleType}
                options={scheduleTypeOptions}
                onChange={() => {
                  row.scheduleID = undefined
                  row.workTime = undefined
                  row.restTime = 0
                  row.takeTime = 0
                }}
                disabled={[2, 3, 4, 6, 8].includes(row.attendanceStatus)}
              ></Select>
            </>
          )
        }
      }
    },
    {
      field: 'scheduleID',
      title: '作业班次',
      width: 250,
      editRender: {},
      slots: {
        default({ row }) {
          return (
            unref(scheduleOptions).find((option) => option.value === row.scheduleType)?.label ||
            row.startTime + '-' + row.endTime
          )
        },
        edit({ row }) {
          return (
            <>
              {row.scheduleType === 1 ? (
                <Select
                  style={'width: 100%'}
                  v-model={row.scheduleID}
                  options={scheduleOptions.value}
                  labelField={'scheduleTime'}
                  valueField={'id'}
                  onChange={(value: number, option: any) => {
                    if (option) {
                      row.takeTime = option.workTime
                      row.restTime = option.restTime
                    }
                  }}
                  slots={{
                    default: ({ option }: { option: any }) => {
                      return <>{option.scheduleTime}</>
                    }
                  }}
                  disabled={[2, 3, 4, 6, 8].includes(row.attendanceStatus)}
                ></Select>
              ) : (
                <div style="display:flex;align-items: center;">
                  <ElTimePicker
                    v-model={row.startTime}
                    style={'width: 150px;'}
                    format={'HH:mm'}
                    value-format={'HH:mm'}
                    onChange={(value: string) => {
                      /**
                       * 处理自定义班次计算
                       */
                      const { restTime } = row

                      // 假设日期都为当前日期
                      const currentDate = dayjs().format('YYYY-MM-DD')
                      const startTime = dayjs(currentDate + ' ' + row.startTime)
                      let endTime = dayjs(currentDate + ' ' + value)

                      if (row.startTime && row.endTime) {
                        // 如果 endTime 小于 startTime，则表示跨天，需要加一天
                        if (endTime.isBefore(startTime)) {
                          endTime = endTime.add(1, 'day')
                        }

                        if (isNumber(restTime)) {
                          const takeTime = Number(
                            (
                              Math.abs(
                                Number((startTime.diff(endTime, 'minute') / 60).toFixed(1))
                              ) - restTime
                            ).toFixed(1)
                          )
                          row.takeTime = takeTime
                        } else {
                          row.takeTime = undefined
                        }
                      }
                    }}
                    disabled={[2, 3, 4, 6, 8].includes(row.attendanceStatus)}
                  ></ElTimePicker>
                  -
                  <ElTimePicker
                    v-model={row.endTime}
                    style={'width: 150px;'}
                    format={'HH:mm'}
                    value-format={'HH:mm'}
                    onChange={(value: string) => {
                      /**
                       * 处理自定义班次计算
                       */
                      const { restTime } = row

                      // 假设日期都为当前日期
                      const currentDate = dayjs().format('YYYY-MM-DD')
                      const startTime = dayjs(currentDate + ' ' + row.startTime)
                      let endTime = dayjs(currentDate + ' ' + value)

                      // 如果 endTime 小于 startTime，则表示跨天，需要加一天
                      if (endTime.isBefore(startTime)) {
                        endTime = endTime.add(1, 'day')
                      }

                      if (row.startTime && row.endTime) {
                        if (isNumber(restTime)) {
                          const takeTime = Number(
                            (
                              Math.abs(
                                Number((startTime.diff(endTime, 'minute') / 60).toFixed(1))
                              ) - restTime
                            ).toFixed(1)
                          )
                          row.takeTime = takeTime
                        } else {
                          row.takeTime = undefined
                        }
                      }
                    }}
                    disabled={[2, 3, 4, 6, 8].includes(row.attendanceStatus)}
                  ></ElTimePicker>
                </div>
              )}
            </>
          )
        }
      }
    },
    {
      field: 'restTime',
      title: '休息用时(h)',
      width: 130,
      editRender: {},
      slots: {
        default({ row }) {
          return typeof row.restTime === 'number' ? `${row.restTime}h` : ''
        },
        edit({ row }) {
          return (
            <>
              <ElInputNumber
                style={'width: 100%'}
                v-model={row.restTime}
                min={0}
                disabled={row.scheduleType === 1 || [2, 3, 4, 6, 8].includes(row.attendanceStatus)}
                onChange={(value: number) => {
                  handleRestTimeChange(row, value)
                }}
              ></ElInputNumber>
            </>
          )
        }
      }
    },
    {
      field: 'takeTime',
      title: '作业用时(h)',
      width: 125,
      formatter({ cellValue }) {
        return typeof cellValue === 'number' ? `${cellValue}h` : ''
      }
    },
    { field: 'createUserName', title: '录入人', width: 100 },

    {
      field: 'operation',
      title: '操作',
      align: 'center',
      fixed: 'right',
      width: 200,
      slots: {
        default: 'operation'
      }
    }
  ],
  pagerConfig: {
    enabled: false,
    pageSize: 20
  },
  proxyConfig: {
    autoLoad: false,
    ajax: {
      query: () => {
        return new Promise((resovle) => {
          // const reportWorkTime =
          //   unref(workReportGridHeaderRef.value?.quickSearchForm)?.reportWorkTime || ''
          const dispatchingGroupId = unref(activeRow)?.id || ''
          getReportWork({
            pageIndex: 0,
            pageSize: 99999,
            reportWorkTime:
              unref(workReportGridHeaderRef.value?.quickSearchForm)?.reportWorkTime || '',
            dispatchingGroupId: dispatchingGroupId,
            isConfirmStatus: unref(isConfirmStatus)
          }).then((res) => {
            resovle(res.data.result)
          })
        })
      }
    }
  }
})

const workReportGridHeaderRef =
  ref<ComponentExposed<typeof GridHeader<GetReportWorkParams, 'reportWorkTime'>>>()

const workReportHeaderOptions = reactive<GridHeaderProps>({
  title: '工序报工',
  quickSearch: {
    singleSearch: {
      field: 'reportWorkTime',
      type: 'date',
      title: '报工时间',
      showTitle: true
    },
    searchFormFields: { reportWorkTime: dayjs().format('YYYY-MM-DD') }
  },
  // showAddButton: false,
  showAdvancedSearchButton: false
})

const workReportHeaderEvent: GridHeaderEvent = {
  quickSearch() {
    if (Object.keys(activeRow.value).length) {
      workReportGridRef.value?.commitProxy('reload')
    } else {
      ElMessage.warning('请选择生产任务')
    }
  },
  advancedSearch() {
    if (Object.keys(activeRow.value).length) {
      workReportGridRef.value?.commitProxy('reload')
    } else {
      ElMessage.warning('请选择生产任务')
    }
  },
  reset() {
    if (Object.keys(activeRow.value).length) {
      workReportGridRef.value?.commitProxy('reload')
    } else {
      ElMessage.warning('请选择生产任务')
    }
  },
  add() {
    if (Object.keys(activeRow.value).length) {
      handleAdd()
    } else {
      ElMessage.warning('请选择生产任务')
    }
  }
}

// 判断是否编辑活跃行
const hasActiveEditRow = (row: GetReportWorkModel, $grid?: VxeGridInstance): boolean => {
  if ($grid) {
    return $grid.isEditByRow(row)
  }
  return false
}
// 处理完成
const handleConfirm = async (row: GetReportWorkModel, $grid?: VxeGridInstance) => {
  // const $grid = workPlanGridRef.value
  if ($grid) {
    const insertRecords = $grid.getInsertRecords()
    const updateRecords = $grid.getUpdateRecords()

    if (updateRecords.length === 0) {
      $grid.clearEdit()
    }

    // 后端逻辑让使用'0'判断是否为新增报工
    if ((row.id === '0' && updateRecords.length) || (!row.id && insertRecords.length)) {
      const addRow = insertRecords[0] || updateRecords[0]
      const { code, message } = await addReportWork({
        ...addRow,
        reportWorkTime: unref(workReportGridHeaderRef.value?.quickSearchForm)?.reportWorkTime
      })

      if (code === 200) {
        ElMessage.success('新增成功')
        await $grid.clearEdit()
        workReportGridRef.value?.commitProxy('reload')
      } else {
        ElMessage.error(message)
      }
    } else if (row.id !== '0' && updateRecords.length) {
      const updateRow = updateRecords[0]

      const { code, message } = await updateReportWork({
        ...updateRow,
        reportWorkTime: unref(workReportGridHeaderRef.value?.quickSearchForm)?.reportWorkTime
      })

      if (code === 200) {
        ElMessage.success('修改成功')
        await $grid.clearEdit()
        workReportGridRef.value?.commitProxy('reload')
      } else {
        ElMessage.error(message)
      }
    }
  }
}
// 处理取消
const handleCancle = (row: GetReportWorkModel, $grid?: VxeGridInstance) => {
  $grid?.commitProxy('reload')
}

const [registerGroupLeaderConfirmModal, { openModal: openGroupLeaderConfirmModal }] = useModal()
// 组长确认
const handleGroupLeaderConfirm = async (row: GetReportWorkModel) => {
  openGroupLeaderConfirmModal(true, {
    row,
    isOtherReport: false
  })
}
// 组长确认成功回调
const handleGroupLeaderConfirmSuccess = () => {
  workReportGridRef.value?.commitProxy('reload')
}

// 作废
const handleCancel = (row: GetReportWorkModel) => {
  ElMessageBox.confirm(
    `是否作废名称为"${row.employeeNo + '-' + row.employeeName}"的数据项?`,
    '警告',
    {
      confirmButtonText: '确定',
      cancelButtonText: '取消',
      type: 'warning'
    }
  )
    .then(async () => {
      const { status, message } = await updateReportWorkState({
        id: row.id!,
        orderStatus: 3
      })
      if (status) {
        ElMessage.success('作废成功')
      } else {
        ElMessage.error(message)
      }
    })
    .catch(() => {})
    .finally(() => {
      workReportGridRef.value?.commitProxy('reload')
    })
}

// 新增报工单
const handleAdd = async () => {
  const $grid = workReportGridRef.value

  const insertRecords = $grid?.getInsertRecords()
  if (insertRecords?.length) {
    return
  }

  if ($grid) {
    const { row: newRow } = await $grid.insertAt(
      {
        workType: 1,
        scheduleType: 1,
        isAdd: true
      },
      -1
    )

    await $grid.setEditRow(newRow)
    reportWorkDetail.value = undefined
  }
}
const reportWorkDetail = ref<GetReportWorkDetailModel>()
// 报工
const handleWorkReport = async (row: GetReportWorkModel) => {
  const $grid = workReportGridRef.value
  if ($grid) {
    const editRecord = $grid.getEditRecord()
    if (editRecord) {
      const { row } = editRecord
      await $grid.revertData(row)
    }
    if (row.scheduleType === 2) {
      row.workTime = [
        dayjs().format('YYYY/MM/DD') + ' ' + row.startTime,
        dayjs().format('YYYY/MM/DD') + ' ' + row.endTime
      ]
    }
    $grid.setEditRow(row)
    const { data } = await getReportWorkDetail({
      dispatchingEmployeeID: row.dispatchingEmployeeID,
      employeeInfoID: row.employeeInfoID,
      reportWorkID: row.id
    })
    reportWorkDetail.value = data

    getReportWorkProjectDetailOptions(unref(row)?.employeeInfoID!)
  }
}

const reloadData = () => {
  workReportGridRef.value?.commitProxy('reload')
  getReportWorkEmployeeOptions()
}

const removeData = () => {
  workReportGridRef.value?.remove()
}

watch(activeRow, () => {
  reloadData()
})

defineExpose({
  reloadData,
  removeData
})
</script>

<style lang="scss" scoped></style>
