<template>
  <BasicModal
    width="80%"
    v-bind="$attrs"
    @register="registerModal"
    title="其他报工"
    :showCancelBtn="false"
    :showConfirmBtn="false"
  >
    <BasicForm @register="registerForm">
      <template #formFooter>
        <el-button style="margin-left: 8px" type="primary" @click="handleSearch">查询</el-button>
      </template>
    </BasicForm>
    <vxe-grid ref="otherReportGridRef" v-bind="otherReportGridOptions">
      <template #operation="{ row }">
        <TableAction
          :actions="[
            {
              icon: 'work-report',
              tooltip: '报工',
              onClick: handleWorkReport.bind(null, row),
              ifShow: !hasActiveEditRow(row, otherReportGridRef) && row.id === '0'
            },
            {
              icon: 'edit-inline',
              tooltip: '编辑',
              onClick: handleWorkReport.bind(null, row),
              ifShow: !hasActiveEditRow(row, otherReportGridRef) && row.id !== '0'
            },
            {
              icon: 'save',
              tooltip: '保存',
              onClick: handleConfirm.bind(null, row, otherReportGridRef),
              ifShow: hasActiveEditRow(row, otherReportGridRef)
            },
            {
              icon: 'cancle',
              tooltip: '取消',
              onClick: handleCancle.bind(null, row, otherReportGridRef),
              ifShow: hasActiveEditRow(row, otherReportGridRef)
            },
            {
              icon: 'finish-wo-status',
              tooltip: '组长确认',
              onClick: handleGroupLeaderConfirm.bind(null, row),
              ifShow: () => row.orderStatus === 1
            },
            {
              icon: 'close-wo-status',
              tooltip: '作废',
              onClick: handleCancel.bind(null, row),
              ifShow: function () {
                return [1, 2].includes(row.orderStatus)
              }
            }
          ]"
        />
      </template>

      <template #bottom>
        <TableAction
          style="margin-top: 16px"
          :actions="[
            {
              icon: 'plus',
              label: '新增行',
              onClick: handleAdd.bind(null),
              style: {
                color: '#008cd6'
              }
            }
          ]"
        ></TableAction>
      </template>
    </vxe-grid>
  </BasicModal>
  <GroupLeaderConfirmDialog
    @register="registerGroupLeaderConfirmModal"
    @success="handleGroupLeaderConfirmSuccess"
  />
</template>

<script lang="tsx" setup>
import type { VxeGridInstance, VxeGridProps } from 'vxe-table'
import type { SelectModel } from '@/api/model/baseModel'
import type { GetOtherReportWorkModel, GetOtherReportWorkParams } from '@/api/sys/model/workModel'
import type { GetEmployeeInfoModel, GetScheduleModel } from '@/api/sys/model/basicModel'

import { reactive, ref, toRefs, unref, watch, nextTick, computed } from 'vue'
import dayjs from 'dayjs'
import { ElInput, ElInputNumber, ElTimePicker } from 'element-plus'
import Select from '@/components/Form/components/Select.vue'
import PersonSelect from '@/components/Form/components/PersonSelect/index.vue'
import GroupLeaderConfirmDialog from './GroupLeaderConfirmDialog.vue'
import { useModal, useModalInner } from '@/components/Modal/hooks/useModal'
import { useForm } from '@/components/Form/hooks/useForm'
import { isNumber } from '@/utils/is'
import { otherReportWorkTypeOptions, scheduleTypeOptions } from '../data'

import { getGroupSelect, getManufactureDepartmentList, getScheduleSelectALL } from '@/api/sys/basic'
import {
  addOtherReportWork,
  getEmployeeStatus,
  getOtherReportWork,
  updateOtherReportWork,
  updateReportWorkState
} from '@/api/sys/work'

const props = defineProps({
  activeRow: {
    type: Object,
    default: () => {
      return {}
    }
  }
})
const { activeRow } = toRefs(props)
const params = reactive({
  departmentID: '',
  groupID: ''
})

const [registerModal, { closeModal, setModalProps, changeOkLoading }] = useModalInner(
  async (data) => {
    setModalProps({ confirmLoading: false })

    setFieldsValue({ ...data })
    params.departmentID = data.departmentID
    params.groupID = data.groupID

    nextTick(() => {
      otherReportGridRef.value?.remove()
    })
  }
)

const [registerForm, { setFieldsValue, resetFields, getFieldsValue, validate, updateSchema }] =
  useForm({
    labelWidth: 120,
    schemas: [
      {
        field: 'departmentID',
        component: 'ApiSelect',
        label: '生产部门',
        componentProps({ formActionType, formModel }) {
          return {
            api: getManufactureDepartmentList,
            resultField: 'data',
            labelField: 'name',
            valueField: 'id',
            filterable: true,
            async onChange(value: string) {
              params.departmentID = value
              formModel.groupID = undefined
              let options: SelectModel[] = []
              if (!(value === '')) {
                const { data } = await getGroupSelect({ departmentID: value })
                options = data.result
              }
              const { updateSchema } = formActionType
              updateSchema({
                field: 'groupID',
                componentProps: {
                  options: options
                }
              })
            }
          }
        },
        colProps: {
          span: 6
        }
      },
      {
        field: 'groupID',
        component: 'Select',
        label: '所属组别',
        componentProps: {
          options: [],
          onChange(value: string) {
            params.groupID = value
          }
        },
        colProps: {
          span: 6
        }
      },
      {
        field: 'reportWorkTime',
        component: 'ElDatePicker',
        label: '报工时间',
        defaultValue: dayjs().format('YYYY-MM-DD'),
        componentProps: {
          valueFormat: 'YYYY-MM-DD'
        },
        colProps: {
          span: 6
        }
      }
    ]
  })
// 处理查询
const handleSearch = () => {
  reloadData()
}

// 作业班次
const scheduleOptions = ref<GetScheduleModel[]>([])
const getScheduleOptions = async () => {
  const { data } = await getScheduleSelectALL()
  scheduleOptions.value = data.result
}
getScheduleOptions()
// 处理员工选择确定
const handlePersonConfirm = async (data: GetEmployeeInfoModel, row: GetOtherReportWorkModel) => {
  row.employeeName = data.employeeName
  const { data: employeeStatusData } = await getEmployeeStatus({
    employeeInfoId: row.employeeInfoID!,
    reportWorkTime: getFieldsValue().reportWorkTime
  })

  row.attendanceStatus = employeeStatusData.attendanceStatus
  row.attendanceStatusName = employeeStatusData.attendanceStatusName
  row.transferInStatus = employeeStatusData.transferInStatus
  row.transferInStatusName = employeeStatusData.transferInStatusName
}

const getDispatchOrderStatusInfo = computed(() => {
  const statusMap: { [key: number]: { text: string; type: string } } = {
    0: { text: '未报工', type: 'warning' },
    1: { text: '未确认', type: 'warning' },
    2: { text: '已确认', type: 'warning' },
    4: { text: '无需报工', type: 'info' }
  }

  return function (status: number) {
    return statusMap[status] || { text: '', color: '' }
  }
})

// 处理休息时间改变
const handleRestTimeChange = (row: GetOtherReportWorkModel, restTime?: number) => {
  const { workTime, scheduleType } = row
  if (scheduleType === 2 && workTime) {
    if (isNumber(restTime) && workTime) {
      const takeTime = Number(
        (
          Math.abs(
            Number((dayjs(workTime[0]).diff(dayjs(workTime[1]), 'minute') / 60).toFixed(1))
          ) - restTime
        ).toFixed(1)
      )
      row.takeTime = takeTime
    } else {
      row.takeTime = 0
    }
  }
}

/**
 * 其他报工
 */
const otherReportGridRef = ref<VxeGridInstance>()
const otherReportGridOptions = reactive<VxeGridProps<GetOtherReportWorkModel>>({
  border: true,
  height: '400px',
  align: null,
  keepSource: true,
  editConfig: {
    trigger: 'manual',
    mode: 'row',
    showStatus: true,
    autoClear: false,
    showUpdateStatus: true
  },
  editRules: {
    employeeInfoID: [{ required: true, message: '请选择作业者' }],
    workType: [{ required: true, message: '请选择工作类别' }],
    scheduleType: [{ required: true, message: '请选择班次类型' }],
    scheduleId: [
      {
        required: true,
        validator({ row }) {
          if (
            (!row.scheduleID && row.scheduleType === 1) ||
            (row.workTime?.length === 0 && row.scheduleType === 2)
          ) {
            return new Error('请选择班次')
          }
        }
      }
    ]
  },
  columnConfig: {
    resizable: true
  },
  columns: [
    { type: 'seq', width: 50 },
    {
      field: 'employeeInfoID',
      title: '作业者',
      minWidth: 120,
      editRender: {},
      slots: {
        default({ row }) {
          return (
            <div>
              {row.employeeNo}-{row.employeeName}
            </div>
          )
        },
        edit({ row }) {
          return (
            <PersonSelect
              v-model={row.employeeInfoID}
              employeeName={row.employeeName}
              departmentID={params?.departmentID}
              groupID={params?.groupID}
              onConfirm={(data: GetEmployeeInfoModel) => handlePersonConfirm(data, row)}
              onClear="row.employeeInfoName = ''"
            ></PersonSelect>
            // <Select
            //   style={'width: 100%'}
            //   v-model={row.employeeInfoId}
            //   options={reportWorkEmployeeOptions.value}
            //   labelField={'employeeName'}
            //   valueField={'id'}
            //   onChange={(id: string) => {
            //     if (id) {
            //       getReportWorkProjectDetailOptions(id)
            //     }
            //   }}
            // >
            //   {{
            //     default: ({ option }: { option: any }) => (
            //       <>
            //         <span style="float: left">{option.employeeNo}</span>
            //         <span
            //           style="
            //           float: right;
            //           font-size: 13px;
            //         "
            //         >
            //           {option.employeeName}
            //         </span>
            //       </>
            //     )
            //   }}
            // </Select>
          )
        }
      }
    },
    {
      field: 'orderStatus', //2：请假；3：休息；4：离职；6：缺勤；8：旷工 禁用其他配置项
      title: '状态',
      width: 130,
      slots: {
        default({ row }) {
          return (
            <div style="display: flex; align-items: center">
              {row.transferInStatus === 1 && row.attendanceStatus === 1 && (
                <el-tag type="warning" size="small" effect="plain" style="margin-left: 5px">
                  {/* 借调 */}
                  {row.transferInStatusName}
                </el-tag>
              )}

              {/* : (
                <>
                  {isDef(row.transferInStatus) && (
                    <el-tag type="info" size="small" effect="plain" style="margin-left: 5px">
                      {row.transferInStatusName}
                    </el-tag>
                  )}
                </>
              ) */}

              {[2, 3, 4, 6, 8].includes(row.attendanceStatus) && (
                <el-tag type="warning" size="small" effect="plain" style="margin-left: 5px">
                  {/* {attendanceStatusMap[row.attendanceStatus]} */}
                  {row.attendanceStatusName}
                </el-tag>
              )}
              {/* : (
                <>
                  {isDef(row.attendanceStatus) && (
                    <el-tag type="info" size="small" effect="plain" style="margin-left: 5px">
                      {row.attendanceStatusName}
                    </el-tag>
                  )}
                </>
              ) */}

              {/* 报工单状态（0：未报工；1：未确认；2：已确认；4：无需报工） */}
              {[0, 1, 2, 4].includes(row.orderStatus) && (
                <el-tag
                  style="margin-left: 5px"
                  type={getDispatchOrderStatusInfo.value(row.orderStatus).type}
                >
                  {getDispatchOrderStatusInfo.value(row.orderStatus).text}
                </el-tag>
              )}
            </div>
          )
        }
      }
    },
    {
      field: 'workType',
      title: '工作类别',
      width: 150,
      editRender: {},
      slots: {
        default({ row }) {
          return otherReportWorkTypeOptions.find((option) => option.value === row.workType)?.label
        },
        edit({ row }) {
          return (
            <Select
              style={'width: 100%'}
              v-model={row.workType}
              options={otherReportWorkTypeOptions}
              disabled={[2, 3, 4, 6, 8].includes(row.attendanceStatus)}
            ></Select>
          )
        }
      }
    },
    {
      field: 'scheduleType',
      title: '班次类型',
      width: 120,
      editRender: {},
      slots: {
        default({ row }) {
          return scheduleTypeOptions.find((option) => option.value === row.scheduleType)?.label
        },
        edit({ row }) {
          return (
            <>
              <Select
                style={'width: 100%'}
                v-model={row.scheduleType}
                options={scheduleTypeOptions}
                onChange={() => {
                  row.scheduleID = undefined
                  row.workTime = []
                  row.restTime = 0
                  row.takeTime = 0
                }}
                disabled={[2, 3, 4, 6, 8].includes(row.attendanceStatus)}
              ></Select>
            </>
          )
        }
      }
    },
    {
      field: 'scheduleId',
      title: '作业班次',
      width: 180,
      editRender: {},
      slots: {
        default({ row }) {
          return (
            unref(scheduleOptions).find((option) => option.value === row.scheduleType)?.label ||
            row.startTime + '-' + row.endTime
          )
        },
        edit({ row }) {
          return (
            <>
              {row.scheduleType === 1 ? (
                <Select
                  style={'width: 100%'}
                  v-if={row.scheduleType === 1}
                  v-model={row.scheduleID}
                  options={scheduleOptions.value}
                  labelField={'scheduleTime'}
                  valueField={'id'}
                  onChange={(value: number, option: any) => {
                    if (option) {
                      row.takeTime = option.workTime
                      row.restTime = option.restTime
                    }
                  }}
                  slots={{
                    default: ({ option }: { option: any }) => {
                      return <>{option.scheduleTime}</>
                    }
                  }}
                  disabled={[2, 3, 4, 6, 8].includes(row.attendanceStatus)}
                ></Select>
              ) : (
                <ElTimePicker
                  v-model={row.workTime}
                  style={'width: 100%'}
                  type={'daterange'}
                  format={'HH:mm'}
                  isRange={true}
                  onChange={(value: [string, string]) => {
                    /**
                     * 处理自定义班次计算
                     */
                    const { restTime } = row
                    if (value) {
                      row.startTime = dayjs(value[0]).format('HH:mm')
                      row.endTime = dayjs(value[1]).format('HH:mm')
                      if (isNumber(restTime)) {
                        const takeTime = Number(
                          (
                            Math.abs(
                              Number(
                                (dayjs(value[0]).diff(dayjs(value[1]), 'minute') / 60).toFixed(1)
                              )
                            ) - restTime
                          ).toFixed(1)
                        )
                        row.takeTime = takeTime
                      } else {
                        row.takeTime = undefined
                      }
                    }
                  }}
                  disabled={[2, 3, 4, 6, 8].includes(row.attendanceStatus)}
                ></ElTimePicker>
              )}
            </>
          )
        }
      }
    },
    {
      field: 'restTime',
      title: '休息用时(h)',
      width: 130,
      editRender: {},
      slots: {
        default({ row }) {
          return typeof row.restTime === 'number'  ? `${row.restTime}h` : ''
        },
        edit({ row }) {
          return (
            <>
              <ElInputNumber
                style={'width: 100%'}
                v-model={row.restTime}
                disabled={row.scheduleType === 1 || [2, 3, 4, 6, 8].includes(row.attendanceStatus)}
                onChange={(value: number) => {
                  handleRestTimeChange(row, value)
                }}
              ></ElInputNumber>
            </>
          )
        }
      }
    },
    {
      field: 'workDescription',
      title: '工作描述',
      width: 130,
      editRender: {},
      slots: {
        edit({ row }) {
          return (
            <>
              <ElInput style={'width: 100%'} v-model={row.workDescription}></ElInput>
            </>
          )
        }
      }
    },
    {
      field: 'takeTime',
      title: '作业用时(h)',
      width: 125,
      formatter({ cellValue }) {
        return typeof cellValue === 'number' ? `${cellValue}h` : ''
      }
    },
    { field: 'createUserName', title: '录入人', width: 100 },

    {
      field: 'operation',
      title: '操作',
      align: 'center',
      fixed: 'right',
      width: 200,
      slots: {
        default: 'operation'
      }
    }
  ],
  pagerConfig: {
    enabled: false,
    pageSize: 20
  },
  proxyConfig: {
    autoLoad: false,
    ajax: {
      query: () => {
        return new Promise((resovle) => {
          const filedsValue = getFieldsValue() as GetOtherReportWorkParams
          getOtherReportWork({
            pageIndex: 0,
            pageSize: 99999,
            ...params,
            ...filedsValue
          }).then((res) => {
            resovle(res.data)
          })
        })
      }
    }
  }
})

// 判断是否编辑活跃行
const hasActiveEditRow = (row: GetOtherReportWorkModel, $grid?: VxeGridInstance): boolean => {
  if ($grid) {
    return $grid.isEditByRow(row)
  }
  return false
}
// 处理完成
const handleConfirm = async (row: GetOtherReportWorkModel, $grid?: VxeGridInstance) => {
  if ([2, 3, 4, 6, 8].includes(row.attendanceStatus)) {
    return ElMessage.error(
      `${row.employeeNo}-${row.employeeName} ${getFieldsValue().reportWorkTime} ${
        row.attendanceStatusName
      },无需报工`
    )
  }
  if ($grid) {
    const errMap = await $grid.validate(row)
    if (!errMap) {
      // 校验失败

      // const $grid = workPlanGridRef.value
      const insertRecords = $grid.getInsertRecords()
      const updateRecords = $grid.getUpdateRecords()

      const filedsValue = getFieldsValue()

      // 后端逻辑让使用'0'判断是否为新增报工
      if (row.id === '0' || insertRecords.length) {
        const addRow = insertRecords[0] || updateRecords[0]

        const { code, message } = await addOtherReportWork({
          ...addRow,
          reportWorkTime: filedsValue.reportWorkTime
        })

        if (code === 200) {
          ElMessage.success('新增成功')
          await $grid.clearEdit()
          otherReportGridRef.value?.commitProxy('reload')
        } else {
          ElMessage.error(message)
        }
      } else if (row.id !== '0' && updateRecords.length) {
        const updateRow = updateRecords[0]

        const { code, message } = await updateOtherReportWork({
          ...updateRow,
          reportWorkTime: filedsValue.reportWorkTime
        })

        if (code === 200) {
          ElMessage.success('修改成功')
          await $grid.clearEdit()
          otherReportGridRef.value?.commitProxy('reload')
        } else {
          ElMessage.error(message)
        }
      }
    }
  }
}
// 处理取消
const handleCancle = (row: GetOtherReportWorkModel, $grid?: VxeGridInstance) => {
  $grid?.commitProxy('reload')
}

const [registerGroupLeaderConfirmModal, { openModal: openGroupLeaderConfirmModal }] = useModal()
// 组长确认
const handleGroupLeaderConfirm = async (row: GetOtherReportWorkModel) => {
  openGroupLeaderConfirmModal(true, {
    row,
    isOtherReport: true
  })
}
// 组长确认成功回调
const handleGroupLeaderConfirmSuccess = () => {
  otherReportGridRef.value?.commitProxy('reload')
}

// 作废
const handleCancel = (row: GetOtherReportWorkModel) => {
  ElMessageBox.confirm(
    `是否作废名称为"${row.employeeNo + '-' + row.employeeName}"的数据项?`,
    '警告',
    {
      confirmButtonText: '确定',
      cancelButtonText: '取消',
      type: 'warning'
    }
  )
    .then(async () => {
      const { status, message } = await updateReportWorkState({
        id: row.id!,
        orderStatus: 3
      })
      if (status) {
        ElMessage.success('作废成功')
      } else {
        ElMessage.error(message)
      }
    })
    .catch(() => {})
    .finally(() => {
      otherReportGridRef.value?.commitProxy('reload')
    })
}

// 新增报工单
const handleAdd = async () => {
  const $grid = otherReportGridRef.value
  if ($grid) {
    const { row: newRow } = await $grid.insertAt(
      {
        workType: 6,
        scheduleType: 1,
        isAdd: true
      },
      -1
    )

    await $grid.setEditRow(newRow)
  }
}

// 报工
const handleWorkReport = async (row: GetOtherReportWorkModel) => {
  const $grid = otherReportGridRef.value
  if ($grid) {
    const editRecord = $grid.getEditRecord()
    if (editRecord) {
      const { row } = editRecord
      await $grid.revertData(row)
    }
    if (row.scheduleType === 2) {
      row.workTime = [
        dayjs().format('YYYY/MM/DD') + ' ' + row.startTime,
        dayjs().format('YYYY/MM/DD') + ' ' + row.endTime
      ]
    }
    $grid.setEditRow(row)
    // getReportWorkDetail({
    //   dispatchingEmployeeID: row.dispatchingEmployeeID,
    //   employeeInfoID: row.employeeInfoID,
    //   reportWorkID: row.id
    // })
    // getReportWorkProjectDetailOptions(unref(row)?.employeeInfoID!)
  }
}

const reloadData = () => {
  otherReportGridRef.value?.commitProxy('reload')
}

watch(activeRow, () => {
  reloadData()
})

defineExpose({
  reloadData
})
</script>

<style lang="scss" scoped></style>
