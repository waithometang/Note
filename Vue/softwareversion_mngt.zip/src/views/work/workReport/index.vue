<template>
  <LayoutContainer>
    <template #leftSide>
      <basic-tree class="basic-list-wrapper" ref="basicTreeRef" v-bind="treeOptions" />
    </template>

    <el-scrollbar class="table-wrapper">
      <div class="grid-container">
        <vxe-grid ref="gridRef" class="box" v-bind="gridOptions" v-on="gridEvents">
          <template #top>
            <GridHeader ref="gridHeaderRef" v-bind="headerOptions" v-on="headerEvent">
              <!-- <template #appendOperation>
                <el-button size="large" @click="handleOtherReport">其他报工</el-button>
              </template> -->
            </GridHeader>
          </template>
          <template #orderSchedule="{ row }">
            <el-progress :stroke-width="12" :percentage="row.orderSchedule" />
          </template>
          <template #orderStatus="{ row }">
            <el-tag :type="getOrderStatus(row.orderStatus)?.type">
              {{ getOrderStatus(row.orderStatus)?.label }}
            </el-tag>
          </template>
        </vxe-grid>

        <div class="box child-grid-container">
          <WorkReportGrid
            ref="workReportGridRef"
            :activeRow="activeRow"
            :isConfirmStatus="isConfirmStatus"
          />
        </div>
      </div>
    </el-scrollbar>

    <OtherReportGridDialog @register="registerModal" @success="handleSuccess" />
  </LayoutContainer>
</template>

<script lang="tsx" setup>
import type { ComponentExposed } from 'vue-component-type-helpers'
import type { GridHeaderEvent, GridHeaderProps } from '@/components/Table/types/gridHeader'
import type { VxeGridInstance, VxeGridListeners, VxeGridProps } from 'vxe-table'
import type { GetDispatchingOrderParams, GetReportWorkModel } from '@/api/sys/model/workModel'
import type { TreeProps } from '@/components/Tree/types/tree'

import { reactive, ref, computed, unref } from 'vue'
import dayjs from 'dayjs'

import BasicTree from '@/components/Tree/BasicTree.vue'
import GridHeader from '@/components/Table/GridHeader.vue'
import WorkReportGrid from './components/WorkReportGrid.vue'
import OtherReportGridDialog from './components/OtherReportGridDialog.vue'
import { useModal } from '@/components/Modal/hooks/useModal'
import { orderStatusOptions } from './data'

import { getProductionProjectAppointData } from '@/api/sys/scheduling'
import {
  getGroupSelect,
  getManufactureDepartment,
  getManufactureDepartmentList,
  getProductionProjectSelect
} from '@/api/sys/basic'
import { getDispatchingOrder, exportReportWork, exportReportWorkScheduling } from '@/api/sys/work'
import { useForm } from '@/components/Form/hooks/useForm'
import { EXPORT_TYPE, exportTypeList } from './data'
import { downloadByApi } from '@/utils/download'

const treeParams = reactive({
  departmentID: '',
  groupID: ''
})
const basicTreeRef = ref<InstanceType<typeof BasicTree>>()
// 列表配置
const treeOptions = reactive<TreeProps>({
  api: getManufactureDepartment,
  title: '部门列表',
  labelField: 'name',
  resultField: 'data',
  childrenField: 'children',
  nodeKey: 'id',
  accordion: true,
  formatter({ data }) {
    return (
      <div>
        {data.label}&nbsp;&nbsp;({data.childrenCount})
      </div>
    )
  },
  cancleHightlightCurrent: true,
  onSelect: async (data, node) => {
    if (data) {
      headerOptions.title = `[${data.label}] 生产任务`

      if (data.isGroup) {
        treeParams.departmentID = node.parent.data.id
        treeParams.groupID = data.id
      } else {
        treeParams.departmentID = data.id
        treeParams.groupID = ''
      }
      gridRef.value?.commitProxy('reload')
    } else {
      headerOptions.title = `生产任务`
      treeParams.departmentID = ''
      treeParams.groupID = ''
      gridRef.value?.remove()
    }

    workReportGridRef.value?.removeData()
  }
})

const gridHeaderRef = ref<ComponentExposed<typeof GridHeader<GetDispatchingOrderParams, 'woNo'>>>()

const headerOptions = reactive<GridHeaderProps>({
  title: '生产任务',
  quickSearch: {
    singleSearch: {
      field: 'woNo',
      type: 'input',
      title: '单据编号/母件编码'
    },
    searchFormFields: { woNo: '' }
  },
  advancedSearch: {
    labelWidth: 120,
    fieldMapToTime: [['dataOfCreate', ['startDataOfCreate', 'endDataOfCreate'], 'YYYY-MM-DD']],
    schemas: [
      {
        field: 'projectID',
        component: 'ApiSelect',
        label: '项目名称',
        componentProps({ formActionType, formModel }) {
          return {
            api: getProductionProjectSelect,
            labelField: 'projectName',
            valueField: 'id',
            resultField: 'data.result',
            filterable: true,
            async onChange(value: string) {
              formModel.orderNo = undefined
              formModel.productName = undefined

              const { updateSchema } = formActionType
              const { data } = await getProductionProjectAppointData({ projectID: value })

              updateSchema({
                field: 'orderNo',
                componentProps: {
                  options: data.result
                }
              })

              updateSchema({
                field: 'productName',
                componentProps: {
                  options: data.result
                }
              })
            }
          }
        },
        colProps: {
          span: 8
        }
      },

      {
        field: 'orderNo',
        component: 'Select',
        label: '需求分类',
        componentProps: {
          options: [],
          // defaultSelectFirst: true,
          labelField: 'orderNo',
          valueField: 'orderNo',
          filterable: true
        },
        colProps: {
          span: 8
        }
      },

      {
        field: 'productName',
        component: 'Select',
        label: '部件名称',
        componentProps: {
          options: [],
          labelField: 'productName',
          valueField: 'productName',
          filterable: true
        },
        colProps: {
          span: 8
        }
      },
      {
        field: 'orderStatus',
        component: 'Select',
        label: '工单状态',
        defaultValue: [0, 1],
        componentProps: {
          options: orderStatusOptions,
          multiple: true
        },
        colProps: {
          span: 8
        }
      },
      {
        field: 'isConfirmStatus',
        component: 'ElCheckbox',
        label: '只显示未确认报工',
        labelWidth: 150,
        componentProps: {},
        colProps: {
          span: 8
        }
      }
    ]
  },
  showAddButton: false,
  showExportButton: true,
  customExport: true
  // exportApi: exportReportWork,
  // exportParams: computed(() => {
  //   const quickSearchForm = unref(gridHeaderRef.value?.quickSearchForm)
  //   const advancedSearchForm = unref(gridHeaderRef.value?.advancedSearchForm)
  //   const departmentId = advancedSearchForm?.departmentId ?? treeParams.departmentId
  //   const groupId = advancedSearchForm?.groupId ?? treeParams.groupId

  //   return { ...quickSearchForm, ...advancedSearchForm, departmentId, groupId }
  // })
})

const headerEvent: GridHeaderEvent = {
  quickSearch() {
    gridRef.value?.commitProxy('reload')
    workReportGridRef.value?.removeData()
  },
  advancedSearch() {
    gridRef.value?.commitProxy('reload')
    workReportGridRef.value?.removeData()
  },
  reset() {
    gridRef.value?.commitProxy('reload')
    workReportGridRef.value?.removeData()
  },
  exportClick() {
    handleExportClick()
  }
}

const gridRef = ref<VxeGridInstance>()
const gridOptions = reactive<VxeGridProps<GetReportWorkModel>>({
  border: true,
  height: '400px',
  align: null,
  columnConfig: {
    resizable: true
  },
  columns: [
    { type: 'seq', width: 50 },
    { field: 'projectName', title: '项目名称', width: 100 },
    { field: 'sonProcessName', title: '工序任务', minWidth: 100 },
    // { field: 'orderNo', title: '需求分类', minWidth: 150 },
    { field: 'woNo', title: '单据编号', minWidth: 150 },
    { field: 'materialNo', title: '母件编码', minWidth: 150 },
    { field: 'productName', title: '部件名称', minWidth: 180 },
    {
      field: 'startDate',
      title: '计划日期',
      width: 100,
      formatter({ cellValue }) {
        return dayjs(cellValue).format('YYYY-MM-DD')
      }
    },
    { field: 'dispatchingNumber', title: '派工数量', width: 100 },
    { field: 'sumFinishCount', title: '完成数量', width: 100 },
    {
      field: 'finishPercent',
      title: '完成率',
      width: 100,
      slots: {
        default({ row }) {
          return row.finishPercent + '%'
        }
      }
    },
    {
      field: 'sumTakeTime',
      title: '累计用时',
      width: 100,
      formatter({ cellValue }) {
        return typeof cellValue === 'number' ? `${cellValue}h` : ''
      }
    },
    {
      field: 'orderStatus',
      title: '派工单状态',
      width: 100,
      slots: {
        default({ row }) {
          return (
            <>
              <el-tag type={getDispatchOrderStatusInfo.value(row.orderStatus).type}>
                {getDispatchOrderStatusInfo.value(row.orderStatus).text}
              </el-tag>
            </>
          )
        }
      }
    }
  ],
  pagerConfig: {
    enabled: true,
    pageSize: 20
  },
  proxyConfig: {
    autoLoad: false,
    ajax: {
      query: ({ page }) => {
        const quickSearchForm = unref(gridHeaderRef.value?.quickSearchForm)
        const advancedSearchForm = unref(gridHeaderRef.value?.advancedSearchForm)

        return getDispatchingOrder({
          pageIndex: page.currentPage - 1, // 由于后端接口限制，首页从0开始
          pageSize: page.pageSize,
          ...treeParams,
          ...quickSearchForm,
          ...advancedSearchForm
        })
      }
    }
  }
})

const getDispatchOrderStatusInfo = computed(() => {
  const statusMap: { [key: number]: { text: string; type: string } } = {}

  orderStatusOptions.forEach((item) => {
    statusMap[item.value] = { text: item.label, type: item.tagType }
  })

  return function (status: number) {
    return statusMap[status] || { text: '', color: '' }
  }
})

const getOrderStatus = (orderStatus: number) => {
  return orderStatusOptions.find((option) => option.value === orderStatus)
}

const activeRow = ref<GetReportWorkModel>()
const isConfirmStatus = ref<boolean>()
const gridEvents: VxeGridListeners<GetReportWorkModel> = {
  cellClick({ row }) {
    activeRow.value = row
    isConfirmStatus.value = unref(gridHeaderRef.value?.advancedSearchForm)?.isConfirmStatus
  }
}

const workReportGridRef = ref()

const [registerModal, { openModal, setModalProps, closeModal }] = useModal()

const handleSuccess = () => {}

const handleOtherReport = () => {
  openModal(true, {
    ...treeParams
  })
}

const [registerForm, { getFieldsValue, validate, updateSchema, setFieldsValue }] = useForm({
  labelWidth: 100,
  // fieldMapToTime: [
  //   ['DispatchingDate', ['DispatchingStartDate', 'DispatchingEndDate'], 'YYYY-MM-DD']
  // ],
  schemas: [
    {
      field: 'exportType',
      component: 'Select',
      label: '导出类型',
      required: true,
      defaultValue: EXPORT_TYPE.WORK_REPORT_TYPE,
      componentProps: {
        clearable: false,
        options: exportTypeList,
        async onChange(value: number) {
          if (value === EXPORT_TYPE.PLAN_ACTUAL_ACHIEVEMENT_TYPE) {
            setFieldsValue({ DispatchingDate: dayjs().format('YYYY-MM-DD') })
          }
        }
      },
      colProps: {
        span: 23
      }
    },
    {
      field: 'DispatchingDate',
      component: 'ElDatePicker',
      label: '日期',
      required: true,
      ifShow({ model }) {
        return model['exportType'] === EXPORT_TYPE.PLAN_ACTUAL_ACHIEVEMENT_TYPE
      },
      componentProps: {
        type: 'date',
        valueFormat: 'YYYY-MM-DD'
      },
      colProps: {
        span: 23
      }
    },
    {
      field: 'DepartmentID',
      component: 'ApiSelect',
      label: '部门',
      required: true,
      ifShow({ model }) {
        return model['exportType'] !== EXPORT_TYPE.WORK_REPORT_TYPE
      },
      componentProps: {
        api: getManufactureDepartmentList,
        resultField: 'data',
        labelField: 'name',
        valueField: 'id',
        async onChange(departmentID: string) {
          await setFieldsValue({ GroupID: void 0 })
          await updateSchema({ field: 'GroupID', componentProps: { options: [] } })

          if (departmentID) {
            getGroupSelect({ departmentID }).then(({ code, data }) => {
              if (code === 200) {
                updateSchema({ field: 'GroupID', componentProps: { options: data.result } })
              }
            })
          }
        }
      },
      colProps: {
        span: 23
      }
    },
    {
      field: 'GroupID',
      component: 'Select',
      label: '组别',
      required: true,
      ifShow({ model }) {
        return model['exportType'] !== EXPORT_TYPE.WORK_REPORT_TYPE
      },
      componentProps: {
        options: []
      },
      colProps: {
        span: 23
      }
    }
  ]
})

const handleExportClick = () => {
  ElMessageBox({
    title: '导出',
    showCancelButton: true,
    message: () => {
      return <basic-form onRegister={registerForm} />
    },
    beforeClose: async (action, instance, done) => {
      if (action === 'confirm') {
        await validate(async (isValid) => {
          const fieldsValue = getFieldsValue()

          if (isValid) {
            const loading = ElLoading.service({
              lock: true,
              text: 'Loading',
              background: 'rgba(0, 0, 0, 0.7)'
            })
            try {
              if (fieldsValue.exportType === EXPORT_TYPE.WORK_REPORT_TYPE) {
                const quickSearchForm = unref(gridHeaderRef.value?.quickSearchForm)
                const advancedSearchForm = unref(gridHeaderRef.value?.advancedSearchForm)
                const departmentID = advancedSearchForm?.departmentID ?? treeParams.departmentID
                const groupID = advancedSearchForm?.groupID ?? treeParams.groupID
                await downloadByApi(exportReportWork, {
                  ...quickSearchForm,
                  ...advancedSearchForm,
                  departmentID,
                  groupID
                })
              } else if (fieldsValue.exportType === EXPORT_TYPE.PLAN_ACTUAL_ACHIEVEMENT_TYPE) {
                await downloadByApi(exportReportWorkScheduling, {
                  DepartmentID: fieldsValue.DepartmentID,
                  GroupID: fieldsValue.GroupID,
                  SchedulingDate: fieldsValue.DispatchingDate
                })
              }

              ElMessage.success('导出成功')
              done()
            } catch (e: any) {
              ElMessage.error(e.message)
            } finally {
              loading.close()
            }
          }
        })
      }

      if (action === 'cancel') {
        done()
      }
    }
  })
}
</script>

<style lang="scss" scoped>
.table-wrapper {
  flex: 1;

  .grid-container {
    margin: $margin $margin $margin 0;

    display: flex;
    flex-direction: column;
    .vxe-grid:last-child {
      margin-top: $margin;
    }

    .child-grid-container {
      margin-top: $margin;

      .tabs-container {
        position: relative;

        .report-time-container {
          z-index: 1;
          position: absolute;
          line-height: 40px;
          right: 20px;
          top: 0;
        }

        :deep(.el-tabs) {
          .el-tabs__header {
            .el-tabs__nav-wrap::after {
              height: 0;
            }
          }
        }
      }
    }
  }
}
</style>
