export const workTypeOptions = [
  { label: '正常工时', value: 1 },
  { label: '设计变更', value: 2 },
  { label: '来料不良', value: 3 },
  { label: '培训', value: 4 },
  { label: '6S', value: 5 },
  { label: '其他', value: 6 }
]
export const orderStatusOptions = [
  { label: '未报工', value: 0, type: 'info' },
  { label: '未确认', value: 1, type: 'warning' },
  { label: '已确认', value: 2, type: 'success' },
  { label: '已作废', value: 3, type: 'danger' }
]
