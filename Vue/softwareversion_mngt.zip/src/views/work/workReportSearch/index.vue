<template>
  <LayoutContainer>
    <template #leftSide>
      <basic-tree class="basic-list-wrapper" ref="basicTreeRef" v-bind="treeOptions" />
    </template>
    <div class="grid-container">
      <vxe-grid class="box" ref="gridRef" v-bind="gridOptions">
        <template #top>
          <GridHeader
            ref="gridHeaderRef"
            v-bind="headerOptions"
            @quickSearch="handleQuickSearch"
            @advancedSearch="handleAdvancedSearch"
            @reset="handleReset"
          >
          </GridHeader>
        </template>
        <template #employeeName="{ row }">
          <div style="display: flex; align-items: center">
            <div>{{ row.employeeNo }}-{{ row.employeeName }}</div>
            <el-tag
              :type="
                row.attendanceStatus === 0
                  ? 'info'
                  : row.attendanceStatus === 1
                  ? 'success'
                  : 'warning'
              "
              size="small"
              effect="plain"
              style="margin-left: 5px"
              >{{ row.attendanceStatusName }}</el-tag
            >
            <el-tag
              v-if="row.transferInStatus === 1"
              type="warning"
              size="small"
              effect="plain"
              style="margin-left: 5px"
              >借调</el-tag
            >
          </div>
        </template>
        <template #sumFinishPercent="{ row }">
          <el-progress
            v-if="row.sumFinishPercent !== null"
            :stroke-width="12"
            :percentage="row.sumFinishPercent"
            :status="row.sumFinishPercent >= 100 ? 'success' : ''"
          />
        </template>
        <template #orderStatus="{ row }">
          <el-tag :type="getOrderStatusInfo(row.orderStatus).type">
            {{ getOrderStatusInfo(row.orderStatus).text }}
          </el-tag>
        </template>
      </vxe-grid>
    </div>
  </LayoutContainer>
</template>

<script setup lang="tsx">
import type { ComponentExposed } from 'vue-component-type-helpers'
import type { VxeGridInstance, VxeGridProps } from 'vxe-table'
import type { GridHeaderProps } from '@/components/Table/types/gridHeader'
import type { GetReportWorkSearchModel, GetReportWorkSearchParams } from '@/api/sys/model/workModel'
import type { TreeProps } from '@/components/Tree/types/tree'

import { computed, reactive, ref } from 'vue'
import BasicTree from '@/components/Tree/BasicTree.vue'

import {
  getManufactureGroupList,
  getManufactureDepartmentList,
  getProductionProcessChildren,
  getProductionProcessTopLevel,
  getProductionProjectSelect,
  getKeyValue,
  getManufactureDepartment
} from '@/api/sys/basic'
import { getProductionWoAndProduct } from '@/api/sys/scheduling'
import { exportReportWorkSearch, getReportWorkSearch } from '@/api/sys/work'

import GridHeader from '@/components/Table/GridHeader.vue'
import dayjs from 'dayjs'
import { dateShortcuts } from '@/constant'
import { workTypeOptions, orderStatusOptions } from './data'

defineOptions({
  name: 'WorkReportWorkSearch',
  inheritAttrs: false
})

const listParams = reactive({
  departmentID: '',
  groupID: ''
})

const basicTreeRef = ref<InstanceType<typeof BasicTree>>()
// 列表配置
const treeOptions = reactive<TreeProps>({
  api: getManufactureDepartment,
  title: '部门列表',
  labelField: 'name',
  resultField: 'data',
  childrenField: 'children',
  nodeKey: 'id',
  accordion: true,
  formatter({ data }) {
    return (
      <div>
        {data.label}&nbsp;&nbsp;({data.childrenCount})
      </div>
    )
  },
  cancleHightlightCurrent: true,
  onSelect: async (data, node) => {
    if (data) {
      if (data.isGroup) {
        listParams.departmentID = node.parent.data.id
        listParams.groupID = data.id
      } else {
        listParams.departmentID = data.id
        listParams.groupID = ''
      }

      gridRef.value?.commitProxy('reload')
    } else {
      listParams.departmentID = ''
      listParams.groupID = ''
      gridRef.value?.remove()
    }
  }
})

const gridHeaderRef =
  ref<ComponentExposed<typeof GridHeader<GetReportWorkSearchParams, 'SearchKey'>>>()

const getProductionWoAndProductList = async () => {
  const { code, data } = await getProductionWoAndProduct()
  if (code === 200) {
    gridHeaderRef.value?.updateAdvancedSearchForm([
      { field: 'OrderNo', componentProps: { options: data.orderList } },
      { field: 'WoNo', componentProps: { options: data.woList } },
      { field: 'ProductName', componentProps: { options: data.productNameList } }
    ])
  }
}
getProductionWoAndProductList()

const headerOptions = reactive<GridHeaderProps>({
  title: '报工查询',
  quickSearch: {
    singleSearch: {
      field: 'SearchKey',
      type: 'input',
      title: '单据编号/需求分类/母件编码'
    },
    searchFormFields: { SearchKey: '' }
  },
  advancedSearch: {
    labelWidth: 120,
    fieldMapToTime: [['date', ['StartReportWorkTime', 'EndReportWorkTime'], 'YYYY-MM-DD']],
    schemas: [
      {
        field: 'ProjectID',
        component: 'ApiSelect',
        label: '项目名称',
        componentProps: {
          filterable: true,
          api: getProductionProjectSelect,
          resultField: 'data.result',
          labelField: 'projectName',
          valueField: 'id'
        },
        colProps: {
          span: 8
        }
      },
      {
        field: 'OrderNo',
        component: 'Select',
        label: '需求分类',
        componentProps: {
          filterable: true,
          labelField: 'name',
          valueField: 'value'
        },
        colProps: {
          span: 8
        }
      },
      {
        field: 'WoNo',
        component: 'Select',
        label: '单据编号',
        componentProps: {
          filterable: true,
          labelField: 'name',
          valueField: 'value'
        },
        colProps: {
          span: 8
        }
      },
      {
        field: 'ProductName',
        component: 'Select',
        componentProps: {
          filterable: true,
          labelField: 'name',
          valueField: 'value'
        },
        label: '部件名称',
        colProps: {
          span: 8
        }
      },
      {
        field: 'ProcessID',
        component: 'ApiSelect',
        label: '设备类型',
        componentProps({ formModel, formActionType }) {
          const { updateSchema } = formActionType
          return {
            filterable: true,
            api: getProductionProcessTopLevel,
            labelField: 'processType',
            valueField: 'id',
            resultField: 'data.result',
            async onChange(processID: string) {
              formModel.SonProcessID = void 0

              updateSchema([
                {
                  field: 'SonProcessID',
                  componentProps: {
                    options: []
                  }
                }
              ])
              const { code, data } = await getProductionProcessChildren({
                processTypeID: processID
              })
              if (code === 200) {
                updateSchema([
                  {
                    field: 'SonProcessID',
                    componentProps: {
                      options: data.result,
                      labelField: 'processType',
                      valueField: 'id'
                    }
                  }
                ])
              }
            }
          }
        },
        colProps: {
          span: 8
        }
      },
      {
        field: 'SonProcessID',
        component: 'Select',
        label: '工序任务',
        colProps: {
          span: 8
        }
      },
      // {
      //   field: 'DepartmentID',
      //   component: 'ApiSelect',
      //   label: '部门名称',
      //   componentProps: {
      //     filterable: true,
      //     api: getManufactureDepartmentList,
      //     labelField: 'name',
      //     valueField: 'id',
      //     resultField: 'data'
      //   },
      //   colProps: {
      //     span: 8
      //   }
      // },
      // {
      //   field: 'GroupID',
      //   component: 'ApiSelect',
      //   label: '班组',
      //   componentProps: {
      //     filterable: true,
      //     api: getManufactureGroupList,
      //     resultField: 'data.result',
      //     labelField: 'name',
      //     valueField: 'id',
      //     params: { departmentID: '' }
      //   },
      //   colProps: {
      //     span: 8
      //   }
      // },
      {
        field: 'EmployeeID',
        component: 'PersonSelect',
        label: '作业者',
        colProps: {
          span: 8
        }
      },
      {
        field: 'date',
        component: 'ElDatePicker',
        label: '报工日期',
        defaultValue: [new Date(), new Date()],
        componentProps: {
          type: 'daterange',
          unlinkPanels: true,
          shortcuts: dateShortcuts,
          valueFormat: 'YYYY-MM-DD'
        },
        colProps: {
          span: 8
        }
      },
      {
        field: 'WorkType',
        label: '工作类别',
        component: 'Select',
        componentProps: {
          options: workTypeOptions
        },
        colProps: {
          span: 8
        }
      },
      {
        field: 'OrderStatus',
        label: '状态',
        component: 'Select',
        componentProps: {
          options: orderStatusOptions,
          multiple: true
        },
        colProps: {
          span: 8
        }
      },
      {
        field: 'positionClassifyID',
        component: 'ApiSelect',
        label: '工种',
        // defaultValue: [0, 1],
        componentProps: {
          api: getKeyValue,
          labelField: 'value',
          valueField: 'id',
          resultField: 'data.result',
          multiple: true,
          params: {
            typeName: 'PositionClassify'
          }
        },
        colProps: {
          span: 8
        }
      }
    ]
  },
  showAddButton: false,
  showExportButton: true,
  exportApi: exportReportWorkSearch,
  exportParams: computed(() => {
    const advancedSearchForm = gridHeaderRef.value?.advancedSearchForm
    const quickSearchForm = gridHeaderRef.value?.quickSearchForm
    return { ...listParams, ...quickSearchForm, ...advancedSearchForm }
  })
})

const getOrderStatusInfo = computed(() => {
  const statusMap: { [key: number]: { text: string; type: string } } = {}

  orderStatusOptions.forEach((item) => {
    statusMap[item.value] = { text: item.label, type: item.type }
  })

  return function (status: number) {
    return statusMap[status] || { text: '', color: '' }
  }
})

const gridRef = ref<VxeGridInstance>()
const gridOptions = reactive<VxeGridProps<GetReportWorkSearchModel>>({
  border: true,
  height: 'auto',
  align: null,
  columnConfig: {
    resizable: true
  },
  columns: [
    { type: 'seq', width: 50 },
    {
      field: 'reportWorkTime',
      title: '报工日期',
      width: 120,
      formatter({ cellValue }) {
        return dayjs(cellValue).format('YYYY-MM-DD')
      }
    },
    {
      field: 'employeeName',
      title: '作业者',
      minWidth: 250,
      slots: { default: 'employeeName' }
    },
    { field: 'departmentName', title: '生产部门', width: 120 },
    { field: 'groupName', title: '班组', width: 100 },
    { field: 'reportWorkName', title: '报工类型', width: 85 },
    { field: 'workTypeName', title: '工作类别', width: 85 },
    { field: 'takeTime', title: '总用时(h)', width: 95 },
    { field: 'dispatchingNumber', title: '派工数量', width: 85 },
    { field: 'finishCount', title: '报工数量', width: 85 },
    { field: 'finishPercentName', title: '当天完成率', width: 100 },
    {
      field: 'sumFinishPercent',
      title: '总完成率',
      minWidth: 180,
      slots: { default: 'sumFinishPercent' },
    },
    { field: 'workDescription', title: '工作描述', minWidth: 150 },
    { field: 'projectName', title: '项目/线体', width: 100 },
    { field: 'orderNo', title: '需求分类', minWidth: 120 },
    { field: 'woNo', title: '单据编号', minWidth: 120 },
    { field: 'materialNo', title: '物料编码', minWidth: 120 },
    { field: 'productName', title: '部件名称', minWidth: 100 },
    { field: 'processName', title: '设备类型', minWidth: 100 },
    { field: 'sonProcessName', title: '工序任务', width: 100 },
    {
      field: 'orderStatus',
      title: '状态',
      width: 90,
      slots: { default: 'orderStatus' }
    },
    { field: 'createUserName', title: '录入人', width: 100 }
  ],
  pagerConfig: {
    enabled: true,
    pageSize: 20
  },
  proxyConfig: {
    ajax: {
      query: ({ page }) => {
        const quickSearchForm = gridHeaderRef.value?.quickSearchForm
        const advancedSearchForm = gridHeaderRef.value?.advancedSearchForm
        return getReportWorkSearch({
          pageIndex: page.currentPage - 1, // 由于后端接口限制，首页从0开始
          pageSize: page.pageSize,
          ...listParams,
          ...quickSearchForm,
          ...advancedSearchForm
        })
      }
    }
  }
})

const handleQuickSearch = () => {
  gridRef.value?.commitProxy('reload')
}

const handleAdvancedSearch = () => {
  gridRef.value?.commitProxy('reload')
}

const handleReset = () => {
  gridRef.value?.commitProxy('reload')
}
</script>

<style lang="scss" scoped>
.grid-container {
  height: 100%;
  padding: $margin $margin $margin 0;
}
</style>
