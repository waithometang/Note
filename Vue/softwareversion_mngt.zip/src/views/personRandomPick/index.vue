<template>
  <div class="page-container">
    <div class="box wrapper">
      <div class="grid-container">
        <vxe-grid ref="gridRef" v-bind="gridOptions">
          <template #top>
            <GridHeader ref="gridHeaderRef" v-bind="headerOptions" v-on="headerEvents">
              <template #prependOperation>
                <div
                  class="pick-operation"
                  :style="loadingStatus ? 'margin-right:100px;' : 'margin-right:80px;'"
                >
                  <span>抽查人数</span>
                  <el-input-number
                    v-model="pickNumber"
                    :disabled="loadingStatus"
                    :min="1"
                  ></el-input-number>
                  <Transition name="slide-up">
                    <el-button
                      v-if="!pickStatus"
                      type="primary"
                      @click="handlePick"
                      :loading="loadingStatus"
                      >开始</el-button
                    >
                    <el-button v-else type="primary" @click="handleStopPick">暂停</el-button>
                  </Transition>
                </div>
              </template>
            </GridHeader>
          </template>
        </vxe-grid>
      </div>
      <div class="chosen">
        <div class="pick-list">
          <span>{{ pickedList?.[0]?.employeeName }}</span>
          <!-- <span v-for="(item, index) in pickedList" :key="index">{{ item }}</span> -->
        </div>
      </div>
    </div>
  </div>
</template>

<script setup lang="ts">
import type { ComponentExposed } from 'vue-component-type-helpers'
import type { GetEmployeeByAttendanceDateModel } from '@/api/sys/model/basicModel'
import type GridHeader from '@/components/Table/GridHeader.vue'
import type { GridHeaderEvent, GridHeaderProps } from '@/components/Table/types/gridHeader'
import type { VxeGridInstance, VxeGridProps } from 'vxe-table'

import { reactive, ref } from 'vue'
import {
  getEmployeeByAttendanceDate,
  getGroupSelect,
  getKeyValue,
  getManufactureDepartmentList
} from '@/api/sys/basic'

const gridHeaderRef = ref<ComponentExposed<typeof GridHeader>>()

const headerOptions = reactive<GridHeaderProps>({
  title: '人员随机抽查',
  showAddButton: false,
  showQuickSearchButton: false,
  // showAdvancedSearchButton: false
  advancedSearch: {
    labelWidth: 100,
    schemas: [
      {
        field: 'DepartmentID',
        label: '部门',
        component: 'ApiSelect',
        componentProps: {
          api: getManufactureDepartmentList,
          resultField: 'data',
          labelField: 'name',
          valueField: 'id',
          // filterable: true,
          async onChange(departmentID: string) {
            await gridHeaderRef.value?.setAdvancedSearchFormFieldValue({ GroupID: void 0 })
            await gridHeaderRef.value?.updateAdvancedSearchForm({
              field: 'GroupID',
              componentProps: { options: [] }
            })

            if (departmentID) {
              getGroupSelect({ departmentID }).then(({ code, data }) => {
                if (code === 200) {
                  gridHeaderRef.value?.updateAdvancedSearchForm({
                    field: 'GroupID',
                    componentProps: { options: data.result }
                  })
                }
              })
            }
          }
        },
        colProps: { span: 12 }
      },
      {
        field: 'GroupID',
        label: '班组',
        component: 'ApiSelect',
        componentProps: {},
        colProps: { span: 12 }
      },
      {
        field: 'PositionClassifyID',
        label: '工种',
        component: 'ApiSelect',
        componentProps: {
          api: getKeyValue,
          labelField: 'value',
          valueField: 'id',
          resultField: 'data.result',
          multiple: true,
          params: {
            typeName: 'PositionClassify'
          }
        },
        colProps: { span: 12 }
      }
    ]
  }
})

const headerEvents: GridHeaderEvent = {
  advancedSearch() {
    if (loadingStatus.value) {
      ElMessage.warning('请先等待本轮抽查结束')
      return
    }
    handlePick()
  },
  reset() {
    gridHeaderRef.value?.updateAdvancedSearchForm({
      field: 'GroupID',
      componentProps: { options: [] }
    })
  }
}

const gridRef = ref<VxeGridInstance>()
const gridOptions = reactive<VxeGridProps<GetEmployeeByAttendanceDateModel>>({
  border: true,
  height: 'auto',
  align: null,
  columnConfig: {
    resizable: true
  },
  columns: [
    { type: 'seq', width: 50 },
    {
      field: 'employeeName',
      title: '员工',
      formatter({ row }) {
        return `${row.employeeNo}-${row.employeeName}`
      }
    },
    { field: 'departmentName', title: '部门' },
    { field: 'groupName', title: '班组' },
    { field: 'positionName', title: '岗位' }
  ],
  pagerConfig: {
    enabled: false,
    pageSize: 10
  }
})

const allData = ref<GetEmployeeByAttendanceDateModel[]>([])
const loadingStatus = ref(false)

const getList = async () => {
  try {
    loadingStatus.value = true

    const advancedSearchForm = gridHeaderRef.value?.getAdvancedSearchForm()

    const { code, data, message } = await getEmployeeByAttendanceDate({
      AttendanceDate: '',
      ...advancedSearchForm
    })
    if (code === 200) {
      if (data.length > 0) {
        allData.value = data
      } else {
        allData.value = []
        pickedList.value = []
        gridRef.value?.loadData([])
        ElMessage.warning('未获取到人员列表')
        loadingStatus.value = false
        return Promise.reject('未获取到人员列表')
      }
    } else {
      ElMessage.error(message)
      loadingStatus.value = false
      return Promise.reject(message)
    }
  } catch (error: any) {
    ElMessage.error(error.message)
    loadingStatus.value = false
  }
}

const pickNumber = ref(1)
const pickStatus = ref(false)
const pickedList = ref<GetEmployeeByAttendanceDateModel[]>([])

let timer: any
const getRandomIndex = () => Math.floor(Math.random() * allData.value.length)

const handlePick = async () => {
  await getList()
  // pickStatus.value = true
  const start = new Date().getTime()
  // const emptyArr = new Array(pickNumber.value).fill('')

  const pick = () => {
    const end = new Date().getTime()
    if (end - start > 2 * 1000) {
      handleStopPick()
      return
    }
    timer && clearTimeout(timer)
    timer = setTimeout(() => {
      // pickedList.value = emptyArr.map(() => {
      //   return allData.value[getRandomIndex()]
      // })
      pickedList.value = [allData.value[getRandomIndex()]]
      pick()
    }, 100)
  }

  pick()
}
const handleStopPick = () => {
  timer && clearTimeout(timer)
  timer = null
  // pickStatus.value = false
  if (pickNumber.value > 1) {
    let randomIndexCache: number[] = []

    const getUniqueRandomIndex: (randomIndex: number) => number = (randomIndex) => {
      if (randomIndexCache.includes(randomIndex)) {
        return getUniqueRandomIndex(getRandomIndex())
      }
      return randomIndex
    }
    let length: number = pickNumber.value
    if (pickNumber.value > allData.value.length) {
      length = allData.value.length
    }
    for (let index = 0; index < length; index++) {
      let randomIndex = getUniqueRandomIndex(getRandomIndex())
      randomIndexCache.push(randomIndex)
      pickedList.value[index] = allData.value[randomIndex]
    }
  }
  gridRef.value?.loadData(pickedList.value)
  loadingStatus.value = false
}
</script>

<style scoped lang="scss">
.wrapper {
  height: 100%;
  display: flex;
  .grid-container {
    flex: 50%;
    overflow: hidden;
  }
  .chosen {
    flex: 50%;
    display: flex;
    align-items: center;
    justify-content: center;
    font-size: 50px;
    font-weight: 700;
    padding: 20px;
    .pick-list {
      display: flex;
      align-items: center;
      gap: 20px;
      flex-wrap: wrap;
    }
  }
  .pick-operation {
    display: flex;
    gap: 10px;
    align-items: center;
    margin-right: 80px;
    .el-button {
      position: absolute;
      right: 115px;
    }
  }
}

.slide-up-enter-active,
.slide-up-leave-active {
  transition: all 0.25s ease-out;
}

.slide-up-enter-from {
  opacity: 0;
  transform: translateY(30px);
}

.slide-up-leave-to {
  opacity: 0;
  transform: translateY(-30px);
}
</style>
