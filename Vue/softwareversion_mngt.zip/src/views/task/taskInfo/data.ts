export const TaskStatusOptions = [
  {
    label: '任务开始',
    value: 1
  },
  {
    label: '已报价,待通知开发',
    value: 2
  },
  {
    label: '未完成(开发中)',
    value: 3
  },
  {
    label: '暂停',
    value: 4
  },
  {
    label: '任务停止',
    value: 5
  },
  {
    label: '任务完成',
    value: 6
  },
  {
    label: '任务关闭',
    value: 7
  }
]
export const EmergencyLevelOptions = [
  {
    label: '高',
    value: 1
  },
  {
    label: '中',
    value: 2
  },
  {
    label: '低',
    value: 3
  },
  {
    label: '一般',
    value: 4
  }
]
