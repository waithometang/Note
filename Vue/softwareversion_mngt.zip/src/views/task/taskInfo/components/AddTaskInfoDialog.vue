<template>
  <BasicModal
    width="1200px"
    v-bind="$attrs"
    @register="registerModal"
    title="新增"
    @confirm="handleSubmit"
  >
    <BasicForm @register="registerForm"> </BasicForm>
  </BasicModal>
</template>

<script setup lang="ts">
import type { ModalMethods } from '@/components/Modal/types'

import BasicModal from '@/components/Modal/BasicModal.vue'
import BasicForm from '@/components/Form/BasicForm.vue'

import { useModalInner } from '@/components/Modal/hooks/useModal'
import { useForm } from '@/components/Form/hooks/useForm'
import { getKeyValue } from '@/api/sys/basic'
import type { AddTaskInformationData } from '@/api/task/model/taskInfoModel'
import { addTaskInformation } from '@/api/task/taskInfo'
import { getSoftwareProject } from '@/api/sys/versionMngt'
import { EmergencyLevelOptions } from '../data'

const emit = defineEmits<{
  register: [modalMethods: ModalMethods, uuid: number]
  success: []
}>()

const [registerForm, { setFieldsValue, resetFields, getFieldsValue, validate, clearValidate }] =
  useForm({
    labelWidth: 110,
    schemas: [
      {
        field: 'sourceName',
        label: '来源名',
        component: 'ElInput',
        required: true,
        componentProps: {},
        colProps: {
          span: 12
        }
      },
      {
        field: 'projectNameID',
        label: '项目名称',
        required: true,
        component: 'ApiSelect',
        componentProps: {
          api: getSoftwareProject,
          resultField: 'data',
          labelField: 'projectName',
          valueField: 'id'
        },
        colProps: {
          span: 12
        }
      },
      {
        field: 'sourceFormID',
        label: '来源方式',
        required: true,
        component: 'ApiSelect',
        componentProps: {
          api: getKeyValue,
          resultField: 'data.result',
          labelField: 'value',
          valueField: 'id',
          params: { typeName: 'SourceForm' }
        },
        colProps: {
          span: 12
        }
      },
      {
        field: 'productNameID',
        label: '产品名称',
        required: true,
        component: 'ApiSelect',
        componentProps: {
          multiple: true,
          api: getKeyValue,
          resultField: 'data.result',
          labelField: 'value',
          valueField: 'id',
          params: { typeName: 'ProductName' }
        },
        colProps: {
          span: 12
        }
      },
      {
        field: 'sourceTime',
        label: '来源时间',
        required: true,
        component: 'ElDatePicker',
        componentProps: {
          type: 'date',
          valueFormat: 'YYYY-MM-DD'
        },
        colProps: {
          span: 12
        }
      },
      {
        field: 'emergencyLevel',
        label: '紧急程度',
        required: true,
        component: 'Select',
        componentProps: {
          options: EmergencyLevelOptions
        },
        colProps: {
          span: 12
        }
      },
      {
        field: 'plannedCompletionTime',
        label: '预计完成时间',
        required: true,
        component: 'ElDatePicker',
        componentProps: { type: 'date', valueFormat: 'YYYY-MM-DD' },
        colProps: {
          span: 12
        }
      },
      {
        field: 'quotationAmount',
        label: '报价金额',
        component: 'ElInputNumber',
        componentProps: {},
        colProps: {
          span: 12
        }
      },
      {
        field: 'assignedIDList',
        label: '被指派人',
        required: true,
        component: 'PersonSelect',
        componentProps: { multiple: true },
        colProps: {
          span: 24
        }
      },
      {
        field: 'taskName',
        label: '任务名称',
        required: true,
        component: 'ElInput',
        componentProps: {},
        colProps: {
          span: 24
        }
      },
      {
        field: 'detailedDescription',
        label: '任务详细描述',
        component: 'ElInput',
        componentProps: {
          type: 'textarea',
          rows: 5
        },
        colProps: {
          span: 24
        }
      }
    ]
  })

const [registerModal, { setModalProps }] = useModalInner(async (data) => {
  await resetFields()
  setModalProps({ confirmLoading: false })
  clearValidate()
})

// 提交
const handleSubmit = async () => {
  await validate()
  setModalProps({ confirmLoading: true })
  try {
    // 新增
    const formData = getFieldsValue()
    const data = {
      ...formData
    } as AddTaskInformationData
    const { code, message } = await addTaskInformation(data)
    if (code === 200) {
      ElMessage.success('新增成功')
      emit('success')
    } else {
      ElMessage.error(message)
    }
  } catch (error: any) {
    ElMessage(error.message)
  } finally {
    setModalProps({ confirmLoading: false })
  }
}
</script>
<style lang="scss" scoped></style>
