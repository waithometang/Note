<template>
  <BasicModal
    width="1200px"
    v-bind="$attrs"
    @register="registerModal"
    title="详情"
    @confirm="handleSubmit"
  >
    <BasicForm @register="registerForm"> </BasicForm>
  </BasicModal>
</template>

<script setup lang="ts">
import type { ModalMethods } from '@/components/Modal/types'

import { ref } from 'vue'

import BasicModal from '@/components/Modal/BasicModal.vue'
import BasicForm from '@/components/Form/BasicForm.vue'

import { useModalInner } from '@/components/Modal/hooks/useModal'
import { useForm } from '@/components/Form/hooks/useForm'

const emit = defineEmits<{
  register: [modalMethods: ModalMethods, uuid: number]
  success: [{ isUpdate: boolean }]
}>()
const isUpdate = ref<boolean>(false)

const rowId = ref<string>('')

const [registerForm, { setFieldsValue, resetFields, clearValidate }] = useForm({
  labelWidth: 110,
  schemas: [
    {
      field: 'detailedDescription',
      label: '任务详细描述',
      component: 'ElInput',
      componentProps: {
        type: 'textarea',
        rows: 5
      },
      colProps: {
        span: 24
      }
    },
    {
      field: 'dataDescribe',
      label: '任务状态描述',
      component: 'ElInput',
      componentProps: {
        type: 'textarea',
        rows: 5
      },
      colProps: {
        span: 24
      }
    }
  ]
})

const [registerModal, { setModalProps, closeModal }] = useModalInner(async (data) => {
  await resetFields()
  setModalProps({ confirmLoading: false })

  rowId.value = data.row.id
  await setFieldsValue({ ...data.row })
  clearValidate()
})

// 提交
const handleSubmit = async () => {
  closeModal()
}
</script>
<style lang="scss" scoped></style>
