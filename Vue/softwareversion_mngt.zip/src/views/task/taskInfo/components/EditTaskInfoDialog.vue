<template>
  <BasicModal
    width="1200px"
    v-bind="$attrs"
    @register="registerModal"
    title="修改"
    @confirm="handleSubmit"
  >
    <BasicForm @register="registerForm"> </BasicForm>
  </BasicModal>
</template>

<script setup lang="ts">
import type { ModalMethods } from '@/components/Modal/types'

import { ref, unref, computed } from 'vue'

import BasicModal from '@/components/Modal/BasicModal.vue'
import BasicForm from '@/components/Form/BasicForm.vue'

import { useModalInner } from '@/components/Modal/hooks/useModal'
import { useForm } from '@/components/Form/hooks/useForm'

import { updateTaskInformationStatus } from '@/api/task/taskInfo'
import type { UpdateTaskInformationStatusData } from '@/api/task/model/taskInfoModel'
import { TaskStatusOptions } from '../data'

const emit = defineEmits<{
  register: [modalMethods: ModalMethods, uuid: number]
  success: [{ isUpdate: boolean }]
}>()
const isUpdate = ref<boolean>(false)

const rowId = ref<string>('')

const [registerForm, { setFieldsValue, resetFields, getFieldsValue, validate, clearValidate }] =
  useForm({
    labelWidth: 110,
    schemas: [
      {
        field: 'quotationAmount',
        label: '报价金额',
        component: 'ElInputNumber',
        componentProps: {},
        colProps: {
          span: 12
        }
      },
      {
        field: 'reminderCycle',
        label: '任务提醒周期',
        component: 'ElInput',
        componentProps: {},
        colProps: {
          span: 12
        }
      },
      {
        field: 'taskStatus',
        label: '任务状态',
        component: 'Select',
        componentProps: {
          options: TaskStatusOptions
        },
        colProps: {
          span: 12
        }
      },
      {
        field: 'plannedCompletionTime',
        label: '预计完成时间',
        component: 'ElDatePicker',
        componentProps: { type: 'date', valueFormat: 'YYYY-MM-DD' },
        colProps: {
          span: 12
        }
      },
      {
        field: 'assignedIDList',
        label: '被指派人',
        component: 'PersonSelect',
        componentProps: { multiple: true },
        colProps: {
          span: 24
        }
      },
      {
        field: 'dataDescribe',
        label: '状态描述',
        component: 'ElInput',
        componentProps: {
          type: 'textarea',
          rows: 5
        },
        colProps: {
          span: 24
        }
      }
    ]
  })

const [registerModal, { setModalProps }] = useModalInner(async (data) => {
  await resetFields()
  setModalProps({ confirmLoading: false })

  rowId.value = data.row.id
  await setFieldsValue({ ...data.row })
  clearValidate()
})

// 提交
const handleSubmit = async () => {
  await validate()
  setModalProps({ confirmLoading: true })
  try {
    const formData = getFieldsValue()
    const data = {
      id: unref(rowId),
      ...formData
    } as UpdateTaskInformationStatusData
    const { code, message } = await updateTaskInformationStatus(data)

    if (code === 200) {
      ElMessage.success('修改成功')
      emit('success', { isUpdate: unref(isUpdate) })
    } else {
      ElMessage.error(message)
    }
  } catch (error: any) {
    ElMessage(error.message)
  } finally {
    setModalProps({ confirmLoading: false })
  }
}
</script>
<style lang="scss" scoped></style>
