<template>
  <div class="page-container">
    <vxe-grid class="box" ref="gridRef" v-bind="gridOptions">
      <template #top>
        <GridHeader
          ref="gridHeaderRef"
          v-bind="headerOptions"
          @quickSearch="handleQuickSearch"
          @advancedSearch="handleAdvancedSearch"
          @reset="handleReset"
          @add="handleAdd"
        />
      </template>
      <template #operation="{ row }">
        <TableAction
          :actions="[
            {
              icon: 'edit',
              tooltip: '编辑',
              onClick: handleModify.bind(null, row)
            },
            {
              icon: 'view',
              tooltip: '详情',
              onClick: handleViewDetail.bind(null, row)
            }
          ]"
        />
      </template>
    </vxe-grid>
  </div>
  <AddTaskInfoDialog @register="registerAddModal" @success="handleAddSuccess" />
  <EditTaskInfoDialog @register="registerEditModal" @success="handleEditSuccess" />
  <TaskInfoDetailDialog @register="registerDetailModal" />
</template>

<script setup lang="ts">
import type { ComponentExposed } from 'vue-component-type-helpers'
import type { VxeGridInstance, VxeGridProps } from 'vxe-table'
import type { GridHeaderProps } from '@/components/Table/types/gridHeader'

import { reactive, ref } from 'vue'
import { getKeyValue } from '@/api/sys/basic'

import { useModal } from '@/components/Modal/hooks/useModal'

import GridHeader from '@/components/Table/GridHeader.vue'
import AddTaskInfoDialog from './components/AddTaskInfoDialog.vue'
import EditTaskInfoDialog from './components/EditTaskInfoDialog.vue'
import TaskInfoDetailDialog from './components/TaskInfoDetailDialog.vue'

import { getTaskInformation } from '@/api/task/taskInfo'
import type { GetTaskInformation, GetTaskInformationParams } from '@/api/task/model/taskInfoModel'
import { dateShortcuts } from '@/constant'
import { TaskStatusOptions, EmergencyLevelOptions } from './data'
import { getSoftwareProject } from '@/api/sys/versionMngt'

defineOptions({
  name: 'TaskInfo',
  inheritAttrs: false
})

const gridHeaderRef =
  ref<ComponentExposed<typeof GridHeader<GetTaskInformationParams, 'ProjectName'>>>()

const getProject = async () => {
  const { code, data } = await getSoftwareProject()
  if (code === 200) {
    headerOptions.quickSearch!.singleSearch!.data = data.map((item) => {
      return { label: item.projectName!, value: item.projectName! }
    })
  }
}
getProject()

const headerOptions = reactive<GridHeaderProps>({
  title: '任务信息',
  quickSearch: {
    singleSearch: {
      field: 'ProjectName',
      type: 'select',
      title: '项目名称',
      data: []
    },
    searchFormFields: { ProjectName: '' }
  },
  advancedSearch: {
    labelWidth: 120,
    fieldMapToTime: [['CreateTime', ['StartCreateTime', 'EndCreateTime'], 'YYYY-MM-DD']],
    schemas: [
      {
        field: 'sourceName',
        label: '来源名',
        component: 'ElInput',
        componentProps: {},
        colProps: {
          span: 8
        }
      },
      {
        field: 'SourceFormID',
        label: '来源方式',
        component: 'ApiSelect',
        componentProps: {
          api: getKeyValue,
          resultField: 'data.result',
          labelField: 'value',
          valueField: 'id',
          params: { typeName: 'SourceForm' }
        },
        colProps: {
          span: 8
        }
      },
      {
        field: 'TaskName',
        label: '任务名称',
        component: 'ElInput',
        componentProps: {},
        colProps: {
          span: 8
        }
      },
      {
        field: 'TaskStatus',
        label: '任务状态',
        component: 'Select',
        componentProps: {
          options: TaskStatusOptions
        },
        colProps: {
          span: 8
        }
      },
      {
        field: 'CreateTime',
        label: '创建时间',
        component: 'ElDatePicker',
        componentProps: {
          type: 'daterange',
          unlinkPanels: true,
          shortcuts: dateShortcuts,
          valueFormat: 'YYYY-MM-DD'
        },
        colProps: {
          span: 8
        }
      }
    ]
  }
})

const gridRef = ref<VxeGridInstance>()
const gridOptions = reactive<VxeGridProps<GetTaskInformation>>({
  border: true,
  height: 'auto',
  align: null,
  columnConfig: {
    resizable: true
  },
  columns: [
    { type: 'seq', width: 50 },
    { field: 'sourceName', title: '来源名', minWidth: 100 },
    { field: 'sourceTime', title: '来源时间', minWidth: 140 },
    { field: 'sourceForm', title: '来源方式', minWidth: 100 },
    { field: 'taskName', title: '任务名', minWidth: 100 },
    { field: 'projectName', title: '项目', minWidth: 100 },
    { field: 'productName', title: '产品名称', minWidth: 100 },
    {
      field: 'emergencyLevel',
      title: '紧急程度',
      minWidth: 100,
      formatter({ cellValue }) {
        return EmergencyLevelOptions.find((item) => item.value === cellValue)?.label || cellValue
      }
    },
    { field: 'createUserName', title: '创建人', minWidth: 100 },
    { field: 'assignedName', title: '被指派人', minWidth: 150 },
    { field: 'createTime', title: '创建时间', minWidth: 140 },
    {
      field: 'plannedCompletionTime',
      title: '计划完成时间',
      minWidth: 140,
      formatter({ cellValue }) {
        return cellValue ? cellValue : ''
      }
    },
    {
      field: 'actualCompletionTime',
      title: '实际完成时间',
      minWidth: 140,
      formatter({ cellValue }) {
        return cellValue ? cellValue : ''
      }
    },
    {
      field: 'taskStatus',
      title: '任务状态',
      minWidth: 150,
      formatter({ cellValue }) {
        return TaskStatusOptions.find((item) => item.value === cellValue)?.label || cellValue
      }
    },
    { field: 'quotationAmount', title: '报价金额', minWidth: 100 },
    { field: 'extensionDays', title: '延期时间', minWidth: 100 },
    { field: 'reminderCycle', title: '提醒周期', minWidth: 100 },
    { field: 'lastModifiedUserName', title: '操作人', minWidth: 100 },
    { field: 'lastModifiedTime', title: '最后更新时间', minWidth: 140 },
    {
      field: 'operation',
      title: '操作',
      align: 'center',
      fixed: 'right',
      width: 150,
      slots: {
        default: 'operation'
      }
    }
  ],
  pagerConfig: {
    enabled: true,
    pageSize: 20
  },
  proxyConfig: {
    ajax: {
      query: ({ page }) => {
        const quickSearchForm = gridHeaderRef.value?.quickSearchForm
        const advancedSearchForm = gridHeaderRef.value?.advancedSearchForm
        return getTaskInformation({
          pageIndex: page.currentPage - 1, // 由于后端接口限制，首页从0开始
          pageSize: page.pageSize,
          ...quickSearchForm,
          ...advancedSearchForm
        })
      }
    }
  }
})

const handleQuickSearch = () => {
  gridRef.value?.commitProxy('reload')
}

const handleAdvancedSearch = () => {
  gridRef.value?.commitProxy('reload')
}

const handleReset = () => {
  gridRef.value?.commitProxy('reload')
}

const [registerAddModal, { openModal: openAddModal, closeModal: closeAddModal }] = useModal()
const handleAdd = () => {
  openAddModal(true, {})
}
const handleAddSuccess = () => {
  gridRef.value?.commitProxy('reload')
  closeAddModal()
}

const [registerEditModal, { openModal: openEditModal, closeModal: closeEditModal }] = useModal()
const handleModify = (row: GetTaskInformation) => {
  openEditModal(true, { row })
}
const handleEditSuccess = () => {
  gridRef.value?.commitProxy('query')
  closeEditModal()
}

const [registerDetailModal, { openModal: openDetailModal }] = useModal()
const handleViewDetail = (row: GetTaskInformation) => {
  openDetailModal(true, { row })
}
</script>

<style scoped></style>
