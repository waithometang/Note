<template>
  <div class="page-container">
    <div class="basic-list-container">
      <basic-tree ref="basicTreeRef" v-bind="listOptions">
        <template #footer>
          <div style="margin: 0 auto">
            <el-checkbox v-model="showAllProject" label="显示所有项目" />
          </div>
        </template>
      </basic-tree>
    </div>

    <el-scrollbar class="grid-container">
      <div class="box vxe-grid-container">
        <vxe-grid ref="gridRef" v-bind="gridOptions" @cellClick="handleCellClick">
          <template #top>
            <GridHeader
              ref="gridHeaderRef"
              v-bind="headerOptions"
              @quickSearch="handleQuickSearch"
              @advancedSearch="handleAdvancedSearch"
              @add="handleAdd"
              @reset="handleReset"
            >
            </GridHeader>
          </template>
          <template #reportFinishType="{ row }">
            <el-tag :type="getReportFinishTypeInfo(row.reportFinishType).type">
              {{ getReportFinishTypeInfo(row.reportFinishType).text }}
            </el-tag>
          </template>
          <template #operation="{ row }">
            <TableAction
              :actions="[
                {
                  icon: 'copy',
                  tooltip: '复制',
                  onClick: handleCopy.bind(null, row)
                },
                {
                  icon: 'edit',
                  tooltip: '编辑',
                  onClick: handleModify.bind(null, row)
                },
                {
                  // icon: 'edit',
                  // tooltip: '编辑',
                  label: '取消隐藏',
                  ifShow: isShowExclude,
                  onClick: handleUnhide.bind(null, row)
                },
                {
                  // icon: 'edit',
                  // tooltip: '编辑',
                  label: '隐藏',
                  ifShow: !isShowExclude,
                  onClick: handleHide.bind(null, row)
                },
                {
                  icon: 'delete',
                  tooltip: '删除',
                  ifShow: false,
                  onClick: handleDelete.bind(null, row)
                }
              ]"
            />
          </template>
        </vxe-grid>
      </div>
      <div class="box vxe-grid-container">
        <vxe-grid ref="processGridRef" v-bind="processGridOptions">
          <template #top>
            <GridHeader ref="processGridHeaderRef" v-bind="processHeaderOptions" />
          </template>
        </vxe-grid>
      </div>
    </el-scrollbar>
  </div>

  <StandardWorkTimeDialog @register="registerModal" @success="handleSuccess" />
  <CopyDialog @register="registerCopyModal" @success="handleCopySuccess" />
</template>

<script setup lang="ts">
import type { ComponentExposed } from 'vue-component-type-helpers'
import type { VxeGridEvents, VxeGridInstance, VxeGridProps } from 'vxe-table'
import type { GridHeaderProps } from '@/components/Table/types/gridHeader'
import type {
  DeleteStandardWorkTimeData,
  GetStandardWorkTimeModel,
  GetStandardWorkTimeParams
} from '@/api/sys/model/basicModel'
import type { TreeProps } from '@/components/Tree/types/tree'

import {
  deleteStandardWorkTime,
  getStandardWorkTime,
  getProductionProjectSelect,
  exportStandardWorkTime,
  exportTemplate,
  getProductionProcessTopLevel,
  addStandardWorkTimeWoExInclude,
  deleteStandardWorkTimeWoExInclude
} from '@/api/sys/basic'
import { getProductionWoAndProduct, getProjectAndProductName } from '@/api/sys/scheduling'

import { computed, reactive, ref, unref } from 'vue'
import BasicTree from '@/components/Tree/BasicTree.vue'
import GridHeader from '@/components/Table/GridHeader.vue'
import StandardWorkTimeDialog from './components/StandardWorkTimeDialog.vue'
import CopyDialog from './components/CopyDialog.vue'
import { useModal } from '@/components/Modal/hooks/useModal'
import dayjs from 'dayjs'
import { dateShortcuts } from '@/constant'

defineOptions({
  name: 'StandardWorkTime',
  inheritAttrs: false
})

const listParams = reactive({
  projectID: '',
  orderProductName: '',
  orderNo: ''
})

const showAllProject = ref(false)

// 列表配置
const listOptions = reactive<TreeProps>({
  api: getProjectAndProductName,
  title: '项目列表',
  labelField: 'name',
  resultField: 'data',
  childrenField: 'productList',
  nodeKey: 'id',
  cancleHightlightCurrent: true,
  params: computed(() => ({ orderStatus: showAllProject.value ? 3 : 1 })),
  onSelect: async (data) => {
    if (data) {
      if (data.isProject) {
        listParams.projectID = data.id
        listParams.orderProductName = ''
        listParams.orderNo = ''
      } else {
        listParams.projectID = data.projectID
        listParams.orderProductName = data.label
        listParams.orderNo = data.orderNo
      }
      headerOptions.title = `标准工时信息 - [${data.label}]`
      gridRef.value?.commitProxy('reload')
    } else {
      listParams.projectID = ''
      listParams.orderProductName = ''
      listParams.orderNo = ''
      headerOptions.title = `标准工时信息`
      gridRef.value?.remove()
    }
    await gridHeaderRef.value?.setAdvancedSearchFormFieldValue({
      ProjectID: listParams.projectID,
      OrderNo: listParams.orderNo
    })

    resetProcessGridTable()
  }
})
const basicTreeRef = ref<InstanceType<typeof BasicTree>>()

const gridHeaderRef =
  ref<ComponentExposed<typeof GridHeader<GetStandardWorkTimeParams, 'ProductName'>>>()

const getProductionWoAndProductList = async () => {
  const { code, data } = await getProductionWoAndProduct()
  if (code === 200) {
    gridHeaderRef.value?.updateAdvancedSearchForm([
      { field: 'OrderNo', componentProps: { options: data.orderList } },
      { field: 'WoNo', componentProps: { options: data.woList } }
    ])
  }
}
getProductionWoAndProductList()

const headerOptions = reactive<GridHeaderProps>({
  title: '标准工时信息',
  quickSearch: {
    singleSearch: {
      field: 'ProductName',
      type: 'input',
      title: '部件名称'
    },
    searchFormFields: { ProductName: '' }
  },
  advancedSearch: {
    labelWidth: 120,
    fieldMapToTime: [
      ['ManufactureDate', ['StartManufactureDate', 'EndManufactureDate'], 'YYYY-MM-DD']
    ],
    schemas: [
      {
        field: 'ProjectID',
        component: 'ApiSelect',
        label: '项目名称',
        componentProps: {
          api: getProductionProjectSelect,
          resultField: 'data.result',
          labelField: 'projectName',
          valueField: 'id'
          // async onChange(projectID: string) {
          //   // gridHeaderRef.value?.setAdvancedSearchFormFieldValue({ OrderNo: '' })
          //   const { code, data } = await getProductionProjectAppointData({ projectID: projectID })
          //   await gridHeaderRef.value?.setAdvancedSearchFormFieldValue({
          //     ParentProcessID: ''
          //   })
          //   if (code === 200) {
          //     // 高级查询
          //     // 更新需求分类
          //     // 根据orderNo去重
          //     const options = data.result.filter(
          //       (obj, index, self) => index === self.findIndex((t) => t.orderNo === obj.orderNo)
          //     )
          //     gridHeaderRef.value?.updateAdvancedSearchForm([
          //       {
          //         field: 'OrderNo',
          //         componentProps: {
          //           options: options,
          //           labelField: 'orderNo',
          //           valueField: 'orderNo',
          //           async onChange(orderNo: string) {
          //             await gridHeaderRef.value?.setAdvancedSearchFormFieldValue({ WoNo: '' })
          //             // 更新单据编号
          //             gridHeaderRef.value?.updateAdvancedSearchForm([
          //               {
          //                 field: 'WoNo',
          //                 componentProps: {
          //                   options: data.result.filter((item) => item.orderNo === orderNo),
          //                   labelField: 'woNo',
          //                   valueField: 'woNo'
          //                 }
          //               }
          //             ])
          //           }
          //         }
          //       }
          //     ])

          //     // 高级查询
          //     // 更新设备类型
          //     // 根据processID去重
          //     const processList = data.result.filter(
          //       (obj, index, self) => index === self.findIndex((t) => t.processID === obj.processID)
          //     )
          //     gridHeaderRef.value?.updateAdvancedSearchForm([
          //       {
          //         field: 'ParentProcessID',
          //         componentProps: {
          //           options: processList,
          //           labelField: 'processName',
          //           valueField: 'processID'
          //         }
          //       }
          //     ])
          //   } else {
          //     gridHeaderRef.value?.updateAdvancedSearchForm([
          //       {
          //         field: 'OrderNo',
          //         componentProps: { options: [] }
          //       },
          //       {
          //         field: 'ParentProcessID',
          //         componentProps: { options: [] }
          //       }
          //     ])
          //   }
          // }
        },
        colProps: {
          span: 8
        }
      },
      {
        field: 'OrderNo',
        component: 'Select',
        label: '需求分类',
        componentProps: { filterable: true, labelField: 'name', valueField: 'value' },
        colProps: {
          span: 8
        }
      },
      {
        field: 'WoNo',
        component: 'Select',
        label: '单据编号',
        componentProps: { filterable: true, labelField: 'name', valueField: 'value' },
        colProps: {
          span: 8
        }
      },
      {
        field: 'ParentProcessID',
        component: 'ApiSelect',
        label: '设备类型',
        componentProps: {
          filterable: true,
          api: getProductionProcessTopLevel,
          labelField: 'processType',
          valueField: 'id',
          resultField: 'data.result'
        },
        colProps: {
          span: 8
        }
      },
      // {
      //   field: 'OrderProductName',
      //   component: 'ElInput',
      //   label: '设备名称',
      //   colProps: {
      //     span: 8
      //   }
      // },
      {
        field: 'CodeNumber',
        component: 'ElInput',
        label: '编码',
        colProps: {
          span: 8
        }
      },
      {
        field: 'ManufactureDate',
        component: 'ElDatePicker',
        label: '制定日期',
        componentProps: {
          type: 'daterange',
          unlinkPanels: true,
          shortcuts: dateShortcuts,
          valueFormat: 'YYYY-MM-DD'
        },
        colProps: {
          span: 8
        }
      },
      {
        field: 'IsBeFilled',
        component: 'ElCheckbox',
        label: '只显示未填部件',
        // labelWidth: 150,
        componentProps: {},
        colProps: {
          span: 8
        }
      },
      {
        field: 'IsShowExclude',
        component: 'ElCheckbox',
        label: '只显示隐藏工单',
        // labelWidth: 150,
        componentProps: {},
        colProps: {
          span: 8
        }
      }
    ]
  },
  showAddButton: false,
  showExportButton: true,
  exportApi: exportStandardWorkTime,
  exportParams: computed(() => {
    const advancedSearchForm = gridHeaderRef.value?.advancedSearchForm
    const quickSearchForm = gridHeaderRef.value?.quickSearchForm
    return { ...quickSearchForm, ...advancedSearchForm }
  }),
  showImportButton: true,
  exportTemplateApi: exportTemplate,
  importUrl: '/StandardWorkTime/ImportExcelData'
})

const isShowExclude = computed(() => {
  return !!unref(gridHeaderRef.value?.advancedSearchForm)?.IsShowExclude
})

const getReportFinishTypeInfo = computed(() => {
  const statusMap: { [key: number]: { text: string; type: string } } = {
    1: { text: '按工时', type: 'success' },
    2: { text: '按数量', type: '' }
  }

  return function (status: number) {
    return statusMap[status] || { text: '', color: '' }
  }
})

const gridRef = ref<VxeGridInstance>()
const gridOptions = reactive<VxeGridProps<GetStandardWorkTimeModel>>({
  border: true,
  minHeight: '400px',
  maxHeight: '564px',
  align: null,
  columnConfig: {
    resizable: true
  },
  columns: [
    { type: 'seq', width: 50 },
    { field: 'productName', title: '部件名称', minWidth: 200 },
    { field: 'parentProcessName', title: '设备类型', minWidth: 150 },
    {
      field: 'sumStandardWorkHour',
      title: '总标准工时(h)',
      minWidth: 120,
      formatter({ cellValue }) {
        return typeof cellValue === 'number' ? `${cellValue}h` : ''
      }
    },
    { field: 'orderNo', title: '需求分类', minWidth: 130 },
    // { field: 'woNo', title: '单据编号', minWidth: 130 },
    // { field: 'codeNumber', title: '编码', minWidth: 60 },
    {
      field: 'manufactureDate',
      title: '制定日期',
      minWidth: 100,
      formatter({ cellValue }) {
        return cellValue ? dayjs(cellValue).format('YYYY-MM-DD') : ''
      }
    },
    // {
    //   field: 'reportFinishType',
    //   title: '完成率计算',
    //   width: 100,
    //   slots: { default: 'reportFinishType' }
    // },
    { field: 'lastModifiedUserName', title: '操作人', minWidth: 120 },
    {
      field: 'operation',
      title: '操作',
      align: 'center',
      fixed: 'right',
      width: 150,
      slots: {
        default: 'operation'
      }
    }
  ],
  pagerConfig: {
    enabled: true,
    pageSize: 10
  },
  proxyConfig: {
    autoLoad: false,
    ajax: {
      query: ({ page }) => {
        const quickSearchForm = gridHeaderRef.value?.quickSearchForm
        const advancedSearchForm = gridHeaderRef.value?.advancedSearchForm

        return getStandardWorkTime({
          pageIndex: page.currentPage - 1, // 由于后端接口限制，首页从0开始
          pageSize: page.pageSize,
          ...quickSearchForm,
          ...advancedSearchForm
        })
      }
    }
  }
})

let isIgnoreClick = false

const handleCellClick: VxeGridEvents.CellClick<GetStandardWorkTimeModel> = ({ row }) => {
  if (isIgnoreClick) {
    isIgnoreClick = false
    return
  }
  processHeaderOptions.title = `作业流程表 - [${row.productName}]`
  processGridRef.value?.loadData(row.standardWorkTimeClassifyModel)
}

const handleReset = () => {
  const advancedSearchForm = gridHeaderRef.value?.advancedSearchForm
  const { ProjectID } = advancedSearchForm as Omit<GetStandardWorkTimeParams, 'ProductName'>
  basicTreeRef.value?.treeRef?.setCurrentKey(ProjectID)
  gridRef.value?.commitProxy('reload')
  resetProcessGridTable()
}

const handleQuickSearch = () => {
  const advancedSearchForm = gridHeaderRef.value?.advancedSearchForm
  const { ProjectID } = advancedSearchForm as Omit<GetStandardWorkTimeParams, 'ProductName'>
  basicTreeRef.value?.treeRef?.setCurrentKey(ProjectID)
  gridRef.value?.commitProxy('reload')
  resetProcessGridTable()
}

const handleAdvancedSearch = () => {
  const advancedSearchForm = gridHeaderRef.value?.advancedSearchForm
  const { ProjectID } = advancedSearchForm as Omit<GetStandardWorkTimeParams, 'ProductName'>
  basicTreeRef.value?.treeRef?.setCurrentKey(ProjectID)
  gridRef.value?.commitProxy('reload')
  resetProcessGridTable()
}

const [registerModal, { openModal, closeModal }] = useModal()
const [registerCopyModal, { openModal: openCopyModal, closeModal: closeCopyModal }] = useModal()

const handleCopy = (row: GetStandardWorkTimeModel) => {
  openCopyModal(true, { row })
}

const handleAdd = () => {
  const { projectID, orderProductName } = listParams
  if (!projectID) {
    ElMessage.warning('请选择项目列表')
    return
  }
  const list = basicTreeRef.value?.getTreeData as any[]
  const productList = list.filter((item) => item.id === projectID)[0]?.productList || []
  let product: any
  if (orderProductName) {
    product = productList.filter((p: { name: string }) => p.name === orderProductName)[0]
  }

  openModal(true, {
    isUpdate: false,
    projectID,
    productList,
    product
  })
}

const handleModify = (row: GetStandardWorkTimeModel) => {
  openModal(true, {
    isUpdate: true,
    row,
    projectID: row.projectID
  })
}

const handleHide = (row: GetStandardWorkTimeModel) => {
  ElMessageBox.confirm(`是否隐藏名称为"${row.productName}"的数据项`, '提示', {
    confirmButtonText: '确定',
    cancelButtonText: '取消',
    type: 'warning'
  }).then(() => {
    isIgnoreClick = true
    addStandardWorkTimeWoExInclude({
      projectID: row.projectID!,
      productName: row.productName!,
      orderNo: row.orderNo!
    })
      .then(({ code, message }) => {
        if (code === 200) {
          gridRef.value?.commitProxy('query')
        } else {
          ElMessage.error(message)
        }
      })
      .finally(() => {
        resetProcessGridTable()
      })
  })
}

const handleUnhide = (row: GetStandardWorkTimeModel) => {
  ElMessageBox.confirm(`是否取消隐藏名称为"${row.productName}"的数据项`, '提示', {
    confirmButtonText: '确定',
    cancelButtonText: '取消',
    type: 'warning'
  }).then(() => {
    isIgnoreClick = true
    deleteStandardWorkTimeWoExInclude({
      projectID: row.projectID!,
      productName: row.productName!,
      orderNo: row.orderNo!,
      parentProcessID: row.parentProcessID!
    })
      .then(({ code, message }) => {
        if (code === 200) {
          gridRef.value?.commitProxy('query')
        } else {
          ElMessage.error(message)
        }
      })
      .finally(() => {
        resetProcessGridTable()
      })
  })
}

const handleDelete = (row: GetStandardWorkTimeModel) => {
  ElMessageBox.confirm(`是否删除名称为"${row.productName}"的数据项`, '警告', {
    confirmButtonText: '确定',
    cancelButtonText: '取消',
    type: 'warning'
  }).then(() => {
    const data: DeleteStandardWorkTimeData = {
      orderNo: row.orderNo!,
      parentProcessID: row.parentProcessID!,
      productName: row.productName!,
      projectID: row.projectID!
    }
    deleteStandardWorkTime(data)
      .then((res) => {
        if (res.code === 200) {
          ElMessage.success('删除')
          gridRef.value?.commitProxy('query')
        } else {
          ElMessage.error(res.message)
        }
      })
      .finally(() => {
        resetProcessGridTable()
      })
  })
}

const handleSuccess = () => {
  gridRef.value?.clearCurrentRow()
  gridRef.value?.commitProxy('query')
  closeModal()
  resetProcessGridTable()
}

const handleCopySuccess = () => {
  gridRef.value?.clearCurrentRow()
  gridRef.value?.commitProxy('query')
  closeCopyModal()
  resetProcessGridTable()
}

const processGridHeaderRef = ref<ComponentExposed<typeof GridHeader>>()
const processHeaderOptions = reactive<GridHeaderProps>({
  title: '作业流程表',
  showQuickSearchButton: false,
  showAddButton: false,
  showAdvancedSearchButton: false
})

const processGridRef = ref<VxeGridInstance>()
const processGridOptions = reactive<VxeGridProps<GetStandardWorkTimeModel>>({
  border: true,
  height: '500px',
  align: null,
  columnConfig: {
    resizable: true
  },
  columns: [
    { type: 'seq', width: 50 },
    { field: 'processName', title: '作业流程', minWidth: 100 },
    {
      field: 'standardWorkHour',
      title: '标准工时(h)',
      minWidth: 120,
      formatter({ cellValue }) {
        return typeof cellValue === 'number' ? `${cellValue}h` : ''
      }
    },
    { field: 'workNumber', title: '作业人数', minWidth: 100 },
    { field: 'processCapacity', title: '工序产能', minWidth: 100 },
    { field: 'dataDescribe', title: '备注', minWidth: 300 }
  ],
  pagerConfig: {
    enabled: false
  },
  data: []
})

const resetProcessGridTable = () => {
  processHeaderOptions.title = `作业流程表`
  processGridRef.value?.loadData([])
}
</script>

<style scoped lang="scss">
.page-container {
  display: flex;
  padding: 0;
  .basic-list-container {
    margin: $margin;
    display: flex;
  }
  .grid-container {
    flex: 1;
    display: flex;
    flex-direction: column;
    .vxe-grid-container {
      margin: $margin $margin $margin 0;
    }
  }
}
</style>
