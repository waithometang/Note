<template>
  <BasicModal
    width="1000px"
    v-bind="$attrs"
    @register="registerModal"
    :title="getTitle"
    @confirm="handleSubmit"
  >
    <BasicForm @register="registerForm"> </BasicForm>
    <vxe-grid ref="gridRef" v-bind="gridOptions">
      <template #processID="{ row }">
        {{ formatProcessLabelFormat(row.processID) }}
      </template>
      <template #processID_edit="{ row }">
        <Select
          :disabled="!isInsertByRow(row) && isUpdate"
          v-model="row.processID"
          :options="processList"
          labelField="processType"
          valueField="id"
        ></Select>
      </template>
      <template #standardWorkHour_edit="{ row }">
        <el-input-number
          v-model="row.standardWorkHour"
          :min="0.001"
          :max="9999"
          :step="0.001"
          :precision="3"
          :stepStrictly="true"
        ></el-input-number>
      </template>
      <template #workNumber_edit="{ row }">
        <el-input-number
          v-model="row.workNumber"
          :min="1"
          :max="9999"
          :step="1"
          :stepStrictly="true"
        ></el-input-number>
      </template>
      <template #processCapacity_edit="{ row }">
        <el-input-number
          v-model="row.processCapacity"
          :min="1"
          :max="9999"
          :step="1"
          :stepStrictly="true"
        ></el-input-number>
      </template>
      <template #dataDescribe_edit="{ row }">
        <el-input v-model="row.dataDescribe"></el-input>
      </template>
      <template #operation="{ row }">
        <TableAction
          :actions="[
            {
              icon: 'edit-inline',
              tooltip: '编辑',
              onClick: handleModify.bind(null, row),
              ifShow: !hasActiveEditRow(row)
            },
            {
              icon: 'delete-inline',
              tooltip: '删除',
              onClick: handleDelete.bind(null, row),
              ifShow: !hasActiveEditRow(row)
            },
            {
              icon: 'cancle',
              tooltip: '取消',
              onClick: handleCancle.bind(null),
              ifShow: hasActiveEditRow(row)
            },
            {
              icon: 'save',
              tooltip: '保存',
              onClick: handleSave.bind(null),
              ifShow: hasActiveEditRow(row)
            }
          ]"
        />
      </template>
      <template #bottom>
        <TableAction
          style="margin-top: 10px"
          :actions="[
            {
              icon: 'plus',
              label: '新增流程',
              onClick: handleAdd.bind(null),
              style: {
                color: '#008cd6'
              }
            }
          ]"
        ></TableAction>
      </template>
    </vxe-grid>
  </BasicModal>
</template>

<script setup lang="ts">
import type {
  AddStandardWorkTimeData,
  GetProductionProcessModel,
  UpdateStandardWorkTimeData,
  StandardWorkTimeClassifyModel
} from '@/api/sys/model/basicModel'
import type { ModalMethods } from '@/components/Modal/types'
import type { VxeGridInstance, VxeGridProps } from 'vxe-table'

import { ref, unref, computed, reactive } from 'vue'

import BasicModal from '@/components/Modal/BasicModal.vue'
import BasicForm from '@/components/Form/BasicForm.vue'
import Select from '@/components/Form/components/Select.vue'

import { useModalInner } from '@/components/Modal/hooks/useModal'
import { useForm } from '@/components/Form/hooks/useForm'
import {
  addStandardWorkTime,
  updateStandardWorkTime,
  getProductionProjectSelect,
  getProductionProcessChildren
} from '@/api/sys/basic'
import { getProductionProjectAppointData } from '@/api/sys/scheduling'
import dayjs from 'dayjs'
import { unionBy } from 'lodash-es'

type tableModel = Omit<StandardWorkTimeClassifyModel, 'id'>

const emit = defineEmits<{
  register: [modalMethods: ModalMethods, uuid: number]
  success: [{ isUpdate: boolean }]
}>()
const isUpdate = ref<boolean>(false)

const rowId = ref<string>('')

const getTitle = computed(() => (!unref(isUpdate) ? '新增' : '修改'))
const gridRef = ref<VxeGridInstance>()

const processList = ref<GetProductionProcessModel[]>([])

const getProcessList = async (processTypeID: string) => {
  const { code, data } = await getProductionProcessChildren({
    processTypeID
  })
  if (code === 200) {
    processList.value = data.result
  } else {
    processList.value = []
  }
}

const gridOptions = reactive<VxeGridProps<tableModel>>({
  border: true,
  height: '400px',
  align: null,
  columnConfig: {
    resizable: true
  },
  keepSource: true,
  editConfig: {
    enabled: true,
    trigger: 'dblclick',
    mode: 'row',
    showIcon: false,
    showStatus: true,
    autoClear: false
  },
  editRules: {
    processID: [
      {
        required: true,
        trigger: 'manual',
        validator: ({ cellValue }) => {
          return new Promise((resolve, reject) => {
            if (cellValue) {
              const tableData = (gridRef.value?.getTableData().fullData || []) as tableModel[]
              const length = tableData.filter((item) => item.processID === cellValue).length
              if (length < 2) {
                resolve()
              } else {
                reject(new Error('作业流程重复'))
              }
            } else {
              reject(new Error('请输入作业流程'))
            }
          })
        }
      }
    ],
    standardWorkHour: [{ required: true, content: '请输入标准工时' }],
    workNumber: [{ required: true, content: '请输入作业人数' }],
    processCapacity: [{ required: true, content: '请输入工序产能' }]
  },
  columns: [
    { type: 'seq', width: 50 },
    {
      field: 'processID',
      title: '作业流程',
      editRender: {},
      slots: { default: 'processID', edit: 'processID_edit' }
      // formatter({ cellValue }) {
      //   return unref(processList).find((item) => item.id === cellValue)?.processType as string
      // }
    },
    {
      field: 'standardWorkHour',
      title: '标准工时',
      editRender: {},
      slots: {
        default({ row }) {
          return typeof row.standardWorkHour === 'number' ? `${row.standardWorkHour}h` : ''
        },
        edit: 'standardWorkHour_edit'
      }
    },
    {
      field: 'workNumber',
      title: '作业人数',
      editRender: {},
      slots: { edit: 'workNumber_edit' }
    },
    {
      field: 'processCapacity',
      title: '工序产能',
      editRender: {},
      slots: { edit: 'processCapacity_edit' }
    },
    {
      field: 'dataDescribe',
      title: '备注',
      editRender: {},
      slots: { edit: 'dataDescribe_edit' }
    },
    {
      field: 'operation',
      title: '操作',
      align: 'center',
      fixed: 'right',
      slots: {
        default: 'operation'
      }
    }
  ],
  data: []
})

const formatProcessLabelFormat = (id: string) => {
  return processList.value.find((item) => item.id === id)?.processType || id
}

const productionProjectList = ref<any[]>([])

const [
  registerForm,
  { setFieldsValue, resetFields, getFieldsValue, validate, clearValidate, updateSchema }
] = useForm({
  labelWidth: 100,
  schemas: [
    {
      field: 'projectID',
      component: 'ApiSelect',
      label: '项目名称',
      rules: [{ required: true, trigger: 'change' }],
      componentProps: {
        disabled: true,
        api: getProductionProjectSelect,
        resultField: 'data.result',
        labelField: 'projectName',
        valueField: 'id'
      },
      colProps: {
        span: 8
      }
    },
    {
      field: 'orderNo',
      component: 'Select',
      label: '需求分类',
      rules: [{ required: true, trigger: 'change' }],
      dynamicDisabled() {
        return unref(isUpdate)
      },
      componentProps: {
        // disabled: true
        valueField: 'orderNo',
        labelField: 'orderNo',
        async onChange(orderNo: string, row: any) {
          if (row) {
            await setFieldsValue({
              orderProductName: row.name
            })
          }
          if (!unref(isUpdate)) {
            await setFieldsValue({ parentProcessID: '' })
          }
          // 更新设备类型
          // 根据 processID 和 需求分类 去重
          const list = productionProjectList.value.filter(
            (obj, index, self) =>
              index ===
              self.findIndex((t) => t.processID === obj.processID && t.orderNo === orderNo)
          )
          updateSchema([
            {
              field: 'parentProcessID',
              componentProps: {
                options: list,
                labelField: 'processName',
                valueField: 'processID',
                async onChange(processID: string) {
                  if (!unref(isUpdate)) {
                    await setFieldsValue({ productName: '' })
                  }
                  const res = productionProjectList.value.filter(
                    (item) => item.processID === processID
                  )
                  const list = unionBy(res, 'productName')
                  // 更新部件名称
                  updateSchema([
                    {
                      field: 'productName',
                      componentProps: {
                        options: list,
                        labelField: 'productName',
                        valueField: 'productName'
                      }
                    }
                  ])

                  if (!unref(isUpdate)) {
                    // 更新作业流程表
                    await gridRef.value?.remove()
                    if (!processID) {
                      processList.value = []
                    } else {
                      await getProcessList(processID)
                    }
                    processList.value.forEach(async (item) => {
                      await gridRef.value?.insertAt(
                        {
                          processID: item.id,
                          standardWorkHour: 0.01,
                          workNumber: 1,
                          processCapacity: 1
                        },
                        -1
                      )
                    })
                  }
                }
              }
            }
          ])
        }
      },
      colProps: {
        span: 8
      }
    },
    // {
    //   field: 'woNo',
    //   component: 'ElInput',
    //   label: '单据编号',
    //   componentProps: {
    //     disabled: true
    //   },
    //   colProps: {
    //     span: 8
    //   }
    // },
    {
      field: 'orderProductName',
      component: 'ElInput',
      label: '设备名称',
      componentProps: {
        disabled: true
      },
      colProps: {
        span: 8
      }
    },
    {
      field: 'parentProcessID',
      component: 'Select',
      label: '设备类型',
      rules: [{ required: true, trigger: 'change' }],
      dynamicDisabled() {
        return unref(isUpdate)
      },
      colProps: {
        span: 8
      }
    },
    {
      field: 'productName',
      component: 'Select',
      label: '部件名称',
      rules: [{ required: true, trigger: 'change' }],
      dynamicDisabled() {
        return unref(isUpdate)
      },
      colProps: {
        span: 8
      }
    },
    {
      field: 'reportFinishType',
      component: 'Select',
      label: '完成率计算',
      defaultValue: 1,
      rules: [{ required: true, trigger: 'change' }],
      componentProps: {
        options: [
          {
            label: '按工时',
            value: 1
          },
          {
            label: '按数量',
            value: 2
          }
        ]
      },
      colProps: {
        span: 8
      }
    },
    {
      field: 'codeNumber',
      component: 'ElInput',
      label: '编码',
      rules: [{ required: true, trigger: 'blur' }],
      colProps: {
        span: 8
      }
    },
    {
      field: 'manufactureDate',
      component: 'ElDatePicker',
      label: '制定日期',
      defaultValue: dayjs().format('YYYY-MM-DD'),
      rules: [{ required: true, trigger: 'change' }],
      componentProps: {
        valueFormat: 'YYYY-MM-DD'
      },
      colProps: {
        span: 8
      }
    }
  ]
})

const [registerModal, { setModalProps }] = useModalInner(async (data) => {
  await updateSchema([
    { field: 'productName', componentProps: { options: [] } },
    { field: 'orderNo', componentProps: { options: data.productList } }
  ])
  await resetFields()
  const { code, data: res } = await getProductionProjectAppointData({ projectID: data.projectID })
  if (code === 200) {
    productionProjectList.value = res.result
  } else {
    productionProjectList.value = []
  }
  setModalProps({ confirmLoading: false })
  isUpdate.value = !!data?.isUpdate

  await setFieldsValue({
    projectID: data.projectID,
    orderNo: data.product?.orderNo,
    orderProductName: data.product?.name
  })

  if (unref(isUpdate)) {
    rowId.value = data.row.id
    await setFieldsValue({ ...data.row })
    getProcessList(data.row.parentProcessID)
    gridRef.value?.loadData(data.row.standardWorkTimeClassifyModel)
  } else {
    await gridRef.value?.remove()
  }

  clearValidate()
})

const handleAdd = async () => {
  if (gridRef.value) {
    const data = getFieldsValue() as AddStandardWorkTimeData
    if (!data.productName) {
      ElMessage.warning('请先选择产品')
      return
    }
    const { row } = await gridRef.value.insertAt(
      {
        processID: '',
        standardWorkHour: 0.01,
        workNumber: 1,
        processCapacity: 1
      },
      -1
    )
    gridRef.value.setEditRow(row)
  }
}

// 判断是否编辑活跃行
const hasActiveEditRow = (row: tableModel): boolean => {
  const $grid = gridRef.value
  if ($grid) {
    return $grid.isEditByRow(row)
  }
  return false
}

const handleModify = (row: tableModel) => {
  gridRef.value?.setEditRow(row)
}

const handleDelete = (row: StandardWorkTimeClassifyModel) => {
  ElMessageBox.confirm(
    `是否删除名称为"${formatProcessLabelFormat(row.processID)}"的数据项`,
    '警告',
    {
      confirmButtonText: '确定',
      cancelButtonText: '取消',
      type: 'warning'
    }
  ).then(() => {
    gridRef.value?.remove(row)
  })
}

// 取消
const handleCancle = () => {
  gridRef.value?.clearEdit()
}

// 保存
const handleSave = async () => {
  await gridRef.value?.clearEdit()
}

const isInsertByRow = (row: StandardWorkTimeClassifyModel) => {
  return gridRef.value?.isInsertByRow(row)
}

// 提交
const handleSubmit = async () => {
  await validate()
  setModalProps({ confirmLoading: true })
  try {
    await gridRef.value?.clearEdit()
    const errMap = await gridRef.value?.fullValidate()

    if (errMap) {
      return
    }

    // 新增
    if (!unref(isUpdate)) {
      const formData = getFieldsValue() as Omit<AddStandardWorkTimeData, 'addStandardworkTimeModel'>
      const tableData = gridRef.value?.getTableData().fullData as tableModel[]

      const data: AddStandardWorkTimeData = {
        codeNumber: formData.codeNumber,
        woNo: formData.woNo,
        productName: formData.productName,
        manufactureDate: formData.manufactureDate,
        reportFinishType: formData.reportFinishType,
        projectID: formData.projectID,
        parentProcessID: formData.parentProcessID,
        orderNo: formData.orderNo,
        addStandardworkTimeModel: tableData?.map((item) => {
          return {
            // projectID: formData.projectID,
            // productName: formData.productName,
            processID: item.processID,
            // parentProcessID: formData.parentProcessID,
            // codeNumber: formData.codeNumber,
            standardWorkHour: item.standardWorkHour,
            // reportFinishType: formData.reportFinishType,
            workNumber: item.workNumber,
            processCapacity: item.processCapacity,
            dataDescribe: item.dataDescribe
            // manufactureDate: formData.manufactureDate
          }
        })
      }
      const { code, message } = await addStandardWorkTime(data)
      if (code === 200) {
        ElMessage.success('新增成功')
        emit('success', { isUpdate: unref(isUpdate) })
      } else {
        ElMessage.error(message)
      }
    } else {
      if (rowId.value === '0') {
        const formData = getFieldsValue() as Omit<
          AddStandardWorkTimeData,
          'addStandardworkTimeModel'
        >
        const tableData = gridRef.value?.getTableData().fullData as tableModel[]

        const data: AddStandardWorkTimeData = {
          codeNumber: formData.codeNumber,
          woNo: formData.woNo,
          productName: formData.productName,
          manufactureDate: formData.manufactureDate,
          reportFinishType: formData.reportFinishType,
          projectID: formData.projectID,
          parentProcessID: formData.parentProcessID,
          orderNo: formData.orderNo,
          addStandardworkTimeModel: tableData?.map((item) => {
            return {
              // projectID: formData.projectID,
              // productName: formData.productName,
              processID: item.processID,
              // parentProcessID: formData.parentProcessID,
              // codeNumber: formData.codeNumber,
              standardWorkHour: item.standardWorkHour,
              // reportFinishType: formData.reportFinishType,
              workNumber: item.workNumber,
              processCapacity: item.processCapacity,
              dataDescribe: item.dataDescribe
              // manufactureDate: formData.manufactureDate
            }
          })
        }
        const { code, message } = await addStandardWorkTime(data)
        if (code === 200) {
          ElMessage.success('新增成功')
          emit('success', { isUpdate: unref(isUpdate) })
        } else {
          ElMessage.error(message)
        }
      } else {
        const formData = getFieldsValue() as AddStandardWorkTimeData
        const tableData = gridRef.value?.getTableData().fullData as (tableModel & { id: string })[]

        const data: UpdateStandardWorkTimeData = {
          id: rowId.value,
          codeNumber: formData.codeNumber,
          manufactureDate: formData.manufactureDate,
          reportFinishType: formData.reportFinishType,
          updateStandardworkTimeModel: tableData?.map((item) => {
            return {
              id: item.id,
              // processID: item.processID,
              // codeNumber: formData.codeNumber,
              // standardWorkHour: item.standardWorkHour,
              // reportFinishType: formData.reportFinishType,
              // workNumber: item.workNumber,
              // processCapacity: item.processCapacity,
              // manufactureDate: formData.manufactureDate

              processID: item.processID,
              standardWorkHour: item.standardWorkHour,
              workNumber: item.workNumber,
              processCapacity: item.processCapacity,
              dataDescribe: item.dataDescribe
            }
          })
        }

        const { code, message } = await updateStandardWorkTime(data)

        if (code === 200) {
          ElMessage.success('修改成功')
          emit('success', { isUpdate: unref(isUpdate) })
        } else {
          ElMessage.error(message)
        }
      }
    }
  } catch (error: any) {
    ElMessage(error.message)
  } finally {
    setModalProps({ confirmLoading: false })
  }
}
</script>
<style lang="scss" scoped>
.el-input-number {
  width: auto;
}
</style>
