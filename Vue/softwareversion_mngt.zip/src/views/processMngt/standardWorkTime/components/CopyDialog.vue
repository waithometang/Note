<template>
  <BasicModal
    width="900px"
    v-bind="$attrs"
    @register="registerModal"
    title="复制"
    @confirm="handleSubmit"
  >
    <div class="title">源项目</div>
    <BasicForm @register="registerForm" />
    <el-divider />
    <div class="title">目标项目</div>
    <BasicForm @register="registerTargetForm" />
  </BasicModal>
</template>

<script setup lang="ts">
import type {
  CopyStandardWorkTimeData,
  AddStandardWorkTimeModel,
  AddStandardWorkTimeData
} from '@/api/sys/model/basicModel'
import type { ModalMethods } from '@/components/Modal/types'
import type { VxeGridInstance } from 'vxe-table'

import { ref } from 'vue'

import BasicModal from '@/components/Modal/BasicModal.vue'
import BasicForm from '@/components/Form/BasicForm.vue'

import { useModalInner } from '@/components/Modal/hooks/useModal'
import { useForm } from '@/components/Form/hooks/useForm'
import {
  copyStandardWorkTime,
  getProductionProcessTopLevel,
  getProductionProjectSelect
} from '@/api/sys/basic'
import { getProductionProjectAppointData } from '@/api/sys/scheduling'
import dayjs from 'dayjs'
import { unionBy } from 'lodash-es'

const emit = defineEmits<{
  register: [modalMethods: ModalMethods, uuid: number]
  success: []
}>()

const gridRef = ref<VxeGridInstance>()

const [registerForm, { setFieldsValue, resetFields, getFieldsValue }] = useForm({
  labelWidth: 100,
  schemas: [
    {
      field: 'projectID',
      component: 'ApiSelect',
      label: '项目名称',
      rules: [{ required: true, trigger: 'change' }],
      componentProps: {
        api: getProductionProjectSelect,
        resultField: 'data.result',
        labelField: 'projectName',
        valueField: 'id',
        disabled: true,
        async onChange(projectID: string) {
          await setTargetFieldsValue({ productName: '' })
          await updateTargetSchema({ field: 'productName', componentProps: { options: [] } })
          if (projectID) {
            const { code, data } = await getProductionProjectAppointData({ projectID })
            if (code === 200) {
              await updateTargetSchema({
                field: 'productName',
                componentProps: {
                  options: unionBy(data.result, 'productName')
                }
              })
            }
          }
        }
      },
      colProps: {
        span: 8
      }
    },
    {
      field: 'orderNo',
      component: 'ElInput',
      label: '需求分类',
      componentProps: {
        disabled: true
      },
      colProps: {
        span: 8
      }
    },
    {
      field: 'orderProductName',
      component: 'ElInput',
      label: '设备名称',
      componentProps: {
        disabled: true
      },
      colProps: {
        span: 8
      }
    },
    {
      field: 'parentProcessID',
      component: 'ApiSelect',
      label: '设备类型',
      rules: [{ required: true, trigger: 'change' }],
      componentProps: {
        api: getProductionProcessTopLevel,
        resultField: 'data.result',
        labelField: 'processType',
        valueField: 'id',
        disabled: true
      },
      colProps: {
        span: 8
      }
    },
    {
      field: 'productName',
      component: 'ElInput',
      label: '部件名称',
      rules: [{ required: true, trigger: 'blur' }],
      componentProps: {
        disabled: true
      },
      colProps: {
        span: 8
      }
    }
    // {
    //   field: 'woNo',
    //   component: 'ElInput',
    //   label: '单据编号',
    //   componentProps: {
    //     disabled: true
    //   },
    //   colProps: {
    //     span: 8
    //   }
    // }
  ]
})
const [
  registerTargetForm,
  {
    setFieldsValue: setTargetFieldsValue,
    resetFields: resetTargetFields,
    getFieldsValue: getTargetFieldsValue,
    validate: validateTarget,
    clearValidate: clearValidateTarget,
    updateSchema: updateTargetSchema
  }
] = useForm({
  labelWidth: 100,
  schemas: [
    // {
    //   field: 'projectID',
    //   component: 'ApiSelect',
    //   label: '项目名称',
    //   rules: [{ required: true, trigger: 'change' }],
    //   componentProps: {
    //     api: getProductionProjectSelect,
    //     resultField: 'data.result',
    //     labelField: 'projectName',
    //     valueField: 'id',
    //     async onChange(projectID: string) {
    //       await setTargetFieldsValue({ productName: '' })

    //       await updateTargetSchema({ field: 'productName', componentProps: { options: [] } })
    //       if (projectID) {
    //         const { code, data } = await getProductionProjectAppointData({ projectID })
    //         if (code === 200) {
    //           await updateTargetSchema({
    //             field: 'productName',
    //             componentProps: {
    //               options: data.result,
    //               onChange(productName: string) {
    //                 const processID = getTargetFieldsValue().parentProcessID
    //                 const res = data.result.filter(
    //                   (item) => item.productName === productName && item.processID === processID
    //                 )[0]
    //                 setTargetFieldsValue({
    //                   orderNo: res?.orderNo,
    //                   woNo: res?.woNo,
    //                   orderProductName: res?.orderProductName
    //                 })
    //               }
    //             }
    //           })
    //         }
    //       }
    //     }
    //   },
    //   colProps: {
    //     span: 8
    //   }
    // },
    {
      field: 'productName',
      component: 'Select',
      label: '部件名称',
      rules: [{ required: true, trigger: 'change' }],
      componentProps: {
        options: [],
        labelField: 'productName',
        valueField: 'productName'
      },
      colProps: {
        span: 8
      }
    },
    // {
    //   field: 'parentProcessID',
    //   component: 'ApiSelect',
    //   label: '设备类型',
    //   rules: [{ required: true, trigger: 'change' }],
    //   componentProps: {
    //     api: getProductionProcessTopLevel,
    //     resultField: 'data.result',
    //     labelField: 'processType',
    //     valueField: 'id',
    //     disabled: true
    //   },
    //   colProps: {
    //     span: 8
    //   }
    // },
    // {
    //   field: 'orderNo',
    //   component: 'ElInput',
    //   label: '需求分类',
    //   componentProps: {
    //     disabled: true
    //   },
    //   colProps: {
    //     span: 8
    //   }
    // },
    // {
    //   field: 'woNo',
    //   component: 'ElInput',
    //   label: '单据编号',
    //   componentProps: {
    //     disabled: true
    //   },
    //   colProps: {
    //     span: 8
    //   }
    // },
    // {
    //   field: 'orderProductName',
    //   component: 'ElInput',
    //   label: '设备名称',
    //   componentProps: {
    //     disabled: true
    //   },
    //   colProps: {
    //     span: 8
    //   }
    // },
    {
      field: 'codeNumber',
      component: 'ElInput',
      label: '编码',
      rules: [{ required: true, trigger: 'blur' }],
      colProps: {
        span: 8
      }
    },
    {
      field: 'manufactureDate',
      component: 'ElDatePicker',
      label: '制定日期',
      rules: [{ required: true, trigger: 'change' }],
      defaultValue: dayjs().format('YYYY-MM-DD'),
      componentProps: {
        valueFormat: 'YYYY-MM-DD'
      },
      colProps: {
        span: 8
      }
    }
  ]
})

const rowId = ref()

const [registerModal, { setModalProps }] = useModalInner(async (data) => {
  setModalProps({ confirmLoading: false })
  await updateTargetSchema({
    field: 'parentProcessID',
    componentProps: { disabled: true }
  })
  rowId.value = data.row.id
  await updateTargetSchema({ field: 'productName', componentProps: { options: [] } })
  await resetFields()
  await resetTargetFields()
  await setFieldsValue({ ...data.row })
  await setTargetFieldsValue({
    parentProcessID: data.row.parentProcessID,
    projectID: data.row.projectID
  })
  clearValidateTarget()
})

// 提交
const handleSubmit = async () => {
  await validateTarget()
  setModalProps({ confirmLoading: true })
  try {
    await gridRef.value?.clearEdit()
    const errMap = await gridRef.value?.fullValidate()
    if (errMap) {
      return
    }
    const formData = getFieldsValue() as AddStandardWorkTimeData
    const targetData = getTargetFieldsValue() as AddStandardWorkTimeData
    const data: CopyStandardWorkTimeData = {
      sourceID: rowId.value,
      // parentProcessID: targetData.parentProcessID,
      // projectID: targetData.projectID,
      productName: targetData.productName,
      codeNumber: targetData.codeNumber,
      manufactureDate: targetData.manufactureDate
    }
    const { code, message } = await copyStandardWorkTime(data)
    if (code === 200) {
      ElMessage.success('新增成功')
      emit('success')
    } else {
      ElMessage.error(message)
    }
  } catch (error: any) {
    ElMessage(error.message)
  } finally {
    setModalProps({ confirmLoading: false })
  }
}
</script>
<style lang="scss" scoped>
.el-input-number {
  width: auto;
}
.title {
  margin: 20px 0 10px;
  font-weight: 700;
}
</style>
