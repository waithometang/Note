<template>
  <BasicModal
    width="756px"
    v-bind="$attrs"
    @register="registerModal"
    :title="getTitle"
    @confirm="handleSubmit"
  >
    <BasicForm @register="registerForm">
      <template #scheduleRestTime>
        <vxe-grid ref="gridRef" v-bind="gridOptions" @editClosed="handleEditClosed">
          <template #startRestTime_edit="{ row }">
            <el-time-picker v-model="row.startRestTime" format="HH:mm"></el-time-picker>
          </template>
          <template #endRestTime_edit="{ row }">
            <el-time-picker v-model="row.endRestTime" format="HH:mm"></el-time-picker>
          </template>
          <template #operation="{ row, rowIndex }">
            <TableAction
              :actions="[
                {
                  icon: 'delete',
                  tooltip: '删除',
                  onClick: handleDelete.bind(null, row, rowIndex)
                }
              ]"
            />
          </template>
          <template #bottom>
            <TableAction
              :actions="[
                {
                  icon: 'plus',
                  label: '添加',
                  onClick: handleAddRestTime.bind(null),
                  style: {
                    color: '#008cd6'
                  }
                }
              ]"
            ></TableAction>
          </template>
        </vxe-grid>
      </template>
      <template #workTime="{ model, field }"> {{ model[field] }} </template>
    </BasicForm>
  </BasicModal>
</template>

<script lang="ts" setup>
import type { VxeGridInstance, VxeGridProps } from 'vxe-table'
import type { AddScheduleData, UpdateScheduleData } from '@/api/sys/model/basicModel'
import type { ModalMethods } from '@/components/Modal/types'

import { computed, ref, unref, reactive } from 'vue'
import BasicModal from '@/components/Modal/BasicModal.vue'
import { useModalInner } from '@/components/Modal/hooks/useModal'
import BasicForm from '@/components/Form/BasicForm.vue'
import { useForm } from '@/components/Form/hooks/useForm'

import { addSchedule, updateSchedule } from '@/api/sys/basic'
import dayjs from 'dayjs'

type RestTime = {
  startRestTime: string
  endRestTime: string
}

function diffTime(start: string, end: string) {
  let endTime = dayjs(end)
  const startime = dayjs(start)

  if (startime.isAfter(endTime)) {
    endTime = endTime.add(1, 'day')
  }

  return dayjs.duration(endTime.diff(startime))
}

const handleTimeChange = () => {
  const data = getFieldsValue() as AddScheduleData
  const workTime = diffTime(data.startWorkTime, data.endWorkTime)
  const restTime = getRestTime(gridRef.value?.getTableData().fullData)
  const time = workTime.subtract(restTime)
  if (!data.isRest) {
    setFieldsValue({
      workTime: `${workTime.hours()}小时${Math.abs(workTime.minutes())}分钟`
    })
    return
  }
  if (time.asMilliseconds() < 0) {
    setFieldsValue({
      workTime: `0小时0分钟`
    })
  } else {
    setFieldsValue({
      workTime: `${time.hours()}小时${Math.abs(time.minutes())}分钟`
    })
  }
}

const handleEditClosed = () => {
  handleTimeChange()
}

const emit = defineEmits<{
  register: [modalMethods: ModalMethods, uuid: number]
  success: [{ isUpdate: boolean }]
}>()

const isUpdate = ref<boolean>(false)
const rowId = ref('')

const getTitle = computed(() => (!unref(isUpdate) ? '新增' : '修改'))

const gridRef = ref<VxeGridInstance>()
const gridOptions = reactive<VxeGridProps<RestTime>>({
  border: true,
  minHeight: '100px',
  maxHeight: '200px',
  align: null,
  columnConfig: {
    resizable: true
  },
  keepSource: true,
  editConfig: {
    enabled: true,
    trigger: 'click',
    mode: 'row',
    showIcon: false,
    showStatus: true,
    // autoClear: false,
    beforeEditMethod() {
      const data = getFieldsValue()
      return data.isRest
    }
  },
  editRules: {
    startRestTime: [
      {
        required: true,
        message: '请输入',
        trigger: 'manual',
        validator: ({ cellValue }) => {
          return new Promise((resolve, reject) => {
            if (!cellValue) {
              reject(new Error('无效输入'))
              return
            }

            const data = getFieldsValue() as AddScheduleData

            let endTime = dayjs(data.endWorkTime)
            const startime = dayjs(data.startWorkTime)

            if (startime.isAfter(endTime)) {
              endTime = endTime.add(1, 'day')
            }

            let restTime = dayjs(cellValue)
            if (restTime.isBefore(startime)) {
              restTime = restTime.add(1, 'day')
            }

            const flag = restTime.isBetween(startime, endTime, null, '[]')
            if (flag) {
              resolve()
            } else {
              reject(new Error('休息时间必须在上班时间内'))
            }
          })
        }
      }
    ],
    endRestTime: [
      {
        required: true,
        message: '请输入',
        trigger: 'manual',
        validator: ({ cellValue, row }) => {
          return new Promise((resolve, reject) => {
            if (!cellValue) {
              reject(new Error('无效输入'))
              return
            }
            const data = getFieldsValue() as AddScheduleData
            let endTime = dayjs(data.endWorkTime)
            const startime = dayjs(data.startWorkTime)

            if (startime.isAfter(endTime)) {
              endTime = endTime.add(1, 'day')
            }

            let restStartTime = dayjs(row.startRestTime)
            if (restStartTime.isBefore(startime)) {
              restStartTime = restStartTime.add(1, 'day')
            }
            let restEndTime = dayjs(cellValue)
            if (restEndTime.isBefore(startime)) {
              restEndTime = restEndTime.add(1, 'day')
            }

            const flag = restEndTime.isBetween(restStartTime, endTime, null, '[]')
            if (flag) {
              resolve()
            } else {
              reject(new Error('休息时间必须在上班时间内'))
            }
          })
        }
      }
    ]
  },
  columns: [
    { type: 'seq', width: 50 },
    {
      field: 'startRestTime',
      title: '休息开始',
      editRender: {},
      slots: { edit: 'startRestTime_edit' },
      formatter({ cellValue }) {
        return dayjs(cellValue).format('HH:mm')
      }
    },
    {
      field: 'endRestTime',
      title: '休息结束',
      editRender: {},
      slots: { edit: 'endRestTime_edit' },
      formatter({ cellValue }) {
        return dayjs(cellValue).format('HH:mm')
      }
    },
    {
      field: 'operation',
      title: '操作',
      align: 'center',
      fixed: 'right',
      slots: {
        default: 'operation'
      }
    }
  ],
  data: []
})

const [registerForm, { setFieldsValue, resetFields, getFieldsValue, validate }] = useForm({
  labelWidth: 120,
  schemas: [
    {
      field: 'scheduleName',
      component: 'ElInput',
      label: '班次名称',
      rules: [{ required: true, trigger: 'blur' }]
    },
    {
      field: 'startWorkTime',
      component: 'ElTimePicker',
      label: '上班时间',
      rules: [{ required: true, trigger: 'change' }],
      componentProps: {
        format: 'HH:mm',
        valueFormat: 'YYYY/MM/DD HH:mm',
        onBlur: handleTimeChange
      },
      colProps: {
        span: 12
      }
    },
    {
      field: 'endWorkTime',
      component: 'ElTimePicker',
      label: '下班时间',
      rules: [{ required: true, trigger: 'change' }],
      componentProps: {
        format: 'HH:mm',
        valueFormat: 'YYYY/MM/DD HH:mm',
        onBlur: handleTimeChange
      },
      colProps: {
        span: 12
      }
    },
    {
      field: 'isRest',
      component: 'ElSwitch',
      label: '休息时间',
      defaultValue: false,
      componentProps: {
        onChange() {
          handleTimeChange()
        }
      }
    },
    {
      field: 'scheduleRestTime',
      component: 'ElInput',
      label: '休息表',
      slot: 'scheduleRestTime'
    },
    {
      field: 'workTime',
      component: 'ElInput',
      label: '合计工作时长',
      defaultValue: '0小时0分钟',
      slot: 'workTime'
    }
  ]
})

const _resetFields = () => {
  gridRef.value?.loadData([])
  resetFields()
}

const [registerModal, { setModalProps, changeOkLoading }] = useModalInner(async (data) => {
  _resetFields()
  setModalProps({ confirmLoading: false })
  isUpdate.value = !!data?.isUpdate

  // 修改设置表单
  if (unref(isUpdate)) {
    rowId.value = data.row.id

    await setFieldsValue({
      ...data.row,
      startWorkTime: dayjs().format('YYYY/MM/DD') + ' ' + data.row.scheduleTime.split('-')[0],
      endWorkTime: dayjs().format('YYYY/MM/DD') + ' ' + data.row.scheduleTime.split('-')[1],
      workTime: `${data.row.workTime.split('.')[0]}小时${data.row.workTime.split('.')[1]}分钟`,
      isRest: data.row.isRest ? true : false
    })

    if (data.row.scheduleRestTime !== null) {
      const tableData = (data.row.scheduleRestTime as RestTime[]).map((item) => ({
        startRestTime: dayjs().format('YYYY/MM/DD') + ' ' + item.startRestTime,
        endRestTime: dayjs().format('YYYY/MM/DD') + ' ' + item.endRestTime
      }))
      gridRef.value?.loadData(tableData)
    } else {
      gridRef.value?.loadData([])
    }
    handleTimeChange()
  }
})

const handleAddRestTime = () => {
  const data = getFieldsValue() as AddScheduleData
  if (data.isRest) {
    gridRef.value?.insertAt(
      {
        startRestTime: data.startWorkTime,
        endRestTime: dayjs(data.startWorkTime).add(1, 'minute').toJSON()
      },
      -1
    )
    handleTimeChange()
  } else {
    ElMessage.warning('请开启休息时间')
  }
}

const handleDelete = async (row: any, index: number) => {
  const data = getFieldsValue() as AddScheduleData
  if (data.isRest) {
    await ElMessageBox.confirm(`是否删除序号为"${index + 1}"的数据项`, '警告', {
      confirmButtonText: '确定',
      cancelButtonText: '取消',
      type: 'warning'
    })
    gridRef.value?.remove(row)
    handleTimeChange()
  } else {
    ElMessage.warning('请开启休息时间')
  }
}

const getRestTime = (restTimeData?: RestTime[]) => {
  let sum = dayjs.duration(0)

  restTimeData?.forEach((data) => {
    sum = sum.add(diffTime(data.startRestTime, data.endRestTime))
  })

  return sum
}

// 提交
const handleSubmit = async () => {
  console.log(getFieldsValue())

  await validate()
  try {
    // validate()
    changeOkLoading(true)

    // 新增
    if (!unref(isUpdate)) {
      const data = getFieldsValue() as AddScheduleData

      const errMap = await gridRef.value?.fullValidate()

      if (errMap) {
        ElMessage.warning({ type: 'error', message: '校验不通过！' })
        return
      }

      const workTime = diffTime(data.startWorkTime, data.endWorkTime)
      const restTime = getRestTime(gridRef.value?.getTableData().fullData)
      if (workTime.subtract(restTime).asMinutes() <= 0) {
        ElMessage.warning('休息总时长不能超过上下班总时长')
        return
      }

      data['restTimeData'] = gridRef.value!.getTableData().fullData.map((item) => ({
        startRestTime: item.startRestTime,
        endRestTime: item.endRestTime
      }))
      data['isRest'] = data['isRest'] ? 1 : 0

      const { code, message } = await addSchedule(data)
      if (code === 200) {
        ElMessage.success('新增成功')
        emit('success', { isUpdate: unref(isUpdate) })
      } else {
        ElMessage.error(message)
      }
    } else {
      const data = getFieldsValue() as Omit<UpdateScheduleData, 'id'>

      const formData: UpdateScheduleData = {
        id: unref(rowId),
        ...data
      }

      const errMap = await gridRef.value?.fullValidate()

      if (errMap) {
        return
      }

      const workTime = diffTime(data.startWorkTime, data.endWorkTime)
      const restTime = getRestTime(gridRef.value?.getTableData().fullData)
      if (workTime.subtract(restTime).asMinutes() <= 0) {
        ElMessage.warning('休息总时长不能超过上下班总时长')
        return
      }

      formData['restTimeData'] = gridRef.value!.getTableData().fullData.map((item) => ({
        startRestTime: item.startRestTime,
        endRestTime: item.endRestTime
      }))
      formData['isRest'] = formData['isRest'] ? 1 : 0

      const { code, message } = await updateSchedule(formData)
      if (code === 200) {
        ElMessage.success('修改成功')
        emit('success', { isUpdate: unref(isUpdate) })
      } else {
        ElMessage.error(message)
      }
    }
  } catch (error: any) {
    ElMessage(error.message)
  } finally {
    changeOkLoading(false)
  }
}
</script>

<style lang="scss" scoped>
:deep(.el-date-editor.el-input, .el-date-editor.el-input__wrapper) {
  width: auto;
}
</style>
