<template>
  <div class="page-container">
    <vxe-grid class="box" ref="gridRef" v-bind="gridOptions">
      <template #top>
        <GridHeader
          ref="gridHeaderRef"
          v-bind="headerOptions"
          @quickSearch="handleQuickSearch"
          @add="handleAdd"
        />
      </template>
      <template #operation="{ row }">
        <TableAction
          :actions="[
            {
              icon: 'edit',
              tooltip: '编辑',
              onClick: handleModify.bind(null, row)
            },
            {
              icon: 'delete',
              tooltip: '删除',
              onClick: handleDelete.bind(null, row)
            }
          ]"
        />
      </template>
    </vxe-grid>
  </div>

  <ScheduleDialog @register="registerModal" @success="handleSuccess" />
</template>

<script setup lang="ts">
import type { ComponentExposed } from 'vue-component-type-helpers'
import type { VxeGridInstance, VxeGridProps } from 'vxe-table'
import type { GridHeaderProps } from '@/components/Table/types/gridHeader'
import type { GetScheduleModel } from '@/api/sys/model/basicModel'

import { reactive, ref } from 'vue'
import { deleteSchedule, getSchedule } from '@/api/sys/basic'

import { useModal } from '@/components/Modal/hooks/useModal'

import GridHeader from '@/components/Table/GridHeader.vue'
import ScheduleDialog from './components/ScheduleDialog.vue'

defineOptions({
  name: 'Schedule',
  inheritAttrs: false
})

const gridHeaderRef = ref<ComponentExposed<typeof GridHeader>>()

const headerOptions = reactive<GridHeaderProps>({
  title: '班次信息',
  quickSearch: {
    singleSearch: {
      field: 'scheduleName',
      type: 'input',
      title: '班次名称'
    },
    searchFormFields: { scheduleName: '' }
  },
  showAdvancedSearchButton: false
})

const gridRef = ref<VxeGridInstance>()
const gridOptions = reactive<VxeGridProps<GetScheduleModel>>({
  border: true,
  height: 'auto',
  align: null,
  columnConfig: {
    resizable: true
  },
  columns: [
    { type: 'seq', width: 50 },
    { field: 'scheduleName', title: '班次名称', width: 150 },
    { field: 'scheduleTime', title: '考勤时间', width: 150 },
    { field: 'restTime', title: '休息时长(h)', width: 150 },
    { field: 'workTime', title: '合计工作时长(h)', width: 150 },
    { field: 'createUserName', title: '创建用户' },
    { field: 'createTime', title: '创建时间' },
    { field: 'lastModifiedUserName', title: '最后修改用户' },
    { field: 'lastModifiedTime', title: '最后修改时间' },
    {
      field: 'operation',
      title: '操作',
      align: 'center',
      fixed: 'right',
      width: 150,
      slots: {
        default: 'operation'
      }
    }
  ],
  pagerConfig: {
    enabled: true,
    pageSize: 20
  },
  proxyConfig: {
    ajax: {
      query: ({ page }) => {
        const quickSearchForm = gridHeaderRef.value?.quickSearchForm
        const advancedSearchForm = gridHeaderRef.value?.advancedSearchForm
        return getSchedule({
          pageIndex: page.currentPage - 1, // 由于后端接口限制，首页从0开始
          pageSize: page.pageSize,
          ...quickSearchForm,
          ...advancedSearchForm
        })
      }
    }
  }
})

const handleQuickSearch = () => {
  gridRef.value?.commitProxy('reload')
}

const [registerModal, { openModal, closeModal }] = useModal()

const handleAdd = () => {
  openModal(true, {
    isUpdate: false
  })
}

const handleModify = (row: GetScheduleModel) => {
  openModal(true, {
    isUpdate: true,
    row
  })
}

const handleDelete = (row: GetScheduleModel) => {
  ElMessageBox.confirm(`是否删除名称为"${row.scheduleName}"的数据项`, '警告', {
    confirmButtonText: '确定',
    cancelButtonText: '取消',
    type: 'warning'
  }).then(() => {
    deleteSchedule({ id: row.id }).then((res) => {
      if (res.code === 200) {
        ElMessage.success('删除')
        gridRef.value?.commitProxy('query')
      } else {
        ElMessage.error(res.message)
      }
    })
  })
}

const handleSuccess = ({ isUpdate }: { isUpdate: boolean }) => {
  gridRef.value?.commitProxy('query')
  closeModal()
}
</script>

<style scoped></style>
