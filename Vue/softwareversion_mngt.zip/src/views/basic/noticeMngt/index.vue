<template>
  <div class="page-container">
    <vxe-grid class="box" ref="gridRef" v-bind="gridOptions">
      <template #top>
        <GridHeader
          ref="gridHeaderRef"
          v-bind="headerOptions"
          @quickSearch="handleQuickSearch"
          @add="handleAdd"
          @advancedSearch="handleAdvancedSearch"
          @reset="handleReset"
        />
      </template>
      <template #orderStatus="{ row }">
        <el-tag :type="getOrderStatusInfo(row.orderStatus).type">
          {{ getOrderStatusInfo(row.orderStatus).text }}
        </el-tag>
      </template>
      <template #operation="{ row }">
        <TableAction
          :actions="[
            {
              icon: 'edit',
              tooltip: '编辑',
              onClick: handleModify.bind(null, row)
            },
            {
              icon: 'delete',
              tooltip: '删除',
              onClick: handleDelete.bind(null, row)
            }
          ]"
        />
      </template>
    </vxe-grid>
    <NoticeMngtDialog @register="registerModal" @success="handleSuccess" />
  </div>
</template>

<script setup lang="ts">
import type { ComponentExposed } from 'vue-component-type-helpers'
import type { GetNoticeMngtModel, GetNoticeMngtParams } from '@/api/sys/model/basicModel'
import type { VxeGridInstance, VxeGridProps } from 'vxe-table'
import type { GridHeaderProps } from '@/components/Table/types/gridHeader'

import { reactive, ref, computed } from 'vue'
import GridHeader from '@/components/Table/GridHeader.vue'
import TableAction from '@/components/Table/TableAction.vue'
import NoticeMngtDialog from './components/NoticeMngtDialog.vue'

import { deleteNoticeMngt, getNoticeMngt } from '@/api/sys/basic'
import { useModal } from '@/components/Modal/hooks/useModal'
import { error } from '@/utils/log'
import { noticeFrequencyType } from './data'

defineOptions({ name: 'NoticeMngt', inheritAttrs: false })
const gridHeaderRef = ref<ComponentExposed<typeof GridHeader<GetNoticeMngtParams, 'SearchKey'>>>()

const headerOptions = reactive<GridHeaderProps>({
  title: '通知管理',
  quickSearch: {
    singleSearch: {
      field: 'SearchKey',
      type: 'input',
      title: '消息类型'
    },
    searchFormFields: { SearchKey: '' }
  },
  showAdvancedSearchButton: false
})

const getOrderStatusInfo = computed(() => {
  const statusMap: { [key: number]: { text: string; type: string } } = {
    1: { text: '已启用', type: 'success' },
    2: { text: '已停用', type: 'danger' }
  }

  return function (status: number) {
    return statusMap[status] || { text: '', color: '' }
  }
})

const handleQuickSearch = () => {
  gridRef.value?.commitProxy('reload')
}

const handleAdvancedSearch = () => {
  gridRef.value?.commitProxy('reload')
}

const handleReset = () => {
  gridRef.value?.commitProxy('reload')
}

const gridRef = ref<VxeGridInstance<GetNoticeMngtModel>>()
const gridOptions = reactive<VxeGridProps<GetNoticeMngtModel>>({
  border: true,
  height: 'auto',
  align: null,
  columnConfig: {
    resizable: true
  },
  columns: [
    { type: 'seq', width: 50 },
    { field: 'messageTypeName', title: '消息类型' },
    {
      field: 'noticeFrequency',
      title: '通知频率',
      formatter({ cellValue }) {
        return noticeFrequencyType[cellValue]
      }
    },
    {
      field: 'noticeFrequencyDayAndTime',
      title: '通知时间',
      formatter({ row }) {
        if (!row.noticeFrequencyDay || !row.noticeFrequencyTime) {
          return ''
        }
        return `每${row.noticeFrequencyDay}天 ${row.noticeFrequencyTime}`
      }
    },
    {
      field: 'noticeMessageType',
      title: '通知方式'
    },
    { field: 'designatedEmployeeName', title: '通知人员' },
    { field: 'orderStatus', title: '状态', slots: { default: 'orderStatus' } },
    { field: 'lastModifiedUserName', title: '操作人' },
    { field: 'lastModifiedTime', title: '最后更新时间' },
    {
      field: 'operation',
      title: '操作',
      align: 'center',
      fixed: 'right',
      width: 150,
      slots: {
        default: 'operation'
      }
    }
  ],
  pagerConfig: {
    enabled: true,
    pageSize: 20
  },
  proxyConfig: {
    ajax: {
      query: ({ page }) => {
        const quickSearchForm = gridHeaderRef.value?.quickSearchForm
        // const advancedSearchForm = gridHeaderRef.value?.advancedSearchForm
        return getNoticeMngt({
          pageIndex: page.currentPage - 1, // 由于后端接口限制，首页从0开始
          pageSize: page.pageSize,
          ...quickSearchForm
          // ...advancedSearchForm
        })
      }
    }
  }
})

const [registerModal, { openModal }] = useModal()

const handleAdd = () => {
  openModal(true, {
    isUpdate: false
  })
}

const handleModify = (row: GetNoticeMngtModel) => {
  openModal(true, {
    isUpdate: true,
    row
  })
}

const handleDelete = (row: GetNoticeMngtModel) => {
  ElMessageBox.confirm(`是否确认删除名称为"${row.messageTypeName}"的数据项?`, '警告', {
    confirmButtonText: '确定',
    cancelButtonText: '取消',
    type: 'warning'
  })
    .then(async () => {
      try {
        const id = row.id
        const { data, message } = await deleteNoticeMngt({ id })

        if (data) {
          ElMessage.success('删除成功')
        } else {
          ElMessage.error(message)
        }
      } catch (err: any) {
        error(err.message)
      }
    })
    .catch(() => {})
    .finally(() => {
      gridRef.value?.commitProxy('query')
    })
}
const handleSuccess = ({ isUpdate }: { isUpdate: boolean }) => {
  gridRef.value?.commitProxy('query')
}
</script>

<style scoped></style>
