export const noticeFrequencyType: Recordable<string> = {
    1: '触发执行',
    2: '定期执行'
  }