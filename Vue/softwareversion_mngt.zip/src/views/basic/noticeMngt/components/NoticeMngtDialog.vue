<template>
  <BasicModal
    width="557px"
    v-bind="$attrs"
    @register="registerModal"
    :title="getTitle"
    @confirm="handleSubmit"
  >
    <BasicForm @register="registerForm">
      <template #noticeFrequencyDayAndTime="{ model }">
        <div class="noticeFrequency-day-and-time">
          <div class="day">
            <span>每</span>
            <el-input-number
              :disabled="model['noticeFrequency'] !== 2"
              v-model="model['noticeFrequencyDay']"
              :min="1"
              :max="99"
              :step="1"
              :stepStrictly="true"
            />
            <div>天</div>
          </div>
          <el-time-picker
            :disabled="model['noticeFrequency'] !== 2"
            v-model="model['noticeFrequencyTime']"
            format="HH:mm"
            value-format="HH:mm"
            placeholder="请选择时间"
          />
        </div>
      </template>
      <template #noticeMessageType="{ model }">
        <el-checkbox
          label="本地消息"
          v-model="model['localNotice']"
          :true-label="1"
          :false-label="0"
        />
        <el-checkbox
          label="钉钉"
          v-model="model['dingTalkNotice']"
          :true-label="1"
          :false-label="0"
        />
      </template>
    </BasicForm>
  </BasicModal>
</template>

<script lang="tsx" setup>
import type { AddNoticeMngtData, UpdateNoticeMngtData } from '@/api/sys/model/basicModel'
import type { ModalMethods } from '@/components/Modal/types'

import { computed, ref, unref } from 'vue'
import BasicModal from '@/components/Modal/BasicModal.vue'
import { useModalInner } from '@/components/Modal/hooks/useModal'
import BasicForm from '@/components/Form/BasicForm.vue'
import { useForm } from '@/components/Form/hooks/useForm'

import { addNoticeMngt, getMessageNoticeType, updateNoticeMngt } from '@/api/sys/basic'
import { noticeFrequencyType } from '../data'

const emit = defineEmits<{
  register: [modalMethods: ModalMethods, uuid: number]
  success: [{ isUpdate: boolean }]
}>()

const isUpdate = ref<boolean>(false)
const rowId = ref('')

const [registerModal, { closeModal, setModalProps, changeOkLoading }] = useModalInner(
  async (data) => {
    resetFields()
    setModalProps({ confirmLoading: false })
    isUpdate.value = !!data?.isUpdate
    console.log(data)

    // 修改设置表单
    if (unref(isUpdate)) {
      rowId.value = data.row.id

      setFieldsValue({
        ...data.row,
        designatedEmployeeID: data.row.designatedEmployeeJson?.map((item: any) => item.id) || []
      })
    }
  }
)

const getTitle = computed(() => (!unref(isUpdate) ? '新增' : '修改'))

const noticeFrequencyOptions: { label: string; value: number }[] = [] // 通知频率
for (const prop in noticeFrequencyType) {
  noticeFrequencyOptions.push({ label: noticeFrequencyType[prop], value: Number(prop) })
}

const [
  registerForm,
  { setFieldsValue, resetFields, getFieldsValue, validate, updateSchema, validateField }
] = useForm({
  labelWidth: 90,
  schemas: [
    {
      field: 'messageTypeID',
      component: 'ApiSelect',
      label: '消息类型',
      rules: [{ required: true, trigger: 'change' }],
      dynamicDisabled() {
        return isUpdate.value
      },
      componentProps: {
        api: getMessageNoticeType,
        labelField: 'name',
        valueField: 'id',
        resultField: 'data'
        //   onChange(value: string, option: any) {
        //     setFieldsValue({ typeModuleName: option?.name })
        //   }
      },
      colProps: {
        span: 24
      }
    },
    {
      field: 'noticeFrequency',
      component: 'Select',
      label: '通知频率',
      rules: [{ required: true, trigger: 'change' }],
      defaultValue: 1,
      componentProps: {
        options: noticeFrequencyOptions,
        onChange() {
          validateField('noticeFrequencyDayAndTime')
        }
      },
      colProps: {
        span: 24
      }
    },
    {
      field: 'noticeFrequencyDay',
      component: 'ElInput',
      label: '定期执行天数',
      defaultValue: 1,
      show: false
    },
    {
      field: 'noticeFrequencyTime',
      component: 'ElInput',
      label: '定期执行时间(格式: HH:mm,如08:00)',
      show: false
    },
    {
      field: 'noticeFrequencyDayAndTime',
      component: 'ElInput',
      label: '通知时间',
      dynamicRules({ model }) {
        return [
          {
            required: model['noticeFrequency'] === 2,
            validator(_rule, _value, cb) {
              if (model['noticeFrequency'] === 2) {
                if (model['noticeFrequencyDay'] && model['noticeFrequencyTime']) {
                  cb()
                } else {
                  cb('请输入通知时间')
                }
              } else {
                cb()
              }
            }
          }
        ]
      },
      componentProps: {},
      slot: 'noticeFrequencyDayAndTime',
      colProps: {
        span: 24
      }
    },
    {
      field: 'localNotice',
      component: 'ElInput',
      label: '是否使用本地通知',
      defaultValue: 1,
      show: false
    },
    {
      field: 'dingTalkNotice',
      component: 'ElInput',
      label: '是否使用钉钉通知',
      show: false
    },
    {
      field: 'noticeMessageType',
      component: 'ElInput',
      label: '通知方式',
      dynamicRules({ model }) {
        return [
          {
            required: true,
            validator(_rule, _value, cb) {
              if (model['localNotice'] || model['dingTalkNotice']) {
                cb()
              } else {
                cb('请输入通知方式')
              }
            }
          }
        ]
      },
      slot: 'noticeMessageType'
    },
    {
      field: 'noticeEmployeeType',
      component: 'Select',
      label: '通知人员',
      rules: [{ required: true, trigger: 'change' }],
      defaultValue: 1,
      componentProps: {
        options: [
          {
            value: 1,
            label: '班组长'
          },
          {
            value: 2,
            label: '部门主管'
          },
          {
            value: 3,
            label: '部门经理'
          },
          {
            value: 4,
            label: '指定人员'
          }
        ],
        onChange() {
          validateField('designatedEmployeeID')
        }
      },
      colProps: {
        span: 24
      }
    },
    {
      field: 'designatedEmployeeID',
      component: 'PersonSelect',
      label: '指定人员',
      dynamicDisabled({ model }) {
        return model['noticeEmployeeType'] !== 4
      },
      dynamicRules({ model }) {
        return [
          {
            required: model['noticeEmployeeType'] === 4,
            trigger: 'change',
            message: '请选择指定人员'
          }
        ]
      },
      componentProps: {
        multiple: true
      },
      colProps: {
        span: 24
      }
    },
    {
      field: 'orderStatus',
      component: 'ElSwitch',
      label: '状态',
      rules: [{ required: true, trigger: 'change' }],
      defaultValue: 1,
      componentProps: {
        activeValue: 1,
        inactiveValue: 0
      },
      colProps: {
        span: 24
      }
    }
  ]
})

// 提交
const handleSubmit = async () => {
  console.log(getFieldsValue())

  try {
    //
    true

    validate(async (isValid) => {
      if (isValid) {
        // 新增
        if (!unref(isUpdate)) {
          const data = getFieldsValue()
          const { code, message } = await addNoticeMngt(data as AddNoticeMngtData)
          if (code === 200) {
            ElMessage.success('新增成功')
            closeModal()
            emit('success', { isUpdate: unref(isUpdate) })
          } else {
            ElMessage.error(message)
          }
        } else {
          const formData = getFieldsValue() as Omit<UpdateNoticeMngtData, 'id'>

          const data = {
            id: unref(rowId),
            ...formData
          }

          const { code, message } = await updateNoticeMngt(data)
          if (code === 200) {
            ElMessage.success('修改成功')
            closeModal()
            emit('success', { isUpdate: unref(isUpdate) })
          } else {
            ElMessage.error(message)
          }
        }
      }
    })
  } catch (error: any) {
    ElMessage(error.message)
  } finally {
    changeOkLoading
    changeOkLoading(false)
  }
}
</script>

<style lang="scss" scoped>
.noticeFrequency-day-and-time {
  display: flex;
  align-items: center;
  gap: 20px;
  .day {
    display: flex;
    align-items: center;
    gap: 5px;
  }
}
</style>
