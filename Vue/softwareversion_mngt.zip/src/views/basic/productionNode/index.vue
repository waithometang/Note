<template>
  <div class="page-container">
    <vxe-grid class="box" ref="gridRef" v-bind="gridOptions">
      <template #top>
        <GridHeader
          ref="gridHeaderRef"
          v-bind="headerOptions"
          @quickSearch="handleQuickSearch"
          @add="handleAdd"
          @advancedSearch="handleAdvancedSearch"
          @reset="handleReset"
        />
      </template>
      <template #operation="{ row }">
        <TableAction
          :actions="[
            {
              icon: 'edit',
              tooltip: '编辑',
              onClick: handleModify.bind(null, row)
            },
            {
              icon: 'delete',
              tooltip: '删除',
              onClick: handleDelete.bind(null, row)
            }
          ]"
        />
      </template>
    </vxe-grid>
    <ProductionNodeDialog @register="registerModal" @success="handleSuccess" />
  </div>
</template>

<script lang="tsx" setup>
import type { ComponentExposed } from 'vue-component-type-helpers'
import type { GetProductionNodeModel, GetProductionNodeParams } from '@/api/sys/model/basicModel'
import type { VxeGridInstance, VxeGridProps } from 'vxe-table'
import type { GridHeaderProps } from '@/components/Table/types/gridHeader'

import { reactive, ref } from 'vue'
import GridHeader from '@/components/Table/GridHeader.vue'
import TableAction from '@/components/Table/TableAction.vue'
import ProductionNodeDialog from './components/ProductionNodeDialog.vue'

import { deleteProductionNode, getProductionNode } from '@/api/sys/basic'
import { useModal } from '@/components/Modal/hooks/useModal'
import { error } from '@/utils/log'

defineOptions({
  name: 'ProductionNode',
  inheritAttrs: false
})

const gridHeaderRef =
  ref<ComponentExposed<typeof GridHeader<GetProductionNodeParams, 'productionNodeName'>>>()

const headerOptions = reactive<GridHeaderProps>({
  title: '生产节点',
  quickSearch: {
    singleSearch: {
      field: 'productionNodeName',
      type: 'input',
      title: '生产节点'
    },
    searchFormFields: { productionNodeName: '' }
  },
  showAdvancedSearchButton: false
})

const handleQuickSearch = () => {
  gridRef.value?.commitProxy('reload')
}

const handleAdvancedSearch = () => {
  gridRef.value?.commitProxy('reload')
}

const handleReset = () => {
  gridRef.value?.commitProxy('reload')
}

const gridRef = ref<VxeGridInstance>()
const gridOptions = reactive<VxeGridProps<GetProductionNodeModel>>({
  border: true,
  height: 'auto',
  align: null,
  columnConfig: {
    resizable: true
  },
  columns: [
    { type: 'seq', width: 50 },
    { field: 'productionNodeName', title: '生产节点' },
    { field: 'createTime', title: '创建时间' },
    { field: 'lastModifiedTime', title: '上一次修改时间' },
    {
      field: 'dataStatus',
      title: '数据状态',
      width: 150,
      visible: false
    },
    { field: 'dataDescribe', title: '数据备注', visible: false },
    {
      field: 'operation',
      title: '操作',
      align: 'center',
      fixed: 'right',
      width: 150,
      slots: {
        default: 'operation'
      }
    }
  ],
  pagerConfig: {
    enabled: true,
    pageSize: 10
  },
  proxyConfig: {
    ajax: {
      query: ({ page }) => {
        const quickSearchForm = gridHeaderRef.value?.quickSearchForm
        const advancedSearchForm = gridHeaderRef.value?.advancedSearchForm
        return getProductionNode({
          pageIndex: page.currentPage - 1, // 由于后端接口限制，首页从0开始
          pageSize: page.pageSize,
          ...quickSearchForm,
          ...advancedSearchForm
        })
      }
    }
  }
})

const [registerModal, { openModal, setModalProps }] = useModal()

const handleAdd = () => {
  openModal(true, {
    isUpdate: false
  })
}

const handleModify = (row: GetProductionNodeModel) => {
  openModal(true, {
    isUpdate: true,
    row
  })
}

const handleDelete = (row: GetProductionNodeModel) => {
  ElMessageBox.confirm(`是否确认删除生产节点为"${row.productionNodeName}"的数据项?`, '警告', {
    confirmButtonText: '确定',
    cancelButtonText: '取消',
    type: 'warning'
  })
    .then(async () => {
      try {
        const id = row.id
        const { data, message } = await deleteProductionNode({ id })

        if (data) {
          ElMessage.success('删除成功')
        } else {
          ElMessage.error(message)
        }
      } catch (err: any) {
        error(err.message)
      }
    })
    .catch(() => {})
    .finally(() => {
      gridRef.value?.commitProxy('query')
    })
}
const handleSuccess = ({ isUpdate }: { isUpdate: boolean }) => {
  gridRef.value?.commitProxy('query')
}
</script>

<style lang="scss" scoped></style>
