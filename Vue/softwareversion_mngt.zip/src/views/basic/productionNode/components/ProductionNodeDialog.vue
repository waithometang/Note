<template>
  <BasicModal
    width="40%"
    v-bind="$attrs"
    @register="registerModal"
    :title="getTitle"
    @confirm="handleSubmit"
  >
    <BasicForm @register="registerForm" />
  </BasicModal>
</template>

<script lang="tsx" setup>
import type { AddProductionNodeData, UpdateProductionNodeData } from '@/api/sys/model/basicModel'
import type { ModalMethods } from '@/components/Modal/types'

import { computed, ref, unref } from 'vue'
import BasicModal from '@/components/Modal/BasicModal.vue'
import { useModalInner } from '@/components/Modal/hooks/useModal'
import BasicForm from '@/components/Form/BasicForm.vue'
import { useForm } from '@/components/Form/hooks/useForm'

import { addProductionNode, updateProductionNode } from '@/api/sys/basic'

const emit = defineEmits<{
  register: [modalMethods: ModalMethods, uuid: number]
  success: [{ isUpdate: boolean }]
}>()

const isUpdate = ref<boolean>(false)
const rowId = ref('')
const getTitle = computed(() => (!unref(isUpdate) ? '新增' : '修改'))

const [registerModal, { closeModal, setModalProps, changeOkLoading }] = useModalInner(
  async (data) => {
    resetFields()
    setModalProps({ confirmLoading: false })
    isUpdate.value = !!data?.isUpdate

    // 修改设置表单
    if (unref(isUpdate)) {
      rowId.value = data.row.id
      setFieldsValue({
        ...data.row
      })
    }
  }
)

const [registerForm, { setFieldsValue, resetFields, getFieldsValue, validate, updateSchema }] =
  useForm({
    labelWidth: 120,
    schemas: [
      {
        field: 'productionNodeName',
        component: 'ElInput',
        label: '生产节点',
        rules: [{ required: true, trigger: 'blur' }],
        componentProps: {},
        colProps: {
          span: 24
        }
      }
    ]
  })

// 提交
const handleSubmit = async () => {
  changeOkLoading(true)

  try {
    validate(async (isValid) => {
      if (isValid) {
        // 新增
        if (!unref(isUpdate)) {
          const data = getFieldsValue()
          const { code, message } = await addProductionNode(data as AddProductionNodeData)
          if (code === 200) {
            ElMessage.success('新增成功')
            emit('success', { isUpdate: unref(isUpdate) })
            closeModal()
          } else {
            ElMessage.error(message)
          }
        } else {
          const formData = getFieldsValue() as Omit<UpdateProductionNodeData, 'id'>

          const data: UpdateProductionNodeData = {
            id: unref(rowId),
            ...formData
          }

          const { code, message } = await updateProductionNode(data)
          if (code === 200) {
            ElMessage.success('修改成功')

            emit('success', { isUpdate: unref(isUpdate) })
            closeModal()
          } else {
            ElMessage.error(message)
          }
        }
      }
    })
  } catch (error: any) {
    ElMessage(error.message)
  } finally {
    changeOkLoading(false)
  }
}
</script>

<style lang="scss" scoped></style>
