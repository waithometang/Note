<template>
  <BasicModal
    width="40%"
    v-bind="$attrs"
    @register="registerModal"
    :title="getTitle"
    @confirm="handleSubmit"
  >
    <BasicForm @register="registerForm" />
  </BasicModal>
</template>

<script lang="tsx" setup>
import type { AddProductionLineData, UpdateProductionLineData } from '@/api/sys/model/basicModel'
import type { ModalMethods } from '@/components/Modal/types'

import { computed, ref, unref } from 'vue'
import BasicModal from '@/components/Modal/BasicModal.vue'
import { useModalInner } from '@/components/Modal/hooks/useModal'
import BasicForm from '@/components/Form/BasicForm.vue'
import { useForm } from '@/components/Form/hooks/useForm'

import { addProductionLine, updateProductionLine } from '@/api/sys/basic'

const emit = defineEmits<{
  register: [modalMethods: ModalMethods, uuid: number]
  success: [{ isUpdate: boolean }]
}>()

const isUpdate = ref<boolean>(false)
const rowId = ref('')

const [registerModal, { closeModal, setModalProps, changeOkLoading }] = useModalInner(
  async (data) => {
    resetFields()
    setModalProps({ confirmLoading: false })
    isUpdate.value = !!data?.isUpdate

    // 修改设置表单
    if (unref(isUpdate)) {
      rowId.value = data.row.id
      setFieldsValue({
        ...data.row
      })
    }
  }
)

const getTitle = computed(() => (!unref(isUpdate) ? '新增' : '修改'))

const [registerForm, { setFieldsValue, resetFields, getFieldsValue, validate, updateSchema }] =
  useForm({
    labelWidth: 120,
    schemas: [
      {
        field: 'lineName',
        component: 'ElInput',
        label: '线体名称',
        componentProps: {},
        colProps: {
          span: 24
        }
      }
    ]
  })

// 提交
const handleSubmit = async () => {
  try {
    // validate()
    changeOkLoading(true)
    // 新增
    if (!unref(isUpdate)) {
      const data = getFieldsValue()
      const { code, message } = await addProductionLine(data as AddProductionLineData)
      if (code === 200) {
        ElMessage.success('新增成功')
        emit('success', { isUpdate: unref(isUpdate) })
      } else {
        ElMessage.error(message)
      }
    } else {
      const formData = getFieldsValue() as Omit<UpdateProductionLineData, 'id'>

      const data: UpdateProductionLineData = {
        id: unref(rowId),
        ...formData
      }

      const { code, message } = await updateProductionLine(data)
      if (code === 200) {
        ElMessage.success('修改成功')
        emit('success', { isUpdate: unref(isUpdate) })
      } else {
        ElMessage.error(message)
      }
    }
  } catch (error: any) {
    ElMessage(error.message)
  } finally {
    changeOkLoading(true)
    closeModal()
  }
}
</script>

<style lang="scss" scoped></style>
