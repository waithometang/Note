<template>
  <BasicModal
    width="40%"
    v-bind="$attrs"
    @register="registerModal"
    :title="getTitle"
    @confirm="handleSubmit"
  >
    <BasicForm @register="registerForm"> </BasicForm>
  </BasicModal>
</template>

<script lang="ts" setup>
import type { AddDictionaryData, UpdateDictionaryData } from '@/api/sys/model/basicModel'
import type { ModalMethods } from '@/components/Modal/types'

import { ref, unref, computed } from 'vue'

import BasicModal from '@/components/Modal/BasicModal.vue'
import { useModalInner } from '@/components/Modal/hooks/useModal'
import BasicForm from '@/components/Form/BasicForm.vue'
import { useForm } from '@/components/Form/hooks/useForm'
import { addKeyValue, updateKeyValue } from '@/api/sys/basic'

const emit = defineEmits<{
  register: [modalMethods: ModalMethods, uuid: number]
  success: []
}>()
const isUpdate = ref<boolean>(false)

const keyValueClassifyID = ref<string>('')
const rowId = ref<string>('')

const getTitle = computed(() => (!unref(isUpdate) ? '新增字典项' : '修改字典项'))
const [registerForm, { setFieldsValue, resetFields, getFieldsValue, validate }] = useForm({
  labelWidth: 120,
  schemas: [
    {
      field: 'typeDescription',
      component: 'ElInput',
      label: '类型',
      componentProps: {
        disabled: true
      },
      colProps: {
        span: 24
      }
    },
    {
      field: 'key',
      component: 'ElInput',
      label: '标识',
      required: true,
      dynamicDisabled: () => unref(isUpdate),
      componentProps: {},
      colProps: {
        span: 24
      }
    },
    {
      field: 'value',
      component: 'ElInput',
      label: '名称',
      required: true,
      componentProps: {},
      colProps: {
        span: 24
      }
    },
    {
      field: 'description',
      component: 'ElInput',
      label: '备注',
      componentProps: {
        type: 'textarea'
      },
      colProps: {
        span: 24
      }
    }
  ]
})

const [registerModal, { closeModal, setModalProps }] = useModalInner(async (data) => {
  resetFields()
  setModalProps({ confirmLoading: false })
  isUpdate.value = !!data?.isUpdate

  if (!unref(isUpdate)) {
    const { activeDictionaryTypeItem } = data

    const { id, typeDescription } = activeDictionaryTypeItem
    keyValueClassifyID.value = id
    setFieldsValue({ typeDescription })
  } else {
    const { row } = data
    rowId.value = row.id

    setFieldsValue({ ...row })
  }
})

// 提交
const handleSubmit = async () => {
  validate(async (isValid) => {
    if (isValid) {
      setModalProps({ confirmLoading: true })

      try {
        if (!unref(isUpdate)) {
          const formData = getFieldsValue() as Omit<AddDictionaryData, 'keyValueClassifyID'>

          const data = {
            keyValueClassifyID: unref(keyValueClassifyID),
            ...formData
          }
          const { code, message } = await addKeyValue(data)
          if (code === 200) {
            ElMessage.success('新增成功')
            closeModal()
            emit('success')
          } else {
            ElMessage.error(message)
          }
        } else {
          const formData = getFieldsValue() as Omit<UpdateDictionaryData, 'id'>
          const data = {
            id: unref(rowId),
            ...formData
          }
          const { code, message } = await updateKeyValue(data)

          if (code === 200) {
            ElMessage.success('修改成功')
            closeModal()
            emit('success')
          } else {
            ElMessage.error(message)
          }
        }
      } catch (error) {
        console.log(error)
      } finally {
        setModalProps({ confirmLoading: false })
      }
      // 新增
    }
  })
}
</script>

<style lang="scss" scoped></style>
