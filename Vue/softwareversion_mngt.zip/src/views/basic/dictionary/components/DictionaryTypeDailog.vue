<template>
  <BasicModal
    width="40%"
    v-bind="$attrs"
    @register="registerModal"
    title="新增字典类型"
    @confirm="handleSubmit"
  >
    <BasicForm @register="registerForm"> </BasicForm>
  </BasicModal>
</template>

<script lang="ts" setup>
import type { AddDictionaryClassifyData } from '@/api/sys/model/basicModel'
import type { ModalMethods } from '@/components/Modal/types'
import { ref } from 'vue'

import BasicModal from '@/components/Modal/BasicModal.vue'
import { useModalInner } from '@/components/Modal/hooks/useModal'
import BasicForm from '@/components/Form/BasicForm.vue'
import { useForm } from '@/components/Form/hooks/useForm'
import { addKeyValueClassify } from '@/api/sys/basic'

const emit = defineEmits<{
  register: [modalMethods: ModalMethods, uuid: number]
  success: []
}>()
const [registerModal, { closeModal, setModalProps }] = useModalInner(async (data) => {
  resetFields()
  setModalProps({ confirmLoading: false })
})

const [registerForm, { setFieldsValue, resetFields, getFieldsValue, validate, updateSchema }] =
  useForm({
    labelWidth: 120,
    schemas: [
      {
        field: 'typeName',
        component: 'ElInput',
        label: '类型标识',
        required: true,
        componentProps: {},
        colProps: {
          span: 24
        }
      },
      {
        field: 'typeDescription',
        component: 'ElInput',
        label: '类型名称',
        required: true,
        componentProps: {},
        colProps: {
          span: 24
        }
      }
    ]
  })

// 提交
const handleSubmit = async () => {
  await validate()
  try {
    setModalProps({ confirmLoading: true })
    const data = getFieldsValue() as AddDictionaryClassifyData
    const { code, message } = await addKeyValueClassify(data)
    if (code === 200) {
      ElMessage.success('新增成功')
      closeModal()
      emit('success')
    } else {
      ElMessage.error(message)
    }
  } catch (error: any) {
    ElMessage(error.message)
  } finally {
    setModalProps({ confirmLoading: false })
  }
}
</script>

<style lang="scss" scoped></style>
