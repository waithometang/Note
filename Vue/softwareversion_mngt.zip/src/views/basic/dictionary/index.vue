<template>
  <div class="page-container">
    <basic-list
      ref="basicListRef"
      class="list"
      v-bind="listOptions"
      @change="handleChange"
      @contextClick="handleContextClick"
    >
      <template #footer>
        <el-tooltip placement="top" content="新增">
          <el-button @click="handleTypeClassifyAdd" style="height: 36px">
            <svg-icon icon="plus" />
          </el-button>
        </el-tooltip>
      </template>
    </basic-list>
    <vxe-grid class="box vxe-grid" ref="gridRef" v-bind="gridOptions">
      <template #top>
        <GridHeader
          ref="gridHeaderRef"
          v-bind="headerOptions"
          @quickSearch="handleQuickSearch"
          @advancedSearch="handleAdvancedSearch"
          @add="handleAdd"
        />
      </template>

      <template #operation="{ row }">
        <TableAction
          :actions="[
            {
              icon: 'edit',
              tooltip: '编辑',
              onClick: handleModifyDictionary.bind(null, row)
            },
            {
              icon: 'delete',
              tooltip: '删除',
              onClick: handleDeleteDictionary.bind(null, row)
            }
          ]"
        />
      </template>
    </vxe-grid>

    <DictionaryTypeDailog @register="registerModal" @success="handleDictionaryTypeSuccess" />
    <DictionaryDailog @register="registerAddDictionaryModal" @success="handleDictionarySuccess" />
  </div>
</template>

<script lang="ts" setup>
import type { ComponentExposed } from 'vue-component-type-helpers'
import type { VxeGridInstance, VxeGridProps } from 'vxe-table'
import type { GridHeaderProps } from '@/components/Table/types/gridHeader'
import type {
  GetDictionaryClassifyModel,
  GetDictionaryModel,
  GetDictionaryParams
} from '@/api/sys/model/basicModel'
import type { ListProps } from '@/components/List/types'

import { ref, reactive, unref } from 'vue'
import { ElMessage } from 'element-plus'

import {
  deleteKeyValueClassify,
  getKeyValue,
  getKeyValueClassify,
  deleteKeyValue
} from '@/api/sys/basic'

import { useModal } from '@/components/Modal/hooks/useModal'
import GridHeader from '@/components/Table/GridHeader.vue'
import { useContextMenu } from '@/hooks/useContextMenu'

import DictionaryTypeDailog from './components/DictionaryTypeDailog.vue'
import DictionaryDailog from './components/DictionaryDailog.vue'
import { error } from '@/utils/log'

defineOptions({
  name: 'Dictionary',
  inheritAttrs: true
})

const basicListRef = ref()

// 列表配置
const listOptions = reactive<ListProps>({
  api: getKeyValueClassify,
  title: '字典类型',
  valueField: 'id',
  labelField: 'typeDescription',
  resultField: 'data.result',
  isCancelCurrent: true,
  showTooltip: true,
  tooltipField: 'typeName'
})

// 列表活跃项改变
const handleChange = () => {
  gridRef.value?.commitProxy('reload')
}
const [registerModal, { openModal, setModalProps }] = useModal()
// 新增分类
const handleTypeClassifyAdd = () => {
  openModal(true, {})
}
const handleDictionaryTypeSuccess = () => {
  basicListRef.value.fetch()
}

const [createContextMenu] = useContextMenu()
// 右键菜单点击
const handleContextClick = (e: MouseEvent, item: GetDictionaryClassifyModel, index: number) => {
  createContextMenu({
    event: e,
    showIcon: true,
    items: [
      {
        icon: 'close',
        label: '删除',
        handler: () => {
          ElMessageBox.confirm(`是否确认删除名称为"${item.typeDescription}"的数据项?`, '警告', {
            confirmButtonText: '确定',
            cancelButtonText: '取消',
            type: 'warning'
          })
            .then(async () => {
              try {
                const id = item.id
                const { data, message } = await deleteKeyValueClassify({ id })

                if (data) {
                  ElMessage.success('删除成功')
                } else {
                  ElMessage.error(message)
                }
              } catch (err: any) {
                error(err.message)
              }
            })
            .catch(() => {})
            .finally(() => {
              basicListRef.value.fetch()
            })
        }
      }
    ]
  })
}

const gridHeaderRef =
  ref<ComponentExposed<typeof GridHeader<GetDictionaryParams, 'value'>>>()

const headerOptions = reactive<GridHeaderProps>({
  title: '字典数据',
  quickSearch: {
    singleSearch: {
      field: 'value',
      type: 'input',
      title: '名称'
    },
    searchFormFields: { value: '' }
  },
  showAdvancedSearchButton: false
})

const handleQuickSearch = () => {
  gridRef.value?.commitProxy('reload')
}

const handleAdvancedSearch = () => {
  gridRef.value?.commitProxy('reload')
}

const gridRef = ref<VxeGridInstance>()
const gridOptions = reactive<VxeGridProps<GetDictionaryModel>>({
  border: true,
  height: 'auto',
  align: null,
  columnConfig: {
    resizable: true
  },
  columns: [
    { type: 'seq', width: 50 },
    // { field: 'typeName', title: '类型名称' },
    { field: 'key', title: '标识' },
    { field: 'value', title: '名称' },
    { field: 'description', title: '描述' },
    { field: 'createTime', title: '创建时间' },
    // { field: 'dataDescribe', title: '数据描述' },
    { field: 'lastModifiedUserName', title: '操作人' },
    { field: 'lastModifiedTime', title: '最后更新时间' },
    {
      field: 'operation',
      title: '操作',
      align: 'center',
      fixed: 'right',
      width: 150,
      slots: {
        default: 'operation'
      }
    }
  ],
  pagerConfig: {
    enabled: false
  },
  proxyConfig: {
    ajax: {
      query: () => {
        const quickSearchForm = unref(gridHeaderRef)?.quickSearchForm || {}
        const advancedSearchForm = unref(gridHeaderRef)?.advancedSearchForm || {}

        const keyValueClassifyID = basicListRef.value.getActiveItem?.value
        return new Promise((resolve) => {
          getKeyValue({
            ...quickSearchForm,
            ...advancedSearchForm,
            keyValueClassifyID
          }).then((res) => {
            resolve(res.data.result)
          })
        })
      }
    }
  }
})

const [registerAddDictionaryModal, { openModal: openDictionaryModal }] = useModal()
const handleAdd = () => {
  const activeDictionaryTypeItem = basicListRef.value.getActiveItem
  if (!activeDictionaryTypeItem) {
    return ElMessage.warning('请先选择字典类型,再点击新增')
  }

  openDictionaryModal(true, {
    activeDictionaryTypeItem
  })
}

const handleDictionarySuccess = () => {
  gridRef.value?.commitProxy('query')
}

const handleModifyDictionary = (row: GetDictionaryModel) => {
  openDictionaryModal(true, { isUpdate: true, row })
}

const handleDeleteDictionary = (row: GetDictionaryModel) => {
  ElMessageBox.confirm(`是否确认删除名称为"${row.value}"的数据项?`, '警告', {
    confirmButtonText: '确定',
    cancelButtonText: '取消',
    type: 'warning'
  })
    .then(async () => {
      try {
        const id = row.id
        const { data, message } = await deleteKeyValue({ id })

        if (data) {
          ElMessage.success('删除成功')
          gridRef.value?.commitProxy('query')
        } else {
          ElMessage.error(message)
        }
      } catch (err: any) {
        error(err.message)
      }
    })
    .catch(() => {})
    .finally(() => {
      basicListRef.value.fetch()
    })
}
</script>

<style lang="scss" scoped>
.page-container {
  display: flex;

  .list {
    width: 14vw;
  }
  .vxe-grid {
    margin-left: $margin;
    flex: 1;
  }
}
</style>
