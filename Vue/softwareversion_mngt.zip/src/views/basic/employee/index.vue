<template>
  <LayoutContainer>
    <!-- <basic-list ref="basicListRef" v-bind="listOptions" @change="handleChange" /> -->

    <template #leftSide>
      <basic-tree ref="basicTreeRef" v-bind="treeOptions" />
    </template>
    <div class="grid-container">
      <vxe-grid class="box" ref="gridRef" v-bind="gridOptions">
        <template #top>
          <GridHeader
            ref="gridHeaderRef"
            v-bind="headerOptions"
            @quickSearch="handleQuickSearch"
            @add="handleAdd"
            @advancedSearch="handleAdvancedSearch"
            @reset="handleReset"
          />
        </template>

        <template #operation="{ row }">
          <TableAction
            :actions="[
              {
                icon: 'edit',
                tooltip: '编辑',
                onClick: handleModify.bind(null, row)
              },
              {
                icon: 'delete',
                tooltip: '删除',
                onClick: handleDelete.bind(null, row)
              }
            ]"
          />
        </template>
      </vxe-grid>
    </div>

    <EmployeeDialog @register="registerModal" @success="handleSuccess" />
  </LayoutContainer>
</template>

<script lang="tsx" setup>
import type { ComponentExposed } from 'vue-component-type-helpers'
import type { VxeGridInstance, VxeGridProps } from 'vxe-table'
import type { GridHeaderProps } from '@/components/Table/types/gridHeader'
import type { GetEmployeeInfoModel, GetEmployeeInfoParams } from '@/api/sys/model/basicModel'
import type { TreeProps } from '@/components/Tree/types/tree'
import type { SelectModel } from '@/api/model/baseModel'

import { computed, reactive, ref, unref } from 'vue'
import dayjs from 'dayjs'

import {
  getEmployeeInfo,
  getDepartment,
  getKeyValue,
  getGroupSelect,
  deleteEmployeeInfo,
  exportEmployeeInfo
} from '@/api/sys/basic'

import GridHeader from '@/components/Table/GridHeader.vue'
import TableAction from '@/components/Table/TableAction.vue'
import { useModal } from '@/components/Modal/hooks/useModal'
import EmployeeDialog from './components/EmployeeDialog.vue'

import { error } from '@/utils/log'
import { dateShortcuts } from '@/constant'

defineOptions({
  name: 'Employee',
  inheritAttrs: false
})

const basicTreeRef = ref()
const activeTreeNode = ref()
// 列表配置
const treeOptions = reactive<TreeProps>({
  api: getDepartment,
  title: '部门列表',
  labelField: 'departmentName',
  resultField: 'data.result',
  childrenField: 'sonData',
  nodeKey: 'id',
  cancleHightlightCurrent: true,
  onSelect: async (nodeData) => {
    activeTreeNode.value = nodeData

    let groupList: SelectModel[] = []
    if (nodeData) {
      const { data } = await getGroupSelect({ departmentID: nodeData.id })

      groupList = data.result
    }

    gridHeaderRef.value?.updateAdvancedSearchForm({
      field: 'groupID',
      componentProps: {
        options: groupList
      }
    })

    gridHeaderRef.value?.setFieldsValue({ groupID: undefined })
    gridRef.value?.commitProxy('reload')
  }
  // nodeContextMenuList: [
  // {
  //   icon: 'close',
  //   label: '删除',
  //   handler: () => {
  //     console.log('close')
  //   }
  // }
  // ]
})

const gridHeaderRef =
  ref<ComponentExposed<typeof GridHeader<GetEmployeeInfoParams, 'employeeName'>>>()

const headerOptions = reactive<GridHeaderProps>({
  title: '员工信息',
  quickSearch: {
    singleSearch: {
      field: 'employeeName',
      type: 'input',
      title: '员工姓名'
    },
    searchFormFields: { employeeName: '' }
  },
  advancedSearch: {
    labelWidth: 120,
    fieldMapToTime: [
      ['dataOfEntry', ['startDataOfEntry', 'endDataOfEntry'], 'YYYY-MM-DD']
      // ['dateofBirth', ['startDateOfBirth', 'endDateOfBirth'], 'YYYY-MM-DD']
    ],
    schemas: [
      {
        field: 'employeeNo',
        component: 'ElInput',
        label: '员工编号',
        componentProps: {
          style: {
            width: '100%'
          }
        },
        colProps: {
          span: 8
        }
      },
      {
        field: 'groupID',
        component: 'Select',
        label: '所属组别',
        componentProps: {
          options: []
        },
        colProps: {
          span: 8
        }
      },

      {
        field: 'dataOfEntry',
        component: 'ElDatePicker',
        label: '入职日期',
        componentProps: {
          type: 'daterange',
          unlinkPanels: true,
          shortcuts: dateShortcuts,
          valueFormat: 'YYYY-MM-DD'
        },
        colProps: {
          span: 8
        }
      },
      // {
      //   field: 'employeeName',
      //   component: 'ElInput',
      //   label: '员工名称',
      //   colProps: {
      //     span: 8
      //   }
      // },
      {
        field: 'employeeOrderStatus',
        component: 'Select',
        label: '在职状态',
        componentProps: {
          options: [
            {
              label: '在职',
              value: 1
            },
            {
              label: '离职',
              value: 2
            }
          ]
        },
        colProps: {
          span: 8
        }
      },
      {
        field: 'sex',
        component: 'Select',
        label: '性别',
        componentProps: {
          options: [
            {
              label: '男',
              value: 1
            },
            {
              label: '女',
              value: 0
            }
          ]
        },
        colProps: {
          span: 8
        }
      },

      // {
      //   field: 'dateofBirth',
      //   component: 'ElDatePicker',
      //   componentProps: {
      //     type: 'daterange'
      //   },
      //   label: '出生日期',
      //   colProps: {
      //     span: 8
      //   }
      // },
      {
        field: 'degreeID',
        component: 'ApiSelect',
        label: '学历',
        componentProps: {
          api: getKeyValue,
          resultField: 'data.result',
          labelField: 'value',
          valueField: 'id',
          params: {
            typeName: 'Degree'
          }
        },
        colProps: {
          span: 8
        }
      },

      // {
      //   field: 'attributesID',
      //   component: 'ApiSelect',
      //   label: '属性',
      //   componentProps: {
      //     api: getKeyValue,
      //     resultField: 'data.result',
      //     labelField: 'value',
      //     valueField: 'id',
      //     params: {
      //       typeName: 'Attributes'
      //     }
      //   },
      //   colProps: {
      //     span: 8
      //   }
      // },
      {
        field: 'levelID',
        component: 'ApiSelect',
        componentProps: {
          api: getKeyValue,
          resultField: 'data.result',
          labelField: 'value',
          valueField: 'id',
          params: {
            typeName: 'PositionLeve'
          }
        },
        label: '岗位等级',
        colProps: {
          span: 8
        }
      },
      {
        field: 'positionID',
        component: 'ApiSelect',
        label: '岗位',
        componentProps: {
          api: getKeyValue,
          resultField: 'data.result',
          labelField: 'value',
          valueField: 'id',
          params: {
            typeName: 'Position'
          }
        },
        colProps: {
          span: 8
        }
      },
      // {
      //   field: 'productionAddressID',
      //   component: 'ApiSelect',
      //   label: '生产厂区',
      //   componentProps: {
      //     api: getKeyValue,
      //     resultField: 'data.result',
      //     labelField: 'value',
      //     valueField: 'id',
      //     params: {
      //       typeName: 'PositionAddress'
      //     }
      //   },
      //   colProps: {
      //     span: 8
      //   }
      // },
      {
        field: 'rankSeriesID',
        component: 'ApiSelect',
        label: '职级',
        componentProps: {
          api: getKeyValue,
          resultField: 'data.result',
          labelField: 'value',
          valueField: 'id',
          params: {
            typeName: 'RankSeries'
          }
        },
        colProps: {
          span: 8
        }
      }
      // {
      //   field: 'createTime',
      //   component: 'ElInput',
      //   label: '创建时间',
      //   colProps: {
      //     span: 8
      //   }
      // },
      // {
      //   field: 'lastModifiedTime',
      //   component: 'ElInput',
      //   label: '上一次修改时间',
      //   colProps: {
      //     span: 8
      //   }
      // },
    ]
  },
  showExportButton: true,
  exportApi: exportEmployeeInfo,
  exportParams: computed(() => ({ departmentID: unref(activeTreeNode)?.id }))
})

const handleQuickSearch = () => {
  gridRef.value?.commitProxy('reload')
}

const handleAdvancedSearch = () => {
  gridRef.value?.commitProxy('reload')
}

const handleReset = () => {
  gridRef.value?.commitProxy('reload')
}

const gridRef = ref<VxeGridInstance>()
const gridOptions = reactive<VxeGridProps<GetEmployeeInfoModel>>({
  border: true,
  height: 'auto',
  align: null,
  columnConfig: {
    resizable: true
  },
  columns: [
    { type: 'seq', width: 50, fixed: 'left' },
    // {
    //   field: 'imageUrl',
    //   title: '头像',
    //   fixed: 'left',
    //   width: 80,
    //   slots: {
    //     default({ row }) {
    //       return row.imageUrl ? (
    //         <el-avatar size={40} src={row.imageUrl} shape="square" fit="cover" />
    //       ) : (
    //         ''
    //       )
    //     }
    //   }
    // },
    { field: 'employeeNo', title: '工号', width: 100, fixed: 'left' },
    { field: 'employeeName', title: '姓名', width: 100, fixed: 'left' },
    { field: 'departmentName', title: '部门', minWidth: 120 },
    { field: 'groupName', title: '班组', minWidth: 150 },
    {
      field: 'sex',
      title: '性别',
      width: 80,
      slots: {
        default: ({ row }) => {
          return <span>{row.sex === 1 ? '男' : '女'}</span>
        }
      }
    },
    {
      field: 'dataOfEntry',
      title: '入职日期',
      width: 150,
      visible:false,
      slots: {
        default: ({ row }) => {
          return dayjs(row.dataOfEntry).format('YYYY-MM-DD')
        }
      }
    },
    { field: 'positionName', title: '岗位', width: 100 },
    { field: 'levelName', title: '岗位等级', width: 100 },
    { field: 'rankSeriesName', title: '职级', width: 100 },
    { field: 'attributesName', title: '属性', width: 100 },
    { field: 'productionAddressName', title: '生产厂区', width: 100 },
    {
      field: 'dateOfBirth',
      title: '出生日期',
      width: 150,
      slots: {
        default: ({ row }) => {
          return dayjs(row.dateOfBirth).format('YYYY-MM-DD')
        }
      },
      visible: false
    },
    { field: 'degreeName', title: '学历', width: 100, visible: false },
    // { field: 'createTime', title: '创建时间', width: 150 },
    // { field: 'dataStatus', title: '数据状态', width: 150 },
    { field: 'lastModifiedUserName', title: '操作人', width: 150 },
    { field: 'lastModifiedTime', title: '最后更新时间', width: 150 },
    { field: 'dataDescribe', title: '备注', width: 150, visible: false },
    {
      field: 'operation',
      title: '操作',
      align: 'center',
      fixed: 'right',
      width: 150,
      slots: {
        default: 'operation'
      }
    }
  ],
  pagerConfig: {
    enabled: true,
    currentPage: 1,
    pageSize: 10
  },
  proxyConfig: {
    ajax: {
      query: ({ page }) => {
        const quickSearchForm = gridHeaderRef.value?.quickSearchForm
        const advancedSearchForm = gridHeaderRef.value?.advancedSearchForm

        const departmentID = unref(activeTreeNode)?.id

        return getEmployeeInfo({
          pageIndex: page.currentPage - 1, // 由于后端接口限制，首页从0开始
          pageSize: page.pageSize,
          departmentID,
          ...quickSearchForm,
          ...advancedSearchForm
        })
      }
    }
  }
})

const [registerModal, { openModal, setModalProps, closeModal }] = useModal()

const handleAdd = () => {
  openModal(true, {
    isUpdate: false
  })
}

const handleModify = (row: GetEmployeeInfoModel) => {
  openModal(true, {
    isUpdate: true,
    row
  })
}

const handleDelete = (row: GetEmployeeInfoModel) => {
  ElMessageBox.confirm(`是否确认删除名称为"${row.employeeName}"的数据项?`, '警告', {
    confirmButtonText: '确定',
    cancelButtonText: '取消',
    type: 'warning'
  })
    .then(async () => {
      try {
        const id = row.id
        const { data, message } = await deleteEmployeeInfo({ id })

        if (data) {
          ElMessage.success('删除成功')
        } else {
          ElMessage.error(message)
        }
      } catch (err: any) {
        error(err.message)
      }
    })
    .catch(() => {})
    .finally(() => {
      gridRef.value?.commitProxy('query')
    })
}
const handleSuccess = ({ isUpdate }: { isUpdate: boolean }) => {
  closeModal()
  gridRef.value?.commitProxy('query')
}
</script>

<style lang="scss" scoped>
.grid-container {
  padding: $margin $margin $margin 0;
  height: 100%;
}
</style>
