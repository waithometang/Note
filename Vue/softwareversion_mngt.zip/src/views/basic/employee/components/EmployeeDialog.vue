<template>
  <BasicModal
    width="70%"
    v-bind="$attrs"
    @register="registerModal"
    :title="getTitle"
    @confirm="handleSubmit"
  >
    <div class="dialog-content-container">
      <BasicForm @register="registerForm"> </BasicForm>
      <div class="avatar-uploader-container">
        <el-upload
          ref="uploadRef"
          class="avatar-uploader"
          action="/api/EmployeeInfo/ImportAvatar"
          name="picture"
          accept=".jpg,.jpeg,.png"
          :headers="{ Authorization: appStore.token }"
          :on-success="handleAvatarSuccess"
          :before-upload="beforeAvatarUpload"
          :show-file-list="false"
        >
          <template v-if="imageUrl">
            <img :src="imageUrl" class="avatar" />

            <span class="el-upload-list__item-actions">
              <span class="el-upload-list__item-delete" @click.stop="handleClearFiles">
                <svg-icon icon="delete" style="font-size: 24px" />
              </span>
            </span>
          </template>

          <div v-else class="empty-avatar-container">
            <svg-icon icon="plus" class="avatar-uploader-icon" />
            <div class="text">点击上传头像</div>
          </div>
        </el-upload>

        <div class="tips">
          <template v-if="imageUrl"> 点击头像重新上传 </template>
          <template v-else> 大小不超过3M </template>
        </div>
      </div>
    </div>
  </BasicModal>
</template>

<script lang="tsx" setup>
import type { AddEmployeeInfoData, UpdateEmployeeInfoData } from '@/api/sys/model/basicModel'
import type { ModalMethods } from '@/components/Modal/types'
import type { RenderCallbackParams } from '@/components/Form/types/form'
import type { ElUpload, UploadProps } from 'element-plus'
import type { CascaderOption } from 'element-plus'
import type { SelectModel } from '@/api/model/baseModel'

import { computed, ref, unref } from 'vue'
import BasicModal from '@/components/Modal/BasicModal.vue'
import { useModalInner } from '@/components/Modal/hooks/useModal'
import BasicForm from '@/components/Form/BasicForm.vue'
import { useForm } from '@/components/Form/hooks/useForm'

import {
  getDepartment,
  addEmployeeInfo,
  updateEmployeeInfo,
  getGroupSelect,
  getKeyValueByClassify
} from '@/api/sys/basic'
import useUserStore from '@/stores/user'

const emit = defineEmits<{
  register: [modalMethods: ModalMethods, uuid: number]
  success: [{ isUpdate: boolean }]
}>()

const isUpdate = ref<boolean>(false)
const rowId = ref('')

const [registerModal, { closeModal, setModalProps, changeOkLoading }] = useModalInner(
  async (data) => {
    resetFields()
    setModalProps({ confirmLoading: false })
    isUpdate.value = !!data?.isUpdate
    imageUrl.value = ''

    // 修改设置表单
    if (unref(isUpdate)) {
      rowId.value = data.row.id
      imageUrl.value = data.row.imageUrl
      setFieldsValue({
        ...data.row
      })

      const { departmentID } = data.row
      if (departmentID) {
        const { data } = await getGroupSelect({ departmentID: departmentID })

        const groupList: SelectModel[] = data.result
        updateSchema({
          field: 'groupID',
          componentProps: {
            options: groupList
          }
        })
      }
    }
  }
)

const getTitle = computed(() => (!unref(isUpdate) ? '新增' : '修改'))

const departmentList = ref<CascaderOption[]>()

const getDepartmentList = () => {
  getDepartment().then(({ data }) => {
    function filterTree(arr: Recordable[]) {
      let res: Recordable[] = []
      arr?.forEach((item: Recordable) => {
        let data: Recordable = {
          label: item.departmentName,
          value: item.id
        }
        if (item.sonData) {
          data.children = filterTree(item.sonData)
        }
        res.push(data)
      })

      return res
    }

    departmentList.value = filterTree(data.result)
  })
}
getDepartmentList()

const appStore = useUserStore()
const [registerForm, { setFieldsValue, resetFields, getFieldsValue, validate, updateSchema }] =
  useForm({
    labelWidth: 120,
    schemas: [
      {
        field: 'employeeNo',
        component: 'ElInput',
        label: '员工编号',
        required: true,
        dynamicDisabled: (renderCallbackParams: RenderCallbackParams) => unref(isUpdate),
        componentProps: {
          // disabled: isUpdate,
          style: {
            width: '100%'
          }
        },
        colProps: {
          span: 8
        }
      },
      {
        field: 'employeeName',
        component: 'ElInput',
        label: '姓名',
        required: true,
        colProps: {
          span: 8
        }
      },
      {
        field: 'sex',
        component: 'Select',
        label: '性别',
        required: true,
        componentProps: {
          options: [
            {
              label: '男',
              value: 1
            },
            {
              label: '女',
              value: 0
            }
          ]
        },
        colProps: {
          span: 8
        }
      },

      {
        field: 'dataOfEntry',
        component: 'ElDatePicker',
        label: '入职日期',
        componentProps: {
          type: 'date'
        },
        colProps: {
          span: 8
        }
      },
      {
        field: 'dateOfBirth',
        component: 'ElDatePicker',
        componentProps: {
          type: 'date'
        },
        label: '出生日期',
        colProps: {
          span: 8
        }
      },
      {
        field: 'degreeID',
        component: 'ApiSelect',
        label: '学历',
        componentProps: {
          api: getKeyValueByClassify,
          resultField: 'data',
          labelField: 'value',
          valueField: 'id',
          params: {
            typeName: 'Degree'
          }
        },
        colProps: {
          span: 8
        }
      },
      {
        field: 'departmentID',
        component: 'ApiCascader',
        label: '部门',
        // required: true,

        rules: [{ required: true, trigger: 'change' }],
        componentProps: ({ formModel, formActionType }) => {
          return {
            api: getDepartment,
            resultField: 'data.result',
            labelField: 'departmentName',
            valueField: 'id',
            childrenField: 'sonData',
            props: {
              checkStrictly: true,
              emitPath: false
            },
            async onChange(value: string) {
              let groupList: SelectModel[] = []
              formModel.groupID = undefined
              if (value) {
                const { data } = await getGroupSelect({ departmentID: value })

                groupList = data.result
              }

              const { updateSchema } = formActionType

              updateSchema({
                field: 'groupID',
                componentProps: {
                  options: groupList
                }
              })
            }
          }
        },
        colProps: {
          span: 8
        }
      },
      {
        field: 'groupID',
        component: 'Select',
        label: '所属组别',
        required: true,
        componentProps: {
          options: []
        },
        colProps: {
          span: 8
        }
      },
      {
        field: 'attributesID',
        component: 'ApiSelect',
        label: '属性',
        componentProps: {
          api: getKeyValueByClassify,
          resultField: 'data',
          labelField: 'value',
          valueField: 'id',
          params: {
            typeName: 'Attributes'
          }
        },
        colProps: {
          span: 8
        }
      },
      {
        field: 'levelID',
        label: '岗位等级',
        component: 'ApiSelect',
        componentProps: {
          api: getKeyValueByClassify,
          resultField: 'data',
          labelField: 'value',
          valueField: 'id',
          params: {
            typeName: 'PositionLeve'
          }
        },

        colProps: {
          span: 8
        }
      },
      {
        field: 'positionID',
        component: 'ApiSelect',
        label: '岗位',
        required: true,
        componentProps: {
          api: getKeyValueByClassify,
          resultField: 'data',
          labelField: 'value',
          valueField: 'id',
          params: {
            typeName: 'Position'
          }
        },
        colProps: {
          span: 8
        }
      },
      // {
      //   field: 'productionAddressID',
      //   component: 'ApiSelect',
      //   label: '生产厂区',
      //   componentProps: {
      //     api: getKeyValueByClassify,
      //     resultField: 'data',
      //     labelField: 'value',
      //     valueField: 'id',
      //     params: {
      //       typeName: 'PositionAddress'
      //     }
      //   },
      //   colProps: {
      //     span: 8
      //   }
      // },
      {
        field: 'rankSeriesID',
        component: 'ApiSelect',
        label: '职级',
        componentProps: {
          api: getKeyValueByClassify,
          resultField: 'data',
          labelField: 'value',
          valueField: 'id',
          params: {
            typeName: 'RankSeries'
          }
        },
        colProps: {
          span: 8
        }
      },
      {
        field: 'dataDescribe',
        component: 'ElInput',
        label: '备注',
        componentProps: {
          type: 'textarea'
        },
        colProps: {
          span: 24
        }
      }
      // {
      //   field: 'imageUrl',
      //   component: 'ElUpload',
      //   label: '用户头像',
      //   render({ model }) {
      //     const imageUrl = ref(model.imageUrl)
      //     const handleAvatarSuccess: UploadProps['onSuccess'] = (response, uploadFile) => {
      //       console.log(response)

      //       const { status, data } = response
      //       if (status) {
      //         imageUrl.value = URL.createObjectURL(uploadFile.raw!)
      //         model.imageUrl = data.fileName
      //       }
      //     }

      //     const beforeAvatarUpload: UploadProps['beforeUpload'] = (rawFile) => {
      //       if (!['image/jpeg', 'image/jpg', 'image/png'].includes(rawFile.type)) {
      //         ElMessage.error('头像图片必须是jpg|jpeg|png其中一种')
      //         return false
      //       } else if (rawFile.size / 1024 / 1024 > 3) {
      //         ElMessage.error('头像图片尺寸不能超过3MB!')
      //         return false
      //       }
      //       return true
      //     }

      //     return (
      //       <el-upload
      //         class={uploadScss['avatar-uploader']}
      //         action="/api/EmployeeInfo/ImportAvatar"
      //         name="picture"
      //         accept=".jpg,.jpeg,.png"
      //         headers={{ Authorization: appStore.token }}
      //         show-file-git
      //         merge
      //         list={false}
      //         fileSizeMax={3}
      //         on-success={handleAvatarSuccess}
      //         before-upload={beforeAvatarUpload}
      //       >
      //         {imageUrl.value ? (
      //           <img src={imageUrl.value} class={uploadScss['avatar']} />
      //         ) : (
      //           <svg-icon icon="plus" class={uploadScss['avatar-uploader-icon']} />
      //         )}
      //       </el-upload>
      //     )
      //   },
      //   colProps: {
      //     span: 8
      //   }
      // }
    ]
  })

const uploadRef = ref<InstanceType<typeof ElUpload>>()
const imageUrl = ref<string>()
const handleAvatarSuccess: UploadProps['onSuccess'] = (response, uploadFile) => {
  const { status, data } = response
  if (status) {
    // imageUrl.value = URL.createObjectURL(uploadFile.raw!)
    imageUrl.value = data.fileName
  }
}

const beforeAvatarUpload: UploadProps['beforeUpload'] = (rawFile) => {
  if (!['image/jpeg', 'image/jpg', 'image/png'].includes(rawFile.type)) {
    ElMessage.error('头像图片必须是jpg|jpeg|png其中一种')
    return false
  } else if (rawFile.size / 1024 / 1024 > 3) {
    ElMessage.error('头像图片尺寸不能超过3MB!')
    return false
  }
  return true
}

// 清空上传头像
const handleClearFiles = () => {
  imageUrl.value = ''
  uploadRef.value?.clearFiles()
}

// 提交
const handleSubmit = async () => {
  await validate()

  try {
    changeOkLoading(true)
    // 新增
    if (!unref(isUpdate)) {
      const data = getFieldsValue() as Omit<AddEmployeeInfoData, 'imageUrl'>

      const addData = {
        ...data,
        imageUrl: unref(imageUrl)
      }
      const { code, message } = await addEmployeeInfo(addData)
      if (code === 200) {
        ElMessage.success('新增成功')
        emit('success', { isUpdate: unref(isUpdate) })
      } else {
        ElMessage.error(message)
      }
    } else {
      const formData = getFieldsValue() as Omit<UpdateEmployeeInfoData, 'id' | 'imageUrl'>

      const data: UpdateEmployeeInfoData = {
        id: unref(rowId),
        ...formData,
        imageUrl: unref(imageUrl)
      }

      const { code, message } = await updateEmployeeInfo(data)
      if (code === 200) {
        ElMessage.success('修改成功')
        emit('success', { isUpdate: unref(isUpdate) })
      } else {
        ElMessage.error(message)
      }
    }
  } catch (error: any) {
    ElMessage(error.message)
  } finally {
    changeOkLoading(false)
  }
}
</script>

<style lang="scss" scoped>
.dialog-content-container {
  display: flex;
  .el-form {
    flex: 1;
  }

  .avatar-uploader-container {
    display: flex;
    flex-direction: column;
    align-items: center;

    .avatar-uploader {
      margin: 0 40px;
      :deep(.el-upload--text) {
        border: 1px dashed var(--el-border-color);
        border-radius: 6px;
        position: relative;
        overflow: hidden;
        transition: var(--el-transition-duration-fast);

        display: inline-flex;
        flex-direction: column;
        align-items: center;
        cursor: pointer;
        outline: none;

        --el-upload-dragger-padding-horizontal: 40px;
        --el-upload-dragger-padding-vertical: 10px;

        width: 160px;
        height: 160px;
      }

      .avatar {
        width: 160px;
        height: 160px;
        display: block;
      }

      .el-upload-list__item-actions {
        position: absolute;
        width: 100%;
        height: 100%;
        left: 0;
        top: 0;
        cursor: pointer;
        display: inline-flex;
        justify-content: center;
        align-items: center;
        color: #fff;
        opacity: 0;
        font-size: 20px;
        background-color: var(--el-overlay-color-lighter);
        transition: opacity var(--el-transition-duration);
        &:hover {
          opacity: 1;
        }

        .el-upload-list__item-delete {
          display: none;
          position: static;
        }

        &:hover span {
          display: inline-flex;
        }
      }

      .empty-avatar-container {
        display: inline-flex;
        flex-direction: column;
        .avatar-uploader-icon {
          font-size: 40px;
          color: #8c939d;

          display: inline-flex;
          justify-content: center;
          align-items: center;
        }

        .text {
          margin-top: 5px;
          color: #8c939d;
        }
      }
    }

    .tips {
      margin-top: 12px;
      color: #8c939d;
      user-select: none;
    }
  }
}
</style>
