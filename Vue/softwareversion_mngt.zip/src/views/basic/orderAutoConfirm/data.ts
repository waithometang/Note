export const orderStatusMap: Record<number, any> = {
  1: { label: '启用', value: 1, type: 'success' },
  2: { label: '停用', value: 2, type: 'danger' }
}
