<template>
  <div class="page-container">
    <vxe-grid class="box" ref="gridRef" v-bind="gridOptions">
      <template #top>
        <GridHeader
          ref="gridHeaderRef"
          v-bind="headerOptions"
          @quickSearch="handleQuickSearch"
          @add="handleAdd"
          @advancedSearch="handleAdvancedSearch"
          @reset="handleReset"
        />
      </template>
      <template #operation="{ row }">
        <TableAction
          :actions="[
            {
              icon: 'edit',
              tooltip: '编辑',
              onClick: handleModify.bind(null, row)
            },
            {
              icon: 'delete',
              tooltip: '删除',
              onClick: handleDelete.bind(null, row)
            }
          ]"
        />
      </template>
    </vxe-grid>
    <OrderAutoConfirmDialog @register="registerModal" @success="handleSuccess" />
  </div>
</template>

<script lang="tsx" setup>
import type { ComponentExposed } from 'vue-component-type-helpers'
import type {
  GetOrderAutoConfirmModel,
  GetOrderAutoConfirmParams
} from '@/api/sys/model/basicModel'
import type { VxeGridInstance, VxeGridProps } from 'vxe-table'
import type { GridHeaderProps } from '@/components/Table/types/gridHeader'

import { reactive, ref, computed } from 'vue'
import GridHeader from '@/components/Table/GridHeader.vue'
import TableAction from '@/components/Table/TableAction.vue'
import OrderAutoConfirmDialog from './components/OrderAutoConfirmDialog.vue'

import { deleteOrderAutoConfirm, getOrderAutoConfirm } from '@/api/sys/basic'
import { useModal } from '@/components/Modal/hooks/useModal'
import { error } from '@/utils/log'
import { orderStatusMap } from './data'

defineOptions({
  name: 'orderAutoConfirm',
  inheritAttrs: false
})

const gridHeaderRef =
  ref<ComponentExposed<typeof GridHeader<GetOrderAutoConfirmParams, 'SearchKey'>>>()

const headerOptions = reactive<GridHeaderProps>({
  title: '单据自动确认',
  quickSearch: {
    singleSearch: {
      field: 'SearchKey',
      type: 'input',
      title: '确认人'
    },
    searchFormFields: { SearchKey: '' }
  },
  showAdvancedSearchButton: false
})

const handleQuickSearch = () => {
  gridRef.value?.commitProxy('reload')
}

const handleAdvancedSearch = () => {
  gridRef.value?.commitProxy('reload')
}

const handleReset = () => {
  gridRef.value?.commitProxy('reload')
}

const gridRef = ref<VxeGridInstance<GetOrderAutoConfirmModel>>()
const gridOptions = reactive<VxeGridProps<GetOrderAutoConfirmModel>>({
  border: true,
  height: 'auto',
  align: null,
  columnConfig: {
    resizable: true
  },
  columns: [
    { type: 'seq', width: 50 },
    { field: 'moduleDisplayName', title: '单据类型' },
    { field: 'confirmEmployeeName', title: '确认人' },
    {
      field: 'overTime',
      title: '超时时间',
      formatter({ cellValue }) {
        return cellValue + 'h'
      }
    },
    {
      field: 'departmentName',
      title: '单据确认部门'
    },
    { field: 'groupName', title: '单据确认班组' },
    { field: 'createOrderEmployeeName', title: '指定申请人' },
    {
      field: 'orderStatus',
      title: '状态',
      width: 80,
      slots: {
        default({ row }) {
          return (
            <>
              <el-tag type={orderStatusMap[row.orderStatus].type}>
                {orderStatusMap[row.orderStatus].label}
              </el-tag>
            </>
          )
        }
      }
    },
    { field: 'lastModifiedUserName', title: '操作人' },
    { field: 'lastModifiedTime', title: '最后更新时间' },
    {
      field: 'operation',
      title: '操作',
      align: 'center',
      fixed: 'right',
      width: 150,
      slots: {
        default: 'operation'
      }
    }
  ],
  pagerConfig: {
    enabled: true,
    pageSize: 10
  },
  proxyConfig: {
    ajax: {
      query: ({ page }) => {
        const quickSearchForm = gridHeaderRef.value?.quickSearchForm
        const advancedSearchForm = gridHeaderRef.value?.advancedSearchForm
        return getOrderAutoConfirm({
          pageIndex: page.currentPage - 1, // 由于后端接口限制，首页从0开始
          pageSize: page.pageSize,
          ...quickSearchForm,
          ...advancedSearchForm
        })
      }
    }
  }
})

const [registerModal, { openModal, setModalProps }] = useModal()

const handleAdd = () => {
  openModal(true, {
    isUpdate: false
  })
}

const handleModify = (row: GetOrderAutoConfirmModel) => {
  openModal(true, {
    isUpdate: true,
    row
  })
}

const handleDelete = (row: GetOrderAutoConfirmModel) => {
  ElMessageBox.confirm(`是否确认删除单据类型为"${row.moduleName}"的数据项?`, '警告', {
    confirmButtonText: '确定',
    cancelButtonText: '取消',
    type: 'warning'
  })
    .then(async () => {
      try {
        const id = row.id
        const { data, message } = await deleteOrderAutoConfirm({ id })

        if (data) {
          ElMessage.success('删除成功')
        } else {
          ElMessage.error(message)
        }
      } catch (err: any) {
        error(err.message)
      }
    })
    .catch(() => {})
    .finally(() => {
      gridRef.value?.commitProxy('query')
    })
}
const handleSuccess = ({ isUpdate }: { isUpdate: boolean }) => {
  gridRef.value?.commitProxy('query')
}
</script>

<style lang="scss" scoped></style>
