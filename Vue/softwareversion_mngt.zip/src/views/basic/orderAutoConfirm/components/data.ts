export const moduleNameTypeOptions = [
  {
    label: '考勤登记',
    value: 'Attendance'
  },
  {
    label: '人员借调',
    value: 'Secondment'
  },
  {
    label: '生产报工',
    value: 'WorkReport'
  },
  {
    label: '其他报工',
    value: 'OtherWorkReport'
  }
]
