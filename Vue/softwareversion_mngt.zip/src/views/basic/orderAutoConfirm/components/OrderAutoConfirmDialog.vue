<template>
  <BasicModal
    width="30%"
    v-bind="$attrs"
    @register="registerModal"
    :title="getTitle"
    @confirm="handleSubmit"
  >
    <BasicForm @register="registerForm" />
  </BasicModal>
</template>

<script lang="tsx" setup>
import type {
  AddOrderAutoConfirmData,
  CreateOrderEmployeeJson,
  UpdateOrderAutoConfirmData
} from '@/api/sys/model/basicModel'
import type { ModalMethods } from '@/components/Modal/types'
import type { GetEmployeeInfoModel } from '@/api/sys/model/basicModel'
import type { SelectModel } from '@/api/model/baseModel'

import { computed, ref, unref } from 'vue'
import BasicModal from '@/components/Modal/BasicModal.vue'
import { useModalInner } from '@/components/Modal/hooks/useModal'
import BasicForm from '@/components/Form/BasicForm.vue'
import { useForm } from '@/components/Form/hooks/useForm'
import { moduleNameTypeOptions } from './data'

import {
  addOrderAutoConfirm,
  getGroupSelect,
  getManufactureDepartmentList,
  updateOrderAutoConfirm
} from '@/api/sys/basic'

const emit = defineEmits<{
  register: [modalMethods: ModalMethods, uuid: number]
  success: [{ isUpdate: boolean }]
}>()

const isUpdate = ref<boolean>(false)
const rowId = ref('')

const [registerModal, { closeModal, setModalProps, changeOkLoading }] = useModalInner(
  async (data) => {
    resetFields()
    setModalProps({ confirmLoading: false })
    isUpdate.value = !!data?.isUpdate

    // 修改设置表单
    if (unref(isUpdate)) {
      rowId.value = data.row.id

      const createOrderEmployeeId = data.row.createOrderEmployeeJson.map(
        (item: CreateOrderEmployeeJson) => item.id
      )

      setFieldsValue({
        ...data.row,
        createOrderEmployeeId: createOrderEmployeeId
      })
    }
  }
)

const getTitle = computed(() => (!unref(isUpdate) ? '新增' : '修改'))

const [registerForm, { setFieldsValue, resetFields, getFieldsValue, validate, updateSchema }] =
  useForm({
    labelWidth: 160,
    schemas: [
      {
        field: 'moduleName',
        component: 'Select',
        label: '单据类型',
        rules: [{ required: true, trigger: 'change' }],
        componentProps: {
          filter: true,
          options: moduleNameTypeOptions,
          style: 'width: 60%'
        },
        colProps: {
          span: 24
        }
      },
      {
        field: 'confirmEmployeeID',
        component: 'PersonSelect',
        label: '确认人',
        rules: [{ required: true, trigger: 'change' }],
        componentProps: {
          formatter(personInfo: GetEmployeeInfoModel) {
            return personInfo.employeeNo + '-' + personInfo.employeeName
          }
        },
        colProps: {
          span: 20
        }
      },
      {
        field: 'overTime',
        component: 'ElInputNumber',
        label: '单据超时时间',
        defaultValue: 1,
        rules: [{ required: true, trigger: 'change' }],
        componentProps: {
          min: 0
        },
        suffix: () => {
          return <span style="margin-left: 8px;">h</span>
        },
        colProps: {
          span: 16
        }
      },
      {
        field: 'departmentID',
        component: 'ApiSelect',
        label: '单据确认部门',
        rules: [{ required: true, trigger: 'change' }],
        componentProps({ formActionType, formModel }) {
          return {
            api: getManufactureDepartmentList,
            resultField: 'data',
            labelField: 'name',
            valueField: 'id',
            filterable: true,
            style: 'width: 60%',
            async onChange(value: string) {
              formModel.groupID = undefined
              let options: SelectModel[] = []
              if (!(value === '')) {
                const { data } = await getGroupSelect({ departmentID: value })
                options = data.result
              }
              const { updateSchema } = formActionType
              updateSchema({
                field: 'groupID',
                componentProps: {
                  options: options
                }
              })
            }
          }
        },
        colProps: {
          span: 24
        }
      },
      {
        field: 'groupID',
        component: 'Select',
        rules: [{ required: true, trigger: 'change' }],
        label: '单据确认班组',
        componentProps: {
          options: [],
          style: 'width: 60%'
        },
        colProps: {
          span: 24
        }
      },
      {
        field: 'createOrderEmployeeId',
        component: 'PersonSelect',
        label: '单据指定申请人员',
        componentProps: {
          formatter(personInfo: GetEmployeeInfoModel) {
            return personInfo.employeeNo + '-' + personInfo.employeeName
          },
          multiple: true
        },
        colProps: {
          span: 20
        }
      },
      {
        field: 'orderStatus',
        label: '状态',
        component: 'Select',
        defaultValue: 1,
        componentProps: {
          options: [
            { label: '启用', value: 1 },
            { label: '停用', value: 2 }
          ],
          style: 'width: 60%'
        },
        colProps: {
          span: 24
        }
      }
    ]
  })

// 提交
const handleSubmit = async () => {
  try {
    //
    changeOkLoading(true)

    validate(async (isValid) => {
      if (isValid) {
        // 新增
        if (!unref(isUpdate)) {
          const data = getFieldsValue()
          const { code, message } = await addOrderAutoConfirm(data as AddOrderAutoConfirmData)
          if (code === 200) {
            ElMessage.success('新增成功')
            closeModal()
            emit('success', { isUpdate: unref(isUpdate) })
          } else {
            ElMessage.error(message)
          }
        } else {
          const formData = getFieldsValue() as Omit<UpdateOrderAutoConfirmData, 'id'>

          const data = {
            id: unref(rowId),
            ...formData
          }

          const { code, message } = await updateOrderAutoConfirm(data)
          if (code === 200) {
            ElMessage.success('修改成功')
            closeModal()
            emit('success', { isUpdate: unref(isUpdate) })
          } else {
            ElMessage.error(message)
          }
        }
      }
    })
  } catch (error: any) {
    ElMessage(error.message)
  } finally {
    changeOkLoading(false)
  }
}
</script>

<style lang="scss" scoped></style>
