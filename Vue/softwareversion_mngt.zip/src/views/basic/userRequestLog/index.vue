<template>
  <div class="page-container">
    <div class="box main-container">
      <GridHeader ref="gridHeaderRef" v-bind="headerOptions" v-on="headerEvent">
        <template #prependOperation>
          <div class="chart-switch-container">
            <span>数据</span>
            <el-switch style="margin-left: 4px" v-model="showData" size="large" />
          </div>
          <div class="chart-switch-container">
            <span>统计图</span>
            <el-switch style="margin-left: 4px" v-model="showChart" size="large" />
          </div>
        </template>
      </GridHeader>
      <div class="content-container">
        <div class="table-container" v-show="showData">
          <vxe-grid ref="gridRef" v-bind="gridOptions" />
        </div>
        <div class="chart-container" v-show="showChart">
          <DepartmentalVisitsChart :data="departmentAccessModel" />
          <ModuleAccessChart :data="modelAccessModel" />
        </div>
      </div>
    </div>
  </div>
</template>

<script lang="ts" setup>
import type { ComponentExposed } from 'vue-component-type-helpers'
import type { VxeGridInstance, VxeGridProps } from 'vxe-table'
import type {
  DepartmentAccessModel,
  GetUserRequestLogModel,
  ModelAccessModel
} from '@/api/sys/model/basicModel'
import type { GridHeaderProps, GridHeaderEvent } from '@/components/Table/types/gridHeader'

import { reactive, ref, unref } from 'vue'
import dayjs from 'dayjs'
import GridHeader from '@/components/Table/GridHeader.vue'
import DepartmentalVisitsChart from './components/DepartmentalVisitsChart.vue'
import ModuleAccessChart from './components/ModuleAccessChart.vue'
import { exportUserRequestLog, getUserRequestLog } from '@/api/sys/basic'
import { dateShortcuts } from '@/constant'

defineOptions({
  name: 'UserRequestLog',
  inheritAttrs: false
})
const departmentAccessModel = ref<DepartmentAccessModel[]>()
const modelAccessModel = ref<ModelAccessModel[]>()
const gridHeaderRef = ref<ComponentExposed<typeof GridHeader>>()

const headerOptions = reactive<GridHeaderProps>({
  title: '操作日志',
  quickSearch: {
    // fieldMapToTime: ['logTime', ['startLogTime', 'endLogTime'], 'YYYY-MM-DD'],
    singleSearch: {
      field: 'logTime',
      type: 'date',
      title: '日期',
      componentProps: {
        type: 'daterange',
        unlinkPanels: true,
        shortcuts: dateShortcuts,
        valueFormat: 'YYYY-MM-DD'
      }
    },
    searchFormFields: {
      logTime: [dayjs().subtract(1, 'day').format('YYYY-MM-DD'), dayjs().format('YYYY-MM-DD')]
    }
  },
  showAdvancedSearchButton: false,
  showAddButton: false,
  showExportButton: true,
  exportApi: exportUserRequestLog
})

const headerEvent: GridHeaderEvent = {
  quickSearch() {
    gridRef.value?.commitProxy('reload')
  },
  advancedSearch() {
    gridRef.value?.commitProxy('reload')
  },
  reset() {
    gridRef.value?.commitProxy('reload')
  }
}

const gridRef = ref<VxeGridInstance>()
const gridOptions = reactive<VxeGridProps<GetUserRequestLogModel>>({
  border: true,
  height: 'auto',
  align: null,
  columnConfig: {
    resizable: true
  },
  columns: [
    { type: 'seq', width: 50 },
    { field: 'employeeNo', title: '账号', width: 100 },
    { field: 'employeeName', title: '操作人员', width: 130 },
    { field: 'departmentName', title: '部门', width: 150 },
    { field: 'groupName', title: '班组', width: 150 },
    { field: 'moduleName', title: '系统模块' },
    { field: 'operationBehavior', title: '行为' },
    { field: 'createTime', title: '操作时间' }
  ],
  pagerConfig: {
    enabled: true,
    pageSize: 20
  },
  proxyConfig: {
    props: {
      list: null,
      result: 'result',
      total: 'total'
    },
    ajax: {
      query: ({ page }) => {
        const quickSearchForm = unref(gridHeaderRef.value?.quickSearchForm) as {
          logTime: [string, string]
        }
        const { logTime = [] } = quickSearchForm
        const [startLogTime = '', endLogTime = ''] = logTime
        const advancedSearchForm = gridHeaderRef.value?.advancedSearchForm
        return new Promise((resolve, reject) => {
          getUserRequestLog({
            pageIndex: page.currentPage - 1, // 由于后端接口限制，首页从0开始
            pageSize: page.pageSize,
            startLogTime,
            endLogTime,
            ...advancedSearchForm
          })
            .then(({ data }) => {
              departmentAccessModel.value = data.departmentAccessModel
              modelAccessModel.value = data.modelAccessModel

              resolve(data.userRequestLogAccessModel)
            })
            .catch((err) => {
              reject(err)
            })
        })
      }
    }
  }
})

const showData = ref(true)
const showChart = ref(true)
</script>

<style lang="scss" scoped>
.page-container {
  .main-container {
    width: 100%;
    height: 100%;
    display: flex;
    flex-direction: column;
    .chart-switch-container {
      margin-right: $margin;
      display: flex;
      align-items: center;
    }
    .content-container {
      flex: 1;
      height: 0;
      width: 100%;
      display: flex;
      .table-container {
        flex: 2;
        width: 0;
      }
      .chart-container {
        flex: 1;
        width: 0;
        display: flex;
        flex-direction: column;
      }
    }
  }
}
</style>
