<template>
  <v-chart style="flex: 1; height: 0" ref="chartRef" autoresize :option="option" />
</template>

<script lang="ts" setup>
import type { PropType } from 'vue'
import type { DepartmentAccessModel } from '@/api/sys/model/basicModel'

import { unref, computed, toRefs } from 'vue'
import VChart from 'vue-echarts'
import { use } from 'echarts/core'
import { PieChart } from 'echarts/charts'
import { TitleComponent, TooltipComponent, LegendComponent } from 'echarts/components'
import { CanvasRenderer } from 'echarts/renderers'
import type { ComposeOption } from 'echarts/core'
import type { PieSeriesOption } from 'echarts/charts'
import type {
  TitleComponentOption,
  TooltipComponentOption,
  LegendComponentOption
} from 'echarts/components'

const props = defineProps({
  data: {
    type: Array as PropType<DepartmentAccessModel[]>,
    defalut: () => {
      return []
    }
  }
})

use([TitleComponent, TooltipComponent, LegendComponent, PieChart, CanvasRenderer])

type EChartsOption = ComposeOption<
  TitleComponentOption | TooltipComponentOption | LegendComponentOption | PieSeriesOption
>

const { data } = toRefs(props)
const option = computed<EChartsOption>(() => {
  return {
    title: {
      text: '部门访问量统计',
      left: 'left'
    },
    tooltip: {
      trigger: 'item'
    },
    legend: {
      // orient: 'vertical',
      left: 'center',
      bottom: 'bottom',
      type: 'scroll'
    },
    series: [
      {
        name: '部门访问量统计',
        type: 'pie',
        radius: '50%',
        data: unref(data)?.map((item) => ({
          name: item.departmentName,
          value: item.departmentSumCount
        })),
        emphasis: {
          itemStyle: {
            shadowBlur: 10,
            shadowOffsetX: 0,
            shadowColor: 'rgba(0, 0, 0, 0.5)'
          }
        },
        label: {
          formatter: '{b}: {c} ({d}%)'
        }
      }
    ]
  }
})
</script>

<style lang="scss" scoped></style>
