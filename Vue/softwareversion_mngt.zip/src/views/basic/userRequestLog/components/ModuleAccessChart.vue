<template>
  <v-chart style="flex: 1; height: 0" ref="chartRef" autoresize :option="option" />
</template>

<script lang="ts" setup>
import type { PropType } from 'vue'
import { unref, computed, toRefs } from 'vue'
import VChart from 'vue-echarts'

import { use } from 'echarts/core'
import { BarChart } from 'echarts/charts'
import {
  TitleComponent,
  TooltipComponent,
  GridComponent,
  DataZoomComponent
} from 'echarts/components'
import { CanvasRenderer } from 'echarts/renderers'
import type { ComposeOption } from 'echarts/core'
import type { BarSeriesOption } from 'echarts/charts'
import type {
  GridComponentOption,
  TitleComponentOption,
  TooltipComponentOption,
  DataZoomComponentOption
} from 'echarts/components'
import type { ModelAccessModel } from '@/api/sys/model/basicModel'

const props = defineProps({
  data: {
    type: Array as PropType<ModelAccessModel[]>,
    defalut: () => {
      return []
    }
  }
})

use([TitleComponent, TooltipComponent, GridComponent, DataZoomComponent, BarChart, CanvasRenderer])

type EChartsOption = ComposeOption<
  | TitleComponentOption
  | TooltipComponentOption
  | GridComponentOption
  | DataZoomComponentOption
  | BarSeriesOption
>
const { data } = toRefs(props)

const option = computed((): EChartsOption => {
  return {
    title: {
      text: '模块访问量统计',
      left: 'left'
    },
    tooltip: {
      trigger: 'item'
    },
    grid: {
      bottom: '30%'
    },
    dataZoom: [
      {
        show: true,
        type: 'slider',
        xAxisIndex: 0,
        startValue: 0,
        endValue: 5
      }
    ],
    xAxis: {
      type: 'category',
      data: unref(data)?.map((item) => item.modelName),
      axisLabel: {
        interval: 0,
        // rotate: 45,
        formatter(value: string) {
          // 判断文本中是否包含中文
          const reg = new RegExp('[\\u4E00-\\u9FFF]+', 'g')
          if (reg.test(value)) {
            return value.replace(/(.{4})/g, '$1\n')
          } else {
            return value.replace(/(.{10})/g, '$1\n')
          }
        }
      }
    },
    yAxis: {
      type: 'value'
    },
    series: [
      {
        name: '模块访问量统计',
        data: unref(data)?.map((item) => item.modelSumCount),
        type: 'bar',
        label: {
          show: true,
          position: 'top'
        }
      }
    ]
  }
})
</script>

<style lang="scss" scoped></style>
