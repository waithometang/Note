<template>
  <div class="page-container">
    <vxe-grid class="box" ref="gridRef" v-bind="gridOptions">
      <template #top>
        <GridHeader
          ref="gridHeaderRef"
          v-bind="headerOptions"
          @quickSearch="handleQuickSearch"
          @add="handleAdd"
          @advancedSearch="handleAdvancedSearch"
          @reset="handleReset"
        />
      </template>
      <template #operation="{ row }">
        <TableAction
          :actions="[
            {
              icon: 'edit',
              tooltip: '编辑',
              onClick: handleModify.bind(null, row)
            },
            {
              icon: 'delete',
              tooltip: '删除',
              onClick: handleDelete.bind(null, row)
            }
          ]"
        />
      </template>
    </vxe-grid>
    <ConfirmSignatureTypeDialog @register="registerModal" @success="handleSuccess" />
  </div>
</template>

<script lang="tsx" setup>
import type { ComponentExposed } from 'vue-component-type-helpers'
import type {
  GetConfirmSignatureTypeModel,
  GetConfirmSignatureTypeParams
} from '@/api/sys/model/basicModel'
import type { VxeGridInstance, VxeGridProps } from 'vxe-table'
import type { GridHeaderProps } from '@/components/Table/types/gridHeader'

import { reactive, ref } from 'vue'
import GridHeader from '@/components/Table/GridHeader.vue'
import TableAction from '@/components/Table/TableAction.vue'
import ConfirmSignatureTypeDialog from './components/ConfirmSignatureTypeDialog.vue'

import { deleteConfirmSignatureType, getConfirmSignatureType } from '@/api/sys/basic'
import { useModal } from '@/components/Modal/hooks/useModal'
import { error } from '@/utils/log'

defineOptions({
  name: 'ConfirmSignatureType',
  inheritAttrs: false
})

const gridHeaderRef =
  ref<ComponentExposed<typeof GridHeader<GetConfirmSignatureTypeParams, 'SearchKey'>>>()

const headerOptions = reactive<GridHeaderProps>({
  title: '应用审批管理',
  quickSearch: {
    singleSearch: {
      field: 'SearchKey',
      type: 'input',
      title: '应用名称/审批人'
    },
    searchFormFields: { SearchKey: '' }
  },
  showAdvancedSearchButton: false
})

const handleQuickSearch = () => {
  gridRef.value?.commitProxy('reload')
}

const handleAdvancedSearch = () => {
  gridRef.value?.commitProxy('reload')
}

const handleReset = () => {
  gridRef.value?.commitProxy('reload')
}

const approvalMethods: Recordable<string> = {
  1: '或签',
  2: '会签',
  3: '依次审批'
}

const gridRef = ref<VxeGridInstance<GetConfirmSignatureTypeModel>>()
const gridOptions = reactive<VxeGridProps<GetConfirmSignatureTypeModel>>({
  border: true,
  height: 'auto',
  align: null,
  columnConfig: {
    resizable: true
  },
  columns: [
    { type: 'seq', width: 50 },
    { field: 'typeModuleName', title: '应用标识' },
    { field: 'typeModuleTitle', title: '应用名称' },
    {
      field: 'confirmationPersonJson',
      title: '审批人',
      formatter({ cellValue }) {
        return cellValue
          .map(
            (item: { id: string; employeeNo: string; employeeName: string }) =>
              item.employeeNo + '-' + item.employeeName
          )
          .join(',')
      }
    },
    {
      field: 'approvalMethod',
      title: '签名方式',
      formatter({ cellValue }) {
        return approvalMethods[cellValue]
      }
    },
    { field: 'createTime', title: '创建时间' },
    { field: 'lastModifiedTime', title: '上一次修改时间' },
    {
      field: 'dataStatus',
      title: '数据状态',
      width: 150,
      visible: false
    },
    { field: 'dataDescribe', title: '数据备注', visible: false },
    {
      field: 'operation',
      title: '操作',
      align: 'center',
      fixed: 'right',
      width: 150,
      slots: {
        default: 'operation'
      }
    }
  ],
  pagerConfig: {
    enabled: true,
    pageSize: 10
  },
  proxyConfig: {
    ajax: {
      query: ({ page }) => {
        const quickSearchForm = gridHeaderRef.value?.quickSearchForm
        const advancedSearchForm = gridHeaderRef.value?.advancedSearchForm
        return getConfirmSignatureType({
          pageIndex: page.currentPage - 1, // 由于后端接口限制，首页从0开始
          pageSize: page.pageSize,
          ...quickSearchForm,
          ...advancedSearchForm
        })
      }
    }
  }
})

const [registerModal, { openModal, setModalProps }] = useModal()

const handleAdd = () => {
  openModal(true, {
    isUpdate: false
  })
}

const handleModify = (row: GetConfirmSignatureTypeModel) => {
  openModal(true, {
    isUpdate: true,
    row
  })
}

const handleDelete = (row: GetConfirmSignatureTypeModel) => {
  ElMessageBox.confirm(`是否确认删除应用名称为"${row.typeModuleName}"的数据项?`, '警告', {
    confirmButtonText: '确定',
    cancelButtonText: '取消',
    type: 'warning'
  })
    .then(async () => {
      try {
        const id = row.id
        const { data, message } = await deleteConfirmSignatureType({ id })

        if (data) {
          ElMessage.success('删除成功')
        } else {
          ElMessage.error(message)
        }
      } catch (err: any) {
        error(err.message)
      }
    })
    .catch(() => {})
    .finally(() => {
      gridRef.value?.commitProxy('query')
    })
}
const handleSuccess = ({ isUpdate }: { isUpdate: boolean }) => {
  gridRef.value?.commitProxy('query')
}
</script>

<style lang="scss" scoped></style>
