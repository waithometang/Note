<template>
  <BasicModal
    width="25%"
    v-bind="$attrs"
    @register="registerModal"
    :title="getTitle"
    @confirm="handleSubmit"
  >
    <BasicForm @register="registerForm" />
  </BasicModal>
</template>

<script lang="tsx" setup>
import type {
  AddConfirmSignatureTypeData,
  ConfirmationPersonJson,
  UpdateConfirmSignatureTypeData
} from '@/api/sys/model/basicModel'
import type { ModalMethods } from '@/components/Modal/types'
import type { GetEmployeeInfoModel } from '@/api/sys/model/basicModel'

import { computed, ref, unref } from 'vue'
import BasicModal from '@/components/Modal/BasicModal.vue'
import { useModalInner } from '@/components/Modal/hooks/useModal'
import BasicForm from '@/components/Form/BasicForm.vue'
import useAppStore from '@/stores/app'
import { getLoginUserMenu } from '@/api/sys/system'
import { useForm } from '@/components/Form/hooks/useForm'

import { addConfirmSignatureType, updateConfirmSignatureType } from '@/api/sys/basic'

const emit = defineEmits<{
  register: [modalMethods: ModalMethods, uuid: number]
  success: [{ isUpdate: boolean }]
}>()

const isUpdate = ref<boolean>(false)
const rowId = ref('')
const appStore = useAppStore()

const [registerModal, { closeModal, setModalProps, changeOkLoading }] = useModalInner(
  async (data) => {
    resetFields()
    setModalProps({ confirmLoading: false })
    isUpdate.value = !!data?.isUpdate

    // 修改设置表单
    if (unref(isUpdate)) {
      rowId.value = data.row.id

      const confirmationPersonJson = data.row.confirmationPersonJson.map(
        (item: ConfirmationPersonJson) => item.id
      )

      setFieldsValue({
        ...data.row,
        employeeInfoId: confirmationPersonJson
      })
    }
  }
)

const getTitle = computed(() => (!unref(isUpdate) ? '新增' : '修改'))

const [registerForm, { setFieldsValue, resetFields, getFieldsValue, validate, updateSchema }] =
  useForm({
    labelWidth: 120,
    schemas: [
      {
        field: 'typeModuleTitle',
        component: 'ApiCascader',
        label: '应用名称',
        rules: [{ required: true, trigger: 'change' }],
        componentProps({ formActionType }) {
          const { setFieldsValue } = formActionType
          return {
            api: getLoginUserMenu,
            params: {
              applicationID: appStore.appInfo.applicationID,
              systemType: appStore.appInfo.systemType,
              systemTypeID: appStore.appInfo.systemTypeID
            },
            labelField: 'title',
            valueField: 'title',
            resultField: 'data',
            childrenField: 'children',
            props: {
              checkStrictly: true,
              emitPath: false
            },
            onChange(value: string, option: any) {
              setFieldsValue({ typeModuleName: option?.name })
            }
          }
        },
        colProps: {
          span: 24
        }
      },
      {
        field: 'typeModuleName',
        component: 'ElInput',
        label: '应用名称',
        show: false,
        rules: [{ required: true, trigger: 'change' }],
        componentProps: {},
        colProps: {
          span: 24
        }
      },
      {
        field: 'employeeInfoId',
        component: 'PersonSelect',
        label: '审批人',
        rules: [{ required: true, trigger: 'change' }],
        componentProps: {
          multiple: true,
          formatter(personInfo: GetEmployeeInfoModel) {
            return personInfo.employeeNo + '-' + personInfo.employeeName
          }
        },
        colProps: {
          span: 24
        }
      },
      {
        field: 'approvalMethod',
        component: 'Select',
        label: '签名方式',
        rules: [{ required: true, trigger: 'change' }],
        componentProps: {
          options: [
            {
              value: 1,
              label: '或签'
            },
            {
              value: 2,
              label: '会签'
            },
            {
              value: 3,
              label: '依次审批'
            }
          ]
        },
        colProps: {
          span: 24
        }
      }
    ]
  })

// 提交
const handleSubmit = async () => {
  try {
    //
    changeOkLoading(true)

    validate(async (isValid) => {
      if (isValid) {
        // 新增
        if (!unref(isUpdate)) {
          const data = getFieldsValue()
          const { code, message } = await addConfirmSignatureType(
            data as AddConfirmSignatureTypeData
          )
          if (code === 200) {
            ElMessage.success('新增成功')
            closeModal()
            emit('success', { isUpdate: unref(isUpdate) })
          } else {
            ElMessage.error(message)
          }
        } else {
          const formData = getFieldsValue() as Omit<UpdateConfirmSignatureTypeData, 'id'>

          const data = {
            id: unref(rowId),
            ...formData
          }

          const { code, message } = await updateConfirmSignatureType(data)
          if (code === 200) {
            ElMessage.success('修改成功')
            closeModal()
            emit('success', { isUpdate: unref(isUpdate) })
          } else {
            ElMessage.error(message)
          }
        }
      }
    })
  } catch (error: any) {
    ElMessage(error.message)
  } finally {
    changeOkLoading(false)
  }
}
</script>

<style lang="scss" scoped></style>
