<template>
  <div class="page-container">
    <DepartmentInfo
      class="department-container"
      @cell-click="handleDepartmentCellClick"
      @search="handleSearch"
      @delete="handleDelete"
      @addOrEditSuccess="handleAddOrEditSuccess"
    />
    <GroupInfo ref="groupInfoRef" />
  </div>
</template>

<script setup lang="ts">
import type { GetDepartmentModel } from '@/api/sys/model/basicModel'

import DepartmentInfo from './components/DepartmentInfo.vue'
import GroupInfo from './components/GroupInfo.vue'

import { ref } from 'vue'

defineOptions({
  name: 'Department',
  inheritAttrs: false
})

const groupInfoRef = ref<InstanceType<typeof GroupInfo>>()

const handleDepartmentCellClick = (data: GetDepartmentModel) => {
  groupInfoRef.value?.handleQuickSearch(data)
}
const handleDelete = () => {
  groupInfoRef.value?.handleReset()
}

const handleSearch = () => {
  groupInfoRef.value!.departmentInfo = void 0
  groupInfoRef.value?.handleReset()
}

const handleAddOrEditSuccess = ({ isUpdate }: { isUpdate: boolean }) => {
  if (isUpdate) {
    groupInfoRef.value?.handleReset()
  }
}
</script>

<style scoped lang="scss">
.page-container {
  height: auto;
}
.department-container {
  margin-bottom: $margin;
}
</style>
