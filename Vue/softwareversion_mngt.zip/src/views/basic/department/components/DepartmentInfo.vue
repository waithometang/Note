<template>
  <div>
    <vxe-grid class="box" ref="gridRef" v-bind="gridOptions" v-on="gridEvents">
      <template #top>
        <GridHeader
          ref="gridHeaderRef"
          v-bind="headerOptions"
          @quickSearch="handleQuickSearch"
          @add="handleAdd"
        >
        </GridHeader>
      </template>
      <template #operation="{ row }">
        <TableAction
          :actions="[
            {
              icon: 'edit',
              tooltip: '编辑',
              onClick: handleModify.bind(null, row)
            },
            {
              icon: 'delete',
              tooltip: '删除',
              onClick: handleDelete.bind(null, row)
            }
          ]"
        />
      </template>
    </vxe-grid>
    <DepartmentDialog @register="registerModal" @success="handleSuccess" />
  </div>
</template>

<script setup lang="ts">
import type { ComponentExposed } from 'vue-component-type-helpers'
import type { VxeGridInstance, VxeGridProps, VxeGridListeners } from 'vxe-table'
import type { GridHeaderProps } from '@/components/Table/types/gridHeader'
import type { GetDepartmentModel, GetDepartmentParams } from '@/api/sys/model/basicModel'

import { reactive, ref, computed } from 'vue'
import { getDepartment, deleteDepartment, exportDepartment } from '@/api/sys/basic'

import { useModal } from '@/components/Modal/hooks/useModal'

import GridHeader from '@/components/Table/GridHeader.vue'

import DepartmentDialog from './DepartmentDialog.vue'


const gridHeaderRef =
  ref<ComponentExposed<typeof GridHeader<GetDepartmentParams, 'DepartmentName'>>>()

const headerOptions = reactive<GridHeaderProps>({
  title: '部门信息',
  quickSearch: {
    singleSearch: {
      field: 'DepartmentName',
      type: 'input',
      title: '部门名称'
    },
    searchFormFields: { DepartmentName: '' }
  },
  showAdvancedSearchButton: false,
  showExportButton: true,
  exportApi: exportDepartment,
  exportParams: computed(() => {
    const quickSearchForm = gridHeaderRef.value?.quickSearchForm
    return { ...quickSearchForm }
  })
})

const gridRef = ref<VxeGridInstance>()
const gridOptions = reactive<VxeGridProps<GetDepartmentModel>>({
  border: true,
  maxHeight: '500px',
  minHeight: '10px',
  align: null,
  columnConfig: {
    resizable: true
  },
  treeConfig: {
    rowField: 'id',
    parentField: 'fatherID',
    childrenField: 'sonData'
  },
  columns: [
    { type: 'seq', width: 50 },
    { field: 'departmentName', title: '部门名称', width: 150, treeNode: true },
    { field: 'sortNo', title: '排序', width: 100 },
    { field: 'dataDescribe', title: '备注' },
    { field: 'createTime', title: '创建时间', width: 150 },
    { field: 'createUserName', title: '创建用户', width: 150 },
    { field: 'lastModifiedUserName', title: '最后修改用户', width: 150 },
    { field: 'lastModifiedTime', title: '最后修改时间', width: 150 },
    {
      field: 'operation',
      title: '操作',
      align: 'center',
      fixed: 'right',
      width: 150,
      slots: {
        default: 'operation'
      }
    }
  ],
  pagerConfig: {
    enabled: false
  },
  proxyConfig: {
    ajax: {
      query: () => {
        const quickSearchForm = gridHeaderRef.value?.quickSearchForm || {}

        return new Promise((res, rej) => {
          getDepartment({
            ...quickSearchForm
          })
            .then((data) => {
              const r = data.data.result.map((item) => {
                item.fatherID === '0' ? (item.fatherID = null) : ''
                return { ...item }
              })
              res(r)
            })
            .catch((err) => rej(err))
        })
      }
    }
  }
})

const emit = defineEmits(['cell-click', 'delete', 'addOrEditSuccess', 'search']) as EmitType

const gridEvents: VxeGridListeners<GetDepartmentModel> = {
  cellClick(data) {
    emit('cell-click', data.row)
  }
}

const handleQuickSearch = () => {
  gridRef.value?.commitProxy('reload')
  emit('search')
}

const [registerModal, { openModal, closeModal }] = useModal()

const handleAdd = () => {
  openModal(true, {
    isUpdate: false
  })
}

const handleModify = (row: GetDepartmentModel) => {
  openModal(true, {
    isUpdate: true,
    row
  })
}

const handleDelete = (row: GetDepartmentModel) => {
  ElMessageBox.confirm(`是否删除名称为"${row.departmentName}"的数据项`, '警告', {
    confirmButtonText: '确定',
    cancelButtonText: '取消',
    type: 'warning'
  }).then(() => {
    deleteDepartment({ id: row.id }).then((res) => {
      if (res.code === 200) {
        ElMessage.success('删除')
        gridRef.value?.commitProxy('query')
        emit('delete')
      } else {
        ElMessage.error(res.message)
      }
    })
  })
}
const handleSuccess = ({ isUpdate }: { isUpdate: boolean }) => {
  closeModal()
  gridRef.value?.commitProxy('query')
  emit('addOrEditSuccess', { isUpdate })
}
</script>

<style scoped></style>
