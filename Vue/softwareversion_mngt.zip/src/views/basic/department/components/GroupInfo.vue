<template>
  <div>
    <vxe-grid class="box" ref="gridRef" v-bind="gridOptions">
      <template #top>
        <GridHeader
          ref="gridHeaderRef"
          v-bind="headerOptions"
          @quickSearch="handleQuickSearch(departmentInfo)"
          @add="handleAdd"
        />
      </template>
      <template #operation="{ row }">
        <TableAction
          :actions="[
            {
              icon: 'edit',
              tooltip: '编辑',
              onClick: handleModify.bind(null, row)
            },
            {
              icon: 'delete',
              tooltip: '删除',
              onClick: handleDelete.bind(null, row)
            }
          ]"
        />
      </template>
    </vxe-grid>
    <GroupDialog @register="registerModal" @success="handleSuccess" />
  </div>
</template>

<script setup lang="ts">
import type { ComponentExposed } from 'vue-component-type-helpers'
import { reactive, ref } from 'vue'
import { getGroup, deleteGroup } from '@/api/sys/basic'

import type { VxeGridInstance, VxeGridProps } from 'vxe-table'
import type { GridHeaderProps } from '@/components/Table/types/gridHeader'
import type { GetGroupModel, GetDepartmentModel } from '@/api/sys/model/basicModel'

import { useModal } from '@/components/Modal/hooks/useModal'

import GridHeader from '@/components/Table/GridHeader.vue'
import GroupDialog from './GroupDialog.vue'

const departmentInfo = ref<GetDepartmentModel>()

const gridHeaderRef = ref<ComponentExposed<typeof GridHeader>>()

const headerOptions = reactive<GridHeaderProps>({
  title: `组别信息`,
  quickSearch: {
    singleSearch: {
      field: 'GroupName',
      type: 'input',
      title: '组别名称'
    },
    searchFormFields: { GroupName: '' }
  },
  showAdvancedSearchButton: false
})

const gridRef = ref<VxeGridInstance>()
const gridOptions = reactive<VxeGridProps<GetGroupModel>>({
  border: true,
  minHeight: '500px',
  maxHeight: '604px',
  align: null,
  columnConfig: {
    resizable: true
  },
  columns: [
    { type: 'seq', width: 50 },
    { field: 'groupName', title: '组别名称', width: 150 },
    { field: 'sortNo', title: '排序', width: 100 },
    { field: 'productionAddressName', title: '厂区位置' },
    { field: 'leaderName', title: '班组长' },
    { field: 'createTime', title: '创建时间', width: 150 },
    { field: 'createUserName', title: '创建用户', width: 150 },
    { field: 'lastModifiedUserName', title: '最后修改用户', width: 150 },
    { field: 'lastModifiedTime', title: '最后修改时间', width: 150 },
    {
      field: 'operation',
      title: '操作',
      align: 'center',
      fixed: 'right',
      width: 150,
      slots: {
        default: 'operation'
      }
    }
  ],
  pagerConfig: {
    enabled: true,
    pageSize: 10
  },
  proxyConfig: {
    autoLoad: false,
    ajax: {
      query: ({ page }) => {
        const quickSearchForm = gridHeaderRef.value?.quickSearchForm
        return getGroup({
          pageIndex: page.currentPage - 1, // 由于后端接口限制，首页从0开始
          pageSize: page.pageSize,
          DepartmentID: departmentInfo.value?.id,
          ...quickSearchForm
        })
      }
    }
  }
})

const handleQuickSearch = (department?: GetDepartmentModel) => {
  departmentInfo.value = department
  if (!department) {
    handleReset()
    ElMessage.warning('请先选择部门')
    return
  }
  headerOptions.title = `[${departmentInfo.value?.departmentName}]组别信息`
  gridRef.value?.commitProxy('reload')
}

const [registerModal, { openModal, closeModal }] = useModal()

const handleAdd = () => {
  if (!departmentInfo.value) {
    ElMessage.warning('请先选择部门')
    return
  }
  openModal(true, {
    isUpdate: false,
    departemt: departmentInfo.value
  })
}

const handleModify = (row: GetGroupModel) => {
  if (!departmentInfo.value) {
    ElMessage.warning('请先选择部门')
    return
  }
  openModal(true, {
    isUpdate: true,
    departemt: departmentInfo.value,
    row
  })
}

const handleDelete = (row: GetGroupModel) => {
  ElMessageBox.confirm(`是否删除名称为"${row.groupName}"的数据项`, '警告', {
    confirmButtonText: '确定',
    cancelButtonText: '取消',
    type: 'warning'
  }).then(() => {
    deleteGroup({ id: row.id }).then((res) => {
      if (res.code === 200) {
        ElMessage.success('删除')
        gridRef.value?.commitProxy('query')
      } else {
        ElMessage.error(res.message)
      }
    })
  })
}
const handleSuccess = ({ isUpdate }: { isUpdate: boolean }) => {
  gridRef.value?.commitProxy('query')
  closeModal()
}

const handleReset = () => {
  headerOptions.title = `组别信息`
  gridRef.value?.reloadData([])
}

defineExpose({ handleQuickSearch, handleReset, departmentInfo })
</script>

<style scoped></style>
