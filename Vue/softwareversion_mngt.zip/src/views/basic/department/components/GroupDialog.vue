<template>
  <BasicModal
    width="556px"
    v-bind="$attrs"
    @register="registerModal"
    :title="getTitle"
    @confirm="handleSubmit"
  >
    <BasicForm @register="registerForm"> </BasicForm>
  </BasicModal>
</template>

<script lang="tsx" setup>
import type { AddGroupData, UpdateGroupData } from '@/api/sys/model/basicModel'
import type { ModalMethods } from '@/components/Modal/types'
import type { CascaderOption } from 'element-plus'

import { computed, ref, unref } from 'vue'
import BasicModal from '@/components/Modal/BasicModal.vue'
import { useModalInner } from '@/components/Modal/hooks/useModal'
import BasicForm from '@/components/Form/BasicForm.vue'
import { useForm } from '@/components/Form/hooks/useForm'

import { getDepartment, addGroup, updateGroup, getKeyValueByClassify } from '@/api/sys/basic'

const emit = defineEmits<{
  register: [modalMethods: ModalMethods, uuid: number]
  success: [{ isUpdate: boolean }]
}>()

const isUpdate = ref<boolean>(false)
const rowId = ref('')

const getTitle = computed(() => (!unref(isUpdate) ? '新增' : '修改'))

const departmentList = ref<CascaderOption[]>()

const getDepartmentList = async () => {
  const { data, code } = await getDepartment()

  if (code === 200) {
    departmentList.value = filterTree(data.result)
  }

  function filterTree(arr: any) {
    let res: any = []
    arr?.forEach((item: any) => {
      let data = {
        label: item.departmentName,
        value: item.id,
        children: filterTree(item.sonData)
      }
      res.push(data)
    })
    return res
  }
}

const formProps = {
  checkStrictly: true
}

const [
  registerForm,
  { setFieldsValue, resetFields, getFieldsValue, updateSchema, validate, clearValidate }
] = useForm({
  labelWidth: 86,
  schemas: [
    {
      field: 'departmentID',
      component: 'ElCascader',
      label: '所属部门',
      rules: [{ required: true, trigger: 'change' }],
      componentProps: {
        options: departmentList,
        props: formProps,
        disabled: true
      },
      colProps: {
        span: 16
      }
    },
    {
      field: 'groupName',
      component: 'ElInput',
      rules: [{ required: true, trigger: 'blur' }],
      label: '组别名称',
      colProps: {
        span: 16
      }
    },
    {
      field: 'sortNo',
      component: 'ElInputNumber',
      rules: [{ required: true, trigger: 'blur' }],
      label: '显示排序',
      componentProps: {
        min: 1,
        max: 9999,
        step: 1,
        stepStrictly: true
      },
      defaultValue: 1,
      colProps: {
        span: 10
      }
    },
    {
      field: 'productionAddressID',
      component: 'ApiSelect',
      label: '厂区位置',
      rules: [{ required: true, trigger: 'change' }],
      componentProps: {
        api: getKeyValueByClassify,
        resultField: 'data',
        labelField: 'value',
        valueField: 'id',
        params: {
          typeName: 'PositionAddress'
        }
      },
      colProps: {
        span: 16
      }
    },
    {
      field: 'leaderID',
      component: 'PersonSelect',
      // rules: [{ required: true, trigger: 'change' }],
      label: '班组长',
      colProps: {
        span: 16
      }
    },
    {
      field: 'dataDescribe',
      component: 'ElInput',
      label: '备注',
      componentProps: {
        type: 'textarea'
      }
    }
  ]
})

const [registerModal, { setModalProps, changeOkLoading }] = useModalInner(async (data) => {
  await resetFields()
  setModalProps({ confirmLoading: false })
  await getDepartmentList()
  isUpdate.value = !!data?.isUpdate

  await setFieldsValue({
    departmentID: data.departemt.id
  })

  // 修改设置表单
  if (unref(isUpdate)) {
    rowId.value = data.row.id

    await setFieldsValue({
      ...data.row
    })
  }
  await updateSchema({
    field: 'leaderID',
    componentProps: {
      departmentID: data.departemt.id,
      groupID: data.row?.id || ''
    }
  })
  clearValidate()
})

// 提交
const handleSubmit = async () => {
  await validate()
  try {
    changeOkLoading(true)

    // 新增
    if (!unref(isUpdate)) {
      const data = getFieldsValue() as AddGroupData

      const { code, data: isSuccess, message } = await addGroup(data)
      if (code === 200 && isSuccess) {
        ElMessage.success('新增成功')
        emit('success', { isUpdate: unref(isUpdate) })
      } else {
        ElMessage.error(message)
      }
    } else {
      const formData = getFieldsValue() as Omit<UpdateGroupData, 'id'>

      const data: UpdateGroupData = {
        id: unref(rowId),
        ...formData
      }

      const { code, data: isSuccess, message } = await updateGroup(data)
      if (code === 200 && isSuccess) {
        ElMessage.success('修改成功')
        emit('success', { isUpdate: unref(isUpdate) })
      } else {
        ElMessage.error(message)
      }
    }
  } catch (error: any) {
    ElMessage(error.message)
  } finally {
    changeOkLoading(false)
  }
}
</script>

<style lang="scss" scoped></style>
