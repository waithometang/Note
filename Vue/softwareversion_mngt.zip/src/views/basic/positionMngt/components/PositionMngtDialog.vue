<template>
  <BasicModal
    width="556px"
    v-bind="$attrs"
    @register="registerModal"
    :title="getTitle"
    @confirm="handleSubmit"
  >
    <BasicForm @register="registerForm"> </BasicForm>
  </BasicModal>
</template>

<script setup lang="ts">
import type {
  AddPositionClassifyData,
  UpdatePositionClassifyData
} from '@/api/sys/model/basicModel'
import type { ModalMethods } from '@/components/Modal/types'

import { ref, unref, computed } from 'vue'

import BasicModal from '@/components/Modal/BasicModal.vue'
import BasicForm from '@/components/Form/BasicForm.vue'

import { useModalInner } from '@/components/Modal/hooks/useModal'
import { useForm } from '@/components/Form/hooks/useForm'
import { addPositionClassify, getKeyValueByClassify, updatePositionClassify } from '@/api/sys/basic'

const emit = defineEmits<{
  register: [modalMethods: ModalMethods, uuid: number]
  success: [{ isUpdate: boolean }]
}>()
const isUpdate = ref<boolean>(false)

const rowId = ref<string>('')

const getTitle = computed(() => (!unref(isUpdate) ? '新增' : '修改'))

const [registerForm, { setFieldsValue, resetFields, getFieldsValue, validate, clearValidate }] =
  useForm({
    labelWidth: 86,
    schemas: [
      {
        field: 'positionID',
        component: 'ApiSelect',
        label: '岗位名称',
        dynamicDisabled() {
          return unref(isUpdate)
        },
        dynamicRules() {
          return [{ required: !unref(isUpdate), message: '请输入岗位定义' }]
        },
        componentProps: {
          api: getKeyValueByClassify,
          resultField: 'data',
          labelField: 'value',
          valueField: 'id',
          params: { typeName: 'Position' }
        }
      },
      {
        field: 'positionClassifyID',
        component: 'ApiSelect',
        label: '岗位类型',
        rules: [{ required: true, trigger: 'change' }],
        componentProps: {
          api: getKeyValueByClassify,
          resultField: 'data',
          labelField: 'value',
          valueField: 'id',
          params: { typeName: 'PositionClassify' }
        }
      }
    ]
  })

const [registerModal, { setModalProps }] = useModalInner(async (data) => {
  await resetFields()
  setModalProps({ confirmLoading: false })
  isUpdate.value = !!data?.isUpdate

  if (unref(isUpdate)) {
    rowId.value = data.row.id
    await setFieldsValue({ ...data.row })
  }
  clearValidate()
})

// 提交
const handleSubmit = async () => {
  await validate()
  setModalProps({ confirmLoading: true })
  try {
    // 新增
    if (!unref(isUpdate)) {
      const formData = getFieldsValue() as AddPositionClassifyData

      const data = {
        ...formData
      }
      const { code, message } = await addPositionClassify(data)
      if (code === 200) {
        ElMessage.success('新增成功')
        emit('success', { isUpdate: unref(isUpdate) })
      } else {
        ElMessage.error(message)
      }
    } else {
      const formData = getFieldsValue() as Omit<UpdatePositionClassifyData, 'id'>
      const data = {
        id: unref(rowId),
        ...formData
      }
      const { code, message } = await updatePositionClassify(data)

      if (code === 200) {
        ElMessage.success('修改成功')
        emit('success', { isUpdate: unref(isUpdate) })
      } else {
        ElMessage.error(message)
      }
    }
  } catch (error: any) {
    ElMessage(error.message)
  } finally {
    setModalProps({ confirmLoading: false })
  }
}
</script>
<style lang="scss" scoped></style>
