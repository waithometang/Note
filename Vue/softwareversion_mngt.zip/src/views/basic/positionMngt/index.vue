<template>
  <div class="page-container">
    <vxe-grid class="box" ref="gridRef" v-bind="gridOptions">
      <template #top>
        <GridHeader
          ref="gridHeaderRef"
          v-bind="headerOptions"
          @quickSearch="handleQuickSearch"
          @add="handleAdd"
        />
      </template>
      <template #operation="{ row }">
        <TableAction
          :actions="[
            {
              icon: 'edit',
              tooltip: '编辑',
              onClick: handleModify.bind(null, row)
            },
            {
              icon: 'delete',
              tooltip: '删除',
              onClick: handleDelete.bind(null, row)
            }
          ]"
        />
      </template>
    </vxe-grid>
  </div>
  <PositionMngtDialog @register="registerModal" @success="handleSuccess" />
</template>

<script setup lang="ts">
import type { ComponentExposed } from 'vue-component-type-helpers'
import type { VxeGridInstance, VxeGridProps } from 'vxe-table'
import type { GridHeaderProps } from '@/components/Table/types/gridHeader'
import type { GetPositionClassifyModel } from '@/api/sys/model/basicModel'

import { reactive, ref } from 'vue'
import { deletePositionClassify, getPositionClassify } from '@/api/sys/basic'

import { useModal } from '@/components/Modal/hooks/useModal'

import GridHeader from '@/components/Table/GridHeader.vue'
import PositionMngtDialog from './components/PositionMngtDialog.vue'

defineOptions({
  name: 'PositionMngt',
  inheritAttrs: false
})

const gridHeaderRef = ref<ComponentExposed<typeof GridHeader>>()

const headerOptions = reactive<GridHeaderProps>({
  title: '岗位管理',
  quickSearch: {
    singleSearch: {
      field: 'PositionName',
      type: 'input',
      title: '岗位名称'
    },
    searchFormFields: { PositionName: '' }
  },
  showAdvancedSearchButton: false
})

const gridRef = ref<VxeGridInstance>()
const gridOptions = reactive<VxeGridProps<GetPositionClassifyModel>>({
  border: true,
  height: 'auto',
  align: null,
  columnConfig: {
    resizable: true
  },
  columns: [
    { type: 'seq', width: 50 },
    { field: 'positionName', title: '岗位名称' },
    { field: 'positionClassifyName', title: '岗位类型' },
    { field: 'lastModifiedUserName', title: '操作人' },
    { field: 'lastModifiedTime', title: '最后更新时间' },
    {
      field: 'operation',
      title: '操作',
      align: 'center',
      fixed: 'right',
      width: 150,
      slots: {
        default: 'operation'
      }
    }
  ],
  pagerConfig: {
    enabled: true,
    pageSize: 20
  },
  proxyConfig: {
    ajax: {
      query: ({ page }) => {
        const quickSearchForm = gridHeaderRef.value?.quickSearchForm
        const advancedSearchForm = gridHeaderRef.value?.advancedSearchForm
        return getPositionClassify({
          pageIndex: page.currentPage - 1, // 由于后端接口限制，首页从0开始
          pageSize: page.pageSize,
          ...quickSearchForm,
          ...advancedSearchForm
        })
      }
    }
  }
})

const handleQuickSearch = () => {
  gridRef.value?.commitProxy('reload')
}

const [registerModal, { openModal, closeModal }] = useModal()

const handleAdd = () => {
  openModal(true, {
    isUpdate: false
  })
}

const handleModify = (row: GetPositionClassifyModel) => {
  openModal(true, {
    isUpdate: true,
    row
  })
}

const handleDelete = (row: GetPositionClassifyModel) => {
  ElMessageBox.confirm(`是否删除名称为"${row.positionName}"的数据项`, '警告', {
    confirmButtonText: '确定',
    cancelButtonText: '取消',
    type: 'warning'
  }).then(() => {
    deletePositionClassify({ id: row.id }).then((res) => {
      if (res.code === 200) {
        ElMessage.success('删除成功')
        gridRef.value?.commitProxy('query')
      } else {
        ElMessage.error(res.message)
      }
    })
  })
}

const handleSuccess = () => {
  gridRef.value?.commitProxy('query')
  closeModal()
}
</script>

<style scoped></style>
