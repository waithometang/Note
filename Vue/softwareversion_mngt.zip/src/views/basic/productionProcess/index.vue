<template>
  <div class="page-container">
    <vxe-grid class="box" ref="gridRef" v-bind="gridOptions">
      <template #top>
        <GridHeader
          ref="gridHeaderRef"
          v-bind="headerOptions"
          @quickSearch="handleQuickSearch"
          @add="handleAdd"
          @advancedSearch="handleAdvancedSearch"
          @reset="handleReset"
        >
          <template #appendOperation>
            <el-button size="large" type="primary" @click="handleProceesTypeSet" plain
              >设备类型配置</el-button
            >
          </template>
        </GridHeader>
      </template>
      <template #operation="{ row }">
        <TableAction
          :actions="[
            {
              icon: 'edit',
              tooltip: '编辑',
              onClick: handleModify.bind(null, row)
            },
            {
              icon: 'delete',
              tooltip: '删除',
              onClick: handleDelete.bind(null, row)
            }
          ]"
        />
      </template>
    </vxe-grid>
    <ProductionProcessDialog @register="registerModal" @success="handleSuccess" />
    <ProcessTypeConfigDialog
      @register="registerProcessTypeConfigModal"
      @success="handleProcessTypeConfigModalSuccess"
    />
  </div>
</template>

<script lang="tsx" setup>
import type { ComponentExposed } from 'vue-component-type-helpers'
import type {
  GetProductionProcessModel,
  GetProductionProcessParams
} from '@/api/sys/model/basicModel'
import type { VxeGridInstance, VxeGridProps } from 'vxe-table'
import type { GridHeaderProps } from '@/components/Table/types/gridHeader'

import { reactive, ref } from 'vue'

import GridHeader from '@/components/Table/GridHeader.vue'
import TableAction from '@/components/Table/TableAction.vue'
import ProductionProcessDialog from './components/ProductionProcessDialog.vue'
import ProcessTypeConfigDialog from './components/ProcessTypeConfigDialog.vue'

import { useModal } from '@/components/Modal/hooks/useModal'
import {
  deleteProductionProcess,
  getProductionProcess,
  exportProductionProcess
} from '@/api/sys/basic'

import { error } from '@/utils/log'

defineOptions({
  name: 'ProductionProcess',
  inheritAttrs: false
})

const gridHeaderRef =
  ref<ComponentExposed<typeof GridHeader<GetProductionProcessParams, 'processType'>>>()

const headerOptions = reactive<GridHeaderProps>({
  title: '生产工序',
  quickSearch: {
    singleSearch: {
      field: 'processType',
      type: 'input',
      title: '工序名称'
    },
    searchFormFields: { processType: '' }
  },
  showAdvancedSearchButton: false,
  showExportButton: true,
  exportApi: exportProductionProcess
})

const handleQuickSearch = () => {
  gridRef.value?.commitProxy('reload')
}

const handleAdvancedSearch = () => {
  gridRef.value?.commitProxy('reload')
}

const handleReset = () => {
  gridRef.value?.commitProxy('reload')
}

const gridRef = ref<VxeGridInstance>()
const gridOptions = reactive<VxeGridProps<GetProductionProcessModel>>({
  border: true,
  stripe: false,
  height: 'auto',
  align: null,
  columnConfig: {
    resizable: true
  },
  treeConfig: {
    rowField: 'id',
    childrenField: 'sonData'
  },
  rowConfig: { keyField: 'id' },
  expandConfig: { reserve: true },
  columns: [
    { type: 'seq', width: 50 },
    { field: 'processType', title: '设备类型', treeNode: true },
    // { field: 'departmentName', title: '部门名称' },
    { field: 'createTime', title: '创建时间' },

    {
      field: 'dataStatus',
      title: '数据状态',
      width: 150,
      visible: false
    },
    { field: 'dataDescribe', title: '数据描述', visible: false },
    { field: 'lastModifiedUserName', title: '操作人' },
    { field: 'lastModifiedTime', title: '最后更新时间' },
    {
      field: 'operation',
      title: '操作',
      align: 'center',
      fixed: 'right',
      width: 150,
      slots: {
        default: 'operation'
      }
    }
  ],
  pagerConfig: {
    enabled: false
  },
  proxyConfig: {
    ajax: {
      query: () => {
        const quickSearchForm = gridHeaderRef.value?.quickSearchForm || {}
        const advancedSearchForm = gridHeaderRef.value?.advancedSearchForm || {}
        return new Promise((resolve) => {
          getProductionProcess({
            ...quickSearchForm,
            ...advancedSearchForm
          }).then((res) => {
            resolve(res.data.result)
          })
        })
      }
    }
  }
})

const [registerModal, { openModal, setModalProps }] = useModal()

const handleAdd = () => {
  openModal(true, {
    isUpdate: false
  })
}

const handleModify = (row: GetProductionProcessModel) => {
  openModal(true, {
    isUpdate: true,
    row
  })
}

const handleDelete = (row: GetProductionProcessModel) => {
  ElMessageBox.confirm(`是否确认删除名称为"${row.processType}"的数据项?`, '警告', {
    confirmButtonText: '确定',
    cancelButtonText: '取消',
    type: 'warning'
  })
    .then(async () => {
      try {
        const id = row.id
        const { data, message } = await deleteProductionProcess({ id })

        if (data) {
          ElMessage.success('删除成功')
        } else {
          ElMessage.error(message)
        }
      } catch (err: any) {
        error(err.message)
      }
    })
    .catch(() => {})
    .finally(() => {
      gridRef.value?.commitProxy('query')
    })
}
const handleSuccess = ({ isUpdate }: { isUpdate: boolean }) => {
  gridRef.value?.commitProxy('query')
}

const [registerProcessTypeConfigModal, processTypeConfigModalAction] = useModal()
// 处理工序设置
const handleProceesTypeSet = () => {
  processTypeConfigModalAction.openModal(true)
}
// 处理工序设置成功回调
const handleProcessTypeConfigModalSuccess = () => {
  gridRef.value?.commitProxy('query')
}
</script>

<style lang="scss" scoped></style>
