export const dispatchingMehtodOptions = [
  { label: '合计分配', value: 1 },
  { label: '最大分配', value: 2 }
]
