<template>
  <BasicModal
    width="40%"
    v-bind="$attrs"
    @register="registerModal"
    :title="getTitle"
    @confirm="handleSubmit"
  >
    <BasicForm @register="registerForm" />
  </BasicModal>
</template>

<script lang="tsx" setup>
import type { CascaderOption } from 'element-plus'
import type {
  AddProductionProcessData,
  UpdateProductionProcessData
} from '@/api/sys/model/basicModel'
import type { ModalMethods } from '@/components/Modal/types'

import { computed, ref, unref } from 'vue'
import BasicModal from '@/components/Modal/BasicModal.vue'
import { useModalInner } from '@/components/Modal/hooks/useModal'
import BasicForm from '@/components/Form/BasicForm.vue'
import { useForm } from '@/components/Form/hooks/useForm'

import {
  addProductionProcess,
  getDepartment,
  getProductionProcessTopLevel,
  updateProductionProcess
} from '@/api/sys/basic'

const emit = defineEmits<{
  register: [modalMethods: ModalMethods, uuid: number]
  success: [{ isUpdate: boolean }]
}>()

const isUpdate = ref<boolean>(false)
const rowId = ref('')

const [registerModal, { closeModal, setModalProps, changeOkLoading }] = useModalInner(
  async (data) => {
    resetFields()
    setModalProps({ confirmLoading: false })
    isUpdate.value = !!data?.isUpdate

    // 修改设置表单
    if (unref(isUpdate)) {
      rowId.value = data.row.id
      setFieldsValue({
        ...data.row
      })
    }
  }
)

const getTitle = computed(() => (!unref(isUpdate) ? '新增' : '修改'))

const [registerForm, { setFieldsValue, resetFields, getFieldsValue, validate, updateSchema }] =
  useForm({
    labelWidth: 120,
    schemas: [
      {
        field: 'fatherID',
        component: 'ApiSelect',
        label: '所属类型',
        dynamicDisabled: ({ model }) => {
          return model.fatherID === null
        },
        componentProps: {
          api: getProductionProcessTopLevel,
          resultField: 'data.result',
          labelField: 'processType',
          valueField: 'id'
        },
        colProps: {
          span: 24
        }
      },
      {
        field: 'processType',
        component: 'ElInput',
        label: '工序名称',
        required: true,
        componentProps: {},
        colProps: {
          span: 24
        }
      },
      {
        field: 'sortNo',
        component: 'ElInputNumber',
        label: '显示排序',
        required: true,
        componentProps: {},
        colProps: {
          span: 10
        }
      },
      {
        field: 'dataDescribe',
        component: 'ElInput',
        label: '备注',
        componentProps: {
          type: 'textarea'
        },
        colProps: {
          span: 24
        }
      }
    ]
  })

// 提交
const handleSubmit = async () => {
  try {
    validate(async (isValid) => {
      if (isValid) {
        changeOkLoading(true)
        // 新增
        if (!unref(isUpdate)) {
          const data = getFieldsValue()
          const { status, message } = await addProductionProcess(data as AddProductionProcessData)
          if (status) {
            ElMessage.success('新增成功')
            closeModal()
            emit('success', { isUpdate: unref(isUpdate) })
          } else {
            ElMessage.error(message)
          }
        } else {
          const formData = getFieldsValue() as Omit<UpdateProductionProcessData, 'id'>

          const data: UpdateProductionProcessData = {
            id: unref(rowId),
            ...formData
          }

          const { status, message } = await updateProductionProcess(data)
          if (status) {
            ElMessage.success('修改成功')
            closeModal()
            emit('success', { isUpdate: unref(isUpdate) })
          } else {
            ElMessage.error(message)
          }
        }
      }
    })
    //
  } catch (error: any) {
    ElMessage(error.message)
  } finally {
    changeOkLoading(false)
  }
}
</script>

<style lang="scss" scoped></style>
