<template>
  <BasicModal
    width="40%"
    v-bind="$attrs"
    @register="registerModal"
    title="配置类型"
    :showCancelBtn="false"
    :showConfirmBtn="false"
  >
    <vxe-grid ref="gridRef" v-bind="gridOptions">
      <template #processType_edit="scope">
        <el-input v-model="scope.row.processType" @input="updateRowStatus(scope)" />
      </template>

      <template #operation="{ row }">
        <TableAction
          :actions="[
            {
              icon: 'edit-inline',
              tooltip: '编辑',
              onClick: handleModify.bind(null, row),
              ifShow: !hasActiveEditRow(row)
            },
            {
              icon: 'delete-inline',
              tooltip: '删除',
              onClick: handleDelete.bind(null, row),
              ifShow: !hasActiveEditRow(row)
            },
            {
              icon: 'cancle',
              tooltip: '取消',
              onClick: handleCancle.bind(null, row),
              ifShow: hasActiveEditRow(row)
            },
            {
              icon: 'save',
              tooltip: '保存',
              onClick: handleSave.bind(null, row),
              ifShow: hasActiveEditRow(row)
            }
          ]"
        ></TableAction>
        <!-- <template v-if="hasActiveEditRow(row)"></template>

        <template v-else> </template> -->
      </template>
      <template #bottom>
        <TableAction
          style="margin-top: 16px"
          :actions="[
            {
              icon: 'plus',
              label: '新增',
              onClick: handleAdd.bind(null),
              style: {
                color: '#008cd6'
              }
            }
          ]"
        ></TableAction>
      </template>
    </vxe-grid>
  </BasicModal>
</template>

<script lang="tsx" setup>
import type { ModalMethods } from '@/components/Modal/types'
import type { VxeGridInstance, VxeGridProps } from 'vxe-table'
import type { GetDictionaryModel } from '@/api/sys/model/basicModel'
import type { CascaderOption } from 'element-plus'

import { reactive, ref, unref } from 'vue'
import { error } from '@/utils/log'
import { dispatchingMehtodOptions } from './data'
import { useModalInner } from '@/components/Modal/hooks/useModal'

import Select from '@/components/Form/components/Select.vue'
import TableAction from '@/components/Table/TableAction.vue'

import {
  addProductionProcess,
  deleteProductionProcess,
  getDepartment,
  getKeyValueByClassify,
  getProductionProcessTopLevel,
  updateProductionProcess
} from '@/api/sys/basic'

const emit = defineEmits<{
  register: [modalMethods: ModalMethods, uuid: number]
  success: [{ isUpdate?: boolean; isDelete?: boolean }]
}>()

const isUpdate = ref<boolean>(false)
const rowId = ref('')

const [registerModal, { closeModal, setModalProps, changeOkLoading }] = useModalInner(
  async (data) => {
    setModalProps({ confirmLoading: false })
    isUpdate.value = !!data?.isUpdate

    // 修改设置表单
    if (unref(isUpdate)) {
      rowId.value = data.row.id
    }
  }
)

const gridRef = ref<VxeGridInstance>()

interface ProcessTypeEditModel {
  id: string
  processType: string
  /**
   * 添加设备类型时必填，设备类型关联的工单数量类型，对应Key字典表
   */
  deviceNumberTypeID: string
  /**
   * 组内派工数量分配方式
   */
  dispatchingMehtod: number
}
const gridOptions = reactive<VxeGridProps<ProcessTypeEditModel>>({
  border: true,
  stripe: false,
  height: '500px',
  align: null,
  keepSource: true,
  columnConfig: {
    resizable: true
  },
  editConfig: {
    trigger: 'dblclick',
    mode: 'row',
    showStatus: true,
    autoClear: false,
    showUpdateStatus: true,
    showInsertStatus: true
  },
  editRules: {
    processType: [{ required: true, message: '设备名称必须填写' }]
  },
  columns: [
    { type: 'seq', width: 50 },
    {
      field: 'processType',
      title: '设备类型',
      editRender: {},
      slots: { edit: 'processType_edit' }
    },
    {
      field: 'dispatchingMehtod',
      title: '组内派工数量分配方式',
      width: 200,
      editRender: {},
      slots: {
        default({ row }) {
          return (
            <span>
              {dispatchingMehtodOptions.find((item) => item.value === row.dispatchingMehtod)?.label}
            </span>
          )
        },
        edit(scope) {
          return (
            <Select
              modelValue={scope.row.dispatchingMehtod}
              options={dispatchingMehtodOptions}
              labelField="label"
              valueField="value"
              onChange={(value: number) => {
                scope.row.dispatchingMehtod = value
                updateRowStatus(scope)
              }}
            ></Select>
          )
        }
      }
    },
    {
      field: 'deviceNumberTypeID',
      title: '关联数量',
      editRender: {},
      slots: {
        default({ row }) {
          return (
            <span>
              {
                unref(deviceNumberTypeList).find((item) => item.id === row.deviceNumberTypeID)
                  ?.value
              }
            </span>
          )
        },
        edit(scope) {
          return (
            <Select
              modelValue={scope.row.deviceNumberTypeID}
              options={unref(deviceNumberTypeList)}
              labelField="value"
              valueField="id"
              onChange={(value: string) => {
                scope.row.deviceNumberTypeID = value
                updateRowStatus(scope)
              }}
            ></Select>
          )
        }
      }
    },
    {
      field: 'operation',
      title: '操作',
      align: 'center',
      fixed: 'right',
      width: 150,
      slots: {
        default: 'operation'
      }
    }
  ],
  pagerConfig: {
    enabled: false,
    pageSize: 10
  },
  proxyConfig: {
    ajax: {
      query: ({ page }) => {
        return new Promise((resolve) => {
          getProductionProcessTopLevel().then((result) => {
            resolve(result.data.result)
          })
        })
      }
    }
  }
})

const deviceNumberTypeList = ref<GetDictionaryModel[]>([])

const getDeviceNumberTypeList = async () => {
  const { data } = await getKeyValueByClassify({ typeName: 'DeviceNumberType' })
  deviceNumberTypeList.value = data
}
getDeviceNumberTypeList()
const departmentList = ref<CascaderOption[]>()
const getDepartmentList = () => {
  getDepartment().then(({ data }) => {
    function filterTree(arr: Recordable[]) {
      let res: Recordable[] = []
      arr?.forEach((item: Recordable) => {
        let data: Recordable = {
          label: item.departmentName,
          value: item.id
        }
        if (item.sonData) {
          data.children = filterTree(item.sonData)
        }
        res.push(data)
      })

      return res
    }

    departmentList.value = filterTree(data.result)
  })
}
getDepartmentList()

// 判断是否编辑活跃行
const hasActiveEditRow = (row: ProcessTypeEditModel): boolean => {
  const $grid = gridRef.value
  if ($grid) {
    return $grid.isEditByRow(row)
  }
  return false
}
// 新增
const handleAdd = async () => {
  const $grid = gridRef.value
  if ($grid) {
    const { row: newRow } = await $grid.insert({
      processType: ''
    })

    await $grid.setEditRow(newRow)
  }
}
// 修改
const handleModify = async (row: ProcessTypeEditModel) => {
  const $grid = gridRef.value
  if ($grid) {
    const editRecord = $grid.getEditRecord()
    if (editRecord) {
      const { row } = editRecord
      await $grid.revertData(row)
    }

    $grid.setEditRow(row)
  }
}
// 删除
const handleDelete = (row: ProcessTypeEditModel) => {
  ElMessageBox.confirm(`是否确认删除设备类型为"${row.processType}"的数据项?`, '警告', {
    confirmButtonText: '确定',
    cancelButtonText: '取消',
    type: 'warning'
  })
    .then(async () => {
      try {
        const id = row.id
        const { data, message } = await deleteProductionProcess({ id })

        if (data) {
          ElMessage.success('删除成功')
          emit('success', { isDelete: true })
        } else {
          ElMessage.error(message)
        }
      } catch (err: any) {
        error(err.message)
      }
    })
    .catch(() => {})
    .finally(() => {
      gridRef.value?.commitProxy('query')
    })
}

// 取消
const handleCancle = (row: ProcessTypeEditModel) => {
  const $grid = gridRef.value
  if ($grid) {
    $grid.clearEdit().then(() => {
      // 还原行数据
      $grid.revertData(row)
    })
  }
}
// 更新行状态
const updateRowStatus = (params: any) => {
  const $grid = gridRef.value
  if ($grid) {
    return $grid.updateStatus(params)
  }
}
// 保存
const handleSave = async (row: ProcessTypeEditModel) => {
  const $grid = gridRef.value

  const errMap = await $grid?.validate(row)
  if (!errMap) {
    if ($grid) {
      await $grid.clearEdit()
      const { insertRecords, updateRecords } = $grid.getRecordset()

      try {
        if (insertRecords.length) {
          const data = insertRecords.map((row: ProcessTypeEditModel) => ({
            processType: row.processType,
            deviceNumberTypeID: row.deviceNumberTypeID,
            dispatchingMehtod: row.dispatchingMehtod
          }))[0]
          const { code, message } = await addProductionProcess(data)

          if (code === 200) {
            ElMessage.success('新增成功')
            emit('success', { isUpdate: unref(isUpdate) })
          } else {
            ElMessage.error(message)
          }
        } else if (updateRecords.length) {
          const data = updateRecords.map((row: ProcessTypeEditModel) => ({
            id: row.id,
            processType: row.processType,
            deviceNumberTypeID: row.deviceNumberTypeID,
            dispatchingMehtod: row.dispatchingMehtod
          }))[0]
          const { code, message } = await updateProductionProcess(data)

          if (code === 200) {
            ElMessage.success('修改成功')
            emit('success', { isUpdate: unref(isUpdate) })
          } else {
            ElMessage.error(message)
          }
        }

        gridRef.value?.commitProxy('query')
      } catch (error) {
        //
      }
    }
  }
}
</script>

<style lang="scss" scoped></style>
