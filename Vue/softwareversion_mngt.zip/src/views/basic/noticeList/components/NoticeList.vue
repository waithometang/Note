<template>
  <div class="notice-list-wrapper" v-loading="loading">
    <el-empty
      v-if="pageConfig.total === 0"
      :description="messageMap[messageType] === 1 ? '暂无新消息' : '暂无消息'"
    >
      <template #image>
        <img src="../../../../assets/png/bells.png" alt="" style="width: 76px; height: 73px" />
      </template>
    </el-empty>
    <template v-else>
      <el-scrollbar ref="scrollbarRef">
        <NoticeItem
          v-for="item in messageList"
          :key="item.id"
          :data="item"
          @refresh="getMessageList"
        />
      </el-scrollbar>
      <div class="pager-wrapper">
        <vxe-pager
          v-model:current-page="pageConfig.currentPage"
          v-model:page-size="pageConfig.pageSize"
          :total="pageConfig.total"
          @page-change="handlePageChange"
        />
      </div>
    </template>
  </div>
</template>

<script setup lang="ts">
import type { ElScrollbar } from 'element-plus'
import type { GetMessageModel } from '@/api/sys/model/basicModel'

import { getMessage } from '@/api/sys/basic'

import { reactive, ref, onMounted } from 'vue'

import NoticeItem from './NoticeItem.vue'
import { SStorage } from '@/utils/storage'
import useCurrentInstance from '@/hooks/useCurrentInstance'

const props = defineProps({
  messageType: {
    type: String,
    default: 'unread'
  }
})

const messageMap: { [key: string]: '' | number } = {
  unread: 1,
  read: 2,
  all: ''
}

const pageConfig = reactive({
  currentPage: 1,
  pageSize: 10,
  total: 10
})
const messageList = ref<GetMessageModel[]>()
const loading = ref(false)
const scrollbarRef = ref<InstanceType<typeof ElScrollbar>>()
const { proxy } = useCurrentInstance()

onMounted(() => {
  getMessageList()
})

const getMessageList = async () => {
  loading.value = true
  try {
    const { code, data, message } = await getMessage({
      ReadStatus: messageMap[props.messageType],
      pageIndex: pageConfig.currentPage - 1,
      pageSize: pageConfig.pageSize
    })
    if (code === 200) {
      messageList.value = data.result
      pageConfig.total = data.total
      proxy.eventBus.emit('messageRefresh')
    } else {
      messageList.value = []
      pageConfig.total = 0
      ElMessage.error(message)
    }
  } finally {
    loading.value = false
  }
}

const handlePageChange = async () => {
  scrollbarRef.value?.setScrollTop(0)
  getMessageList()
}

const refresh = () => {
  //通知列表页面切换tab时调用refresh方法 setScrollTop无效?? 所以父组件用v-if重置滚动条
  scrollbarRef.value?.setScrollTop(0) // 无效果bug
  pageConfig.currentPage = 1
  getMessageList()
}

defineExpose({ refresh })
</script>

<style scoped lang="scss">
.notice-list-wrapper {
  height: 100%;
  display: flex;
  flex-direction: column;
  .pager-wrapper {
    padding: 10px 34px;
  }
}
.el-scrollbar {
  flex: 1;
}
.el-empty {
  height: 100%;
}
</style>
