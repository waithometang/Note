<template>
  <div class="notice-item-wrapper">
    <div class="left">
      <div class="message-title">{{ data.messageTitle }}</div>
      <div class="message-content">{{ data.messageContent }}</div>
      <div class="message-tool">
        <el-button size="small" type="primary" @click="handleReview({ ...data })"
          >立即查看</el-button
        >
        <el-button
          size="small"
          type="primary"
          plain
          :loading="loading"
          v-if="data.readStatus === 1"
          @click="updateStatus(data.id, false)"
          >标记为已读</el-button
        >
      </div>
    </div>
    <div class="right">{{ data.createTime }}</div>
  </div>
</template>

<script setup lang="ts">
import type { GetMessageModel } from '@/api/sys/model/basicModel'
import type { PropType } from 'vue'

import { updateMessageReadStatus } from '@/api/sys/basic'

import router from '@/router'
import { ref } from 'vue'
import useCurrentInstance from '@/hooks/useCurrentInstance'

defineProps({
  data: {
    type: Object as PropType<GetMessageModel>,
    default: () => ({})
  }
})

const emit = defineEmits(['refresh'])

const { proxy } = useCurrentInstance()

const loading = ref(false)

const handleReview = ({ moduleName, id }: GetMessageModel) => {
  router.push({ name: moduleName }).then(async () => {
    await updateMessageReadStatus({ id, allMessageRead: false })
    proxy.eventBus.emit('messageRefresh')
  })
}

const updateStatus = async (messageID: string, allMessageRead: boolean) => {
  loading.value = true
  try {
    const { code, message } = await updateMessageReadStatus({ id: messageID, allMessageRead })
    if (code === 200) {
      emit('refresh')
      proxy.eventBus.emit('messageRefresh')
    } else {
      ElMessage.error(message)
    }
  } finally {
    loading.value = false
  }
}
</script>

<style scoped lang="scss">
.notice-item-wrapper {
  padding: 24px 34px;
  display: flex;
  justify-content: space-between;
  border-bottom: 1px solid #eee;
  margin-right: 15px;
  .left {
    flex: 1;
    overflow: hidden;
    display: flex;
    flex-direction: column;
    gap: 14px;
    .message-title {
      font-weight: 700;
      font-size: 15px;
    }
    .message-content {
      text-overflow: ellipsis;
      overflow: hidden;
      word-break: break-all;
      white-space: nowrap;
      font-size: 14px;
    }
  }
  .right {
    min-width: 150px;
    text-align: end;
    font-size: 14px;
    color: rgba(56, 56, 56, 0.45);
  }
}
</style>
