<template>
  <div class="page-container">
    <div class="box">
      <el-button
        v-if="tabName !== MESSAGE_TYPE.READ && unReadCount !== 0"
        type="primary"
        link
        class="all-read-btn"
        @click="handleReadAllMessage(tabName)"
        :loading="btnLoading"
        >全部标记为已读</el-button
      >
      <el-tabs v-model="tabName" class="message-tabs">
        <el-tab-pane label="未读" :name="MESSAGE_TYPE.UNREAD" lazy>
          <NoticeList
            :message-type="MESSAGE_TYPE.UNREAD"
            v-if="tabName === MESSAGE_TYPE.UNREAD"
            ref="unreadMessageListRef"
          />
        </el-tab-pane>
        <el-tab-pane label="全部" :name="MESSAGE_TYPE.ALL" lazy>
          <NoticeList
            :message-type="MESSAGE_TYPE.ALL"
            v-if="tabName === MESSAGE_TYPE.ALL"
            ref="allMessageListRef"
          />
        </el-tab-pane>
        <el-tab-pane label="已读" :name="MESSAGE_TYPE.READ" lazy>
          <NoticeList
            :message-type="MESSAGE_TYPE.READ"
            v-if="tabName === MESSAGE_TYPE.READ"
            ref="readMessageListRef"
          />
        </el-tab-pane>
      </el-tabs>
    </div>
  </div>
</template>

<script setup lang="ts">
import NoticeList from './components/NoticeList.vue'

import { ref } from 'vue'
import { MESSAGE_TYPE } from '@/constant'
import { updateMessageReadStatus } from '@/api/sys/basic'
import useCurrentInstance from '@/hooks/useCurrentInstance'
import { SStorage } from '@/utils/storage'
import { computed } from 'vue'

const tabName = ref<string>(MESSAGE_TYPE.UNREAD)

const unreadMessageListRef = ref<InstanceType<typeof NoticeList>>()
const allMessageListRef = ref<InstanceType<typeof NoticeList>>()
const readMessageListRef = ref<InstanceType<typeof NoticeList>>()

const unReadCount = computed(() => SStorage.get('unReadCount') || 0)

const { proxy } = useCurrentInstance()
const btnLoading = ref(false)
const handleReadAllMessage = async (name: string) => {
  tabName.value = ''
  btnLoading.value = true
  try {
    const { code, message } = await updateMessageReadStatus({ id: '0', allMessageRead: true })
    if (code === 200) {
      proxy.eventBus.emit('messageRefresh')
    } else {
      ElMessage.error(message)
    }
  } finally {
    tabName.value = name
    btnLoading.value = false
  }
}
</script>

<style scoped lang="scss">
.box {
  padding: 0;
  height: 100%;
  --header-height: 64px;
}
.all-read-btn {
  position: absolute;
  top: $margin;
  height: var(--header-height);
  right: $margin + 20px;
  z-index: 1;
}
:deep(.el-tabs) {
  height: 100%;
  --el-tabs-header-height: var(--header-height);
  display: flex;
  flex-direction: column;
  .el-tabs__header {
    margin-bottom: 0;
  }
  .el-tabs__nav {
    padding: 0 24px;
    .el-tabs__active-bar {
      background-color: rgba(0, 140, 214, 1);
    }
    .el-tabs__item {
      width: 128px;
      font-size: 16px;
      font-weight: 400;
      letter-spacing: 0px;
      line-height: 24px;
      color: rgba(0, 0, 0, 0.85);
      transition: 0.5s all;
      &:hover {
        color: rgba(0, 0, 0, 0.85);
      }
      &.is-active {
        font-weight: 700;
        color: rgba(0, 0, 0, 0.85);
      }
    }
  }
  .el-tabs__content {
    flex: 1;
    .el-tab-pane {
      height: 100%;
    }
  }
}
</style>
