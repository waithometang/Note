<template>
  <el-scrollbar>
    <div class="page-container">
      <div class="grid-container box">
        <vxe-grid ref="gridRef" v-bind="gridOptions">
          <template #top>
            <GridHeader
              ref="gridHeaderRef"
              v-bind="headerOptions"
              @quickSearch="handleQuickSearch"
              @advancedSearch="handleAdvancedSearch"
              @reset="handleReset"
            />
          </template>
          <template #versionsStatus="{ row }">
            <el-tag :type="getVersionsStatusInfo(row.versionsStatus).type">
              {{ getVersionsStatusInfo(row.versionsStatus).text }}
            </el-tag>
          </template>
          <template #operation="{ row }">
            <TableAction
              :actions="[
                {
                  icon: 'download',
                  tooltip: '下载',
                  loading: !!row.downloadStatus,
                  ifShow: hasCode(VERSION_HISTORY.DOWNLOAD_VERSION),
                  onClick: handleDownload.bind(null, row)
                }
              ]"
            />
          </template>
        </vxe-grid>
      </div>
      <div class="grid-container box">
        <vxe-grid ref="gridReportRef" v-bind="gridReportOptions">
          <template #top>
            <GridHeader
              ref="gridReportHeaderRef"
              v-bind="reportHeaderOptions"
              @quickSearch="handleReportQuickSearch"
              @advancedSearch="handleReportAdvancedSearch"
              @reset="handleReportReset"
            />
          </template>
          <template #fileStatus="{ row }">
            <el-tag :type="row.fileStatus === '已通过' ? 'success' : 'info'">
              {{ row.fileStatus }}
            </el-tag>
          </template>
          <template #operation="{ row }">
            <TableAction
              :actions="[
                {
                  icon: 'download',
                  tooltip: '下载',
                  loading: !!row.downloadStatus,
                  ifShow: showDownloadTestBtn(row.reportTypeID),
                  onClick: handleReportDownload.bind(null, row)
                }
              ]"
            />
          </template>
        </vxe-grid>
      </div>
    </div>
  </el-scrollbar>
</template>

<script setup lang="ts">
import type { ComponentExposed } from 'vue-component-type-helpers'
import type { VxeGridInstance, VxeGridProps } from 'vxe-table'
import type { GridHeaderProps } from '@/components/Table/types/gridHeader'
import type {
  GetSoftwareReportModel,
  GetSoftwareReportParams,
  GetHistorySoftwareVersionModel,
  GetHistorySoftwareVersionParams
} from '@/api/sys/model/versionMngtModel'

import { reactive, ref, computed, watch } from 'vue'
import { versionsStatusOptions } from '../data'
import { downloadByApi } from '@/utils/download'

import GridHeader from '@/components/Table/GridHeader.vue'

import { getKeyValue } from '@/api/sys/basic'
import {
  getSoftwareReport,
  getHistorySoftwareVersion,
  loadSoftwareReport,
  loadSoftwareVersion,
  getSoftwareProject
} from '@/api/sys/versionMngt'
import useAuthStore from '@/stores/auth'
import {
  VERSION_HISTORY,
  TESTCASE_KEY,
  TESTREPORT_KEY,
  TESTPLAN_KEY,
  SOFTWAREMANUAL_KEY,
  RJBDJL_KEY
} from '@/constant/auth/versionMngt'
import type { GetDictionaryModel } from '@/api/sys/model/basicModel'

defineOptions({
  name: 'VersionSearch',
  inheritAttrs: false
})

const { hasCode } = useAuthStore()

const getVersionsStatusInfo = computed(() => {
  const statusMap: { [key: number]: { text: string; type: string } } = {}
  versionsStatusOptions.forEach((item) => {
    statusMap[item.value] = { text: item.label, type: item.type }
  })

  return function (status: number) {
    return statusMap[status] || { text: '', color: '' }
  }
})

const gridHeaderRef =
  ref<ComponentExposed<typeof GridHeader<GetHistorySoftwareVersionParams, 'projectID'>>>()

const getSoftwareProjectList = async () => {
  const { code, data } = await getSoftwareProject()
  if (code === 200) {
    headerOptions.quickSearch!.singleSearch.data = data.map((item) => ({
      label: item.projectName!,
      value: item.projectName!
    }))
  }
}

getSoftwareProjectList()

const headerOptions = reactive<GridHeaderProps>({
  title: '历史版本',
  quickSearch: {
    singleSearch: {
      field: 'projectName',
      type: 'select',
      title: '软件项目',
      filterable: true,
      data: []
    },
    searchFormFields: { projectName: '' }
  },
  advancedSearch: {
    labelWidth: 120,
    schemas: [
      {
        field: 'branchesID',
        label: '版本分支',
        component: 'ApiSelect',
        componentProps: {
          api: getKeyValue,
          resultField: 'data.result',
          labelField: 'value',
          valueField: 'id',
          params: {
            typeName: 'SoftwareBranch'
          }
        },
        colProps: {
          span: 8
        }
      },
      {
        field: 'versionsNo',
        label: '版本号',
        component: 'ElInput',
        componentProps: {},
        colProps: {
          span: 8
        }
      },
      {
        field: 'versionsStatus',
        label: '版本状态',
        component: 'Select',
        componentProps: {
          options: versionsStatusOptions
        },
        colProps: {
          span: 8
        }
      },
      {
        field: 'fileName',
        label: '文件名称',
        component: 'ElInput',
        componentProps: {},
        colProps: {
          span: 8
        }
      }
    ]
  },
  showAddButton: false
})

const gridRef = ref<VxeGridInstance>()
const gridOptions = reactive<VxeGridProps<GetHistorySoftwareVersionModel>>({
  border: true,
  height: '400px',
  align: null,
  columnConfig: {
    resizable: true
  },
  columns: [
    { type: 'seq', width: 50 },
    { field: 'projectName', title: '软件项目', minWidth: 100 },
    { field: 'branchesName', title: '软件版本分支', minWidth: 120 },
    { field: 'versionsNo', title: '版本号', minWidth: 100 },
    {
      field: 'versionsStatus',
      title: '版本状态',
      slots: { default: 'versionsStatus' },
      minWidth: 90
    },
    { field: 'fileName', title: '文件名', minWidth: 150 },
    { field: 'createUserName', title: '创建人', minWidth: 100 },
    { field: 'lastModifiedUserName', title: '操作人', minWidth: 100 },
    { field: 'versionSubmissionAuthor', title: '版本提交者', minWidth: 100 },
    { field: 'lastModifiedTime', title: '最后更新时间', minWidth: 140 },
    { field: 'versionUpdateRecord', title: '版本更新记录', minWidth: 120 },
    {
      field: 'operation',
      title: '操作',
      align: 'center',
      fixed: 'right',
      width: 150,
      slots: {
        default: 'operation'
      }
    }
  ],
  pagerConfig: {
    enabled: true,
    pageSize: 20
  },
  proxyConfig: {
    ajax: {
      query: ({ page }) => {
        const quickSearchForm = gridHeaderRef.value?.quickSearchForm
        const advancedSearchForm = gridHeaderRef.value?.advancedSearchForm

        return getHistorySoftwareVersion({
          pageIndex: page.currentPage - 1, // 由于后端接口限制，首页从0开始
          pageSize: page.pageSize,
          ...quickSearchForm,
          ...advancedSearchForm
        })
      }
    }
  }
})

const handleQuickSearch = () => {
  gridRef.value?.commitProxy('reload')
}

const handleAdvancedSearch = () => {
  gridRef.value?.commitProxy('reload')
}

const handleReset = () => {
  gridRef.value?.commitProxy('reload')
}

watch(
  () => gridRef.value?.getCurrentRecord(),
  (row: GetHistorySoftwareVersionModel | null) => {
    if (row) {
      versionID.value = row.id
      reportHeaderOptions.title = `测试文件 - [${row.projectName} ${row.versionsNo}]`
      gridReportRef.value?.commitProxy('reload')
    } else {
      reportHeaderOptions.title = `测试文件`
      gridReportRef.value?.loadData([])
    }
  }
)

const versionID = ref<string>('')

const gridReportHeaderRef =
  ref<ComponentExposed<typeof GridHeader<GetSoftwareReportParams, 'fileName'>>>()

const reportHeaderOptions = reactive<GridHeaderProps>({
  title: '测试文件',
  quickSearch: {
    singleSearch: {
      field: 'fileName',
      type: 'input',
      title: '文件名称'
    },
    searchFormFields: { fileName: '' }
  },
  advancedSearch: {
    labelWidth: 120,
    schemas: [
      {
        field: 'reportTypeID',
        label: '测试文件类型',
        component: 'ApiSelect',
        componentProps: {
          api: getKeyValue,
          resultField: 'data.result',
          labelField: 'value',
          valueField: 'id',
          params: {
            typeName: 'SoftwareReport'
          }
        },
        colProps: {
          span: 8
        }
      }
    ]
  },
  showAddButton: false
})

const gridReportRef = ref<VxeGridInstance>()
const gridReportOptions = reactive<VxeGridProps<GetSoftwareReportModel>>({
  border: true,
  height: '400px',
  align: null,
  columnConfig: {
    resizable: true
  },
  columns: [
    { type: 'seq', width: 50 },
    { field: 'reportTypeName', title: '测试文件类型' },
    { field: 'fileName', title: '测试文件名称', minWidth: 150 },
    {
      field: 'fileStatus',
      title: '测试文件状态',
      minWidth: 150,
      slots: { default: 'fileStatus' }
    },
    { field: 'dataDescribe', title: '备注' },
    {
      field: 'operation',
      title: '操作',
      align: 'center',
      fixed: 'right',
      width: 150,
      slots: {
        default: 'operation'
      }
    }
  ],
  pagerConfig: {
    enabled: false
  },
  proxyConfig: {
    autoLoad: false,
    ajax: {
      query: () => {
        const quickSearchForm = gridReportHeaderRef.value?.quickSearchForm
        const advancedSearchForm = gridReportHeaderRef.value?.advancedSearchForm
        return new Promise((resolve) => {
          getSoftwareReport({
            ...quickSearchForm,
            ...advancedSearchForm,
            versionID: versionID.value
          }).then((res) => {
            resolve(res.data)
          })
        })
      }
    }
  }
})

const handleReportQuickSearch = () => {
  gridReportRef.value?.commitProxy('reload')
}

const handleReportAdvancedSearch = () => {
  gridReportRef.value?.commitProxy('reload')
}

const handleReportReset = () => {
  gridReportRef.value?.commitProxy('reload')
}

const handleDownload = async (row: GetHistorySoftwareVersionModel) => {
  row.downloadStatus = true
  await downloadByApi(loadSoftwareVersion, { id: row.id })

  row.downloadStatus = false
}

const handleReportDownload = async (row: GetSoftwareReportModel) => {
  row.downloadStatus = true
  await downloadByApi(loadSoftwareReport, { id: row.id })

  row.downloadStatus = false
}

const softwareReportTypeList = ref<GetDictionaryModel[]>()

const getSoftwareReportTypeList = async () => {
  const { code, data } = await getKeyValue({ typeName: 'SoftwareReport' })
  if (code === 200) {
    softwareReportTypeList.value = data.result
  }
}
getSoftwareReportTypeList()

const showDownloadTestBtn = (reportTypeID: string) => {
  const res = softwareReportTypeList.value!.find((item) => item.id === reportTypeID)
  if (!res) {
    return false
  }
  const map: { [key: string]: string } = {}
  map[TESTCASE_KEY] = VERSION_HISTORY.DOWNLOAD_TESTCASE
  map[TESTREPORT_KEY] = VERSION_HISTORY.DOWNLOAD_TESTREPORT
  map[TESTPLAN_KEY] = VERSION_HISTORY.DOWNLOAD_TESTPLAN
  map[SOFTWAREMANUAL_KEY] = VERSION_HISTORY.DOWNLOAD_SOFTWAREMANUAL
  map[RJBDJL_KEY] = VERSION_HISTORY.DOWNLOAD_RJBDJL
  return hasCode(map[res!.value])
}
</script>

<style scoped lang="scss">
.page-container {
  display: flex;
  flex-direction: column;
  gap: $margin;
}
</style>
