<template>
  <BasicModal
    width="567px"
    v-bind="$attrs"
    @register="registerModal"
    title="上传测试文件"
    @confirm="handleSubmit"
  >
    <BasicForm @register="registerForm">
      <template #fileName="{ model, field }">
        <div style="display: flex; gap: 10px">
          <el-input size="default" disabled v-model="model[field]" />
          <el-upload
            ref="uploadRef"
            :action="getAction"
            name="file"
            accept="*"
            :headers="{ Authorization: appStore.token }"
            :auto-upload="false"
            :show-file-list="false"
            :limit="1"
            :on-change="handleFileChange"
            :on-exceed="handleExceed"
            :on-success="handUploadSuccess"
            :on-progress="handleUploadProgress"
            :on-error="handleUploadError"
          >
            <template #trigger>
              <el-button type="primary">选择文件</el-button>
            </template>
          </el-upload>
        </div>
        <div style="margin-top: 5px" v-if="process !== 0">
          <el-progress :percentage="round(process, 1)" :status="process === 100 ? 'success' : ''" />
        </div>
      </template>
    </BasicForm>
  </BasicModal>
</template>

<script lang="ts" setup>
import type { ModalMethods } from '@/components/Modal/types'
import { computed, ref } from 'vue'
import { round } from 'lodash-es'

import BasicModal from '@/components/Modal/BasicModal.vue'
import { useModalInner } from '@/components/Modal/hooks/useModal'
import BasicForm from '@/components/Form/BasicForm.vue'
import { useForm } from '@/components/Form/hooks/useForm'
import { getKeyValueByClassify } from '@/api/sys/basic'
import {
  genFileId,
  type UploadFile,
  type UploadInstance,
  type UploadProgressEvent,
  type UploadProps,
  type UploadRawFile
} from 'element-plus'
import useUserStore from '@/stores/user'
import { addSoftwareReport } from '@/api/sys/versionMngt'
import type { AddSoftwareReportData } from '@/api/sys/model/versionMngtModel'
import { RJBDJL_KEY, TESTCASE_KEY, TESTREPORT_KEY, VERSION_CONTROL } from '@/constant/auth/versionMngt'
import useAuthStore from '@/stores/auth'
import { TESTPLAN_KEY } from '@/constant/auth/versionMngt'
import { SOFTWAREMANUAL_KEY } from '@/constant/auth/versionMngt'

const emit = defineEmits<{
  register: [modalMethods: ModalMethods, uuid: number]
  success: []
}>()

const rowID = ref<string>()

const uploadRef = ref<UploadInstance>()

const appStore = useUserStore()

const { hasCode } = useAuthStore()

const getAction = computed(() => {
  return import.meta.env.VITE_BASE_URL + '/UploadFile/UploadTempFile'
})
const isError = ref(false)

const handleFileChange = (uploadFile: UploadFile) => {
  if (!isError.value) {
    setFieldsValue({ fileName: uploadFile.name })
  }
  isError.value = false
}
const handleExceed: UploadProps['onExceed'] = (files) => {
  uploadRef.value!.clearFiles()
  const file = files[0] as UploadRawFile
  file.uid = genFileId()
  uploadRef.value!.handleStart(file)
}

const [registerModal, { closeModal, setModalProps }] = useModalInner(async (data) => {
  resetFields()
  rowID.value = data.row.id
  uploadRef.value!.clearFiles()
  process.value = 0
  setFieldsValue({ fileName: '' })
  setModalProps({ confirmLoading: false })
})

const [registerForm, { setFieldsValue, resetFields, getFieldsValue, validate }] = useForm({
  labelWidth: 120,
  schemas: [
    {
      field: 'reportTypeID',
      component: 'ApiSelect',
      label: '上传文件类型',
      required: true,
      componentProps: {
        api: getKeyValueByClassify,
        resultField: 'data',
        labelField: 'value',
        valueField: 'id',
        params: {
          typeName: 'SoftwareReport'
        },
        onOptionsChange(options: any) {
          const map: { [key: string]: string } = {}
          map[TESTCASE_KEY] = VERSION_CONTROL.UPLOAD_TESTCASE
          map[TESTREPORT_KEY] = VERSION_CONTROL.UPLOAD_TESTREPORT
          map[TESTPLAN_KEY] = VERSION_CONTROL.UPLOAD_TESTPLAN
          map[SOFTWAREMANUAL_KEY] = VERSION_CONTROL.UPLOAD_SOFTWAREMANUAL
          map[RJBDJL_KEY] = VERSION_CONTROL.UPLOAD_RJBDJL

          const disabledHandler = (key: string) => {
            return !hasCode(map[key])
          }
          options.forEach((item: any) => {
            item.disabled = disabledHandler(item.label)
          })
        }
      },
      colProps: {
        span: 24
      }
    },
    {
      field: 'fileName',
      component: 'ElInput',
      label: '文件名称',
      required: true,
      slot: 'fileName',
      componentProps: {},
      colProps: {
        span: 24
      }
    },
    {
      field: 'dataDescribe',
      component: 'ElInput',
      label: '备注',
      componentProps: { type: 'textarea' },
      colProps: {
        span: 24
      }
    }
  ]
})

const process = ref(0)
const handleUploadProgress = (evt: UploadProgressEvent) => {
  process.value = evt.percent
}

// 提交
const handleSubmit = async () => {
  await validate()
  uploadRef.value?.submit()
  setModalProps({ confirmLoading: true })
  // handUploadSuccess()
}
const handUploadSuccess = async () => {
  try {
    const data: AddSoftwareReportData = {
      versionID: rowID.value,
      ...getFieldsValue()
    }
    const { code, message } = await addSoftwareReport(data)
    if (code === 200) {
      ElMessage.success('上传成功')
      closeModal()
      emit('success')
    } else {
      ElMessage.error(message)
    }
  } catch (error: any) {
    ElMessage(error.message)
  } finally {
    uploadRef.value!.clearFiles()
    process.value = 0
    setFieldsValue({ fileName: '' })
    setModalProps({ confirmLoading: false })
  }
}

const handleUploadError = (error: Error) => {
  uploadRef.value!.clearFiles()
  process.value = 0
  setFieldsValue({ fileName: '' })
  setModalProps({ confirmLoading: false })
  ElMessage.error(error.message)
  isError.value = true
}
</script>

<style lang="scss" scoped></style>
