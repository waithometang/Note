<template>
  <BasicModal
    width="567px"
    v-bind="$attrs"
    @register="registerModal"
    :title="getTitle"
    @confirm="handleSubmit"
  >
    <BasicForm @register="registerForm"> </BasicForm>
  </BasicModal>
</template>

<script lang="ts" setup>
import type { ModalMethods } from '@/components/Modal/types'

import BasicModal from '@/components/Modal/BasicModal.vue'
import { useModalInner } from '@/components/Modal/hooks/useModal'
import BasicForm from '@/components/Form/BasicForm.vue'
import { useForm } from '@/components/Form/hooks/useForm'
import { addSoftwareProject, updateSoftwareProject } from '@/api/sys/versionMngt'
import type { AddSoftwareProjectData } from '@/api/sys/model/versionMngtModel'
import { computed, unref, ref } from 'vue'

const emit = defineEmits<{
  register: [modalMethods: ModalMethods, uuid: number]
  success: []
}>()

const isUpdate = ref<boolean>(false)

const rowId = ref<string>('')

const getTitle = computed(() => (!unref(isUpdate) ? '新增' : '修改'))

const [registerModal, { closeModal, setModalProps }] = useModalInner(async (data) => {
  resetFields()
  setModalProps({ confirmLoading: false })
  isUpdate.value = !!data?.isUpdate
  if (unref(isUpdate)) {
    rowId.value = data.row.id
    setFieldsValue({ ...data.row })
  }
})

const [registerForm, { resetFields, getFieldsValue, validate, setFieldsValue }] = useForm({
  labelWidth: 120,
  schemas: [
    {
      field: 'projectName',
      component: 'ElInput',
      label: '项目名称',
      required: true,
      componentProps: {},
      colProps: {
        span: 24
      }
    }
  ]
})

// 提交
const handleSubmit = async () => {
  await validate()
  setModalProps({ confirmLoading: true })
  try {
    const data = getFieldsValue() as AddSoftwareProjectData
    if (!unref(isUpdate)) {
      const { code, message } = await addSoftwareProject(data)
      if (code === 200) {
        ElMessage.success('新增成功')
        closeModal()
        emit('success')
      } else {
        ElMessage.error(message)
      }
    } else {
      const { code, message } = await updateSoftwareProject({
        id: rowId.value,
        ...data
      })
      if (code === 200) {
        ElMessage.success('修改成功')
        closeModal()
        emit('success')
      } else {
        ElMessage.error(message)
      }
    }
  } catch (error: any) {
    ElMessage(error.message)
  } finally {
    setModalProps({ confirmLoading: false })
  }
}
</script>

<style lang="scss" scoped></style>
