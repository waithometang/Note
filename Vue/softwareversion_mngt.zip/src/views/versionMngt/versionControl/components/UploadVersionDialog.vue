<template>
  <BasicModal
    width="567px"
    v-bind="$attrs"
    @register="registerModal"
    title="上传软件分支版本"
    @confirm="handleSubmit"
  >
    <BasicForm @register="registerForm">
      <template #fileName="{ model, field }">
        <div style="display: flex; gap: 10px">
          <el-input size="default" disabled v-model="model[field]" />
          <el-upload
            ref="uploadRef"
            :action="getAction"
            name="file"
            accept="*"
            :headers="{ Authorization: appStore.token }"
            :auto-upload="false"
            :show-file-list="false"
            :limit="1"
            :on-change="handleFileChange"
            :on-exceed="handleExceed"
            :on-success="handUploadSuccess"
            :on-progress="handleUploadProgress"
            :on-error="handleUploadError"
          >
            <template #trigger>
              <el-button type="primary">选择文件</el-button>
            </template>
          </el-upload>
        </div>
        <div style="margin-top: 5px" v-if="process !== 0">
          <el-progress :percentage="round(process, 1)" :status="process === 100 ? 'success' : ''" />
        </div>
      </template>
    </BasicForm>
  </BasicModal>
</template>

<script lang="ts" setup>
import type { ModalMethods } from '@/components/Modal/types'
import type { AddSoftwareVersiontData } from '@/api/sys/model/versionMngtModel'

import { computed, ref } from 'vue'
import { round } from 'lodash-es'

import BasicModal from '@/components/Modal/BasicModal.vue'
import { useModalInner } from '@/components/Modal/hooks/useModal'
import BasicForm from '@/components/Form/BasicForm.vue'
import { useForm } from '@/components/Form/hooks/useForm'
import {
  genFileId,
  type UploadFile,
  type UploadInstance,
  type UploadProps,
  type UploadRawFile,
  type UploadProgressEvent
} from 'element-plus'
import useUserStore from '@/stores/user'

import { addSoftwareVersion, getSoftwareProject } from '@/api/sys/versionMngt'
import { getKeyValueByClassify } from '@/api/sys/basic'

const emit = defineEmits<{
  register: [modalMethods: ModalMethods, uuid: number]
  success: []
}>()

const uploadRef = ref<UploadInstance>()

const appStore = useUserStore()

const getAction = computed(() => {
  return import.meta.env.VITE_BASE_URL + '/UploadFile/UploadTempFile'
})

const isError = ref(false)

const handleFileChange = (uploadFile: UploadFile) => {
  if (!isError.value) {
    setFieldsValue({ fileName: uploadFile.name })
  }
  isError.value = false
}
const handleExceed: UploadProps['onExceed'] = (files) => {
  uploadRef.value!.clearFiles()
  const file = files[0] as UploadRawFile
  file.uid = genFileId()
  uploadRef.value!.handleStart(file)
}

const [registerModal, { closeModal, setModalProps }] = useModalInner(async (data) => {
  resetFields()
  uploadRef.value!.clearFiles()
  process.value = 0
  setFieldsValue({ projectID: data.projectID, fileName: '' })
  setModalProps({ confirmLoading: false })
})

const [registerForm, { setFieldsValue, resetFields, getFieldsValue, validate }] = useForm({
  labelWidth: 125,
  schemas: [
    {
      field: 'projectID',
      component: 'ApiSelect',
      label: '项目名称',
      required: true,
      componentProps: {
        api: getSoftwareProject,
        valueField: 'id',
        labelField: 'projectName',
        resultField: 'data'
      },
      colProps: {
        span: 24
      }
    },
    {
      field: 'fileName',
      component: 'ElInput',
      label: '文件名称',
      required: true,
      slot: 'fileName',
      componentProps: {},
      colProps: {
        span: 24
      }
    },
    {
      field: 'versionsNo',
      component: 'ElInput',
      label: '版本号',
      required: true,
      componentProps: {},
      colProps: {
        span: 24
      }
    },
    {
      field: 'branchesID',
      component: 'ApiSelect',
      label: '版本分支',
      required: true,
      componentProps: {
        api: getKeyValueByClassify,
        resultField: 'data',
        labelField: 'value',
        valueField: 'id',
        params: {
          typeName: 'SoftwareBranch'
        }
      },
      colProps: {
        span: 24
      }
    },
    {
      field: 'versionSubmissionAuthor',
      component: 'ElInput',
      label: '版本提交作者',
      required: true,
      componentProps: {},
      colProps: {
        span: 24
      }
    },
    {
      field: 'codeSubmissionVersion',
      component: 'ElInput',
      label: '代码提交版本号',
      required: true,
      componentProps: {},
      colProps: {
        span: 24
      }
    },
    {
      field: 'codeBasePath',
      component: 'ElInput',
      label: '代码库路径',
      required: true,
      componentProps: {},
      colProps: {
        span: 24
      }
    },
    {
      field: 'codeBranch',
      component: 'ElInput',
      label: '代码分支',
      // required: true,
      componentProps: {},
      colProps: {
        span: 24
      }
    },
    {
      field: 'versionUpdateRecord',
      component: 'ElInput',
      label: '版本更新记录',
      required: true,
      componentProps: {},
      colProps: {
        span: 24
      }
    }
  ]
})

const process = ref(0)
const handleUploadProgress = (evt: UploadProgressEvent) => {
  process.value = evt.percent
}

// 提交
const handleSubmit = async () => {
  await validate()
  uploadRef.value?.submit()
  setModalProps({ confirmLoading: true })
  // handUploadSuccess()
}

const handUploadSuccess = async () => {
  try {
    // uploadRef.value?.submit() // 上传文件
    const data = getFieldsValue() as AddSoftwareVersiontData
    const { code, message } = await addSoftwareVersion(data)
    if (code === 200) {
      ElMessage.success('上传成功')
      closeModal()
      emit('success')
    } else {
      ElMessage.error(message)
    }
  } catch (error: any) {
    ElMessage(error.message)
  } finally {
    uploadRef.value!.clearFiles()
    process.value = 0
    setFieldsValue({ fileName: '' })
    setModalProps({ confirmLoading: false })
  }
}

const handleUploadError = (error: Error) => {
  uploadRef.value!.clearFiles()
  process.value = 0
  setFieldsValue({ fileName: '' })
  setModalProps({ confirmLoading: false })
  ElMessage.error(error.message)
  isError.value = true
}
</script>

<style lang="scss" scoped></style>
