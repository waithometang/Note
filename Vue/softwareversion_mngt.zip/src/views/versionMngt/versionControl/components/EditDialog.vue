<template>
  <BasicModal
    width="567px"
    v-bind="$attrs"
    @register="registerModal"
    title="编辑"
    @confirm="handleSubmit"
  >
    <BasicForm @register="registerForm"> </BasicForm>
  </BasicModal>
</template>

<script lang="ts" setup>
import type { ModalMethods } from '@/components/Modal/types'

import BasicModal from '@/components/Modal/BasicModal.vue'
import { useModalInner } from '@/components/Modal/hooks/useModal'
import BasicForm from '@/components/Form/BasicForm.vue'
import { useForm } from '@/components/Form/hooks/useForm'
import { updateSoftwareVersionStatus } from '@/api/sys/versionMngt'
import type { UpdateSoftwareVersiontData } from '@/api/sys/model/versionMngtModel'
import { ref } from 'vue'
import { versionsStatusOptions } from '../../data'
import useAuthStore from '@/stores/auth'
import { VERSION_CONTROL } from '@/constant/auth/versionMngt'

const emit = defineEmits<{
  register: [modalMethods: ModalMethods, uuid: number]
  success: []
}>()

const rowID = ref<string>()

const { hasCode } = useAuthStore()

const [registerModal, { closeModal, setModalProps }] = useModalInner(async (data) => {
  resetFields()
  rowID.value = data.row.id
  setFieldsValue({ ...data.row })
  setModalProps({ confirmLoading: false })
})

const [registerForm, { resetFields, getFieldsValue, validate, setFieldsValue }] = useForm({
  labelWidth: 120,
  schemas: [
    {
      field: 'versionsStatus',
      component: 'Select',
      label: '版本状态',
      required: true,
      componentProps: {
        options: versionsStatusOptions.map((item) => {
          return {
            ...item,
            disabled: item.value === 5 ? !hasCode(VERSION_CONTROL.QUICK_PUBLISH) : false
          }
        })
      },
      colProps: {
        span: 24
      }
    }
  ]
})

// 提交
const handleSubmit = async () => {
  await validate()
  setModalProps({ confirmLoading: true })
  try {
    const data: UpdateSoftwareVersiontData = {
      id: rowID.value,
      ...getFieldsValue()
    }
    const { code, message } = await updateSoftwareVersionStatus(data)
    if (code === 200) {
      ElMessage.success('修改成功')
      closeModal()
      emit('success')
    } else {
      ElMessage.error(message)
    }
  } catch (error: any) {
    ElMessage(error.message)
  } finally {
    setModalProps({ confirmLoading: false })
  }
}
</script>

<style lang="scss" scoped></style>
