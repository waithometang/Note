export const versionsStatusOptions = [
  { label: '待测试', value: 0, type: 'info' },
  { label: '测试中', value: 1, type: 'warning' },
  { label: '测试通过', value: 2, type: 'success' },
  { label: '测试未通过', value: 3, type: 'danger' },
  { label: '测试发布', value: 4, type: '' },
  { label: '紧急发布', value: 5, type: 'warning' },
]
