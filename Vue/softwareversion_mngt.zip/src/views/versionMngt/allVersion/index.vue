<template>
  <LayoutContainer>
    <template #leftSide>
      <basic-list ref="basicListRef" v-bind="listOptions"> </basic-list>
    </template>
    <el-scrollbar>
      <div class="page-container">
        <div class="grid-container box">
          <vxe-grid class="vxe-grid" ref="gridRef" v-bind="gridOptions">
            <template #top>
              <GridHeader
                ref="gridHeaderRef"
                v-bind="headerOptions"
                @quickSearch="handleQuickSearch"
              >
              </GridHeader>
            </template>
            <template #versionsStatus="{ row }">
              <el-tag :type="getVersionsStatusInfo(row.versionsStatus).type">
                {{ getVersionsStatusInfo(row.versionsStatus).text }}
              </el-tag>
            </template>

            <template #operation="{ row }">
              <TableAction
                :actions="[
                  {
                    icon: 'download',
                    tooltip: '下载',
                    loading: !!row.downloadStatus,
                    ifShow: hasCode(ALL_VERSION.DOWNLOAD_VERSION),
                    onClick: handleDownload.bind(null, row)
                  }
                ]"
              />
            </template>
          </vxe-grid>
        </div>
        <div class="grid-container box">
          <vxe-grid ref="gridReportRef" v-bind="gridReportOptions">
            <template #top>
              <GridHeader
                ref="gridReportHeaderRef"
                v-bind="reportHeaderOptions"
                @quickSearch="handleReportQuickSearch"
                @advancedSearch="handleReportAdvancedSearch"
                @reset="handleReportReset"
              />
            </template>
            <template #fileStatus="{ row }">
              <el-tag :type="row.fileStatus === '已通过' ? 'success' : 'info'">
                {{ row.fileStatus }}
              </el-tag>
            </template>
            <template #operation="{ row }">
              <TableAction
                :actions="[
                  {
                    icon: 'download',
                    tooltip: '下载',
                    loading: !!row.downloadStatus,
                    ifShow: showDownloadTestBtn(row.reportTypeID),
                    onClick: handleReportDownload.bind(null, row)
                  }
                ]"
              />
            </template>
          </vxe-grid>
        </div>
      </div>
    </el-scrollbar>
  </LayoutContainer>
</template>

<script setup lang="ts">
import type { ComponentExposed } from 'vue-component-type-helpers'
import type { VxeGridInstance, VxeGridProps } from 'vxe-table'
import type { GridHeaderProps } from '@/components/Table/types/gridHeader'
import type { ListProps } from '@/components/List/types'

import { ref, reactive, unref, computed, watch } from 'vue'

import GridHeader from '@/components/Table/GridHeader.vue'

import {
  getAllSoftwareVersion,
  getSoftwareProject,
  loadSoftwareReport,
  getSoftwareReport
} from '@/api/sys/versionMngt'
import type {
  GetCurrentSoftwareVersionModel,
  GetCurrentSoftwareVersionParams,
  GetSoftwareVersionModel,
  GetSoftwareReportModel,
  GetSoftwareReportParams
} from '@/api/sys/model/versionMngtModel'
import { versionsStatusOptions } from '../data'
import {
  TESTCASE_KEY,
  TESTREPORT_KEY,
  TESTPLAN_KEY,
  SOFTWAREMANUAL_KEY,
  RJBDJL_KEY,
  ALL_VERSION
} from '@/constant/auth/versionMngt'
import useAuthStore from '@/stores/auth'
import { downloadByApi } from '@/utils/download'
import { loadSoftwareVersion } from '@/api/sys/versionMngt'
import type { GetDictionaryModel } from '@/api/sys/model/basicModel'
import { getKeyValue } from '@/api/sys/basic'

defineOptions({
  name: 'AllVersion',
  inheritAttrs: false
})

const { hasCode } = useAuthStore()

const basicListRef = ref()
const gridRef = ref<VxeGridInstance>()

// 列表配置
const listOptions = reactive<ListProps>({
  api: getSoftwareProject,
  title: '软件项目列表',
  valueField: 'id',
  labelField: 'projectName',
  resultField: 'data',
  isCancelCurrent: true,
  onChange({ item }) {
    if (item) {
      gridRef.value?.commitProxy('reload')
      headerOptions.title = `版本控制-${basicListRef.value?.getActiveItem.projectName}`
    } else {
      headerOptions.title = `版本控制`
      gridRef.value?.remove()
    }
  }
})

const gridHeaderRef =
  ref<ComponentExposed<typeof GridHeader<GetCurrentSoftwareVersionParams, 'branchesName'>>>()

const headerOptions = reactive<GridHeaderProps>({
  title: '版本控制',
  quickSearch: {
    singleSearch: {
      field: 'branchesName',
      type: 'input',
      title: '软件版本分支'
    },
    searchFormFields: { branchesName: '' }
  },
  showAddButton: false,
  showAdvancedSearchButton: false
})

const handleQuickSearch = () => {
  gridRef.value?.commitProxy('reload')
}

watch(
  () => gridRef.value?.getCurrentRecord(),
  (row: GetSoftwareVersionModel | null) => {
    if (row) {
      versionID.value = row.id
      reportHeaderOptions.title = `测试文件 - [${row.projectName} ${row.versionsNo}]`
      gridReportRef.value?.commitProxy('reload')
    } else {
      reportHeaderOptions.title = `测试文件`
      gridReportRef.value?.loadData([])
    }
  }
)

const versionID = ref<string>('')

const gridOptions = reactive<VxeGridProps<GetCurrentSoftwareVersionModel>>({
  border: true,
  height: '400px',
  align: null,
  columnConfig: {
    resizable: true
  },
  columns: [
    { type: 'seq', width: 50 },
    { field: 'projectName', title: '软件项目', minWidth: 100 },
    { field: 'branchesName', title: '软件版本分支', minWidth: 120 },
    { field: 'versionsNo', title: '版本号', minWidth: 100 },
    { field: 'fileName', title: '文件名称', minWidth: 100 },
    {
      field: 'versionsStatus',
      title: '软件状态',
      slots: { default: 'versionsStatus' },
      minWidth: 100
    },
    { field: 'createUserName', title: '创建人', minWidth: 100 },
    { field: 'lastModifiedUserName', title: '操作人', minWidth: 100 },
    { field: 'lastModifiedTime', title: '最后更新时间', minWidth: 140 },
    { field: 'versionUpdateRecord', title: '版本更新记录', minWidth: 130 },
    {
      field: 'operation',
      title: '操作',
      align: 'center',
      fixed: 'right',
      width: 100,
      slots: {
        default: 'operation'
      }
    }
  ],
  pagerConfig: {
    enabled: false
  },
  proxyConfig: {
    ajax: {
      query: () => {
        const quickSearchForm = unref(gridHeaderRef)?.quickSearchForm || {}
        const advancedSearchForm = unref(gridHeaderRef)?.advancedSearchForm || {}

        const projectID = basicListRef.value.getActiveItem?.value
        return new Promise((res) => {
          getAllSoftwareVersion({
            ...quickSearchForm,
            ...advancedSearchForm,
            projectID
          }).then((data) => res(data.data))
        })
      }
    }
  }
})

const gridReportHeaderRef =
  ref<ComponentExposed<typeof GridHeader<GetSoftwareReportParams, 'fileName'>>>()
const reportHeaderOptions = reactive<GridHeaderProps>({
  title: '测试文件',
  quickSearch: {
    singleSearch: {
      field: 'fileName',
      type: 'input',
      title: '文件名称'
    },
    searchFormFields: { fileName: '' }
  },
  advancedSearch: {
    labelWidth: 120,
    schemas: [
      {
        field: 'reportTypeID',
        label: '测试文件类型',
        component: 'ApiSelect',
        componentProps: {
          api: getKeyValue,
          resultField: 'data.result',
          labelField: 'value',
          valueField: 'id',
          params: {
            typeName: 'SoftwareReport'
          }
        },
        colProps: {
          span: 8
        }
      }
    ]
  },
  showAddButton: false
})

const gridReportRef = ref<VxeGridInstance>()
const gridReportOptions = reactive<VxeGridProps<GetSoftwareReportModel>>({
  border: true,
  height: '400px',
  align: null,
  columnConfig: {
    resizable: true
  },
  columns: [
    { type: 'seq', width: 50 },
    { field: 'reportTypeName', title: '测试文件类型' },
    { field: 'fileName', title: '测试文件名称', minWidth: 150 },
    {
      field: 'fileStatus',
      title: '测试文件状态',
      minWidth: 150,
      slots: { default: 'fileStatus' }
    },
    { field: 'dataDescribe', title: '备注' },
    {
      field: 'operation',
      title: '操作',
      align: 'center',
      fixed: 'right',
      width: 100,
      slots: {
        default: 'operation'
      }
    }
  ],
  pagerConfig: {
    enabled: false
  },
  proxyConfig: {
    autoLoad: false,
    ajax: {
      query: () => {
        const quickSearchForm = gridReportHeaderRef.value?.quickSearchForm
        const advancedSearchForm = gridReportHeaderRef.value?.advancedSearchForm
        return new Promise((resolve) => {
          getSoftwareReport({
            ...quickSearchForm,
            ...advancedSearchForm,
            versionID: versionID.value
          }).then((res) => {
            resolve(res.data)
          })
        })
      }
    }
  }
})

const handleReportQuickSearch = () => {
  gridReportRef.value?.commitProxy('reload')
}

const handleReportAdvancedSearch = () => {
  gridReportRef.value?.commitProxy('reload')
}

const handleReportReset = () => {
  gridReportRef.value?.commitProxy('reload')
}

const getVersionsStatusInfo = computed(() => {
  const statusMap: { [key: number]: { text: string; type: string } } = {}
  versionsStatusOptions.forEach((item) => {
    statusMap[item.value] = { text: item.label, type: item.type }
  })

  return function (status: number) {
    return statusMap[status] || { text: '', color: '' }
  }
})

const softwareReportTypeList = ref<GetDictionaryModel[]>()

const getSoftwareReportTypeList = async () => {
  const { code, data } = await getKeyValue({ typeName: 'SoftwareReport' })
  if (code === 200) {
    softwareReportTypeList.value = data.result
  }
}
getSoftwareReportTypeList()

// 下载
const handleDownload = async (row: GetSoftwareVersionModel) => {
  row.downloadStatus = true
  await downloadByApi(loadSoftwareVersion, { id: row.id })
  row.downloadStatus = false
}

const showDownloadTestBtn = (reportTypeID: string) => {
  const res = softwareReportTypeList.value!.find((item) => item.id === reportTypeID)
  if (!res) {
    return false
  }
  const map: { [key: string]: string } = {}
  map[TESTCASE_KEY] = ALL_VERSION.DOWNLOAD_TESTCASE
  map[TESTREPORT_KEY] = ALL_VERSION.DOWNLOAD_TESTREPORT
  map[TESTPLAN_KEY] = ALL_VERSION.DOWNLOAD_TESTPLAN
  map[SOFTWAREMANUAL_KEY] = ALL_VERSION.DOWNLOAD_SOFTWAREMANUAL
  map[RJBDJL_KEY] = ALL_VERSION.DOWNLOAD_RJBDJL
  return hasCode(map[res!.value])
}

const handleReportDownload = async (row: GetSoftwareReportModel) => {
  row.downloadStatus = true
  await downloadByApi(loadSoftwareReport, { id: row.id })

  row.downloadStatus = false
}
</script>

<style scoped lang="scss">
.page-container {
  display: flex;
  flex-direction: column;
  gap: $margin;
  padding-left: 0px;
}
</style>
