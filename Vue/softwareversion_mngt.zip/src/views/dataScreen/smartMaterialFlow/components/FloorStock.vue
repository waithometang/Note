<template>
  <div class="floor-stock-container">
    <div class="progress-bar-container" v-for="item in storeData" :key="item.storeName">
      <div class="caption">
        <div class="left">{{ item.storeName }}</div>
        <div class="right">{{ item.storePercent }}%</div>
      </div>
      <div class="bar">
        <div class="progress" :style="{ width: item.storePercent + '%' }">
          <div class="text" :style="item.storePercent < 15 ? 'left:5px' : 'right:10px'">
            {{ item.storeCount }}
          </div>
          <div class="slide-block"></div>
        </div>
      </div>
    </div>
  </div>
</template>

<script setup lang="ts">
import type { PropType } from 'vue'
import type { InventoryFloorReportModel } from '../types'
import { computed } from 'vue'

const props = defineProps({
  data: { type: Array as PropType<InventoryFloorReportModel[]>, default: () => [] }
})

const storeData = computed(() => props.data)
</script>

<style scoped lang="scss">
.floor-stock-container {
  padding: 20px;
  display: flex;
  height: 100%;
  flex-direction: column;
  // gap: 24px;
  justify-content: space-between;
}
.progress-bar-container {
  .caption {
    display: flex;
    justify-content: space-between;
    padding-bottom: 8px;
    .left {
      font-size: 12px;
      font-weight: 500;
    }
    .right {
      font-size: 14px;
      font-weight: 500;
      letter-spacing: 1px;
      color: rgba(60, 177, 251, 1);
    }
  }
  .bar {
    --bar-height: 20px;
    background: rgba(217, 231, 255, 0.1);
    height: var(--bar-height);
    position: relative;
    .progress {
      position: absolute;
      top: 0;
      left: 0;
      width: 0%;
      height: var(--bar-height);
      background: linear-gradient(
        116.57deg,
        rgba(59, 163, 255, 0.35) 0%,
        rgba(60, 177, 251, 1) 100%
      );
      transition: width 0.6 ease;
      transform: translateZ(0); // 开启GPU加速

      // display: flex;justify-content: flex-end;
    }
    .text {
      position: absolute;
      // float: right;
      // margin-right: 15px;
      line-height: var(--bar-height);
    }
    .slide-block {
      position: absolute;
      right: 0;
      top: 0;
      transform: translateY(-2.5px) translateZ(0);
      width: 5px;
      height: calc(var(--bar-height) + 5px);
      background-color: #fff;
    }
  }
}
</style>
