<template>
  <v-chart ref="chartRef" autoresize :option="option" />
</template>

<script setup lang="ts">
import { ref, computed, onUnmounted } from 'vue'
import { use } from 'echarts/core'
import VChart from 'vue-echarts'
import { LineChart, BarChart } from 'echarts/charts'
import {
  TitleComponent,
  TooltipComponent,
  LegendComponent,
  GridComponent,
  DataZoomComponent
} from 'echarts/components'
import { CanvasRenderer } from 'echarts/renderers'
import type { ComposeOption } from 'echarts/core'
import type { LineSeriesOption, BarSeriesOption } from 'echarts/charts'
import type {
  TitleComponentOption,
  TooltipComponentOption,
  LegendComponentOption,
  GridComponentOption,
  DataZoomComponentOption
} from 'echarts/components'
import type { PropType } from 'vue'
import { onMounted } from 'vue'
import { DATASCREEN_CONFIG } from '@/constant'
import type { InOutBarChartReportModel } from '../types'

use([
  TitleComponent,
  TooltipComponent,
  LegendComponent,
  GridComponent,
  LineChart,
  BarChart,
  CanvasRenderer,
  DataZoomComponent
])

type EChartsOption = ComposeOption<
  | TitleComponentOption
  | TooltipComponentOption
  | LegendComponentOption
  | GridComponentOption
  | LineSeriesOption
  | BarSeriesOption
  | DataZoomComponentOption
>

const props = defineProps({
  data: { type: Object as PropType<InOutBarChartReportModel>, default: () => ({}) }
})

const chartRef = ref<InstanceType<typeof VChart> | null>(null)

const option = computed<EChartsOption>(() => {
  const data = props.data

  return {
    grid: {
      top: '40px',
      left: '65px',
      right: '12px',
      bottom: '50px' //也可设置left和right设置距离来控制图表的大小
    },
    tooltip: {
      trigger: 'axis',
      axisPointer: {
        type: 'shadow',
        label: {
          show: true
        }
      },
      confine: true
    },
    // dataZoom: {
    //   type: 'slider', // 内置型数据缩放组件
    //   show: true,
    //   // xAxisIndex: 0, // 指定要缩放的x轴
    //   startValue: xAxisData[dataZoomIndex.startIndex], // 开始缩放位置
    //   endValue: xAxisData[dataZoomIndex.endIndex] // 结束缩放位置
    // },
    legend: {
      // show: false,
      bottom: '5px',
      itemHeight: 10,
      itemWidth: 20,
      textStyle: {
        fontSize: 12,
        color: 'rgba(255, 255, 255, 0.6)'
      }
    },
    xAxis: {
      type: 'category',
      axisLabel: {
        color: '#a4a8b4'
      },
      data: data?.timeData?.map((item) => item) || []
    },
    yAxis: {
      type: 'value',
      splitLine: {
        lineStyle: { opacity: 0.1 }
      },
      axisLabel: { color: 'rgba(255, 255, 255, 0.4)', show: true }
    },

    series: [
      {
        name: '入库',
        type: 'line',
        // smooth: true,
        showAllSymbol: true, //显示所有图形。
        symbol: 'circle', //标记的图形为实心圆
        itemStyle: {
          //折线拐点标志的样式
          borderWidth: 2
        },
        label: { show: true, color: 'inherit', formatter: '{c}h' },
        lineStyle: {
          width: 3
        },
        data: data?.inCountData?.map((value) => {
          return {
            value: value,
            label: {
              show: false,
              color: '#fff',
              position: 'inside',
              formatter: '{c}h'
            }
          }
        })
      },
      {
        name: '出库',
        type: 'line',
        // smooth: true,
        showAllSymbol: true, //显示所有图形。
        symbol: 'circle', //标记的图形为实心圆
        itemStyle: {
          //折线拐点标志的样式
          borderWidth: 2
        },
        label: { show: true, color: 'inherit', formatter: '{c}h' },
        lineStyle: {
          width: 3
        },
        data: data?.outCountData?.map((value) => {
          return {
            value: value,
            label: {
              show: false,
              color: '#fff',
              position: 'inside',
              formatter: '{c}h'
            }
          }
        })
      }
    ]
  }
})

let timer: number

const animation = (index: number = -1) => {
  timer = setTimeout(() => {
    const dataLength = props.data?.timeData?.length || 0
    chartRef.value?.dispatchAction({
      type: 'downplay',
      seriesIndex: 0,
      dataIndex: index
    })
    index = (index + 1) % dataLength
    chartRef.value?.dispatchAction({
      type: 'highlight',
      seriesIndex: 0,
      dataIndex: index
    })
    chartRef.value?.dispatchAction({
      type: 'showTip',
      seriesIndex: 0,
      dataIndex: index
    })
    animation(index)
  }, DATASCREEN_CONFIG.interval)
}

onMounted(() => {
  animation()
})

onUnmounted(() => {
  clearTimeout(timer)
  chartRef.value?.dispose()
  chartRef.value = null
})
</script>

<style scoped lang="scss"></style>
