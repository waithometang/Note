<template>
  <v-chart ref="chartRef" autoresize :option="option" />
</template>

<script setup lang="ts">
import { ref, computed, onUnmounted } from 'vue'
import { use } from 'echarts/core'
import VChart from 'vue-echarts'
import { LineChart, BarChart } from 'echarts/charts'
import {
  TitleComponent,
  TooltipComponent,
  LegendComponent,
  GridComponent,
  DataZoomComponent
} from 'echarts/components'
import { CanvasRenderer } from 'echarts/renderers'
import type { ComposeOption } from 'echarts/core'
import type { LineSeriesOption, BarSeriesOption } from 'echarts/charts'
import type {
  TitleComponentOption,
  TooltipComponentOption,
  LegendComponentOption,
  GridComponentOption,
  DataZoomComponentOption
} from 'echarts/components'
import type { PropType } from 'vue'
import { onMounted } from 'vue'
import { DATASCREEN_CONFIG } from '@/constant'
import type { InOutWeekStatisticsReportModel } from '../types'

use([
  TitleComponent,
  TooltipComponent,
  LegendComponent,
  GridComponent,
  LineChart,
  BarChart,
  CanvasRenderer,
  DataZoomComponent
])

type EChartsOption = ComposeOption<
  | TitleComponentOption
  | TooltipComponentOption
  | LegendComponentOption
  | GridComponentOption
  | LineSeriesOption
  | BarSeriesOption
  | DataZoomComponentOption
>

const props = defineProps({
  data: { type: Object as PropType<InOutWeekStatisticsReportModel>, default: () => ({}) }
})

const chartRef = ref<InstanceType<typeof VChart> | null>(null)

const option = computed<EChartsOption>(() => {
  const data = props.data

  const xAxisData: string[] =
    data?.dateList?.map((item) => {
      return item
    }) || []

  const seriesData: BarSeriesOption[] =
    data?.storeInfoList?.map((store) => {
      return {
        name: store.barName,
        type: 'bar',
        barMaxWidth: 12,
        data: store.numList
      }
    }) || []

  return {
    grid: {
      top: '40px',
      left: '50px',
      right: '12px',
      bottom: '60px' //也可设置left和right设置距离来控制图表的大小
    },
    tooltip: {
      trigger: 'axis',
      axisPointer: {
        type: 'shadow',
        label: {
          show: true
        }
      },
      confine: true
    },
    legend: {
      bottom: '7px',
      itemHeight: 10,
      itemWidth: 20,
      textStyle: {
        fontSize: 12,
        color: 'rgba(255, 255, 255, 0.6)'
      }
    },
    xAxis: {
      data: xAxisData,
      axisLabel: {
        interval: xAxisData.length > 10 ? 2 : 0,
        color: ' rgba(255, 255, 255, 0.6)',
        fontSize: 12,
        fontWeight: 400,
        lineHeight: 12
      }
    },

    yAxis: [
      {
        type: 'value',
        min: 0,
        nameTextStyle: {
          fontSize: 12,
          fontWeight: 400,
          lineHeight: 16.8,
          color: '#fff'
        },
        splitLine: {
          lineStyle: { opacity: 0.1 }
        },
        axisLabel: {
          fontSize: 12,
          fontWeight: 400,
          lineHeight: 16.8,
          color: ' rgba(255, 255, 255, 0.4)'
        }
      }
    ],
    series: seriesData
  }
})

let timer: number

const animation = (index: number = -1) => {
  timer = setTimeout(() => {
    const dataLength = props.data?.dateList?.length || 0
    chartRef.value?.dispatchAction({
      type: 'downplay',
      seriesIndex: 0,
      dataIndex: index
    })
    index = (index + 1) % dataLength
    chartRef.value?.dispatchAction({
      type: 'highlight',
      seriesIndex: 0,
      dataIndex: index
    })
    chartRef.value?.dispatchAction({
      type: 'showTip',
      seriesIndex: 0,
      dataIndex: index
    })
    animation(index)
  }, DATASCREEN_CONFIG.interval)
}

onMounted(() => {
  animation()
})

onUnmounted(() => {
  clearTimeout(timer)
  chartRef.value?.dispose()
  chartRef.value = null
})
</script>

<style scoped lang="scss"></style>
