<template>
  <ScrollTable
    :columns="columns"
    :data="tableData"
    :showNumber="11"
    :rowHeight="40"
    emptyText="暂无数据"
  />
</template>

<script setup lang="ts">
import type { PropType } from 'vue'
import type { InMaterialInfoReportModel } from '../types'
import { computed } from 'vue'
import ScrollTable from '@/components/ScrollTable/index.vue'

const props = defineProps({
  data: { type: Array as PropType<InMaterialInfoReportModel[]>, default: () => [] }
})

const columns = [
  { field: 'materialNo', title: '物料编码' },
  { field: 'materialName', title: '物料名称' },
  { field: 'inNum', title: '入库数量' },
  { field: 'storeName', title: '仓库名称' }
]

const tableData = computed(() => props.data || [])
</script>

<style scoped></style>
