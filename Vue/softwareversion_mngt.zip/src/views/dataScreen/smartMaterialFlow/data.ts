export const inventoryTitleMap: { [key: number]: { name: string; color: string } } = {
  1: { name: '原材料入库数量', color: 'rgba(45, 178, 231, 1)' },
  2: { name: '原材料出库数量', color: 'rgba(24, 199, 184, 1)' },
  3: { name: '产成品入库数量', color: 'rgba(210, 158, 8, 1)' },
  4: { name: '产成品出库数量', color: 'rgba(179, 130, 240, 1)' }
}

export const todayWorkCountColorList = [
  'rgba(33, 116, 255, 1)',
  'rgba(60, 177, 251, 1)',
  'rgba(7, 168, 114, 1)'
]

export const agvMngtInfoMap: { [key: number]: { name: string; color: string } } = {
  1: { name: '待入库任务', color: 'rgba(7, 168, 114, 1)' },
  2: { name: '当日已完成入库任务', color: 'rgba(60, 177, 251, 1)' },
  3: { name: '累计完成入库任务', color: 'rgba(255, 235, 59, 1)' },
  4: { name: '待出库任务', color: 'rgba(255, 112, 207, 1)' },
  5: { name: '当日已完成出库任务', color: 'rgba(179, 130, 240, 1)' },
  6: { name: '累计完成出库任务', color: 'rgba(210, 158, 8, 1)' }
}
