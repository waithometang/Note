export interface SmartMaterialFlowModel {
  inMaterialInfoReportModel: InMaterialInfoReportModel[]
  inOutBarChartReportModel: InOutBarChartReportModel
  inOutStatisticsReportModel: InOutStatisticsReportModel[]
  inOutWeekStatisticsReportModel: InOutWeekStatisticsReportModel
  inventoryFloorRatiosReportModel: InventoryFloorRatiosReportModel[]
  inventoryFloorReportModel: InventoryFloorReportModel[]
}

export interface InMaterialInfoReportModel {
  materialNo: string
  materialName: string
  inNum: number
  storeName: string
}

export interface InOutBarChartReportModel {
  timeData: string[]
  inCountData: number[]
  outCountData: number[]
}

export interface InOutStatisticsReportModel {
  inOutType: number
  count: number
  passedRate: number
  defectRate: number
  sortationRate: number
  storeInfoList: { storeName: string; storeCount: number }[]
}

export interface InOutWeekStatisticsReportModel {
  dateList: string[]
  storeInfoList: { barName: string; numList: number[] }[]
}

export interface InventoryFloorRatiosReportModel {
  storeName: string
  storeCount: number
  storePercent: number
}

export interface InventoryFloorReportModel {
  storeName: string
  storeCount: number
  storePercent: number
}
