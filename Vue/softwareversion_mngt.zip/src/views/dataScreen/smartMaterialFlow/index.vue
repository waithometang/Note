<template>
  <div id="board-container">
    <div class="header">
      <div class="title">智能物流信息看板</div>
      <div class="date">{{ date }}</div>
    </div>
    <div class="wrapper">
      <div class="left">
        <div class="board-box inventory-change-count">
          <div class="title">当日库存量变动统计</div>
          <div class="main-box">
            <Backboard
              class="count-item"
              v-for="item in smartMaterialFlowData?.inOutStatisticsReportModel"
              :key="item.inOutType"
            >
              <div class="caption">{{ inventoryTitleMap[item.inOutType].name }}</div>
              <div class="number">
                <CountTo :endVal="item.count" :color="inventoryTitleMap[item.inOutType].color" />
                <span
                  :style="{
                    color: inventoryTitleMap[item.inOutType].color,
                    fontSize: '16px',
                    fontStyle: 'italic'
                  }"
                >
                  款
                </span>
              </div>
            </Backboard>
          </div>
        </div>
        <div class="board-box inventory-change-count-chart">
          <div class="title">库存量变动统计</div>
          <Backboard class="main-box">
            <InventoryChangeCountChart
              :data="smartMaterialFlowData?.inOutWeekStatisticsReportModel"
            />
          </Backboard>
        </div>
        <div class="board-box floor-stock">
          <div class="title">各楼层库存量</div>
          <Backboard class="main-box">
            <FloorStock :data="smartMaterialFlowData?.inventoryFloorReportModel" />
          </Backboard>
        </div>
        <div class="board-box inbound-dynamic-count">
          <div class="title">出入库动态统计</div>
          <Backboard class="main-box">
            <InboundDynamicCountChart :data="smartMaterialFlowData?.inOutBarChartReportModel" />
          </Backboard>
        </div>
        <div class="board-box agv-mngt-info">
          <div class="title">AGV管理信息</div>
          <div class="main-box">
            <Backboard class="count-item" v-for="(item, index) in agvMngtInfoMap" :key="item.name">
              <div class="caption">{{ agvMngtInfoMap[index].name }}</div>
              <div class="number">
                <CountTo :endVal="0" :color="agvMngtInfoMap[index].color" />
              </div>
            </Backboard>
          </div>
        </div>
      </div>
      <div class="right">
        <div class="board-box floor-stock-ratio">
          <div class="title">各楼层库存量比例</div>
          <div class="main-box">
            <Backboard>
              <FloorStockRatioChart
                :data="smartMaterialFlowData?.inventoryFloorRatiosReportModel"
              />
            </Backboard>
            <Backboard
              class="count-item"
              v-for="(item, index) in smartMaterialFlowData?.inventoryFloorRatiosReportModel"
              :key="item.storeName"
            >
              <div class="caption">{{ item.storeName }}</div>
              <div class="number">
                <!-- <CountTo :endVal="item.storeCount" :color="todayWorkCountColorList[index]" /> -->
                <span :style="{ color: todayWorkCountColorList[index] }">
                  {{ item.storePercent }}
                </span>
                <span :style="{ color: todayWorkCountColorList[index], fontSize: '12px' }"> %</span>
              </div>
            </Backboard>
          </div>
        </div>
        <div class="board-box incoming-material-info">
          <div class="title">入库物料信息</div>
          <div class="main-box" style="left: 0; right: 0; bottom: 0">
            <IncomingMaterialInfo :data="smartMaterialFlowData?.inMaterialInfoReportModel" />
          </div>
        </div>
      </div>
    </div>
  </div>
</template>

<script setup lang="ts">
import { useKeepFit } from '@/hooks/useKeepFit'
import { connection } from '@/utils/signalr'
import dayjs from 'dayjs'
import { ref, onMounted, onBeforeUnmount, watch, nextTick } from 'vue'

import Backboard from '@/components/Backboard/index.vue'
import CountTo from '@/components/CountTo/index.vue'
import FloorStock from './components/FloorStock.vue'
import InboundDynamicCountChart from './components/InboundDynamicCountChart.vue'
import IncomingMaterialInfo from './components/IncomingMaterialInfo.vue'
import InventoryChangeCountChart from './components/InventoryChangeCountChart.vue'
import FloorStockRatioChart from './components/FloorStockRatioChart.vue'
import type { SmartMaterialFlowModel } from './types'
import { inventoryTitleMap, todayWorkCountColorList, agvMngtInfoMap } from './data'
import { useUrlSearchParams } from '@vueuse/core'

const date = ref(dayjs().format('YYYY-MM-DD dddd HH:mm:ss'))

const timer = setInterval(() => {
  date.value = dayjs().format('YYYY-MM-DD dddd HH:mm:ss')
}, 1000)

const smartMaterialFlowData = ref<SmartMaterialFlowModel>()

const query = useUrlSearchParams('hash')

watch(
  () => query.positionAddress,
  (newPositionAddress) => {
    if (newPositionAddress) {
      nextTick(() => {
        connection.invoke(
          'SendDynamicMessageToAllClientsAsync',
          'StoreRedisKey',
          newPositionAddress
        )
      })
    }
  },
  {
    immediate: true
  }
)

connection.on('StoreRedisKey', (data: SmartMaterialFlowModel) => {
  smartMaterialFlowData.value = data
  console.log(data)
})

onMounted(async () => {
  useKeepFit({
    dw: 1920,
    dh: 1080,
    el: '#board-container'
  })
})

onBeforeUnmount(() => {
  connection.off('StoreRedisKey')
  connection.invoke('StopSendDynamicMessageToAllClientsAsync')
  clearInterval(timer)
})
</script>

<style scoped lang="scss">
#board-container {
  height: 100%;
  color: #fff;
  background: linear-gradient(
    179.99deg,
    rgba(12, 19, 71, 1) 0%,
    rgba(11, 28, 157, 1) 6.09%,
    rgba(13, 18, 57, 1) 17.89%,
    rgba(1, 5, 39, 1) 79.64%,
    rgba(12, 23, 109, 1) 100%
  );
  box-sizing: border-box;
  display: flex;
  flex-direction: column;
}

.header {
  // height: 135px;
  flex: 0 0 135px;
  background-repeat: no-repeat;
  background-size: 100% 100%;
  background-image: url('@/assets/png/data-screen-header.png');
  position: relative;
  .title {
    font-size: 40px;
    font-weight: 900;
    letter-spacing: 9px;
    line-height: 57.92px;
    color: rgba(255, 255, 255, 1);
    text-align: center;
    padding-top: 23px;
  }
  .date {
    position: absolute;
    top: 62px;
    right: 163px;
    font-size: 14px;
    font-weight: 700;
    color: rgba(50, 197, 255, 1);
  }
}

.wrapper {
  padding: 20px 38px 24px;
  display: flex;
  gap: 24px;
  flex: 1;
  // overflow: hidden;
  .left {
    width: 1224px;
    display: grid;
    grid-template-columns: 1fr 1fr; /* 定义2列 */
    grid-template-rows: 280px auto;
    gap: 24px;
    .board-box:first-child {
      grid-column: span 2;
    }
  }
  .right {
    flex: 1;
    display: grid;
    grid-template-columns: 1fr;
    grid-template-rows: 358px auto;
    gap: 24px;
  }
}

.board-box {
  position: relative;
  // padding: 52px 24px 24px;
  // overflow: hidden;
  & > .title {
    position: absolute;
    top: 8px;
    left: 50%;
    transform: translateX(-50%);
    font-size: 14px;
    font-weight: 700;
    line-height: 20.27px;
    color: rgba(25, 236, 255, 1);
  }
  .main-box {
    position: absolute;
    left: 24px;
    right: 24px;
    top: 52px;
    bottom: 24px;
  }
  .bg-box {
    position: relative;
    .title {
      position: absolute;
      left: 24px;
      top: 24px;
      font-size: 13px;
      font-weight: 700;
      line-height: 12.57px;
      color: rgba(255, 255, 255, 1);
      text-align: left;
      vertical-align: top;
    }
  }
}

.inventory-change-count {
  background-image: url('@/assets/png/data-screen-box-1224x280.png');
  background-repeat: no-repeat;
  background-size: 100% 100%;
  .main-box {
    display: grid;
    grid-template-columns: 1fr 1fr 1fr 1fr;
    gap: 24px;
    .count-item {
      padding: 40px 35px 0;
      .caption {
        font-size: 16px;
        font-weight: 700;
        color: rgba(255, 255, 255, 1);
      }
      .number {
        padding-top: 40px;
        font-size: 56px;
        font-weight: 700;
        letter-spacing: 0px;
        color: rgba(45, 178, 231, 1);
      }
    }
  }
}
.agv-mngt-info {
  .main-box {
    display: grid;
    grid-template-columns: 1fr 1fr 1fr;
    grid-template-rows: 1fr 1fr;
    gap: 24px;
    .count-item {
      padding: 21px 24px 0;
      .caption {
        font-size: 13px;
        font-weight: 700;
        color: rgba(255, 255, 255, 1);
      }
      .number {
        font-size: 21px;
        padding-top: 15px;
        font-weight: 600;
        color: rgba(7, 168, 114, 1);
      }
    }
  }
}

.inventory-change-count-chart,
.floor-stock,
.inbound-dynamic-count,
.agv-mngt-info {
  background-image: url('@/assets/png/data-screen-box-600x286.png');
  background-repeat: no-repeat;
  background-size: 100% 100%;
}
.floor-stock-ratio {
  background-image: url('@/assets/png/data-screen-box-600x358.png');
  background-repeat: no-repeat;
  background-size: 100% 100%;
  .main-box {
    display: grid;
    grid-template-columns: 1fr 170px;
    grid-template-rows: 1fr 1fr 1fr;
    gap: 24px;
    > div:first-child {
      grid-row: span 3; /* 第一个元素跨三行 */
      overflow: hidden;
    }
    .count-item {
      padding: 21px 24px 0;
      .caption {
        font-size: 13px;
        font-weight: 700;
        color: rgba(255, 255, 255, 1);
      }
      .number {
        font-size: 21px;
        padding-top: 9px;
        font-weight: 600;
        color: rgba(7, 168, 114, 1);
      }
    }
  }
}
.incoming-material-info {
  background-image: url('@/assets/png/data-screen-box-600x524.png');
  background-repeat: no-repeat;
  background-size: 100% 100%;
}
</style>
