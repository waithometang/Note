<template>
  <kanban pamars="A6-3F" />
</template>

<script setup lang="ts">
import kanban from '../default/index.vue'
</script>

<style scoped></style>
