<template>
  <kanban pamars="A6-1F" />
</template>

<script setup lang="ts">
import kanban from '../default/index.vue'
</script>

<style scoped></style>
