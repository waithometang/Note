<template>
  <Executive v-if="(query.positionAddress === 'admin')" />
  <Default v-else />
</template>

<script setup lang="ts">
import Default from '@/views/dataScreen/personnelStructureStatistics/default/index.vue'
import Executive from '@/views/dataScreen/personnelStructureStatistics/executive/index.vue'
import { useUrlSearchParams } from '@vueuse/core'
const query = useUrlSearchParams('hash')
</script>

<style scoped></style>
