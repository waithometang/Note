<template>
  <v-chart autoresize ref="chartRef" :option="option" />
</template>

<script setup lang="ts">
import { onUnmounted, ref, onMounted, computed } from 'vue'
import VChart from 'vue-echarts'
import { use } from 'echarts/core'
import { LineChart } from 'echarts/charts'
import { LegendComponent, TooltipComponent, GridComponent } from 'echarts/components'
import { CanvasRenderer } from 'echarts/renderers'
import type { ComposeOption } from 'echarts/core'
import type { LineSeriesOption, BarSeriesOption } from 'echarts/charts'
import type {
  LegendComponentOption,
  TooltipComponentOption,
  GridComponentOption
} from 'echarts/components'
import type { ReportWorkShopWorkingHoursModel } from '../types'
import type { PropType } from 'vue'
import { DATASCREEN_CONFIG } from '@/constant'

use([LegendComponent, TooltipComponent, GridComponent, LineChart, CanvasRenderer])

type EChartsOption = ComposeOption<
  | LegendComponentOption
  | TooltipComponentOption
  | GridComponentOption
  | LineSeriesOption
  | BarSeriesOption
>

const props = defineProps({
  data: { type: Array as PropType<ReportWorkShopWorkingHoursModel[]>, default: () => [] }
})

const chartRef = ref<InstanceType<typeof VChart> | null>(null)

const option = computed<EChartsOption>(() => {
  const data = props.data

  const series: BarSeriesOption[] =
    data?.map((item) => {
      return {
        name: item.groupName,
        type: 'bar',
        stack: 'groupName',
        barWidth: 30,
        data: item.workShopWeekWorkingHoursModel.map((model) => {
          return {
            value: model.workingHoursCount,
            label: {
              show: model.workingHoursCount !== 0,
              color: '#fff',
              position: 'right',
              distance: 0,
              formatter: '{c}h'
            }
          }
        })
      }
    }) || []

  return {
    legend: {
      type: 'scroll',
      pageButtonGap: 0,
      pageButtonItemGap: 0,
      pageIconColor: '#d6540063',
      pageIconInactiveColor: 'transparent',
      pageIconSize: 15,
      pageTextStyle: { color: '#fff' },
      data: data?.map((item) => item.groupName) || [],
      bottom: 12,
      itemWidth: 20,
      itemHeight: 8,
      // itemStyle: {
      //   color: '#fff'
      // },
      textStyle: {
        fontSize: 12,
        color: 'rgba(255, 255, 255, 0.6)'
      }
    },
    tooltip: {
      trigger: 'axis',
      axisPointer: {
        // 坐标轴指示器，坐标轴触发有效
        type: 'shadow' // 默认为直线，可选为：'line' | 'shadow',
      }
      // confine: true
      // formatter:'{c}h'
    },
    grid: {
      left: '3%',
      top: '10%',
      right: '4%',
      bottom: '40px',
      containLabel: true
    },
    xAxis: {
      type: 'category',
      axisLabel: {
        color: '#a4a8b4'
      },
      data: data?.[0]?.workShopWeekWorkingHoursModel.map((item) => item.weekDate) || []
    },
    yAxis: {
      type: 'value',
      splitLine: {
        lineStyle: { opacity: 0.1 }
      },
      axisLabel: { formatter: '{value}h', color: 'rgba(255, 255, 255, 0.4)', show: false }
    },
    series: series
  }
})

let timer: number

const animation = (index: number = -1) => {
  timer = setTimeout(() => {
    const dataLength = 7 || 0

    chartRef.value?.dispatchAction({
      type: 'downplay',
      seriesIndex: 0,
      dataIndex: index
    })
    index = (index + 1) % dataLength
    chartRef.value?.dispatchAction({
      type: 'highlight',
      seriesIndex: 0,
      dataIndex: index
    })
    chartRef.value?.dispatchAction({
      type: 'showTip',
      seriesIndex: 0,
      dataIndex: index
    })
    animation(index)
  }, DATASCREEN_CONFIG.interval)
}

onMounted(() => {
  // animation()
})

onUnmounted(() => {
  clearTimeout(timer)
  chartRef.value?.dispose()
  chartRef.value = null
})
</script>

<style scoped lang="scss"></style>
