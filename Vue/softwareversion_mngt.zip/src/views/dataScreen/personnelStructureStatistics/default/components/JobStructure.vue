<template>
  <v-chart v-if="data?.length" autoresize ref="chartRef" :option="option" />
</template>

<script setup lang="ts">
import { onUnmounted, ref, computed, onMounted } from 'vue'
import { use } from 'echarts/core'
import VChart from 'vue-echarts'
import { PieChart } from 'echarts/charts'
import { TitleComponent, TooltipComponent, LegendComponent } from 'echarts/components'
import { CanvasRenderer } from 'echarts/renderers'
import type { ComposeOption } from 'echarts/core'
import type { PieSeriesOption } from 'echarts/charts'
import type {
  TitleComponentOption,
  TooltipComponentOption,
  LegendComponentOption
} from 'echarts/components'
import type { ReportWorkShopPeoplePositionStructureModel } from '../types'
import type { PropType } from 'vue'
import { DATASCREEN_CONFIG } from '@/constant'

use([TitleComponent, TooltipComponent, LegendComponent, PieChart, CanvasRenderer])

type EChartsOption = ComposeOption<
  TitleComponentOption | TooltipComponentOption | LegendComponentOption | PieSeriesOption
>

const props = defineProps({
  data: { type: Array as PropType<ReportWorkShopPeoplePositionStructureModel[]>, default: () => [] }
})

const chartRef = ref<InstanceType<typeof VChart> | null>(null)

const option = computed<EChartsOption>(() => {
  const data = props.data
  return {
    tooltip: {
      trigger: 'item',
      confine: true
    },
    legend: {
      type: 'scroll',
      pageButtonGap: 0,
      pageButtonItemGap: 0,
      pageIconColor: '#d6540063',
      pageIconInactiveColor: 'transparent',
      pageIconSize: 15,
      pageTextStyle: {
        color: '#fff'
      },
      orient: 'horizontal',
      bottom: 24,
      textStyle: {
        color: 'rgba(255, 255, 255, 0.6)'
      },
      icon: 'circle',
      itemWidth: 10,
      itemHeight: 10
    },
    series: [
      {
        type: 'pie',
        radius: '57%',
        data:
          data?.map((item) => {
            return { value: item.positionProportionCount, name: item.positionName }
          }) || [],
        label: {
          show: true,
          fontSize: 12,
          color: 'rgba(255, 255, 255, 0.6)',
          overflow: 'none',
          formatter: ({ name, value, percent }) => {
            return `${name} ${value}人\n${percent?.toFixed(0)}%`
          },
          lineHeight: 16,
          position: 'outer',
          alignTo: 'edge',
          margin: 10
        },
        labelLine: { show: true, length: 20, length2: 10 }
      }
    ]
  }
})

let timer: number

const animation = (index: number = -1) => {
  timer = setTimeout(() => {
    const dataLength = props.data?.length || 0
    chartRef.value?.dispatchAction({
      type: 'downplay',
      seriesIndex: 0,
      dataIndex: index
    })
    index = (index + 1) % dataLength
    chartRef.value?.dispatchAction({
      type: 'highlight',
      seriesIndex: 0,
      dataIndex: index
    })
    chartRef.value?.dispatchAction({
      type: 'showTip',
      seriesIndex: 0,
      dataIndex: index
    })
    animation(index)
  }, DATASCREEN_CONFIG.interval)
}

onMounted(() => {
  animation()
})

onUnmounted(() => {
  clearTimeout(timer)
  chartRef.value?.dispose()
  chartRef.value = null
})
</script>

<style scoped lang="scss"></style>
