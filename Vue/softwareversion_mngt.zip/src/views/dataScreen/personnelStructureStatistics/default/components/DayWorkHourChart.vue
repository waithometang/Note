<template>
  <v-chart v-if="data?.length" autoresize ref="chartRef" :option="option" />
</template>

<script setup lang="ts">
import { onUnmounted, ref, computed, type PropType, onMounted } from 'vue'
import { use } from 'echarts/core'
import VChart from 'vue-echarts'
import { PieChart } from 'echarts/charts'
import { TitleComponent, TooltipComponent, LegendComponent } from 'echarts/components'
import { CanvasRenderer } from 'echarts/renderers'
import type { ComposeOption } from 'echarts/core'
import type { PieSeriesOption } from 'echarts/charts'
import type {
  TitleComponentOption,
  TooltipComponentOption,
  LegendComponentOption
} from 'echarts/components'
import type { ReportWorkShopWorkTypeHoursModel } from '../types'
import { DATASCREEN_CONFIG } from '@/constant'

use([TitleComponent, TooltipComponent, LegendComponent, PieChart, CanvasRenderer])

type EChartsOption = ComposeOption<
  TitleComponentOption | TooltipComponentOption | LegendComponentOption | PieSeriesOption
>

const props = defineProps({
  data: { type: Array as PropType<ReportWorkShopWorkTypeHoursModel[]>, default: () => [] },
  colorList: { type: Array as PropType<string[]>, default: () => [] }
})

const chartRef = ref<InstanceType<typeof VChart> | null>(null)

const option = computed<EChartsOption>(() => {
  const data = props.data
  return {
    tooltip: {
      trigger: 'item',
      confine: true
    },
    // color: [],
    legend: {
      show: false,
      orient: 'horizontal',
      bottom: 24,
      textStyle: {
        color: 'rgba(255, 255, 255, 0.6)',
        backgroundColor: 'transparent', //设置width 必须先设置backgroundColor
        width: 60
      },
      icon: 'rect',
      itemWidth: 10,
      itemHeight: 10
    },
    series: [
      {
        type: 'pie',
        radius: '57%',
        data:
          data?.map((item, index) => {
            return {
              name: item.workTypeName,
              value: item.workingHoursCount,
              itemStyle: { color: props.colorList[index] },
              label: {
                show: item.workingHoursCount !== 0
              }
            }
          }) || [],
        label: {
          fontSize: 12,
          color: 'rgba(255, 255, 255, 0.6)',
          overflow: 'none',
          formatter: '{b}\n{d}%',
          lineHeight: 16,
          position: 'outer',
          alignTo: 'edge',
          margin: 10
        },
        labelLine: { show: true, length: 20, length2: 10 }
      }
    ]
  }
})
let timer: number

const animation = (index: number = -1) => {
  timer = setTimeout(() => {
    const dataLength = props.data?.length || 0

    chartRef.value?.dispatchAction({
      type: 'downplay',
      seriesIndex: 0,
      dataIndex: index
    })
    index = (index + 1) % dataLength
    chartRef.value?.dispatchAction({
      type: 'highlight',
      seriesIndex: 0,
      dataIndex: index
    })
    chartRef.value?.dispatchAction({
      type: 'showTip',
      seriesIndex: 0,
      dataIndex: index
    })
    animation(index)
  }, DATASCREEN_CONFIG.interval)
}

onMounted(() => {
  animation()
})

onUnmounted(() => {
  clearTimeout(timer)
  chartRef.value?.dispose()
  chartRef.value = null
})
</script>

<style scoped lang="scss"></style>
