<template>
  <v-chart autoresize ref="chartRef" :option="option" />
</template>

<script setup lang="ts">
import { onUnmounted, ref, computed, type PropType, onMounted } from 'vue'
import VChart from 'vue-echarts'
import { use } from 'echarts/core'
import { BarChart } from 'echarts/charts'
import {
  TitleComponent,
  LegendComponent,
  GridComponent,
  TooltipComponent
} from 'echarts/components'
import { CanvasRenderer } from 'echarts/renderers'
import type { ComposeOption } from 'echarts/core'
import type { BarSeriesOption } from 'echarts/charts'
import type {
  LegendComponentOption,
  GridComponentOption,
  TooltipComponentOption
} from 'echarts/components'
import type { ReportWorkShopGroupWorkTypeHoursModel } from '../types'
import { DATASCREEN_CONFIG } from '@/constant'

use([TitleComponent, LegendComponent, GridComponent, BarChart, CanvasRenderer, TooltipComponent])

type EChartsOption = ComposeOption<
  LegendComponentOption | GridComponentOption | BarSeriesOption | TooltipComponentOption
>

const props = defineProps({
  data: { type: Array as PropType<ReportWorkShopGroupWorkTypeHoursModel[]>, default: () => [] }
})

const chartRef = ref<InstanceType<typeof VChart> | null>(null)

const option = computed<EChartsOption>(() => {
  const data = props.data
  const yAxisData =
    data?.[0]?.workShopGroupWorkTypeHoursCountModel?.map((item) => item.workTypeName) || []
  const legendData = data?.map((item) => item.groupName) || []
  const series: BarSeriesOption[] =
    data?.map((item) => {
      return {
        name: item.groupName,
        type: 'bar',
        stack: 'workHour',
        barWidth: 25,
        data:
          item.workShopGroupWorkTypeHoursCountModel?.map((model) => {
            return {
              name: model.workTypeName,
              value: model.workingHoursCount,
              label: {
                show: model.workingHoursCount !== 0,
                color: '#fff',
                position: 'top',
                distance: 0,
                formatter: '{c}h'
              }
            }
          }) || []
      }
    }) || []

  return {
    legend: {
      type: 'scroll',
      pageButtonGap: 0,
      pageButtonItemGap: 0,
      pageIconColor: '#d6540063',
      pageIconInactiveColor: 'transparent',
      pageIconSize: 15,
      pageTextStyle: { color: '#fff' },
      data: legendData,
      bottom: 12,
      itemWidth: 8,
      itemHeight: 8,
      icon: 'rect',
      textStyle: {
        fontSize: 12,
        color: 'rgba(255, 255, 255, 0.6)'
      }
    },
    tooltip: {
      trigger: 'axis',
      axisPointer: {
        // 坐标轴指示器，坐标轴触发有效
        type: 'shadow' // 默认为直线，可选为：'line' | 'shadow'
      }
      // confine: true
    },
    grid: {
      left: '3%',
      top: '10%',
      right: '4%',
      bottom: '40px',
      containLabel: true
    },
    xAxis: {
      type: 'value',
      splitLine: {
        lineStyle: { opacity: 0.1 }
      },
      // max: 250,
      axisLabel: {
        color: '#a4a8b4',
        formatter(value) {
          return value + 'h'
        }
      }
    },
    yAxis: {
      type: 'category',
      data: yAxisData,
      axisLine: {
        lineStyle: {
          color: 'rgba(255,255,255,0.3)'
        }
      },
      axisLabel: {
        // margin: 10,
        color: 'rgba(255, 255, 255, 0.4)'
      }
    },
    // color: ['#bbb', '#000', '#bc7'],
    series: series
  }
})

let timer: number

const animation = (index: number = -1) => {
  timer = setTimeout(() => {
    const dataLength =
      props.data?.[0]?.workShopGroupWorkTypeHoursCountModel?.map((item) => item.workTypeName)
        .length || 0

    chartRef.value?.dispatchAction({
      type: 'downplay',
      seriesIndex: 0,
      dataIndex: index
    })
    index = (index + 1) % dataLength
    chartRef.value?.dispatchAction({
      type: 'highlight',
      seriesIndex: 0,
      dataIndex: index
    })
    chartRef.value?.dispatchAction({
      type: 'showTip',
      seriesIndex: 0,
      dataIndex: index
    })
    animation(index)
  }, DATASCREEN_CONFIG.interval)
}

onMounted(() => {
  // animation()
})

onUnmounted(() => {
  clearTimeout(timer)
  chartRef.value?.dispose()
  chartRef.value = null
})
</script>

<style scoped lang="scss"></style>
