<template>
  <v-chart ref="chartRef" autoresize :option="option" />
</template>

<script setup lang="ts">
import { ref, computed, onUnmounted } from 'vue'
import { use } from 'echarts/core'
import VChart from 'vue-echarts'
import { LineChart, BarChart } from 'echarts/charts'
import {
  TitleComponent,
  TooltipComponent,
  LegendComponent,
  GridComponent,
  DataZoomComponent
} from 'echarts/components'
import { CanvasRenderer } from 'echarts/renderers'
import type { ComposeOption } from 'echarts/core'
import type { LineSeriesOption, BarSeriesOption } from 'echarts/charts'
import type {
  TitleComponentOption,
  TooltipComponentOption,
  LegendComponentOption,
  GridComponentOption,
  DataZoomComponentOption
} from 'echarts/components'
import type { ReportWorkShopAttendanceSituationModel } from '../types'
import type { PropType } from 'vue'
import { max } from 'lodash-es'
import { onMounted } from 'vue'
import { DATASCREEN_CONFIG } from '@/constant'

use([
  TitleComponent,
  TooltipComponent,
  LegendComponent,
  GridComponent,
  LineChart,
  BarChart,
  CanvasRenderer,
  DataZoomComponent
])

type EChartsOption = ComposeOption<
  | TitleComponentOption
  | TooltipComponentOption
  | LegendComponentOption
  | GridComponentOption
  | LineSeriesOption
  | BarSeriesOption
  | DataZoomComponentOption
>

const props = defineProps({
  data: { type: Array as PropType<ReportWorkShopAttendanceSituationModel[]>, default: () => [] }
})

const chartRef = ref<InstanceType<typeof VChart> | null>(null)

const option = computed<EChartsOption>(() => {
  const data = props.data
  const xAxisData =
    data?.map((item) => {
      return item.groupName
    }) || []

  const seriesShouldData =
    data?.map((item) => {
      return item.shouldArriveNumber
    }) || []

  const seriesRealData =
    data?.map((item) => {
      return item.realisticNumber
    }) || []

  const yMax = max([max(seriesShouldData), max(seriesRealData)])

  return {
    grid: {
      top: '50px',
      left: '50px',
      right: '50px',
      bottom: '61px' //也可设置left和right设置距离来控制图表的大小
    },
    tooltip: {
      trigger: 'axis',
      axisPointer: {
        type: 'shadow',
        label: {
          show: true
        }
      },
      confine: true
    },
    // dataZoom: {
    //   type: 'slider', // 内置型数据缩放组件
    //   show: true,
    //   // xAxisIndex: 0, // 指定要缩放的x轴
    //   startValue: xAxisData[dataZoomIndex.startIndex], // 开始缩放位置
    //   endValue: xAxisData[dataZoomIndex.endIndex] // 结束缩放位置
    // },
    legend: {
      // data: ['实到', '应到'],
      bottom: '13px',
      itemHeight: 10,
      itemWidth: 20,
      textStyle: {
        fontSize: 12,
        color: 'rgba(255, 255, 255, 0.6)'
      }
    },
    xAxis: {
      data: xAxisData,
      axisLabel: {
        interval: xAxisData.length > 10 ? 2 : 0,
        color: ' rgba(255, 255, 255, 0.6)',
        fontSize: 12,
        fontWeight: 400,
        lineHeight: 12
      }
    },
    yAxis: [
      {
        type: 'value',
        max: yMax,
        min: 0,
        nameTextStyle: {
          fontSize: 12,
          fontWeight: 400,
          lineHeight: 16.8,
          color: '#fff'
        },
        splitLine: {
          lineStyle: { opacity: 0.1 }
        },
        axisLabel: {
          fontSize: 12,
          fontWeight: 400,
          lineHeight: 16.8,
          color: ' rgba(255, 255, 255, 0.4)'
        }
      },
      {
        type: 'value',
        max: yMax,
        min: 0,
        nameTextStyle: {
          fontSize: 12,
          fontWeight: 400,
          lineHeight: 16.8,
          color: '#fff'
        },
        splitLine: {
          lineStyle: { opacity: 0.1 }
        },
        axisLabel: {
          fontSize: 12,
          fontWeight: 400,
          lineHeight: 16.8,
          show: false,
          // formatter: '{value} %', //右侧Y轴文字显示
          color: ' rgba(255, 255, 255, 0.4)'
        }
      }
    ],
    series: [
      {
        name: '应到',
        type: 'bar',
        // barMinWidth: 16,
        barMaxWidth: 30,
        yAxisIndex: 1, //使用的 y 轴的 index，在单个图表实例中存在多个 y轴的时候有用
        itemStyle: {
          color: '#3CB1FB'
        },
        data: seriesShouldData,
        label: { show: true, color: '#fff', position: 'top' }
      },
      {
        name: '实到',
        type: 'bar',
        // barMinWidth: 16,
        barMaxWidth: 30,
        yAxisIndex: 0,
        itemStyle: {
          color: '#005DFC'
        },
        data: seriesRealData,
        label: { show: true, color: '#fff', position: 'top' }
      }
    ]
  }
})

let timer: number

const animation = (index: number = -1) => {
  timer = setTimeout(() => {
    const dataLength = props.data?.length || 0
    chartRef.value?.dispatchAction({
      type: 'downplay',
      seriesIndex: 0,
      dataIndex: index
    })
    index = (index + 1) % dataLength
    chartRef.value?.dispatchAction({
      type: 'highlight',
      seriesIndex: 0,
      dataIndex: index
    })
    chartRef.value?.dispatchAction({
      type: 'showTip',
      seriesIndex: 0,
      dataIndex: index
    })
    animation(index)
  }, DATASCREEN_CONFIG.interval)
}

onMounted(() => {
  animation()
})

onUnmounted(() => {
  clearTimeout(timer)
  chartRef.value?.dispose()
  chartRef.value = null
})
</script>

<style scoped lang="scss"></style>
