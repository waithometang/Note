<template>
  <div id="board-container">
    <div class="header">
      <div class="title">生产人员结构统计</div>
      <div class="date">{{ date }}</div>
    </div>
    <div class="wrapper">
      <div class="wrapper-box">
        <div class="board-box personnel-structure-overview">
          <div class="title">人员结构概括</div>
          <div class="main-box">
            <el-carousel
              class="left"
              autoplay
              indicator-position="none"
              height="100%"
              :interval="DATASCREEN_CONFIG.interval"
            >
              <el-carousel-item class="content" v-for="(arr, i) in departmentNumberData" :key="i">
                <div class="bg-box bg-186" v-for="item in arr" :key="item.departmentName">
                  <div class="title">{{ item.departmentName }}</div>
                  <div class="count-to">{{ item.peopleNumberCount }}</div>
                </div>
              </el-carousel-item>
            </el-carousel>
            <div class="right">
              <div class="bg-box bg-314">
                <div class="title">用工比例</div>
                <WorkRatio
                  :data="personnelStructureData?.reportWorkShopFlexibleEmploymentProportionModel"
                />
              </div>
              <div class="bg-box bg-314">
                <div class="title">人员工种结构</div>
                <JobStructure
                  :data="personnelStructureData?.reportWorkShopPeoplePositionStructureModel"
                />
              </div>
            </div>
          </div>
        </div>
        <div class="board-box day-group-attendance">
          <div class="title">当日班组考勤统计</div>
          <div class="main-box bg-862">
            <DayGroupAttendanceChart
              :data="personnelStructureData?.reportWorkShopAttendanceSituationModel"
            />
          </div>
        </div>
      </div>
      <div class="wrapper-box">
        <div class="board-box group-work-hour">
          <div class="title">近7日班组工时趋势</div>
          <div class="main-box bg-580">
            <GroupWorkHourChart :data="personnelStructureData?.reportWorkShopWorkingHoursModel" />
          </div>
        </div>
        <div class="board-box group-work-category">
          <div class="title">昨日班组工时类别统计</div>
          <div class="main-box bg-492">
            <DayGroupWorkHourTypeChart
              :data="personnelStructureData?.reportWorkShopGroupWorkTypeHoursModel"
            />
          </div>
        </div>
        <div class="board-box day-work-hour">
          <div class="title">昨日工时统计</div>
          <div class="main-box">
            <div class="left bg-242">
              <DayWorkHourChart
                :data="personnelStructureData?.reportWorkShopWorkTypeHoursModel"
                :colorList="colorList"
              />
            </div>
            <div class="right">
              <div class="row" v-for="(arr, i) in dayWorkHourData" :key="i">
                <div class="bg-box bg-108" v-for="(item, j) in arr" :key="item.workTypeName">
                  <div class="title">
                    <div class="legend" :style="'background-color:' + colorList[i + i + j]"></div>
                    <div>{{ item.workTypeName }}</div>
                  </div>
                  <div class="count-to" :style="'color:' + colorList[i + i + j]">
                    {{ item.workingHoursCount }}
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>
</template>

<script setup lang="ts">
import dayjs from 'dayjs'
import { onMounted, onBeforeUnmount, ref, watch, nextTick } from 'vue'
import { connection } from '@/utils/signalr'
import { useKeepFit } from '@/hooks/useKeepFit'
import WorkRatio from './components/WorkRatio.vue'
import JobStructure from './components/JobStructure.vue'
import DayGroupAttendanceChart from './components/DayGroupAttendanceChart.vue'
import DayGroupWorkHourTypeChart from './components/DayGroupWorkHourTypeChart.vue'
import DayWorkHourChart from './components/DayWorkHourChart.vue'
import GroupWorkHourChart from './components/GroupWorkHourChart.vue'

import type {
  PersonnelStructureStatisticsModel,
  ReportWorkShopDepartmentNumberModel,
  ReportWorkShopWorkTypeHoursModel
} from './types'
import { clone } from 'xe-utils'
import { DATASCREEN_CONFIG } from '@/constant'
import { useUrlSearchParams } from '@vueuse/core'

const query = useUrlSearchParams('hash')

const personnelStructureData = ref<PersonnelStructureStatisticsModel>()

const dayWorkHourData = ref<ReportWorkShopWorkTypeHoursModel[][]>([])

const departmentNumberData = ref<ReportWorkShopDepartmentNumberModel[][]>()

const date = ref(dayjs().format('YYYY-MM-DD dddd HH:mm:ss'))

const timer = setInterval(() => {
  date.value = dayjs().format('YYYY-MM-DD dddd HH:mm:ss')
}, 1000)

const setData = async (data: any) => {
  personnelStructureData.value = data.personnelStructureStatisticsModel
  // 昨日工时统计数据处理
  let groupData = []
  const arr = clone(data.personnelStructureStatisticsModel.reportWorkShopWorkTypeHoursModel)
  for (let i = 0; i < arr.length; i += 2) {
    const group = arr.slice(i, i + 2)
    groupData.push(group)
  }
  dayWorkHourData.value = groupData

  // 人员结构概况部门数据处理
  let departmentData = []
  const reportWorkShopDepartmentNumberModel = clone(
    data.personnelStructureStatisticsModel.reportWorkShopDepartmentNumberModel
  )
  for (let i = 0; i < reportWorkShopDepartmentNumberModel.length; i += 2) {
    const group = reportWorkShopDepartmentNumberModel.slice(i, i + 2)
    departmentData.push(group)
  }
  departmentNumberData.value = departmentData
}

const colorList = ['#2DB2E7', 'rgb(91,104,193)', '#07A872', '#D29E08', '#ED8139', '#FB6E77']

onMounted(async () => {
  useKeepFit({
    dw: 1920,
    dh: 1080,
    el: '#board-container'
  })

  // watch(
  //   () => useAppStore().signalrConnectionStatus,
  //   (status) => {
  //     if (status) {
  //       connection.invoke(
  //         'SendDynamicMessageToAllClientsAsync',
  //         'PersonnelRedisKey',
  //         query.positionAddress
  //       ) // 发送数据到服务端
  //     }
  //   },
  //   { immediate: true }
  // )

  watch(
    () => query.positionAddress,
    (newPositionAddress) => {
      if (newPositionAddress) {
        nextTick(() => {
          connection.invoke(
            'SendDynamicMessageToAllClientsAsync',
            'PersonnelRedisKey',
            newPositionAddress
          )
        })
      }
    },
    {
      immediate: true
    }
  )

  // 接收服务端发送的数据
  connection.on('GetPersonnelInfo', (data: any) => {
    // console.log('on PersonnelStructureStatistics', JSON.parse(data))
    setData(JSON.parse(data))
  })
})

onBeforeUnmount(() => {
  connection.off('GetPersonnelInfo')
  connection.invoke('StopSendDynamicMessageToAllClientsAsync') // 发送数据到服务端
  clearInterval(timer)
})
</script>

<style scoped lang="scss">
#board-container {
  height: 100%;
  color: #fff;
  background: linear-gradient(
    179.99deg,
    rgba(12, 19, 71, 1) 0%,
    rgba(11, 28, 157, 1) 6.09%,
    rgba(13, 18, 57, 1) 17.89%,
    rgba(1, 5, 39, 1) 79.64%,
    rgba(12, 23, 109, 1) 100%
  );
  box-sizing: border-box;
  display: flex;
  flex-direction: column;
}
.header {
  // height: 135px;
  flex: 0 0 135px;
  background-repeat: no-repeat;
  background-size: 100% 100%;
  background-image: url('@/assets/png/data-screen-header.png');
  position: relative;
  .title {
    font-size: 40px;
    font-weight: 900;
    letter-spacing: 9px;
    line-height: 57.92px;
    color: rgba(255, 255, 255, 1);
    text-align: center;
    padding-top: 23px;
  }
  .date {
    position: absolute;
    top: 62px;
    right: 163px;
    font-size: 14px;
    font-weight: 700;
    color: rgba(50, 197, 255, 1);
  }
}
.wrapper {
  padding: 18px 38px 52px;
  display: flex;
  gap: 24px;
  flex-direction: column;
  flex: 1;
  // overflow: hidden;
  .wrapper-box {
    flex: 1;
    display: flex;
    gap: 24px;
    // overflow: hidden;
  }
}
.board-box {
  position: relative;
  // padding: 52px 24px 24px;
  // overflow: hidden;
  & > .title {
    position: absolute;
    top: 8px;
    left: 50%;
    transform: translateX(-50%);
    font-size: 14px;
    font-weight: 700;
    line-height: 20.27px;
    color: rgba(25, 236, 255, 1);
  }
  .main-box {
    position: absolute;
    left: 24px;
    right: 24px;
    top: 52px;
    bottom: 24px;
  }
  .bg-box {
    position: relative;
    .title {
      position: absolute;
      left: 24px;
      top: 24px;
      font-size: 13px;
      font-weight: 700;
      line-height: 12.57px;
      color: rgba(255, 255, 255, 1);
      text-align: left;
      vertical-align: top;
    }
  }
}

.personnel-structure-overview {
  background-image: url('@/assets/png/data-screen-box-910.png');
  background-repeat: no-repeat;
  background-size: 100% 100%;
  flex: 1;
  .main-box {
    display: flex;
    gap: 24px;
    .left {
      flex: 0 0 186px;

      .content {
        display: flex;
        flex-direction: column;
        gap: 24px;
      }
      .bg-box {
        padding: 24px;
      }
      .count-to {
        padding-top: 60px;
        font-size: 48px;
        font-weight: 400;
        letter-spacing: 0px;
        color: rgba(0, 176, 237, 1);
      }
    }
    .right {
      flex: 1;
      display: flex;
      gap: 24px;
      & > div {
        width: 0;
        flex: 1;
      }
    }
  }
}

.day-group-attendance {
  background-image: url('@/assets/png/data-screen-box-910.png');
  background-repeat: no-repeat;
  background-size: 100% 100%;
  flex: 1;
}

.group-work-category {
  background-image: url('@/assets/png/data-screen-box-540.png');
  background-repeat: no-repeat;
  background-size: 100% 100%;
  flex: 0 0 29.28%;
}

.group-work-hour,
.day-work-hour {
  background-image: url('@/assets/png/data-screen-box-628.png');
  background-repeat: no-repeat;
  background-size: 100% 100%;
  flex: 1;
}

.day-work-hour {
  .main-box {
    display: flex;
    gap: 24px;
    .left {
      flex: 0 0 316px;
    }
    .right {
      flex: 1;
      display: flex;
      flex-direction: column;
      gap: 24px;
      & > .row {
        flex: 1;
        display: flex;
        gap: 24px;
        & > div {
          flex: 1;
          .title {
            left: 20px;
            top: 22px;
            display: flex;
            align-items: center;
            .legend {
              width: 12px;
              height: 12px;
              margin-right: 4px;
            }
          }
          .count-to {
            padding-left: 20px;
            padding-top: 57px;
            font-size: 21px;
            font-weight: 400;
            letter-spacing: 0px;
            line-height: 20.95px;
          }
        }
      }
    }
  }
}

.bg-314 {
  background-image: url('@/assets/png/data-screen-inner-box-314.png');
  background-repeat: no-repeat;
  background-size: 100% 100%;
}
.bg-186 {
  background-image: url('@/assets/png/data-screen-inner-box-186.png');
  background-repeat: no-repeat;
  background-size: 100% 100%;
}
.bg-862 {
  background-image: url('@/assets/png/data-screen-inner-box-862.png');
  background-repeat: no-repeat;
  background-size: 100% 100%;
}

.bg-492 {
  background-image: url('@/assets/png/data-screen-inner-box-492.png');
  background-repeat: no-repeat;
  background-size: 100% 100%;
}
.bg-580 {
  background-image: url('@/assets/png/data-screen-inner-box-580.png');
  background-repeat: no-repeat;
  background-size: 100% 100%;
}
.bg-242 {
  background-image: url('@/assets/png/data-screen-inner-box-242.png');
  background-repeat: no-repeat;
  background-size: 100% 100%;
}
.bg-108 {
  background-image: url('@/assets/png/data-screen-inner-box-108.png');
  background-repeat: no-repeat;
  background-size: 100% 100%;
}
</style>
