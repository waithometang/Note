export interface PersonnelStructureStatisticsModel {
  reportWorkShopAttendanceSituationModel: ReportWorkShopAttendanceSituationModel[]
  reportWorkShopDepartmentNumberModel: ReportWorkShopDepartmentNumberModel[]
  reportWorkShopFlexibleEmploymentProportionModel: ReportWorkShopFlexibleEmploymentProportionModel[]
  reportWorkShopPeoplePositionStructureModel: ReportWorkShopPeoplePositionStructureModel[]
  reportWorkShopWorkingHoursModel: ReportWorkShopWorkingHoursModel[]
  reportWorkShopGroupWorkTypeHoursModel: ReportWorkShopGroupWorkTypeHoursModel[]
  reportWorkShopWorkTypeHoursModel: ReportWorkShopWorkTypeHoursModel[]
}

export interface ReportWorkShopAttendanceSituationModel {
  groupName: string
  realisticNumber: number
  shouldArriveNumber: number
}

export interface ReportWorkShopDepartmentNumberModel {
  departmentName?: string
  peopleNumberCount?: number
}

export interface ReportWorkShopFlexibleEmploymentProportionModel {
  positionName: string
  positionProportion: string
  positionProportionCount: number
}

export interface ReportWorkShopPeoplePositionStructureModel {
  positionName: string
  positionProportion: string
  positionProportionCount: number
}

export interface ReportWorkShopWorkingHoursModel {
  groupName: string
  workShopWeekWorkingHoursModel: WorkShopWeekWorkingHoursModel[]
}

export interface WorkShopWeekWorkingHoursModel {
  weekDate: string
  workingHoursCount: number
}

export interface ReportWorkShopGroupWorkTypeHoursModel {
  groupName: string
  workShopGroupWorkTypeHoursCountModel: WorkShopGroupWorkTypeHoursCountModel[]
}

export interface WorkShopGroupWorkTypeHoursCountModel {
  workingHoursCount: number
  workTypeName: string
}

export interface ReportWorkShopWorkTypeHoursModel {
  workingHoursCount: number
  workTypeName: string
}
