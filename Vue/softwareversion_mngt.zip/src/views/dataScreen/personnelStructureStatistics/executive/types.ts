export interface PersonnelStructureStatisticsModel {
  reportAdminAttendanceSituationModel: ReportAdminAttendanceSituationModel[]
  reportAdminDepartmentNumberModel: ReportAdminDepartmentNumberModel[]
  reportAdminFlexibleEmploymentProportionModel: ReportAdminFlexibleEmploymentProportionModel[]
  reportAdminPeoplePositionStructureModel: ReportAdminPeoplePositionStructureModel[]
  reportAdminWorkingHoursModel: ReportAdminWorkingHoursModel[]
  reportAdminDepartmentWorkTypeHoursModel: ReportAdminDepartmentWorkTypeHoursModel[]
  reportAdminWorkTypeHoursModel: ReportAdminWorkTypeHoursModel[]
}

export interface ReportAdminAttendanceSituationModel {
  departmentName: string
  realisticNumber: number
  shouldArriveNumber: number
}

export interface ReportAdminDepartmentNumberModel {
  departmentName: string
  peopleNumberCount: number
}

export interface ReportAdminFlexibleEmploymentProportionModel {
  positionName: string
  positionProportion: string
  positionProportionCount: number
}

export interface ReportAdminPeoplePositionStructureModel {
  positionName: string
  positionProportion: string
  positionProportionCount: number
}

export interface ReportAdminWorkingHoursModel {
  departmentName: string
  adminWeekWorkingHoursModel: AdminWeekWorkingHoursModel[]
}

export interface AdminWeekWorkingHoursModel {
  weekDate: string
  workingHoursCount: number
}

export interface ReportAdminDepartmentWorkTypeHoursModel {
  departmentName: string
  adminDepartmentWorkTypeHoursCountModel: AdminDepartmentWorkTypeHoursCountModel[]
}

export interface AdminDepartmentWorkTypeHoursCountModel {
  workingHoursCount: number
  workTypeName: string
}

export interface ReportAdminWorkTypeHoursModel {
  workingHoursCount: number
  workTypeName: string
}
