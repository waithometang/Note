<template>
  <div class="page-container" v-if="!query.positionAddress">
    <div class="search">
      <el-input v-model="searchText" placeholder="输入关键字查找">
        <template #prefix>
          <svg-icon icon="search" style="font-size: 24px; color: #008cd6"></svg-icon>
        </template>
      </el-input>
    </div>
    <el-scrollbar>
      <TransitionGroup class="kanban-list-container" name="list" tag="div">
        <div
          class="kanban-list-item"
          v-for="item in getKanBanList"
          :key="item.id"
          @click="handleKanbanClick(item)"
        >
          <div class="kanban-avatar">
            <svg-icon style="font-size: 68px" icon="kanban-screen" />
          </div>
          <div class="kanban-info">
            <div class="kanban-info-title">{{ item.menuTitle }}</div>
            <div class="online-count">在线人数 {{ item.onlineUserCount }}</div>
          </div>
        </div>
      </TransitionGroup>
    </el-scrollbar>
  </div>
  <div v-else class="kanban-container">
    <div style="height: 100%">
      <Suspense>
        <component :is="activeComponent" />

        <template #fallback> <p>Loading...</p> </template>
      </Suspense>
    </div>
  </div>
</template>

<script setup lang="ts">
import type { Component } from 'vue'
import type {
  GetKanBanInfoModel,
  KanBanInfoByNameListGetResultModel
} from '@/api/sys/model/dataScreenModel'

import { ref, shallowRef, unref, onUnmounted, watch, defineAsyncComponent } from 'vue'
import { unionBy } from 'lodash-es'
import { useUrlSearchParams } from '@vueuse/core'

import { getKanBanInfo, getKanBanInfoByName } from '@/api/sys/dataScreen'
import { computed } from 'vue'
defineOptions({
  name: 'Kanban',
  inheritAttrs: false
})

const query = useUrlSearchParams('hash')

const componentMap: Record<number, any> = {
  1: defineAsyncComponent(
    () => import('@/views/dataScreen/personnelStructureStatistics/index.vue')
  ),
  2: defineAsyncComponent(() => import('@/views/dataScreen/projectProductionProgress/index.vue')),
  3: defineAsyncComponent(
    () => import('@/views/dataScreen/employeePerformanceStatistics/index.vue')
  ),
  4: defineAsyncComponent(() => import('@/views/dataScreen/smartMaterialFlow/index.vue')),
  5: defineAsyncComponent(() => import('@/views/dataScreen/pictureBoard/index.vue'))
}
const searchText = ref('')
const kanbanList = ref<GetKanBanInfoModel[]>() // 看板列表
const kanbanConfigData = ref<KanBanInfoByNameListGetResultModel>([]) // 看板配置项
const activeComponent = shallowRef<Component>() // 当前活跃组件
const cancelFlag = ref(false) // 停止播放标志

const getKanBanList = computed(() => {
  return unref(kanbanList)?.filter((item) =>
    item.menuTitle.toLowerCase().includes(unref(searchText).toLowerCase())
  )
})

// 获取已启用的看板
const getKanBanListData = async () => {
  const { data, code, message } = await getKanBanInfo({ pageIndex: 0, pageSize: 9999 })
  if (code === 200) {
    kanbanList.value = unionBy(data.result, 'menuName')
  } else {
    ElMessage.error(message)
  }
}
getKanBanListData() // 获取已启用的看板

// 初始化看板配置
const getKanbanConfig = (kanban: KanBanInfoByNameListGetResultModel) => {
  return (
    kanban?.sort((a, b) => a.playOrder - b.playOrder).filter((item) => item.orderStatus === 1) || []
  )
}

const handleKanbanClick = (kanBanInfo: GetKanBanInfoModel) => {
  query.positionAddress = kanBanInfo.menuName
  // query.playTime = String(kanBanInfo.playTime)
}

const getKanbanItemInfo = async (menuName: string) => {
  const { data, code, message } = await getKanBanInfoByName({ name: menuName })
  if (code === 200) {
    kanbanConfigData.value = getKanbanConfig(data)
  } else {
    ElMessage.error(message)
  }
}

// const handleBack = () => {
//   delete query.positionAddress
//   delete query.playTime
// }

// 播放流程控制
const playKanban = (kanban: GetKanBanInfoModel): Promise<void> => {
  return new Promise((resolve) => {
    activeComponent.value = componentMap[kanban.kanBanType]
    // console.log(`正在播放看板：${unref(activeComponent)}`)
    // 模拟播放时长
    setTimeout(() => {
      // console.log(`看板：${unref(activeComponent)} 播放完毕`)
      resolve()
    }, kanban.playTime * 1000)
  })
}
// 开始播放
const startPlay = async () => {
  cancelFlag.value = false
  while (!unref(cancelFlag)) {
    for (let kanban of unref(kanbanConfigData)) {
      if (unref(cancelFlag)) {
        // console.log('任务取消')
        return
      }
      // console.log('启动任务', kanban)

      await playKanban(kanban)
    }
  }
}
// 停止播放
const stopPlay = () => {
  // console.log('停止播放')
  cancelFlag.value = true
}

watch(
  () => query.positionAddress,
  async (newPositionAddress) => {
    stopPlay()
    if (newPositionAddress && typeof newPositionAddress === 'string') {
      // console.log('厂区位置改变,获取配置并启动播放')
      await getKanbanItemInfo(newPositionAddress)
      startPlay()
    }
  },
  {
    immediate: true
  }
)

onUnmounted(() => {
  stopPlay()
})
</script>

<style scoped lang="scss">
.page-container {
  padding: 0;
  display: flex;
  flex-direction: column;
  .box {
    height: 100%;
  }
  .search {
    margin-top: 24px;
    margin-left: 24px;
    .el-input {
      width: 498px;
      height: 52px;

      :deep(.el-input__wrapper) {
        padding: 1px 24px;
        border-radius: 26px;
        background: rgba(255, 255, 255, 1);

        border: 1px solid rgba(229, 229, 229, 1);

        box-shadow: 0px 0px 10px rgba(0, 0, 0, 0.05);
      }
    }
  }
  .kanban-list-container {
    flex: 1;
    padding: $margin;
    display: Grid;
    gap: $margin;
    flex-wrap: wrap;
    grid-template-columns: repeat(6, 1fr);

    .kanban-list-item {
      overflow: hidden;
      cursor: pointer;

      border-radius: 20px;
      background: rgba(255, 255, 255, 1);
      box-shadow: 0px 0px 10px rgba(0, 0, 0, 0.05);

      display: flex;
      .kanban-avatar {
        display: flex;
        align-items: center;
        padding: $margin 0 $margin $margin;
      }
      .kanban-info {
        flex: 1;
        padding: $margin;
        display: flex;
        flex-direction: column;
        gap: 20px;
        .kanban-info-title {
          font-size: 20px;
          font-weight: 700;
          color: rgba(0, 0, 0, 1);
        }
        .online-count {
          color: rgba(140, 140, 140, 1);
        }
      }
    }
  }
}
.kanban-container {
  height: 100%;
  width: 100%;
  overflow: hidden;
  .back-btn {
    position: absolute;
    right: 30px;
    bottom: 30px;
    background-color: rgba(0, 0, 0, 0.5);
    color: #fff;
    cursor: pointer;
    border-radius: 50%;
    width: 50px;
    height: 50px;
    text-align: center;
    line-height: 50px;
  }
}

.list-move, /* 对移动中的元素应用的过渡 */
.list-enter-active,
.list-leave-active {
  transition: all 0.5s ease;
}

.list-enter-from,
.list-leave-to {
  opacity: 0;
  transform: translateX(30px);
}

/* 确保将离开的元素从布局流中删除
  以便能够正确地计算移动的动画。 */
.list-leave-active {
  position: absolute;
}
</style>
