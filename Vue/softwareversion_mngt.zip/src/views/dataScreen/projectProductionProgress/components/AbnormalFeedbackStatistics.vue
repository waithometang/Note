<template>
  <ScrollTable
    :columns="columns"
    :data="tableData"
    :bg-width="864"
    :showNumber="5"
    emptyText="暂无异常"
  />
</template>

<script lang="ts" setup>
import type { AbnormalFeedbackData } from './types'

import { onMounted, ref } from 'vue'
import { connection } from '@/utils/signalr'
const tableData = ref<AbnormalFeedbackData[]>()

const columns = [
  { field: 'execptionTime', title: '日期' },
  { field: 'projectName', title: '项目' },
  { field: 'productName', title: '设备' },
  { field: 'departmentName', title: '部门' },
  { field: 'groupName', title: '班组' },
  { field: 'exceptionDescription', title: '异常情况' },
  { field: 'dutyEmployeeName', title: '责任人' }
]

onMounted(() => {
  connection.on('GetProductionException', (data) => {
    // tableData.value = JSON.parse(data)
    tableData.value = data
  })
})
</script>

<style lang="scss" scoped></style>
