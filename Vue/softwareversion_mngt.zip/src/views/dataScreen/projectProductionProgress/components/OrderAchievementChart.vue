<template>
  <v-chart
    ref="chartRef"
    :option="planAchievementOption"
    :loadingOptions="loadingOptions"
    autoresize
  />
</template>

<script lang="ts" setup>
import type { LineChartData } from './types'
import type {
  TitleComponentOption,
  TooltipComponentOption,
  LegendComponentOption,
  GridComponentOption,
  ToolboxComponentOption
} from 'echarts/components'
import type { ComposeOption } from 'echarts/core'
import type { LineSeriesOption } from 'echarts/charts'

import { ref, provide, onMounted, computed, onUnmounted } from 'vue'

import VChart, { THEME_KEY } from 'vue-echarts'
import { use } from 'echarts/core'
import { LineChart } from 'echarts/charts'
import {
  TitleComponent,
  TooltipComponent,
  LegendComponent,
  GridComponent,
  ToolboxComponent
} from 'echarts/components'
import { CanvasRenderer } from 'echarts/renderers'
import { connection } from '@/utils/signalr'
import { unref } from 'vue'
import { DATASCREEN_CONFIG } from '@/constant'

use([
  TitleComponent,
  TooltipComponent,
  LegendComponent,
  GridComponent,
  ToolboxComponent,
  LineChart,
  CanvasRenderer
])
provide(THEME_KEY, 'dark')

type EChartsOption = ComposeOption<
  | TitleComponentOption
  | TooltipComponentOption
  | LegendComponentOption
  | GridComponentOption
  | ToolboxComponentOption
  | LineSeriesOption
>

const chartRef = ref()
const planAchievementOption = computed<EChartsOption>(() => {
  return {
    backgroundColor: 'rgba(0, 0, 0, 0)',
    animation: true,
    animationEasing: 'quadraticIn',
    animationDuration: 300,
    resize: {},
    tooltip: {
      trigger: 'axis',
      confine: true
    },
    legend: {
      left: 'center',
      bottom: 8,
      type: 'scroll',
      itemWidth: 12,
      itemHeight: 10,
      data: unref(lineData).seriesData.map((item) => item.name)
    },
    grid: {
      left: '4%',
      right: '10%',
      bottom: '20%',
      top: '20%',
      containLabel: true
    },
    xAxis: {
      type: 'category',
      // name: '日期',
      boundaryGap: false,
      data: unref(lineData).xAxis
    },
    yAxis: {
      type: 'value',
      scale: true,
      axisLabel: { formatter: '{value}%' }
    },
    series: unref(lineData).seriesData.map((item) => ({
      name: item.name,
      type: 'line',
      data: item.data,
      smooth: true
    }))
  }
})

const loadingOptions = {
  text: 'Loading…',
  color: '#4ea397',
  maskColor: 'rgba(255, 255, 255, 0.4)'
}

const lineData = ref<LineChartData>({
  seriesData: [],
  xAxis: []
})

connection.on('GetWoAchievementRate', (data) => {
  lineData.value = data
})

let timer: number
function startActions() {
  let dataIndex = -1
  // const dataLen = option.value?.series[0]?.data?.length || 0
  const dataLen = unref(lineData).seriesData[0]?.data.length || 0

  if (!chartRef.value || dataLen === 0) {
    return setTimeout(() => {
      startActions()
    }, 1000)
  }

  timer = setInterval(() => {
    if (!chartRef.value) {
      clearInterval(timer)
      return
    }

    // 取消之前高亮的图形
    unref(chartRef)?.dispatchAction({
      type: 'downplay',
      seriesIndex: 0,
      dataIndex: dataIndex
    })
    dataIndex = (dataIndex + 1) % dataLen
    //console.log(dataIndex);
    // 高亮当前图形
    unref(chartRef)?.dispatchAction({
      type: 'highlight',
      seriesIndex: 0,
      dataIndex: dataIndex
    })
    // 显示 tooltip
    unref(chartRef)?.dispatchAction({
      type: 'showTip',
      seriesIndex: 0,
      dataIndex: dataIndex
    })
  }, DATASCREEN_CONFIG.interval)
}
function stopActions() {
  clearInterval(timer)
}

onMounted(() => {
  startActions()
})

onUnmounted(() => {
  stopActions()
  connection.off('GetWoAchievementRate')
})
</script>

<style lang="scss" scoped></style>
