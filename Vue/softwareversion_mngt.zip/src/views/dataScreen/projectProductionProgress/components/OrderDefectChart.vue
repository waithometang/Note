<template>
  <v-chart ref="chartRef" :option="option" :loadingOptions="loadingOptions" autoresize />
</template>

<script lang="ts" setup>
import type {
  TitleComponentOption,
  TooltipComponentOption,
  LegendComponentOption,
  DataZoomComponentOption
} from 'echarts/components'
import type { ComposeOption } from 'echarts/core'
import type { BarSeriesOption } from 'echarts/charts'
import type { ColumnChartData } from './types'

import { ref, provide, computed, onMounted, unref, onUnmounted } from 'vue'

import VChart, { THEME_KEY } from 'vue-echarts'
import { use } from 'echarts/core'
import { BarChart } from 'echarts/charts'
import {
  TitleComponent,
  TooltipComponent,
  LegendComponent,
  GridComponent,
  DataZoomComponent
} from 'echarts/components'
import { CanvasRenderer } from 'echarts/renderers'
import { connection } from '@/utils/signalr'
import { DATASCREEN_CONFIG } from '@/constant'

use([
  TitleComponent,
  TooltipComponent,
  LegendComponent,
  GridComponent,
  DataZoomComponent,
  BarChart,
  CanvasRenderer
])
provide(THEME_KEY, 'dark')

export type EChartsOption = ComposeOption<
  | TitleComponentOption
  | TooltipComponentOption
  | LegendComponentOption
  | BarSeriesOption
  | DataZoomComponentOption
>

const chartRef = ref()
const option = computed<EChartsOption>(() => {
  return {
    color: ['#2174ff', '#3cb1fb', '#07a872', '#d29e08', '#ed8139'],
    backgroundColor: '',
    tooltip: {
      trigger: 'axis',
      axisPointer: {
        type: 'shadow'
      },
      confine: true
    },
    dataZoom: [
      {
        show: false,
        type: 'slider',
        xAxisIndex: 0, // 设置对应的x轴索引
        startValue: 0, // 设置显示的起始位置
        endValue: 3 // 设置显示的结束位置
      }
    ],
    legend: {
      data: unref(chartData).seriesData.map((item) => item.name),
      left: 'center',
      bottom: 8,
      itemWidth: 12,
      itemHeight: 10,
      type: 'scroll'
    },
    grid: {
      left: '4%',
      right: '10%',
      bottom: '20%',
      top: '20%',
      containLabel: true
    },
    xAxis: {
      type: 'category',
      // name: '单据编号',
      data: unref(chartData).xAxis,
      axisLabel: {
        interval: 0,
        formatter: function (value: string) {
          // 对标签内容进行处理，实现换行或其他格式化操作
          return value.replace(/(.{10})/g, '$1\n') // 以每 4 个字符换行
        }
      }
      // boundaryGap: [0, 0.01]
    },
    yAxis: {
      type: 'value',
      splitNumber: 3,
      minInterval: 1
    },
    series: unref(chartData).seriesData.map((item) => {
      return {
        name: item.name,
        type: 'bar',
        stack: '不良类型',
        data: item.data,
        label: {
          show: true,
          color: '#fff',
          position: 'top',
          formatter(params) {
            if (params.value !== 0) {
              return params.value as string
            } else {
              return ''
            }
          }
        }
      }
    })
  }
})

const loadingOptions = {
  text: 'Loading…',
  color: '#4ea397',
  maskColor: 'rgba(255, 255, 255, 0.4)'
}

const chartData = ref<ColumnChartData>({
  seriesData: [],
  xAxis: []
})

connection.on('GetWoExceptionCount', (data) => {
  chartData.value = data
})

let timer: number
function startActions() {
  let dataIndex = -1
  // const dataLen = option.value?.series[0]?.data?.length || 0
  const dataLen = unref(chartData).seriesData[0]?.data.length || 0

  if (!chartRef.value || dataLen === 0) {
    return setTimeout(() => {
      startActions()
    }, 1000)
  }

  timer = setInterval(() => {
    if (!chartRef.value) {
      clearInterval(timer)
      return
    }

    // 取消之前高亮的图形
    unref(chartRef)?.dispatchAction({
      type: 'downplay',
      seriesIndex: 0,
      dataIndex: dataIndex
    })
    dataIndex = (dataIndex + 1) % dataLen
    // console.log(dataIndex)

    // 区间滚动到当前
    unref(chartRef)?.dispatchAction({
      type: 'dataZoom',
      startValue: dataIndex,
      endValue: 3 + dataIndex
    })

    // 高亮当前图形
    unref(chartRef)?.dispatchAction({
      type: 'highlight',
      seriesIndex: 0,
      dataIndex: dataIndex
    })

    // 显示 tooltip
    unref(chartRef)?.dispatchAction({
      type: 'showTip',
      seriesIndex: 0,
      dataIndex: dataIndex
    })
  }, DATASCREEN_CONFIG.interval)
}
function stopActions() {
  clearInterval(timer)
}

onMounted(() => {
  startActions()
})

onUnmounted(() => {
  stopActions()
  connection.off('GetWoExceptionCount')
})
</script>

<style lang="scss" scoped></style>
