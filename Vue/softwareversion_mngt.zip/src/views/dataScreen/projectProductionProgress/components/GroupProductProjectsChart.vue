<template>
  <v-chart ref="chartRef" :option="option" :loadingOptions="loadingOptions" autoresize />
</template>

<script lang="ts" setup>
import type {
  TitleComponentOption,
  TooltipComponentOption,
  LegendComponentOption,
  DataZoomComponentOption
} from 'echarts/components'
import type { ComposeOption } from 'echarts/core'
import type { BarSeriesOption } from 'echarts/charts'
import type { ColumnChartData } from './types'

import { ref, unref, provide, onUnmounted, onMounted, computed } from 'vue'

import VChart, { THEME_KEY } from 'vue-echarts'
import { use } from 'echarts/core'
import { BarChart } from 'echarts/charts'
import {
  TitleComponent,
  TooltipComponent,
  LegendComponent,
  GridComponent,
  DataZoomComponent
} from 'echarts/components'
import { CanvasRenderer } from 'echarts/renderers'
import { connection } from '@/utils/signalr'
import { DATASCREEN_CONFIG } from '@/constant'

use([
  TitleComponent,
  TooltipComponent,
  LegendComponent,
  GridComponent,
  DataZoomComponent,
  BarChart,
  CanvasRenderer
])
provide(THEME_KEY, 'dark')

export type EChartsOption = ComposeOption<
  | TitleComponentOption
  | TooltipComponentOption
  | LegendComponentOption
  | DataZoomComponentOption
  | BarSeriesOption
>

const chartRef = ref<InstanceType<typeof VChart>>()
const option = computed<EChartsOption>(() => {
  return {
    backgroundColor: 'rgba(0, 0, 0, 0)',
    tooltip: {
      trigger: 'axis',
      axisPointer: {
        type: 'shadow' // 默认为直线，可选为：'line' | 'shadow'
      },
      confine: true
    },
    dataZoom: [
      {
        show: false,
        type: 'slider',
        xAxisIndex: 0, // 设置对应的x轴索引
        startValue: 0, // 设置显示的起始位置
        endValue: 3 // 设置显示的结束位置
      }
    ],
    grid: {
      left: '4%',
      right: '10%',
      bottom: '20%',
      top: '20%',
      containLabel: true
    },
    legend: {
      data: unref(chartData).seriesData.map((item) => item.name),
      left: 'center',
      bottom: 8,
      itemWidth: 12,
      itemHeight: 10,
      type: 'scroll'
    },
    xAxis: {
      type: 'category',
      // name: '组别',
      data: unref(chartData).xAxis,
      axisLine: {
        lineStyle: {
          color: 'white'
        }
      },
      axisLabel: {
        interval: 0,
        formatter: function (value: string) {
          // 对标签内容进行处理，实现换行或其他格式化操作
          return value.replace(/(.{4})/g, '$1\n') // 以每 4 个字符换行
        }
      }
    },
    yAxis: {
      type: 'value',
      splitNumber: 3,
      axisLine: {
        show: false,
        lineStyle: {
          color: 'white'
        }
      },
      splitLine: {
        show: true,
        lineStyle: {
          color: 'rgba(255,255,255,0.3)'
        }
      },
      minInterval: 1
    },
    series: unref(chartData).seriesData.map((item) => {
      return {
        name: item.name,
        type: 'bar',
        barWidth: '15%',
        stack: '在制项目数量',
        data: item.data
        // label: {
        //   show: true,
        //   color: '#fff',
        //   position: 'top',
        //   formatter(params) {
        //     if (params.value !== 0) {
        //       return params.value as string
        //     } else {
        //       return ''
        //     }
        //   }
        // }
        // hoverAnimation: true
        // emphasis: {
        //   focus: 'series'
        // }
      }
    })
  }
})

const loadingOptions = {
  text: 'Loading…',
  color: '#4ea397',
  maskColor: 'rgba(255, 255, 255, 0.4)'
}

const chartData = ref<ColumnChartData>({
  seriesData: [],
  xAxis: []
})

connection.on('GetProjectCount', (data) => {
  chartData.value = data
})

let timer: number
function startActions() {
  let dataIndex = -1
  // const dataLen = option.value?.series[0]?.data?.length || 0
  const dataLen = unref(chartData).seriesData[0]?.data.length || 0

  if (!chartRef.value || dataLen === 0) {
    return setTimeout(() => {
      startActions()
    }, 1000)
  }

  timer = setInterval(() => {
    if (!chartRef.value) {
      clearInterval(timer)
      return
    }

    // 取消之前高亮的图形
    unref(chartRef)?.dispatchAction({
      type: 'downplay',
      seriesIndex: 0,
      dataIndex: dataIndex
    })
    dataIndex = (dataIndex + 1) % dataLen

    // 区间滚动到当前
    unref(chartRef)?.dispatchAction({
      type: 'dataZoom',
      startValue: dataIndex,
      endValue: 3 + dataIndex
    })

    // 高亮当前图形
    unref(chartRef)?.dispatchAction({
      type: 'highlight',
      seriesIndex: 0,
      dataIndex: dataIndex
    })

    // // 显示 tooltip
    // unref(chartRef)?.dispatchAction({
    //   type: 'showTip',
    //   seriesIndex: 0,
    //   dataIndex: dataIndex
    // })
  }, DATASCREEN_CONFIG.interval)
}
function stopActions() {
  clearInterval(timer)
}

onMounted(() => {
  startActions()
})
onUnmounted(() => {
  stopActions()
})
</script>

<style lang="scss" scoped></style>
