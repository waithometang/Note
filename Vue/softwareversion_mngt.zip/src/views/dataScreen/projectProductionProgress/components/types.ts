export interface CompleteSetMaterialsData {
  /**
   * 部门
   */
  departmentName: string
  /**
   * 物料情况
   */
  materialInfo: null | string
  /**
   * 需求分类
   */
  orderNo: string
}

export interface LineChartData {
  /**
   * Y轴数据
   */
  seriesData: LineChartSeriesDatum[]
  /**
   * X轴数据，近7天日期
   */
  xAxis: string[]
}

export interface LineChartSeriesDatum {
  /**
   * 数据，达成率
   */
  data: number[]
  /**
   * 数据标题，项目名称
   */
  name: string
}

export interface BarChartData {
  /**
   * X轴数据
   */
  seriesData: BarChartSeriesDatum[]
  /**
   * Y轴标题，项目名称
   */
  yAxis: string[]
}

export interface BarChartSeriesDatum {
  /**
   * 数据，工时，显示单位H
   */
  data: number[]
  /**
   * 数据标题，花费工时、预算工时
   */
  name: string
}

export interface ColumnChartData {
  /**
   * Y轴数据
   */
  seriesData: ColumnChartSeriesDatum[]
  /**
   * X轴数据，班组名称
   */
  xAxis: string[]
}

export interface ColumnChartSeriesDatum {
  /**
   * 数据，在制项目数量
   */
  data: number[]
  /**
   * 数据标题，项目名称
   */
  name: string
}

export interface AbnormalFeedbackData {
  /**
   * 部门
   */
  departmentName?: string
  /**
   * 责任人
   */
  dutyEmployeeName?: string
  /**
   * 异常情况
   */
  exceptionDescription?: string
  /**
   * 日期
   */
  execptionTime?: string
  /**
   * 班组
   */
  groupName?: string
  /**
   * 设备名称
   */
  productName?: string
  /**
   * 项目
   */
  projectName?: string
}
export interface QualityIPQCData {
  /**
   * 责任人
   */
  dutyEmployeeName: string
  /**
   * 异常描述
   */
  exceptionDescription: string
  /**
   * 检验项目
   */
  productCheckName: string
  /**
   * 检验区域
   */
  productionAddressName: string
  /**
   * 设备名称
   */
  productName: string
  /**
   * 项目名称
   */
  projectName: string
  /**
   * 日期
   */
  resultDate: string
}
