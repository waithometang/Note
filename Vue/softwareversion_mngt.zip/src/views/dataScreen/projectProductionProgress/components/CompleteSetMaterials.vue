<template>
  <ScrollTable :columns="columns" :data="data" :showNumber="5" />
</template>

<script lang="ts" setup>
import type { CompleteSetMaterialsData } from './types'

import { onMounted, ref } from 'vue'
// import ScrollTable from './components/ScrollTable.vue'
import { connection } from '@/utils/signalr'

const data = ref<CompleteSetMaterialsData[]>()

const columns = [
  { field: 'departmentName', title: '部门' },
  { field: 'orderNo', title: '需求分类' },
  { field: 'materialInfo', title: '物料情况' }
]
// const testData = []
// for (let i = 1; i <= 600; i++) {
//   testData.push({
//     id: i,
//     departmentName: `部门${i}`,
//     orderNo: `需求分类${i}`,
//     materialInfo: `物料情况${i}`
//   })
// }
// data.value = testData
onMounted(() => {
  connection.on('GetWoMaterialInfo', (woMaterialInfo) => {
    data.value = woMaterialInfo
  })
})
</script>

<style lang="scss" scoped></style>
