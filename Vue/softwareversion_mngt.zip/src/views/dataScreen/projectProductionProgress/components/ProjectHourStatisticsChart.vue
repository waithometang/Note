<template>
  <v-chart ref="chartRef" :option="option" :loadingOptions="loadingOptions" autoresize />
</template>

<script lang="ts" setup>
import type {
  TitleComponentOption,
  TooltipComponentOption,
  LegendComponentOption,
  DataZoomComponentOption,
  GridComponentOption
} from 'echarts/components'
import type { ComposeOption } from 'echarts/core'
import type { BarSeriesOption } from 'echarts/charts'
import type { BarChartData } from './types'

import { ref, unref, provide, onUnmounted, onMounted, computed } from 'vue'

import VChart, { THEME_KEY } from 'vue-echarts'
import { use } from 'echarts/core'
import { BarChart } from 'echarts/charts'
import {
  TitleComponent,
  TooltipComponent,
  LegendComponent,
  GridComponent,
  DataZoomComponent
} from 'echarts/components'
import { CanvasRenderer } from 'echarts/renderers'
import { connection } from '@/utils/signalr'
import { DATASCREEN_CONFIG } from '@/constant'

use([
  TitleComponent,
  TooltipComponent,
  LegendComponent,
  GridComponent,
  DataZoomComponent,
  BarChart,
  CanvasRenderer
])
provide(THEME_KEY, 'dark')

export type EChartsOption = ComposeOption<
  | TitleComponentOption
  | TooltipComponentOption
  | LegendComponentOption
  | DataZoomComponentOption
  | GridComponentOption
  | BarSeriesOption
>

const chartRef = ref()
const option = computed<EChartsOption>(() => {
  return {
    backgroundColor: 'rgba(0, 0, 0, 0)',
    tooltip: {
      trigger: 'axis',
      axisPointer: {
        // 坐标轴指示器，坐标轴触发有效
        type: 'shadow' // 默认为直线，可选为：'line' | 'shadow'
      }
    },
    grid: {
      left: '4%',
      right: '10%',
      bottom: '20%',
      top: '10%',
      containLabel: true
    },
    legend: {
      left: 'center',
      bottom: 8,
      itemWidth: 12,
      itemHeight: 10,
      type: 'scroll'
      // itemGap: 35
    },
    dataZoom: [
      {
        show: false,
        type: 'slider',
        yAxisIndex: 0, // 设置对应的y轴索引
        startValue: 0, // 设置显示的起始位置
        endValue: 3 // 设置显示的结束位置
      }
    ],
    xAxis: {
      type: 'value',
      // name: '工时',
      data: unref(barChartData).seriesData.map((item) => item.name),
      axisLine: {
        lineStyle: {
          color: 'white'
        }
      },
      axisLabel: {
        // interval: 0,
        // rotate: 40,
        fontFamily: 'Microsoft YaHei',
        formatter: '{value}h'
      }
    },

    yAxis: {
      type: 'category',
      data: unref(barChartData).yAxis,
      axisLine: {
        show: false,
        lineStyle: {
          color: 'white'
        }
      },
      splitLine: {
        show: true,
        lineStyle: {
          color: 'rgba(255,255,255,0.3)'
        }
      }
    },
    series: [
      {
        name: '预算工时',
        type: 'bar',
        barWidth: 8,
        stack: '工时统计',
        itemStyle: {
          color: '#3cb1fb'
        },
        data: unref(barChartData).seriesData[1]?.data
        // label: {
        //   show: true, // 显示标签
        //   color: '#3cb1fb',
        //   position: 'right',
        //   formatter(params) {
        //     if (params.value !== 0) {
        //       return params.value + 'h'
        //     } else {
        //       return ''
        //     }
        //   }
        // }
      },
      {
        name: '花费工时',
        type: 'bar',
        stack: '工时统计',
        barWidth: 8,
        itemStyle: {
          color: '#07a872'
        },
        data: unref(barChartData).seriesData[0]?.data
        // label: {
        //   show: true, // 显示标签
        //   color: '#07a872',
        //   position: 'right',
        //   formatter(params) {
        //     if (params.value !== 0) {
        //       return params.value + 'h'
        //     } else {
        //       return ''
        //     }
        //   }
        // }
      }
    ]
  }
})

connection.on('GetProjectTakeHour', (data) => {
  barChartData.value = data
})

let timer: number
function startActions() {
  let dataIndex = -1
  // const dataLen = option.value?.series[0]?.data?.length || 0
  const dataLen = unref(barChartData).seriesData[0]?.data.length || 0

  if (!chartRef.value || dataLen === 0) {
    return setTimeout(() => {
      startActions()
    }, 1000)
  }

  timer = setInterval(() => {
    if (!chartRef.value) {
      clearInterval(timer)
      return
    }

    // 取消之前高亮的图形
    unref(chartRef)?.dispatchAction({
      type: 'downplay',
      seriesIndex: 0,
      dataIndex: dataIndex
    })
    dataIndex = (dataIndex + 1) % dataLen

    // 高亮当前图形
    unref(chartRef)?.dispatchAction({
      type: 'highlight',
      seriesIndex: 0,
      dataIndex: dataIndex
    })
    // 区间滚动到当前
    unref(chartRef)?.dispatchAction({
      type: 'dataZoom',
      startValue: dataIndex,
      endValue: 3 + dataIndex
    })
    // 显示 tooltip
    unref(chartRef)?.dispatchAction({
      type: 'showTip',
      seriesIndex: 0,
      dataIndex: dataIndex
    })
  }, DATASCREEN_CONFIG.interval)
}
function stopActions() {
  clearInterval(timer)
}

const loadingOptions = {
  text: 'Loading…',
  color: '#4ea397',
  maskColor: 'rgba(255, 255, 255, 0.4)'
}

const barChartData = ref<BarChartData>({
  seriesData: [],
  yAxis: []
})

onMounted(() => {
  startActions()
})
onUnmounted(() => {
  stopActions()
  connection.off('GetProjectTakeHour')
})
</script>

<style lang="scss" scoped></style>
