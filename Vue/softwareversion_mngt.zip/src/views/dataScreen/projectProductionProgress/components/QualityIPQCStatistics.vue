<template>
  <ScrollTable
    :columns="columns"
    :data="tableData"
    :bgWidth="1173"
    :showNumber="5"
    emptyText="暂无异常"
  />
</template>

<script lang="ts" setup>
import type { QualityIPQCData } from './types'
import type { TableColumn } from '@/components/ScrollTable/types'

import { onMounted, ref, onUnmounted } from 'vue'
import { connection } from '@/utils/signalr'

const tableData = ref<QualityIPQCData[]>()

const columns: TableColumn[] = [
  { field: 'projectName', title: '项目名称' },
  { field: 'productName', title: '设备名称' },
  { field: 'resultDate', title: '日期' },
  { field: 'productCheckName', title: '检验项目' },
  { field: 'productionAddressName', title: '检验区域' },
  { field: 'dutyEmployeeName', title: '责任人' },
  { field: 'exceptionDescription', title: '异常描述' }
]

onMounted(() => {
  connection.on('GetQualityIPQC', (data) => {
    tableData.value = data
    // tableData.value = [
    //   {
    //     projectName: 'HC',
    //     productName: 'YC',
    //     exceptionDescription: '3213213'
    //   },
    //   {
    //     projectName: 'CATL',
    //     productName: 'OCV1',
    //     exceptionDescription: 'sfsf'
    //   },
    //   {
    //     projectName: '3',
    //     productName: '3',
    //     exceptionDescription: '3'
    //   },
    //   {
    //     projectName: '4',
    //     productName: '4',
    //     exceptionDescription: '4'
    //   },
    //   {
    //     projectName: '5',
    //     productName: '5',
    //     exceptionDescription: '5'
    //   },
    //   {
    //     projectName: '6',
    //     productName: '6',
    //     exceptionDescription: '6'
    //   }
    // ]
  })
})

onUnmounted(() => {
  connection.off('GetQualityIPQC')
})
</script>

<style lang="scss" scoped></style>
