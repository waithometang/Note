<template>
  <div class="project-production-progress-container">
    <div id="project-production-progress-screen" class="data-screen-container">
      <div class="data-screen-header">
        <div class="data-screen-title">项目生产进度</div>
        <div class="clock-container">{{ time }}</div>
      </div>

      <div class="data-screen-main">
        <div class="main-top">
          <div class="bg-600 materials-complete-container">
            <div class="title">排产物料齐套情况</div>
            <div class="inner-552">
              <CompleteSetMaterials />
            </div>
          </div>
          <div class="bg-600 project-achievement-container">
            <div class="title">近7日项目达成率</div>
            <div class="inner-552 inner-bg-552">
              <ProjectAchievementChart />
            </div>
          </div>
          <div class="bg-600 work-order-achievement-container">
            <div class="title">近7日工单达成率</div>
            <div class="inner-552 inner-bg-552">
              <OrderAchievementChart />
            </div>
          </div>
        </div>
        <div class="main-center">
          <div class="bg-600 project-hour-statistics">
            <div class="title">项目工时统计</div>

            <div class="inner-552 inner-bg-552">
              <ProjectHourStatisticsChart />
            </div>
          </div>
          <div class="bg-600 team-in-process-statistics">
            <div class="title">班组在制项目统计</div>

            <div class="inner-552 inner-bg-552">
              <GroupProductProjectsChart />
            </div>
          </div>
          <div class="bg-600 order-defect-statistics">
            <div class="title">订单不良统计</div>
            <div class="inner-552 inner-bg-552">
              <OrderDefectChart />
            </div>
          </div>
        </div>
        <div class="main-bottom">
          <div class="bg-912 abnormal-feedback-statistics">
            <div class="title">近7日异常反馈</div>

            <AbnormalFeedbackStatistics />
          </div>

          <div class="bg-912 feedback-on-inspection-defects">
            <div class="title">巡检不良反馈</div>

            <div class="inner-552">
              <QualityIPQCStatistics />
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>
</template>

<script lang="ts" setup>
import { ref, onMounted, watch, nextTick, onBeforeUnmount } from 'vue'
import dayjs from 'dayjs'

import ProjectAchievementChart from './components/ProjectAchievementChart.vue'
import OrderAchievementChart from './components/OrderAchievementChart.vue'
import ProjectHourStatisticsChart from './components/ProjectHourStatisticsChart.vue'
import GroupProductProjectsChart from './components/GroupProductProjectsChart.vue'
import OrderDefectChart from './components/OrderDefectChart.vue'
import AbnormalFeedbackStatistics from './components/AbnormalFeedbackStatistics.vue'
import CompleteSetMaterials from './components/CompleteSetMaterials.vue'
import QualityIPQCStatistics from './components/QualityIPQCStatistics.vue'

import { useKeepFit } from '@/hooks/useKeepFit'
import { connection } from '@/utils/signalr'
import { useUrlSearchParams } from '@vueuse/core'

defineOptions({
  name: 'ProjectProductionProgress',
  inheritAttrs: false
})
const query = useUrlSearchParams('hash')
let clock: number
const time = ref<string>()

const getTime = () => {
  time.value = dayjs().format('YYYY-MM-DD dddd HH:mm:ss')
  clock = setInterval(() => {
    time.value = dayjs().format('YYYY-MM-DD dddd HH:mm:ss')
  }, 1000)
}
watch(
  () => query.positionAddress,
  (newPositionAddress) => {
    if (newPositionAddress) {
      nextTick(() => {
        connection.invoke(
          'SendDynamicMessageToAllClientsAsync',
          'ProjectProgressKey',
          newPositionAddress
        )
      })
    }
  },
  {
    immediate: true
  }
)
onMounted(() => {
  useKeepFit({
    dw: 1920,
    dh: 1080,
    el: '#project-production-progress-screen'
  })
  getTime()
})
onBeforeUnmount(() => {
  clearInterval(clock)
  connection.invoke('StopSendDynamicMessageToAllClientsAsync')
})
</script>

<style lang="scss" scoped>
.project-production-progress-container {
  height: 100%;
  width: 100%;

  .data-screen-container {
    background: url('@/assets/png/data-screen-background.png') no-repeat;
    background-size: 100% 100%;
    display: flex;
    flex-direction: column;
    position: relative;

    height: 100%;
    .data-screen-header {
      background: url('@/assets/png/data-screen-header.png') no-repeat;
      background-size: 100% 100%;
      height: 135px;

      display: flex;
      flex-direction: column;
      .data-screen-title {
        margin-top: 23px;
        font-size: 40px;
        font-weight: 900;
        letter-spacing: 9px;
        color: rgba(255, 255, 255, 1);

        display: flex;
        justify-content: center;
        user-select: none;
      }
      .clock-container {
        position: absolute;
        right: 8.48%;
        top: 5.74%;
        height: 21px;

        font-size: 14px;
        font-weight: 700;
        color: rgba(50, 197, 255, 1);
        user-select: none;
      }
    }

    .data-screen-main {
      flex: 1;
      padding: 18px 0 24px 0;

      display: flex;
      flex-direction: column;
      overflow: hidden;
      gap: 24px;
      .title {
        height: 36px;
        font-size: 14px;
        font-weight: 700;
        color: rgba(25, 236, 255, 1);
        user-select: none;

        display: flex;
        justify-content: center;
        align-items: center;
      }
      .main-top,
      .main-center,
      .main-bottom {
        height: 0;

        flex: 1;
      }
      .main-top {
        display: flex;
        justify-content: center;
        gap: 1.25%;
        .materials-complete-container {
          width: 31.25%;
        }

        .project-achievement-container {
          width: 31.25%;
        }
        .work-order-achievement-container {
          width: 31.25%;
        }
      }

      .main-center {
        display: flex;
        justify-content: center;
        gap: 1.25%;
        .project-hour-statistics {
          width: 31.25%;
        }
        .team-in-process-statistics {
          width: 31.25%;
        }

        .order-defect-statistics {
          width: 31.25%;
        }
      }
      .main-bottom {
        gap: 1.25%;
        display: flex;
        justify-content: center;
        overflow: hidden;

        .abnormal-feedback-statistics {
          width: 47.5%;
        }
        .feedback-on-inspection-defects {
          width: 47.5%;
        }
      }
    }
  }
}

.bg-600 {
  background: url('@/assets/png/data-screen-box-600.png') no-repeat;
  background-size: 100% 100%;

  display: flex;
  flex-direction: column;
}
.bg-912 {
  background: url('@/assets/png/data-screen-box-912.png') no-repeat;
  background-size: 100% 100%;

  display: flex;
  flex-direction: column;
}
.bg-1225 {
  background: url('@/assets/png/data-screen-box-1225.png') no-repeat;
  background-size: 100% 100%;

  display: flex;
  flex-direction: column;
}

.inner-552 {
  flex: 1;
  margin: 12px 24px 24px 24px;
}
.inner-bg-552 {
  background-image: url('@/assets/png/data-screen-inner-box-552.png');
  background-repeat: no-repeat;
  background-size: 100% 100%;
}
</style>
