<template>
  <div class="page-container">
    <basic-list ref="basicListRef" v-bind="listOptions" @change="handleChange" />
    <vxe-grid class="box vxe-grid" ref="gridRef" v-bind="gridOptions">
      <template #top>
        <GridHeader
          ref="gridHeaderRef"
          v-bind="headerOptions"
          @quickSearch="handleQuickSearch"
          @advancedSearch="handleAdvancedSearch"
          @add="handleAdd"
        />
      </template>
      <template #orderStatus="{ row }">
        <el-tag :type="getOrderStatusInfo(row.orderStatus).type">
          {{ getOrderStatusInfo(row.orderStatus).text }}
        </el-tag>
      </template>
      <template #operation="{ row }">
        <TableAction
          :actions="[
            {
              icon: 'edit',
              tooltip: '编辑',
              onClick: handleModify.bind(null, row)
            },
            {
              icon: 'delete',
              tooltip: '删除',
              onClick: handleDelete.bind(null, row)
            }
          ]"
        />
      </template>
    </vxe-grid>

    <KanbanDialog @register="registerModal" @success="handleSuccess" />
  </div>
</template>

<script setup lang="ts">
import type { VxeGridInstance, VxeGridProps } from 'vxe-table'
import type { GridHeaderProps } from '@/components/Table/types/gridHeader'
import type { GetKanBanInfoModel } from '@/api/sys/model/dataScreenModel'
import type { ListProps } from '@/components/List/types'

import { ref, reactive, computed } from 'vue'
import { ElMessage } from 'element-plus'

import { getKeyValue } from '@/api/sys/basic'
import { deleteKanBanInfo, getKanBanInfo } from '@/api/sys/dataScreen'

import { useModal } from '@/components/Modal/hooks/useModal'
import GridHeader from '@/components/Table/GridHeader.vue'

import KanbanDialog from './components/KanbanDialog.vue'
import { error } from '@/utils/log'
import { clone } from 'lodash-es'
import { kanbanTypeOptions } from './data'

defineOptions({
  name: 'KanbanMngt',
  inheritAttrs: false
})

const basicListRef = ref()

const getBasicListData = async () => {
  const { code, data } = await getKeyValue({ typeName: 'PositionAddress' })

  if (code === 200) {
    data.result.push(clone(data.result[0]))
    data.result[data.result.length - 1].id = new Date().getTime().toString()
    data.result[data.result.length - 1].key = 'admin'
    data.result[data.result.length - 1].value = '行政级'

    listOptions.data = data.result
  }
}

getBasicListData()

// 列表配置
const listOptions = reactive<ListProps>({
  title: '厂区位置',
  valueField: 'value',
  labelField: 'value',
  resultField: 'data.result',
  isCancelCurrent: true,
  showTooltip: true,
  tooltipField: 'key',
  isApiEnabled: false,
  data: []
  // autoSelectFirst: true,
})

const positionAddress = computed(() => basicListRef.value.getActiveItem?.value)

// 列表活跃项改变
const handleChange = () => {
  if (positionAddress.value) {
    headerOptions.title = `看板配置 - [${positionAddress.value}]`
  } else {
    headerOptions.title = `看板配置`
  }
  gridRef.value?.commitProxy('reload')
}

const getOrderStatusInfo = computed(() => {
  const statusMap: { [key: number]: { text: string; type: string } } = {
    1: { text: '已启用', type: 'success' },
    2: { text: '已停用', type: 'danger' }
  }

  return function (status: number) {
    return statusMap[status] || { text: '', color: '' }
  }
})

const [registerModal, { openModal }] = useModal()

const gridHeaderRef = ref<typeof GridHeader>()

const headerOptions = reactive<GridHeaderProps>({
  title: '看板配置',
  // showQuickSearchButton: false,
  quickSearch: {
    singleSearch: {
      field: 'SearchKey',
      type: 'input',
      title: ''
    },
    searchFormFields: { SearchKey: '' }
  },
  showAdvancedSearchButton: false
})

const gridRef = ref<VxeGridInstance>()
const gridOptions = reactive<VxeGridProps<GetKanBanInfoModel>>({
  border: true,
  height: 'auto',
  align: null,
  columnConfig: {
    resizable: true
  },
  columns: [
    { type: 'seq', width: 50 },
    { field: 'menuTitle', title: '厂区位置', minWidth: 90 },
    {
      field: 'kanBanType',
      title: '看板类型',
      formatter({ cellValue }) {
        return kanbanTypeOptions.find((item) => item.value == cellValue)?.label || ''
      },
      minWidth: 120
    },
    { field: 'playOrder', title: '播放顺序', minWidth: 90 },
    {
      field: 'playTime',
      title: '播放时间(s)',
      minWidth: 110
      // formatter({ cellValue }) {
      //   return cellValue + 's'
      // }
    },
    {
      field: 'refreshTime',
      title: '数据切换间隔(s)',
      minWidth: 140
      // formatter({ cellValue }) {
      //   return cellValue + 's'
      // }
    },
    { field: 'onlineUserCount', title: '在线用户', minWidth: 90 },
    { field: 'maxOnlineDuration', title: '最大在线时长', minWidth: 120 },
    { field: 'lastConnetionTime', title: '最新连接时间', minWidth: 150 },
    { field: 'orderStatus', title: '启用状态', minWidth: 90, slots: { default: 'orderStatus' } },
    { field: 'lastModifiedUserName', title: '最后修改人', minWidth: 120 },
    { field: 'lastModifiedTime', title: '最后更新时间', minWidth: 150 },
    {
      field: 'operation',
      title: '操作',
      align: 'center',
      fixed: 'right',
      width: 150,
      slots: {
        default: 'operation'
      }
    }
  ],
  pagerConfig: {
    enabled: true,
    pageSize: 20
  },
  proxyConfig: {
    // autoLoad: false,
    ajax: {
      query: ({ page }) => {
        const searchKey = positionAddress.value
        return getKanBanInfo({
          pageIndex: page.currentPage - 1, // 由于后端接口限制，首页从0开始
          pageSize: page.pageSize,
          searchKey
        })
      }
    }
  }
})

const handleQuickSearch = () => {
  gridRef.value?.commitProxy('reload')
}

const handleAdvancedSearch = () => {
  gridRef.value?.commitProxy('reload')
}

const handleAdd = () => {
  const activeListItem = basicListRef.value.getActiveItem
  const { tableData } = gridRef.value?.getTableData() || {}
  if (!activeListItem) {
    return ElMessage.warning('请先选择厂区位置,再点击新增')
  }

  openModal(true, { isUpdate: false, activeListItem: activeListItem, tableData: tableData })
}
const handleSuccess = () => {
  gridRef.value?.commitProxy('query')
}

const handleModify = (row: GetKanBanInfoModel) => {
  openModal(true, { isUpdate: true, row })
}
const handleDelete = (row: GetKanBanInfoModel) => {
  const name = kanbanTypeOptions.find((item) => item.value == row.kanBanType)?.label
  ElMessageBox.confirm(`是否确认删除类型为"${name}"的数据项?`, '警告', {
    confirmButtonText: '确定',
    cancelButtonText: '取消',
    type: 'warning'
  }).then(async () => {
    try {
      const id = row.id
      const { data, message } = await deleteKanBanInfo({ id })

      if (data) {
        ElMessage.success('删除成功')
        gridRef.value?.commitProxy('query')
      } else {
        ElMessage.error(message)
      }
    } catch (err: any) {
      error(err.message)
    }
  })
}
</script>

<style scoped lang="scss">
.page-container {
  display: flex;
  .list-container {
    width: 14vw;
  }

  .vxe-grid {
    margin-left: $margin;
    flex: 1;
    :deep(.operation-container) {
      .quick-search-input {
        display: none;
      }
    }
  }
}
</style>
