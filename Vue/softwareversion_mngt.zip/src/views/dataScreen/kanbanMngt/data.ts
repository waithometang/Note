export const kanbanTypeOptions = [
  { label: '人员结构看板', value: 1 },
  { label: '项目生产进度', value: 2 },
  { label: '员工绩效统计', value: 3 },
  { label: '智能物流信息看板', value: 4 },
  { label: '图片展示', value: 5 },
]
