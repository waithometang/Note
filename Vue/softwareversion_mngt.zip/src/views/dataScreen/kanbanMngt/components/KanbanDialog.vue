<template>
  <BasicModal
    width="680px"
    v-bind="$attrs"
    @register="registerModal"
    :title="getTitle"
    @confirm="handleSubmit"
  >
    <BasicForm @register="registerForm">
      <template #imageUrl>
        <el-upload
          v-model:file-list="fileList"
          ref="upload"
          action=""
          :auto-upload="false"
          name="picture"
          accept=".jpg,.png,.jpeg"
          :on-remove="handleUploadRemove"
          :on-preview="handlePictureCardPreview"
          multiple
          list-type="picture-card"
        >
          <template #trigger>
            <el-button type="primary">点击上传</el-button>
          </template>
          <template #tip>
            <div class="el-upload__tip">只能上传 jpg/png 文件,且单个文件大小不超过10MB</div>
          </template>
        </el-upload>
      </template>
    </BasicForm>
  </BasicModal>
  <el-dialog v-model="dialogVisible">
    <img :src="dialogImageUrl" style="display: block; margin: 0 auto; max-width: 100%" />
  </el-dialog>
</template>

<script lang="ts" setup>
import type {
  AddKanBanInfoData,
  GetKanBanInfoModel,
  UpdateKanBanInfoData
} from '@/api/sys/model/dataScreenModel'
import type { ModalMethods } from '@/components/Modal/types'

import { ref, unref, computed } from 'vue'
import { addKanBanInfo, importCustomImage, updateKanBanInfo } from '@/api/sys/dataScreen'

import BasicModal from '@/components/Modal/BasicModal.vue'
import { useModalInner } from '@/components/Modal/hooks/useModal'
import BasicForm from '@/components/Form/BasicForm.vue'
import { useForm } from '@/components/Form/hooks/useForm'
import { cloneDeep } from 'lodash-es'
import { kanbanTypeOptions } from '../data'
import { ElUpload, type UploadInstance, type UploadProps, type UploadUserFile } from 'element-plus'

const emit = defineEmits<{
  register: [modalMethods: ModalMethods, uuid: number]
  success: []
}>()
const isUpdate = ref<boolean>(false)

const rowId = ref<string>('')

const getTitle = computed(() => (!unref(isUpdate) ? '新增' : '修改'))

const [registerForm, { setFieldsValue, resetFields, updateSchema, getFieldsValue, validate }] =
  useForm({
    labelWidth: 130,
    schemas: [
      {
        field: 'menuName',
        component: 'ElInput',
        label: '厂区位置key',
        ifShow: false
      },
      {
        field: 'menuTitle',
        component: 'ElInput',
        label: '厂区位置',
        componentProps: {
          disabled: true,
          style: { width: '300px' }
        },
        colProps: {
          span: 24
        }
      },
      {
        field: 'kanBanType',
        component: 'Select',
        label: '看板类型',
        required: true,
        dynamicDisabled() {
          return unref(isUpdate)
        },
        componentProps: {
          style: { width: '300px' },
          options: cloneDeep(kanbanTypeOptions)
        },
        colProps: {
          span: 24
        }
      },
      {
        field: 'imageUrl',
        component: 'ElInput',
        label: '',
        ifShow({ model }) {
          return model['kanBanType'] == 5
        },
        componentProps: {},
        slot: 'imageUrl',
        colProps: {
          span: 24
        }
      },
      {
        field: 'playOrder',
        component: 'ElInputNumber',
        label: '播放顺序',
        required: true,
        defaultValue: 1,
        componentProps: {
          style: { width: '250px' },
          min: 1,
          max: 9999,
          step: 1,
          stepStrictly: true
        },
        colProps: {
          span: 24
        }
      },
      {
        field: 'playTime',
        component: 'ElInputNumber',
        label: '播放时间(s)',
        required: true,
        defaultValue: 120,
        componentProps: {
          style: { width: '250px' },
          min: 1,
          max: 9999,
          step: 1,
          stepStrictly: true
        },
        colProps: {
          span: 24
        }
      },
      {
        field: 'refreshTime',
        component: 'ElInputNumber',
        label: '数据切换间隔(s)',
        required: true,
        defaultValue: 10,
        componentProps: {
          style: { width: '250px' },
          min: 1,
          max: 9999,
          step: 1,
          stepStrictly: true
        },
        colProps: {
          span: 24
        }
      },
      {
        field: 'orderStatus',
        component: 'ElSwitch',
        label: '启用状态',
        required: true,
        defaultValue: 1,
        componentProps: {
          activeValue: 1,
          inactiveValue: 2
        },
        colProps: {
          span: 24
        }
      },
      {
        field: 'dataDescribe',
        component: 'ElInput',
        label: '参数',
        componentProps: {
          type: 'textarea',
          placeholder: '如name=测试&value=1'
        },
        colProps: {
          span: 24
        }
      }
    ]
  })

const [registerModal, { closeModal, setModalProps }] = useModalInner(async (data) => {
  resetFields()
  setModalProps({ confirmLoading: false })
  isUpdate.value = !!data?.isUpdate
  fileList.value = []
  if (!unref(isUpdate)) {
    const { activeListItem, tableData } = data
    setFieldsValue({ menuTitle: activeListItem.value, menuName: activeListItem.key })
    const kanBanTypeList = (tableData as GetKanBanInfoModel[]).map((row) => row.kanBanType)
    const options = cloneDeep(kanbanTypeOptions).map((option) => ({
      ...option,
      disabled: kanBanTypeList.includes(option.value)
    }))

    updateSchema({
      field: 'kanBanType',
      componentProps: {
        options
      }
    })
  } else {
    const { row } = data
    rowId.value = row.id
    await setFieldsValue({ ...row })
    if (row.imageUrl) {
      fileList.value = row.imageUrl.map((url: string) => {
        return {
          name: getFileName(url),
          url: url,
          status: 'success'
        } as UploadUserFile
      })
    }
  }
})

const dialogImageUrl = ref('')
const dialogVisible = ref(false)

const handlePictureCardPreview: UploadProps['onPreview'] = (uploadFile) => {
  dialogImageUrl.value = uploadFile.url!
  dialogVisible.value = true
}

const upload = ref<UploadInstance>()
const fileList = ref<UploadUserFile[]>()

const getFileName = (fileUrl: string) => {
  const arr = fileUrl.split('\\')
  const length = arr.length
  return arr[length - 1]
}

const handleUploadRemove: UploadProps['onRemove'] = () => {
  setFieldsValue({ imageUrl: fileList.value?.map((item) => item.url) || [] })
}

const handleUploadBefore = () => {
  fileList.value?.forEach((file) => {
    if (file.status !== 'success') {
      if (file.size! / 1024 / 1024 > 10) {
        file.status = 'fail'
        throw Error('文件：' + file.name + '，超过10MB')
      }
    }
  })
}

const handleUpload = async () => {
  const formData = new FormData()
  fileList.value?.forEach((item) => {
    if (item.status !== 'success') {
      formData.append('picture', item.raw as File)
    }
  })
  if (formData.getAll('picture').length === 0) {
    return
  }
  const { code, data, message } = await importCustomImage(formData)
  if (code === 200) {
    data.forEach((item) => {
      const index = fileList.value!.findIndex((file) => item.regionName === file.name)
      if (index !== -1) {
        fileList.value![index].status = 'success'
        fileList.value![index].url = item.fileName
      }
    })
    await setFieldsValue({ imageUrl: fileList.value!.map((item) => item.url) })
  } else {
    throw Error(message)
  }
}

// 提交
const handleSubmit = async () => {
  await validate()
  try {
    setModalProps({ confirmLoading: true })
    handleUploadBefore()
    await handleUpload()
    // 新增
    if (!unref(isUpdate)) {
      const formData = getFieldsValue() as AddKanBanInfoData

      const data = {
        ...formData
      }
      const { code, message } = await addKanBanInfo(data)
      if (code === 200) {
        closeModal()
        ElMessage.success('新增成功')
        emit('success')
      } else {
        ElMessage.error(message)
      }
    } else {
      const formData = getFieldsValue() as Omit<UpdateKanBanInfoData, 'id'>
      const data = {
        id: unref(rowId),
        ...formData
      }
      const { code, message } = await updateKanBanInfo(data)

      if (code === 200) {
        closeModal()
        ElMessage.success('修改成功')
        emit('success')
      } else {
        ElMessage.error(message)
      }
    }
  } catch (error: any) {
    ElMessage.error(error.message)
  } finally {
    setModalProps({ confirmLoading: false })
  }
}
</script>

<style lang="scss" scoped></style>
