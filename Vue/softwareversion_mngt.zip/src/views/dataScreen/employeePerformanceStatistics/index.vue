<template>
  <div class="project-production-progress-container">
    <div id="project-production-progress-screen" class="data-screen-container">
      <div class="data-screen-header">
        <div class="data-screen-title">{{ $dayjs().format('M') }}月员工绩效统计</div>
        <div class="clock-container">{{ time }}</div>
      </div>

      <div class="data-screen-main">
        <div class="main-left">
          <swiper
            class="swiper"
            :centeredSlides="true"
            :spaceBetween="30"
            :virtual="true"
            :modules="[Autoplay, Virtual]"
            :autoplay="{
              delay: DATASCREEN_CONFIG.interval,
              disableOnInteraction: false
            }"
          >
            <swiper-slide
              class="swiper-slide"
              v-for="(performanceCalendarCarousel, index) in performanceCalendarCarouselData"
              :key="index"
              :virtualIndex="index"
            >
              <div class="employee-performance-calendar-container">
                <template
                  v-for="employeePerformanceCalendarData in performanceCalendarCarousel"
                  :key="employeePerformanceCalendarData"
                >
                  <EmployeePerformanceCalendar :data="employeePerformanceCalendarData" />
                </template>
              </div>
            </swiper-slide>
          </swiper>
        </div>
        <div class="main-right">
          <HonorRanking :data="honorRankingData" />
          <EnhanceRanking :data="enhanceRankingData" />
        </div>
      </div>
    </div>
  </div>
</template>

<script lang="ts" setup>
import type {
  EmployeePerformanceCalendarData,
  HonorAndEnhanceRankingData
} from './components/types'

import { ref, onMounted, watch, nextTick, onBeforeUnmount } from 'vue'
import dayjs from 'dayjs'
import { useUrlSearchParams } from '@vueuse/core'
import { Swiper, SwiperSlide } from 'swiper/vue'

// Import Swiper styles
import 'swiper/css'

import 'swiper/css/pagination'
import 'swiper/css/navigation'
import 'swiper/css/virtual'

// import Swiper core and required modules
import { Autoplay, Virtual } from 'swiper/modules'

import { useKeepFit } from '@/hooks/useKeepFit'
import { connection } from '@/utils/signalr'
import EmployeePerformanceCalendar from './components/EmployeePerformanceCalendar.vue'
import HonorRanking from './components/HonorRanking.vue'
import EnhanceRanking from './components/EnhanceRanking.vue'
import { chunkArray } from '@/utils'
import { DATASCREEN_CONFIG } from '@/constant'

defineOptions({
  name: 'EmployeePerformanceStatistics',
  inheritAttrs: false
})
const query = useUrlSearchParams('hash')
const performanceCalendarCarouselData = ref<EmployeePerformanceCalendarData[][]>([])

const honorRankingData = ref<Omit<HonorAndEnhanceRankingData, 'honorType'>[]>()
const enhanceRankingData = ref<Omit<HonorAndEnhanceRankingData, 'honorType'>[]>()

type GroupedData = { [key: number]: Omit<HonorAndEnhanceRankingData, 'honorType'>[] }

let clock: number
const time = ref<string>()

const getTime = () => {
  time.value = dayjs().format('YYYY-MM-DD dddd HH:mm:ss')
  clock = setInterval(() => {
    time.value = dayjs().format('YYYY-MM-DD dddd HH:mm:ss')
  }, 1000)
}

connection.on('GetPersonnelPerformance', (data: EmployeePerformanceCalendarData[]) => {
  performanceCalendarCarouselData.value = chunkArray(data, 4)
})

connection.on('GetHonorRoll', (data: HonorAndEnhanceRankingData[]) => {
  const result: GroupedData = data.reduce((pre, cur) => {
    const { honorType, ...rest } = cur
    if (!pre[honorType]) {
      pre[honorType] = []
    }
    pre[honorType].push(rest)
    return pre
  }, {} as GroupedData)
  honorRankingData.value = result[1]
  enhanceRankingData.value = result[2]
})

const stopSend = async () => {
  clearInterval(clock)

  await connection.invoke('StopSendDynamicMessageToAllClientsAsync')
}

watch(
  () => query.positionAddress,
  (newPositionAddress) => {
    if (newPositionAddress) {
      nextTick(() => {
        connection.invoke(
          'SendDynamicMessageToAllClientsAsync',
          'PersonnelPerformanceRedisKey',
          newPositionAddress
        )
      })
    }
  },
  {
    immediate: true
  }
)

onMounted(() => {
  useKeepFit({
    dw: 1920,
    dh: 1080,
    el: '#project-production-progress-screen'
  })
  getTime()
})

onBeforeUnmount(() => {
  stopSend()
})
// onActivated(() => {
//   connection.invoke(
//     'SendDynamicMessageToAllClientsAsync',
//     'PersonnelPerformanceRedisKey',
//     query.positionAddress
//   )
// })

// onDeactivated(() => {
//   stopSend()
// })
</script>

<style lang="scss" scoped>
.project-production-progress-container {
  height: 100%;
  width: 100%;

  .data-screen-container {
    background: url('@/assets/png/data-screen-background.png') no-repeat;
    background-size: 100% 100%;
    display: flex;
    flex-direction: column;
    position: relative;

    height: 100%;
    .data-screen-header {
      background: url('@/assets/png/data-screen-header.png') no-repeat;
      background-size: 100% 100%;
      height: 135px;

      display: flex;
      flex-direction: column;
      .data-screen-title {
        margin-top: 23px;
        font-size: 40px;
        font-weight: 900;
        letter-spacing: 9px;
        color: rgba(255, 255, 255, 1);

        display: flex;
        justify-content: center;
        user-select: none;
      }
      .clock-container {
        position: absolute;
        right: 8.48%;
        top: 5.74%;
        height: 21px;

        font-size: 14px;
        font-weight: 700;
        color: rgba(50, 197, 255, 1);
        user-select: none;
      }
    }

    .data-screen-main {
      flex: 1;
      padding: 32px 36px 48px 38px;

      display: flex;
      overflow: hidden;
      gap: 24px;

      .main-left {
        flex: 1;

        overflow: hidden;

        display: flex;
        .swiper {
          flex: 1;
          width: 0;
          display: flex;
        }

        .employee-performance-calendar-container {
          flex: 1;
          display: grid;
          grid-template-columns: 1fr 1fr;
          grid-template-rows: 1fr 1fr;
          gap: 54px 36px;
        }
      }
      .main-right {
        width: 31.25%;
        height: 100%;

        display: flex;
        flex-direction: column;
        gap: 24px;
        overflow: hidden;
      }
    }
  }
}
</style>
