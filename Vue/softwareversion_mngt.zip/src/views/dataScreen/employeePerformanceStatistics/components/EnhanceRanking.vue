<template>
  <div class="enhance-ranking-container">
    <div class="enhance-ranking-header">
      <div class="title">提升榜</div>
    </div>
    <div class="enhance-ranking-main">
      <div class="enhance-employee-card">
        <div class="enhance-employee-info">
          <div class="user-info">
            <span class="name">{{ data[0]?.employeeName }}</span>
            <span class="group">{{ data[0]?.departmentName }}</span>
          </div>
          <div class="user-story">
            {{ data[0]?.dataDescribe }}
          </div>
        </div>

        <div class="img-container">
          <el-image v-if="data[0]?.imageUrl" :src="data[0]?.imageUrl" fit="cover" />
        </div>
      </div>
    </div>
  </div>
</template>

<script lang="ts" setup>
import type { PropType } from 'vue'
import type { HonorAndEnhanceRankingData } from './types'

defineProps({
  data: {
    type: Array as PropType<Omit<HonorAndEnhanceRankingData, 'honorType'>[]>,
    default: () => {
      return []
    }
  }
})
</script>

<style lang="scss" scoped>
.enhance-ranking-container {
  height: 27.31%;
  background: url('@/assets/png/data-screen-box-600x238.png') no-repeat;
  background-size: 100% 100%;
  overflow: hidden;

  display: flex;
  flex-direction: column;
  font-family: 思源黑体;
  .enhance-ranking-header {
    height: 36px;

    display: flex;
    justify-content: center;
    align-items: center;

    .title {
      font-size: 14px;
      font-weight: 700;
      color: rgba(25, 236, 255, 1);
    }
  }

  .enhance-ranking-main {
    flex: 1;
    height: 0;
    overflow: hidden;
    padding: 16px 24px 24px 24px;
    display: flex;
    gap: 24px;
    .enhance-employee-card {
      background: url('@/assets/png/data-screen-inner-box-552x159.png') no-repeat;
      background-size: 100% 100%;
      flex: 1;
      width: 0;

      width: 552px;
      height: 159px;

      display: flex;
      gap: 24px;

      overflow: hidden;

      .enhance-employee-info {
        margin: 16px 0 16px 24px;
        flex: 1;
        width: 0;
        display: flex;
        flex-direction: column;
        overflow: hidden;

        .user-info {
          color: rgba(255, 255, 255, 1);
          .name {
            font-size: 14px;
            font-weight: 700;
          }
          .group {
            margin-left: 8px;
            font-size: 12px;
            font-weight: 400;
          }
        }
        .user-story {
          margin-top: 8px;
          flex: 1;

          font-size: 12px;
          line-height: 24px;
          color: rgba(255, 255, 255, 1);
        }
      }

      .img-container {
        padding: 24px 24px 24px 0;
        width: 36.9%;
        height: 100%; /* 容器高度 */
        overflow: hidden; /* 隐藏超出容器的部分 */
        display: flex;
        .el-image {
          flex: 1;
        }
      }
    }
  }
}
</style>
