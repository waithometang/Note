export interface EmployeePerformanceCalendarData {
  /**
   * 考核人
   */
  assessorName: string
  /**
   * 被考核人ID
   */
  beAssessorID: string
  /**
   * 员工头像Url，如果为空则显示默认头像
   */
  employeeImageUrl: string
  /**
   * 员工姓名
   */
  employeeInfoName: string
  /**
   * 员工月内绩效数据
   */
  employeePerformanceReportList: EmployeePerformanceReportList[]
  /**
   * 组别名称
   */
  groupName: string
  /**
   * 当前月份
   */
  month: number
  /**
   * 岗位名称
   */
  positionName: string
  /**
   * 月绩效总分
   */
  sumPerformanceMark: number
}

/**
 * 没有绩效数据则当天显示0
 */
export interface EmployeePerformanceReportList {
  /**
   * 日期数，天
   */
  day: number
  /**
   * 绩效分数
   */
  performanceMark: number
}



export interface HonorAndEnhanceRankingData {
    /**
     * 事迹
     */
    dataDescribe: string;
    /**
     * 部门名称
     */
    departmentName: string;
    /**
     * 员工名称
     */
    employeeName: string;
    /**
     * 类型(1：荣誉榜；2：提升榜)
     */
    honorType: number;
    /**
     * 事迹图片Url，没有图片需显示默认图片
     */
    imageUrl: null | string;
}
