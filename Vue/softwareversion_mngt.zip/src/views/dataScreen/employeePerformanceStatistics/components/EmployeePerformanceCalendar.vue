<template>
  <div class="calendar-container">
    <div class="calender-header">
      <div class="avatar-container">
        <img v-if="data.employeeImageUrl" :src="data.employeeImageUrl" />
        <svg-icon v-else icon="empty-avatar" style="font-size: 31px" />
      </div>
      <div class="employee-info-container">
        <div class="info-card">
          <div class="label">组别</div>
          <div class="value">{{ data.groupName }}</div>
        </div>

        <div class="info-card">
          <div class="label">岗位</div>
          <div class="value">{{ data.positionName }}</div>
        </div>

        <div class="info-card">
          <div class="label">月份</div>
          <div class="value">{{ data.month }}</div>
        </div>
        <div class="info-card">
          <div class="label">姓名</div>
          <div class="value">{{ data.employeeInfoName }}</div>
        </div>
        <div class="info-card">
          <div class="label">考核人</div>
          <div class="value">{{ data.assessorName }}</div>
        </div>
        <div class="info-card">
          <div class="label">积分</div>
          <div class="value">{{ data.sumPerformanceMark }}</div>
        </div>
      </div>
    </div>
    <el-calendar v-model="value">
      <template #header>
        <div></div>
      </template>

      <template #date-cell="{ data }">
        <div class="date-cell-container">
          <div class="day">{{ $dayjs(data.day).format('D') }}</div>
          <div class="points" :class="getPointsClass(data.day)">{{ getPoints(data.day) }}</div>
        </div>
      </template>
    </el-calendar>
  </div>
</template>

<script lang="ts" setup>
import type { PropType } from 'vue'
import type { EmployeePerformanceCalendarData } from './types'

import { ref } from 'vue'
import dayjs from 'dayjs'

const props = defineProps({
  data: {
    type: Object as PropType<EmployeePerformanceCalendarData>,
    default: () => {
      return {}
    }
  }
})

const value = ref(new Date())

const getPoints = (day: string) => {
  const dayFormat = Number(dayjs(day).format('D'))

  const employeePerformanceReportList = props.data.employeePerformanceReportList

  const item = employeePerformanceReportList.find((item) => item.day === dayFormat)
  return item?.performanceMark
}
const getPointsClass = (day: string) => {
  const dayFormat = Number(dayjs(day).format('D'))

  const employeePerformanceReportList = props.data.employeePerformanceReportList

  const item = employeePerformanceReportList.find((item) => item.day === dayFormat)
  item?.performanceMark

  switch (item?.performanceMark) {
    case 3:
      return 'date-cell-excellent'
    case 1:
      return 'date-cell-good'
    case 0:
      return 'date-cell-ordinary'
    case -3:
      return 'date-cell-unqualified'

    default:
      return ''
  }
}
</script>

<style lang="scss" scoped>
.calendar-container {
  background: url('@/assets/png/data-screen-employee-performance-box.png');
  background-size: 100% 100%;

  padding: 20px;

  .calender-header {
    height: 68px;

    display: flex;
    .avatar-container {
      width: 66px;
      background: rgba(20, 35, 77, 1);
      display: flex;
      justify-content: center;
      align-items: center;
      overflow: hidden;
      img {
        flex: 1;
        height: 100%;

        object-fit: fill;
      }
    }

    .employee-info-container {
      margin-left: 12px;

      flex: 1;
      color: #fff;

      display: grid;
      grid-template-rows: auto auto; /* 定义两行 */
      grid-template-columns: auto auto auto; /* 定义三列 */
      gap: 12px; /* 设置网格间距 */

      .info-card {
        background: rgba(47, 85, 143, 0.3);

        border: 2px solid rgba(61, 127, 255, 0.3);

        display: flex;
        align-items: center;
        font-size: 12px;
        line-height: 12px;
        padding-left: 8px;
        .label {
          color: rgba(255, 255, 255, 0.6);
        }
        .value {
          margin-left: 8px;
          color: rgba(255, 255, 255, 1);
        }
      }
    }
  }

  .el-calendar {
    background-color: unset;
    :deep(.el-calendar-table) {
      td {
        border: none;
      }
    }

    :deep(.el-calendar__header) {
      display: none;
    }
    :deep(.el-calendar__body) {
      padding: 0;

      th {
        /** 文本1 */
        font-size: 12px;
        font-weight: 400;
        color: rgba(255, 255, 255, 0.6);

        padding: 6px 0 0 0;
      }

      th,
      td {
        user-select: none;
      }

      td.is-today {
        color: unset;
      }

      td.is-selected {
        background-color: unset;
      }

      th::before {
        content: '周';
      }

      .el-calendar-day {
        padding: 6px;

        display: flex;
        align-items: center;
        justify-content: center;
        height: 54px;
        .date-cell-container {
          flex: 1;

          background: rgba(47, 85, 143, 0.3);
          border: 2px solid rgba(61, 127, 255, 0.3);

          display: flex;
          justify-content: space-between;
          padding: 8px;
          .day {
            color: #6f738b;
            display: flex;
            align-items: center;
          }
          .points {
            width: 24px;
            height: 24px;
            border-radius: 4px;

            color: #fff;

            display: flex;
            justify-content: center;
            align-items: center;
          }

          .date-cell-excellent {
            background: rgba(60, 177, 251, 1);
            box-shadow: 0px 0px 4px rgba(60, 177, 251, 0.8);
          }
          .date-cell-good {
            background: rgba(33, 116, 255, 1);
            box-shadow: 0px 0px 4px rgba(33, 116, 255, 0.8);
          }
          .date-cell-ordinary {
            background: rgba(61, 86, 133, 1);
            background: rgba(150, 199, 255, 0.31);
          }
          .date-cell-unqualified {
            background: rgba(251, 110, 119, 1);
            box-shadow: 0px 0px 4px rgba(251, 110, 119, 1);
          }
        }
      }
      .el-calendar-table .el-calendar-day:hover {
        cursor: pointer;
        background-color: unset;
      }
      .el-calendar-table:not(.is-range) td.current {
      }

      .el-calendar-table:not(.is-range) td.prev,
      .el-calendar-table:not(.is-range) td.next {
        pointer-events: none;

        border: none;
      }

      td.prev,
      td.next {
        .el-calendar-day {
          .date-cell-container {
            background: rgba(47, 85, 143, 0.1);
            border: 2px solid rgba(61, 127, 255, 0.1);

            .points {
              display: none;
            }
          }
        }
      }
    }
  }
}
</style>
