<template>
  <div class="honor-ranking-container">
    <div class="honor-ranking-header">
      <div class="title">光荣榜</div>
    </div>

    <div class="honor-ranking-main">
      <div class="honor-employee-card">
        <div class="honor-employee-info">
          <div class="user-info">
            <span class="name">{{ data[0]?.employeeName }}</span>
            <span class="group">{{ data[0]?.departmentName }}</span>
          </div>
          <div class="user-story">
            {{ data[0]?.dataDescribe }}
          </div>
        </div>

        <div class="img-container">
          <el-image v-if="data[0]?.imageUrl" :src="data[0]?.imageUrl" fit="cover" />
        </div>
      </div>

      <div class="honor-employee-card">
        <div class="honor-employee-info">
          <div class="user-info">
            <span class="name">{{ data[1]?.employeeName }}</span>
            <span class="group">{{ data[1]?.departmentName }}</span>
          </div>
          <div class="user-story">
            {{ data[1]?.dataDescribe }}
          </div>
        </div>

        <div class="img-container">
          <el-image v-if="data[1]?.imageUrl" :src="data[1]?.imageUrl" fit="cover" />
        </div>
      </div>

      <div class="honor-employee-card">
        <div class="honor-employee-info">
          <div class="user-info">
            <span class="name">{{ data[2]?.employeeName }}</span>
            <span class="group">{{ data[2]?.departmentName }}</span>
          </div>
          <div class="user-story">
            {{ data[2]?.dataDescribe }}
          </div>
        </div>

        <div class="img-container">
          <el-image v-if="data[2]?.imageUrl" :src="data[2]?.imageUrl" fit="cover" />
        </div>
      </div>
    </div>
  </div>
</template>

<script lang="ts" setup>
import type { PropType } from 'vue'
import type { HonorAndEnhanceRankingData } from './types'

defineProps({
  data: {
    type: Array as PropType<Omit<HonorAndEnhanceRankingData, 'honorType'>[]>,
    default: () => {
      return []
    }
  }
})
</script>

<style lang="scss" scoped>
.honor-ranking-container {
  flex: 1;
  height: 0;
  width: 100%;
  background: url('@/assets/png/data-screen-box-600x604.png') no-repeat;
  background-size: 100% 100%;

  display: flex;
  flex-direction: column;
  font-family: 思源黑体;

  .honor-ranking-header {
    height: 36px;

    display: flex;
    justify-content: center;
    align-items: center;

    .title {
      font-size: 14px;
      font-weight: 700;
      color: rgba(25, 236, 255, 1);
    }
  }

  .honor-ranking-main {
    height: 0;
    flex: 1;

    padding: 16px 24px 24px 24px;
    display: flex;
    flex-direction: column;
    gap: 24px;

    overflow: hidden;
    .honor-employee-card {
      background: url('@/assets/png/data-screen-inner-box-552x159.png') no-repeat;
      background-size: 100% 100%;

      width: 552px;
      height: 159px;

      flex: 1;
      height: 0;
      width: 100%;
      display: flex;
      gap: 24px;

      .honor-employee-info {
        margin: 16px 0 16px 24px;
        width: 58.3%;
        display: flex;
        flex-direction: column;

        .user-info {
          color: rgba(255, 255, 255, 1);
          .name {
            font-size: 14px;
            font-weight: 700;
          }
          .group {
            margin-left: 8px;
            font-size: 12px;
            font-weight: 400;
          }
        }
        .user-story {
          margin-top: 8px;
          flex: 1;
          height: 0;

          font-size: 12px;
          line-height: 24px;
          color: rgba(255, 255, 255, 1);
        }
      }

      .img-container {
        padding: 24px 24px 24px 0;
        width: 36.9%;
        height: 100%; /* 容器高度 */
        overflow: hidden; /* 隐藏超出容器的部分 */

        display: flex;
        .el-image {
          flex: 1;
        }
      }
    }
  }
}
</style>
