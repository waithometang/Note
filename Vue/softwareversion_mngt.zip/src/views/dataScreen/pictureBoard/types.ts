export interface PictureListModel {
  imageUrl: string[]
  refreshTime: number
}
