<template>
  <div class="picture-board">
    <template v-for="(pic, index) in pictureList" :key="pic">
      <Transition>
        <img :src="pic" v-show="picIndex === index" class="pic" />
      </Transition>
    </template>
  </div>
</template>

<script setup lang="ts">
import type { PictureListModel } from './types'
import { connection } from '@/utils/signalr'
import { useUrlSearchParams } from '@vueuse/core'
import { ref, onBeforeUnmount, watch, nextTick } from 'vue'

const query = useUrlSearchParams('hash')

const pictureList = ref<string[]>([])

let picIndex = ref(0)

let timer: any

watch(
  () => query.positionAddress,
  (newPositionAddress) => {
    if (newPositionAddress) {
      nextTick(() => {
        connection.invoke(
          'SendDynamicMessageToAllClientsAsync',
          'CustomImageRedisKey',
          newPositionAddress
        )
      })
    }
  },
  {
    immediate: true
  }
)

connection.on('GetCustomImage', (data: string) => {
  const res = JSON.parse(data) as PictureListModel[]
  pictureList.value = res[0].imageUrl
  console.log(res)

  const len = pictureList.value.length
  const time = res[0].refreshTime * 1000
  clearInterval(timer)
  picIndex.value = 0
  timer = setInterval(() => {
    picIndex.value++
    picIndex.value === len && (picIndex.value = 0)
  }, time)
})

onBeforeUnmount(() => {
  connection.off('GetCustomImage')
  connection.invoke('StopSendDynamicMessageToAllClientsAsync')
  clearInterval(timer)
})
</script>

<style scoped lang="scss">
.picture-board {
  width: 100%;
  height: 100%;
  .pic {
    display: block;
    font-size: 0;
    width: 100%;
    height: 100%;
    border-radius: 8px;object-fit: contain;
  }
}

.v-enter-active,
.v-leave-active {
  transition: opacity 0.5s ease;
}
.v-enter-from,
.v-leave-to {
  opacity: 0;
}
</style>
