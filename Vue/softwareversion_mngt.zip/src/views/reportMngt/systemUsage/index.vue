<template>
  <div class="page-container">
    <div class="box system-usage-wrapper">
      <GridHeader ref="gridHeaderRef" v-bind="headerOptions" @quickSearch="handleQuickSearch" />
      <el-tabs v-model="activeName">
        <el-tab-pane
          v-for="item in tabMap"
          :key="item.name"
          :label="item.label"
          :name="item.name"
          lazy
        >
          <Component
            :is="item.comp"
            :ref="getRefs"
            :quickSearchForm="quickSearchForm"
            :name="item.name"
          />
        </el-tab-pane>
      </el-tabs>
    </div>
  </div>
</template>

<script setup lang="ts">
import type { ComponentExposed } from 'vue-component-type-helpers'
import type { GridHeaderProps } from '@/components/Table/types/gridHeader'
import type { GetSystemUsageParams } from '@/api/sys/model/reportMngtModel'

import { reactive, ref, computed } from 'vue'
import GridHeader from '@/components/Table/GridHeader.vue'

import AttendanceTable from './components/AttendanceTable.vue'
import OtherDispatchTable from './components/OtherDispatchTable.vue'
import OtherWorkReportTable from './components/OtherWorkReportTable.vue'
import ProductivityTable from './components/ProductivityTable.vue'
import SecondmentTable from './components/SecondmentTable.vue'
import WorkDispatchEmployeeeTable from './components/WorkDispatchEmployeeeTable.vue'
import WorkErrorReportTable from './components/WorkErrorReportTable.vue'
import WorkReportTable from './components/WorkReportTable.vue'
import { exportSystemUsage } from '@/api/sys/reportMngt'
import dayjs from 'dayjs'

defineOptions({
  name: 'SystemUsage',
  inheritAttrs: false
})

const activeName = ref('attendance')

const tabMap: { [key: string]: any } = {
  attendance: {
    ins: {},
    comp: AttendanceTable,
    label: '考勤登记',
    name: 'attendance'
  },
  secondment: {
    ins: {},
    comp: SecondmentTable,
    label: '人员借调',
    name: 'secondment'
  },
  workDispatchEmployee: {
    ins: {},
    comp: WorkDispatchEmployeeeTable,
    label: '组内派工',
    name: 'workDispatchEmployee'
  },
  otherDispatch: {
    ins: {},
    comp: OtherDispatchTable,
    label: '其他派工',
    name: 'otherDispatch'
  },
  workReport: {
    ins: {},
    comp: WorkReportTable,
    label: '生产报工',
    name: 'workReport'
  },
  otherWorkReport: {
    ins: {},
    comp: OtherWorkReportTable,
    label: '其他报工',
    name: 'otherWorkReport'
  },
  workErrorReport: {
    ins: {},
    comp: WorkErrorReportTable,
    label: '生产异常反馈',
    name: 'workErrorReport'
  },
  productivity: {
    ins: {},
    comp: ProductivityTable,
    label: '生产绩效',
    name: 'productivity'
  }
}

const getRefs = (tableRef: any) => {
  if (tableRef) {
    tabMap[tableRef.name].ins = tableRef
  }
}

const gridHeaderRef =
  ref<ComponentExposed<typeof GridHeader<GetSystemUsageParams, 'BegTime' | 'EndTime'>>>()

const headerOptions = reactive<GridHeaderProps>({
  title: '系统使用情况',
  quickSearch: {
    fieldMapToTime: ['time', ['BegTime', 'EndTime'], 'YYYY-MM-DD'],
    singleSearch: {
      field: 'time',
      type: 'date',
      title: '日期',
      componentProps: {
        type: 'daterange',
        valueFormat: 'YYYY-MM-DD'
      }
    },
    searchFormFields: { time: [dayjs().format('YYYY-MM-DD'), dayjs().format('YYYY-MM-DD')] }
  },
  showAdvancedSearchButton: false,
  showAddButton: false,
  showExportButton: true,
  exportApi: exportSystemUsage,
  exportParams: computed(() => {
    return { ...quickSearchForm.value }
  })
})

const quickSearchForm = computed(() => {
  return gridHeaderRef.value?.quickSearchForm
})

const handleQuickSearch = () => {
  const tabName = activeName.value
  tabMap[tabName].ins?.handleQuickSearch()
}
</script>

<style scoped lang="scss">
.system-usage-wrapper {
  height: 100%;
  display: flex;
  flex-direction: column;
  .table-wrapper {
    flex: 1;
    overflow: hidden;
  }
  .el-tabs {
    flex: 1;
    display: flex;
    flex-direction: column;
    overflow: hidden;
    :deep(.el-tabs__content) {
      flex: 1;
      display: flex;
      flex-direction: column;
      overflow: hidden;
      .el-tab-pane {
        flex: 1;
        display: flex;
        flex-direction: column;
        overflow: hidden;
      }
    }
  }
}
</style>
