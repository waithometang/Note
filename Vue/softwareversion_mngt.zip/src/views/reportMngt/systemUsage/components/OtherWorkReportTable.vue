<template>
  <vxe-grid ref="gridRef" v-bind="gridOptions"> </vxe-grid>
</template>

<script setup lang="ts">
import type { GetSystemUsageParams } from '@/api/sys/model/reportMngtModel'
import type { PropType } from 'vue'
import type { VxeGridInstance, VxeGridProps } from 'vxe-table'

import { getReportWorkOtherSystemUsage } from '@/api/sys/reportMngt'
import { reactive, ref } from 'vue'
import dayjs from 'dayjs'

const props = defineProps({
  quickSearchForm: {
    type: Object as PropType<Pick<GetSystemUsageParams, 'BegTime' | 'EndTime'>>,
    default: () => {}
  },
  name: {
    type: String,
    default: ''
  }
})

const gridRef = ref<VxeGridInstance>()
const gridOptions = reactive<VxeGridProps>({
  border: true,
  height: 'auto',
  align: null,
  columnConfig: {
    resizable: true
  },
  columns: [
    { type: 'seq', width: 50 },
    { field: 'departmentName', title: '部门', minWidth: 100 },
    { field: 'groupName', title: '班组', minWidth: 100 },
    { field: 'groupLeaderName', title: '班组长姓名', minWidth: 100 },
    {
      field: 'time',
      title: '日期',
      minWidth: 100,
      formatter({ cellValue }) {
        return dayjs(cellValue).format('YYYY-MM-DD')
      }
    },
    { field: 'departmentReportWorkHours', title: '部门报工工时', minWidth: 130 },
    { field: 'groupReportWorkHoursr', title: '班组报工工时', minWidth: 130 }
  ],
  pagerConfig: {
    enabled: true,
    pageSize: 20
  },
  proxyConfig: {
    ajax: {
      query: ({ page }) => {
        return getReportWorkOtherSystemUsage({
          pageIndex: page.currentPage - 1, // 由于后端接口限制，首页从0开始
          pageSize: page.pageSize,
          ...props.quickSearchForm
        })
      }
    }
  }
})

const handleQuickSearch = () => {
  gridRef.value?.commitProxy('reload')
}

defineExpose({ handleQuickSearch, ...props })
</script>

<style scoped lang="scss"></style>
