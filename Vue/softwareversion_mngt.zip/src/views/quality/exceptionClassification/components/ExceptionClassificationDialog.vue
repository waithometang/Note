<template>
  <BasicModal
    width="556px"
    v-bind="$attrs"
    @register="registerModal"
    :title="getTitle"
    @confirm="handleSubmit"
  >
    <BasicForm @register="registerForm"> </BasicForm>
  </BasicModal>
</template>

<script setup lang="ts">
import type { AddExceptionTypeData, UpdateExceptionTypeData } from '@/api/sys/model/qualityModel'
import type { ModalMethods } from '@/components/Modal/types'

import { ref, unref, computed } from 'vue'

import BasicModal from '@/components/Modal/BasicModal.vue'
import BasicForm from '@/components/Form/BasicForm.vue'

import { useModalInner } from '@/components/Modal/hooks/useModal'
import { useForm } from '@/components/Form/hooks/useForm'
import { addExceptionType, updateExceptionType } from '@/api/sys/quality'
import { getKeyValueByClassify } from '@/api/sys/basic'

const emit = defineEmits<{
  register: [modalMethods: ModalMethods, uuid: number]
  success: [{ isUpdate: boolean }]
}>()
const isUpdate = ref<boolean>(false)

const rowId = ref<string>('')

const getTitle = computed(() => (!unref(isUpdate) ? '新增' : '修改'))

const [registerForm, { setFieldsValue, resetFields, getFieldsValue, validate, clearValidate }] =
  useForm({
    labelWidth: 86,
    schemas: [
      {
        field: 'exceptionTypeID',
        component: 'ApiSelect',
        label: '异常类型',
        rules: [{ required: true, trigger: 'change' }],
        dynamicDisabled() {
          return unref(isUpdate)
        },
        componentProps: {
          api: getKeyValueByClassify,
          resultField: 'data',
          labelField: 'value',
          valueField: 'id',
          params: { typeName: 'BasicExceptionType' }
        }
      },
      {
        field: 'exceptionName',
        component: 'ElInput',
        label: '异常项',
        rules: [{ required: true, trigger: 'blur' }],
        componentProps: {}
      }
    ]
  })

const [registerModal, { setModalProps }] = useModalInner(async (data) => {
  await resetFields()
  setModalProps({ confirmLoading: false })
  isUpdate.value = !!data?.isUpdate

  if (unref(isUpdate)) {
    rowId.value = data.row.id
    await setFieldsValue({ ...data.row })
  }
  clearValidate()
})

// 提交
const handleSubmit = async () => {
  await validate()
  setModalProps({ confirmLoading: true })
  try {
    // 新增
    if (!unref(isUpdate)) {
      const formData = getFieldsValue() as AddExceptionTypeData

      const data = {
        ...formData
      }
      const { code, message } = await addExceptionType(data)
      if (code === 200) {
        ElMessage.success('新增成功')
        emit('success', { isUpdate: unref(isUpdate) })
      } else {
        ElMessage.error(message)
      }
    } else {
      const formData = getFieldsValue() as Omit<UpdateExceptionTypeData, 'id'>
      const data = {
        id: unref(rowId),
        ...formData
      }
      const { code, message } = await updateExceptionType(data)

      if (code === 200) {
        ElMessage.success('修改成功')
        emit('success', { isUpdate: unref(isUpdate) })
      } else {
        ElMessage.error(message)
      }
    }
  } catch (error: any) {
    ElMessage(error.message)
  } finally {
    setModalProps({ confirmLoading: false })
  }
}
</script>
<style lang="scss" scoped></style>
