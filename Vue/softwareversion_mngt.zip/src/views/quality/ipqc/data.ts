export const resultConfirmOptions = [
  { label: '延迟', value: 1, type: 'warning' },
  { label: '进行', value: 2, type: '' },
  { label: '关闭', value: 3, type: 'info' },
  { label: '持续', value: 4, type: '' },
  { label: 'OK', value: 5, type: 'success' }
]
export const severityOptions = [
  { label: '低', value: 1 },
  { label: '中', value: 2 },
  { label: '高', value: 3 }
]

export const PASS = 1
export const UNPASS = -1

export const resultOptions = [
  { label: '不合格', value: UNPASS },
  { label: '合格', value: PASS }
]
