<template>
  <BasicModal
    width="70%"
    top="10vh"
    v-bind="$attrs"
    @register="registerModal"
    :title="getTitle"
    heigth="70%"
    @confirm="handleSubmit"
    @close="() => (rowId = '')"
  >
    <div style="height: 65vh; overflow-y: scroll">
      <el-scrollbar>
        <BasicForm @register="registerForm"> </BasicForm>
        <el-collapse v-model="collapseName">
          <el-collapse-item name="checkResult">
            <template #title>
              <span class="collapse-title">校验结果</span>
              <svg-icon class="collapse-title-icon" icon="fold" />
            </template>
            <BasicForm @register="registerFormCheckResult"> </BasicForm>
          </el-collapse-item>
          <el-collapse-item name="problemDesc">
            <template #title>
              <span class="collapse-title">问题描述</span>
              <svg-icon class="collapse-title-icon" icon="fold" />
            </template>
            <BasicForm @register="registerFormProblemDesc"> </BasicForm>
          </el-collapse-item>
          <el-collapse-item name="solution">
            <template #title>
              <span class="collapse-title">解决方案</span>
              <svg-icon class="collapse-title-icon" icon="fold" />
            </template>
            <BasicForm @register="registerFormSolution"> </BasicForm>
          </el-collapse-item>
        </el-collapse>
      </el-scrollbar>
    </div>
    <el-dialog v-model="dialogVisible">
      <img
        style="display: block; margin: 0 auto; max-width: 100%"
        :src="dialogImageUrl"
        alt="Preview Image"
      />
    </el-dialog>
  </BasicModal>
</template>

<script setup lang="tsx">
import type { ADDIPQCData, GetIPQCModel, UpdateIPQCData } from '@/api/sys/model/qualityModel'
import type { ModalMethods } from '@/components/Modal/types'

import { ref, unref, computed, toRaw } from 'vue'
import dayjs from 'dayjs'

import BasicModal from '@/components/Modal/BasicModal.vue'
import BasicForm from '@/components/Form/BasicForm.vue'

import { useModalInner } from '@/components/Modal/hooks/useModal'
import { useForm } from '@/components/Form/hooks/useForm'

import {
  getKeyValueByClassify,
  getProductionProjectSelect,
  getGroupSelect,
  getDepartment
} from '@/api/sys/basic'
import { addIPQC, getExceptionByTypeID, updateIPQC } from '@/api/sys/quality'
import { getProductionProjectAppointData } from '@/api/sys/scheduling'

import { ElUpload, type UploadProps } from 'element-plus'
import { round } from 'xe-utils'
import { resultConfirmOptions, resultOptions, severityOptions, PASS, UNPASS } from '../data'
import { cloneDeep, floor, uniqBy } from 'lodash-es'
import useUserStore from '@/stores/user'
import type { GetProductionProjectAppointDataModel } from '@/api/sys/model/schedulingModel'

const emit = defineEmits<{
  register: [modalMethods: ModalMethods, uuid: number]
  success: [{ isUpdate: boolean }]
}>()
const isUpdate = ref<boolean>(false)

const rowId = ref<string>('')
const getTitle = computed(() => (!unref(isUpdate) ? '新增' : '修改'))

const appStore = useUserStore()

const productionProjectAppointData = ref<GetProductionProjectAppointDataModel[]>()

//
let getProductionProjectAppointDataResolve: (value?: unknown) => void
let getProductionProjectAppointDataReject: (reason?: any) => void
const getProductionProjectAppointDataPromise = () => {
  return new Promise((resolve, reject) => {
    getProductionProjectAppointDataResolve = resolve
    getProductionProjectAppointDataReject = reject
  })
}

let getWoNoDataResolve: (value?: unknown) => void
let getWoNoDataReject: (reason?: any) => void
const getWoNoDataPromise = () => {
  return new Promise((resolve, reject) => {
    getWoNoDataResolve = resolve
    getWoNoDataReject = reject
  })
}

const handleUpdateSchema = async () => {
  await updateSchema([
    { field: 'productCheckName', componentProps: { options: [] } },
    { field: 'woNo', componentProps: { options: [] } }
  ])
  await updateSchemaCheckResult([{ field: 'groupID', componentProps: { options: [] } }])
  await updateSchemaProblemDesc([{ field: 'exceptionTypeID', componentProps: { options: [] } }])
}

const handleResetFiles = async () => {
  await resetFields()
  await resetFieldsCheckResult()
  await resetFieldsProblemDesc()
  await resetFieldsSolution()
}
const handleValidate = async () => {
  await Promise.all([validate(), validateCheckResult(), validateProblemDesc(), validateSolution()])
}

const handleClearValidate = async () => {
  clearValidate()
  clearValidateCheckResult()
  clearValidateProblemDesc()
  clearValidateSolution()
}

const handleSetFieldsValue = async (data: GetIPQCModel) => {
  data.ipqcSplitData.problemImagePath =
    (data.ipqcSplitData.problemImagePath as string[])?.map((item: string) => ({
      url: item,
      name: item.split('\\').reverse()[0]
    })) || []

  data.ipqcSplitData.effectImagePath =
    (data.ipqcSplitData.effectImagePath as string[])?.map((item: string) => ({
      url: item,
      name: item.split('\\').reverse()[0]
    })) || []

  await setFieldsValue({ ...data, ...data.ipqcSplitData })
  await setFieldsValueCheckResult({
    ...data,
    ...data.ipqcSplitData,
    takeTime: data.ipqcSplitData.takeTime
      ? data.ipqcSplitData.takeTime + 'h'
      : data.ipqcSplitData.takeTime
  })
  await setFieldsValueProblemDesc({
    ...data,
    ...data.ipqcSplitData
  })
  await setFieldsValueSolution({
    ...data,
    ...data.ipqcSplitData
  })
}

const handleGetFieldsValue = () => {
  return {
    ...getFieldsValue(),
    ...getFieldsValueCheckResult(),
    ...getFieldsValueProblemDesc(),
    ...getFieldsValueSolution()
  }
}

const collapseName = ref('checkResult')

const [registerModal, { setModalProps }] = useModalInner(async (data) => {
  await handleUpdateSchema()
  await handleResetFiles()
  isUpdate.value = !!data?.isUpdate

  collapseName.value = 'checkResult'

  setModalProps({ confirmLoading: false })

  if (unref(isUpdate)) {
    await handleSetFieldsValue(cloneDeep(data.row))
    rowId.value = data.row.id
  }
  handleClearValidate()
})

const labelWidth = 120

const [
  registerForm,
  { setFieldsValue, resetFields, getFieldsValue, updateSchema, validate, clearValidate }
] = useForm({
  labelWidth: labelWidth,
  schemas: [
    {
      field: 'projectID',
      component: 'ApiSelect',
      label: '项目',
      rules: [{ required: true, trigger: 'change' }],
      dynamicDisabled() {
        return !!isUpdate.value
      },
      componentProps: {
        api: getProductionProjectSelect,
        valueField: 'id',
        labelField: 'projectName',
        resultField: 'data.result',
        async onChange(projectID: string) {
          if (!isUpdate.value) {
            setFieldsValue({
              productCheckName: void 0
            })
            updateSchema({
              field: 'productCheckName',
              componentProps: {
                options: []
              }
            })
          }

          try {
            const { code, data } = await getProductionProjectAppointData({ projectID })
            if (code === 200) {
              productionProjectAppointData.value = data.result
              updateSchema({
                field: 'productCheckName',
                componentProps: {
                  options: uniqBy(productionProjectAppointData.value, 'orderProductName')
                }
              })
            }
            getProductionProjectAppointDataResolve()
            getWoNoDataResolve()
          } catch (error) {
            getProductionProjectAppointDataReject('getProductionProjectAppointDataReject')
            getWoNoDataReject('getWoNoDataReject')
          }
        }
      },
      colProps: {
        span: 8
      }
    },
    {
      field: 'productCheckName',
      component: 'Select',
      label: '设备名称',
      rules: [{ required: true, trigger: 'change' }],
      dynamicDisabled() {
        return !!isUpdate.value
      },
      componentProps: {
        options: [],
        valueField: 'orderProductName',
        labelField: 'orderProductName',
        async onChange(productCheckName: string) {
          if (isUpdate.value && !productionProjectAppointData.value) {
            await getProductionProjectAppointDataPromise()
          }
          const options = toRaw(
            productionProjectAppointData.value?.filter(
              (item) => item.orderProductName === productCheckName
            ) || []
          )
          if (!isUpdate.value) {
            setFieldsValue({
              woNo: void 0
            })
          }

          updateSchema({
            field: 'woNo',
            componentProps: {
              options: options || []
            }
          })
        }
      },
      colProps: {
        span: 8
      }
    },
    {
      field: 'woNo',
      component: 'Select',
      label: '单据编码',
      rules: [{ required: true, trigger: 'change' }],
      dynamicDisabled() {
        return !!isUpdate.value
      },
      componentProps: {
        options: [],
        valueField: 'woNo',
        labelField: 'woNo',
        async onChange(woNo: string) {
          if (isUpdate.value && !productionProjectAppointData.value) {
            await getWoNoDataPromise()
          }
          const row = productionProjectAppointData.value!.find((item) => item.woNo === woNo)

          setFieldsValue({
            productName: row?.productName,
            materialNo: row?.materialNo,
            itemFormAttribute: row?.itemFormAttribute
          })

          setFieldsValueCheckResult({ productionOrderNum: row?.productionOrderNumber })

          if (!isUpdate.value) {
            setFieldsValue({
              groupID: void 0
            })
            updateSchemaCheckResult({ field: 'groupID', componentProps: { options: [] } })
          }
          if (row) {
            const { code, data } = await getGroupSelect({ departmentID: row!.departmentID })
            if (code === 200) {
              await updateSchemaCheckResult({
                field: 'groupID',
                componentProps: { options: data.result }
              })
            }
          }
        }
      },
      colProps: {
        span: 8
      }
    },
    {
      field: 'productName',
      component: 'ElInput',
      label: '部件名称',
      componentProps: { disabled: true },
      colProps: {
        span: 8
      }
    },
    {
      field: 'materialNo',
      component: 'ElInput',
      label: '料号',
      componentProps: { disabled: true },
      colProps: {
        span: 8
      }
    },
    {
      field: 'itemFormAttribute',
      component: 'ElInput',
      label: '料品类型',
      componentProps: { disabled: true },
      colProps: {
        span: 8
      }
    },
    {
      field: 'productCheckItem',
      component: 'ElInput',
      label: '检验项',
      rules: [{ required: true }],
      componentProps: {},
      colProps: {
        span: 8
      }
    }
  ]
})

const [
  registerFormCheckResult,
  {
    setFieldsValue: setFieldsValueCheckResult,
    resetFields: resetFieldsCheckResult,
    getFieldsValue: getFieldsValueCheckResult,
    updateSchema: updateSchemaCheckResult,
    validate: validateCheckResult,
    clearValidate: clearValidateCheckResult
  }
] = useForm({
  labelWidth: labelWidth,
  schemas: [
    {
      field: 'checkMethodID',
      component: 'ApiSelect',
      label: '检验方式',
      rules: [{ required: true, trigger: 'change' }],
      componentProps: {
        api: getKeyValueByClassify,
        valueField: 'id',
        labelField: 'value',
        resultField: 'data',
        params: { typeName: 'QCTestingType' }
      },
      colProps: {
        span: 8
      }
    },
    {
      field: 'productionOrderNum',
      component: 'ElInput',
      label: '订单数量',
      componentProps: { disabled: true },
      colProps: {
        span: 8
      }
    },
    {
      field: 'checkNum',
      component: 'ElInputNumber',
      label: '检验数量',
      rules: [{ required: true, trigger: 'blur' }],
      defaultValue: 1,
      componentProps: {
        step: 1,
        min: 1,
        max: 9999,
        stepStrictly: true,
        onChange() {
          const data = getFieldsValueCheckResult() as ADDIPQCData
          const rejectRate = (data['rejectNum'] / data['checkNum']) * 100
          setFieldsValueCheckResult({ rejectRate: round(rejectRate, 0) + '%' })
        }
      },
      colProps: {
        span: 8
      }
    },
    {
      field: 'rejectNum',
      component: 'ElInputNumber',
      label: '不良数量',
      rules: [{ required: true, trigger: 'blur' }],
      defaultValue: 0,
      componentProps: ({ formModel }: { formModel: ADDIPQCData }) => {
        return {
          step: 1,
          min: 0,
          max: formModel.checkNum,
          stepStrictly: true,
          onChange(rejectNum: number) {
            const rejectRate = (rejectNum / formModel['checkNum']) * 100
            setFieldsValueCheckResult({
              rejectRate: round(rejectRate, 0) + '%',
              result: rejectNum > 0 ? UNPASS : PASS
            })
          }
        }
      },
      colProps: {
        span: 8
      }
    },
    {
      field: 'rejectRate',
      component: 'ElInput',
      label: '不良率',
      defaultValue: '0%',
      componentProps: {
        disabled: true,
        style: { textAlign: 'center' }
      },
      colProps: {
        span: 8
      }
    },
    {
      field: 'result',
      component: 'Select',
      label: '判定结果',
      defaultValue: PASS,
      componentProps: {
        disabled: true,
        options: resultOptions,
        onChange(result: number) {
          if (!isUpdate.value || rowId.value) {
            console.log(rowId.value)
            setFieldsValueCheckResult({ resultConfirm: result === UNPASS ? '' : 5 })
          }

          updateSchemaSolution({
            field: 'temporarySolution',
            rules: [{ required: result === UNPASS }]
          })

          updateSchemaProblemDesc([
            {
              field: 'ipqcProblemStageID',
              rules: [{ required: result === UNPASS }]
            },
            {
              field: 'checkEmployeeID',
              rules: [{ required: result === UNPASS }]
            },
            {
              field: 'resultDate',
              rules: [{ required: result === UNPASS }]
            },
            {
              field: 'ipqcProblemCategoryID',
              rules: [{ required: result === UNPASS }]
            },
            {
              field: 'exceptionTypeID',
              rules: [{ required: result === UNPASS }]
            },
            {
              field: 'severity',
              rules: [{ required: result === UNPASS }]
            },
            {
              field: 'exceptionDescription',
              rules: [{ required: result === UNPASS }]
            }
          ])
        }
      },
      colProps: {
        span: 8
      }
    },
    {
      field: 'productionAddressID',
      component: 'ApiSelect',
      label: '检验区域',
      rules: [{ required: true, trigger: 'change' }],
      componentProps: {
        api: getKeyValueByClassify,
        valueField: 'id',
        labelField: 'value',
        resultField: 'data',
        params: { typeName: 'PositionAddress' }
      },
      colProps: {
        span: 8
      }
    },
    {
      field: 'exceptionClassifyID',
      component: 'ApiSelect',
      label: '责任归类',
      dynamicRules({ model }) {
        return [{ required: model.result === UNPASS, trigger: 'change', message: '请选择责任区分' }]
      },
      componentProps: {
        api: getKeyValueByClassify,
        valueField: 'id',
        labelField: 'value',
        resultField: 'data',
        params: { typeName: 'BasicExceptionType' },
        async onChange(exceptionClassifyID: string) {
          if (exceptionClassifyID) {
            const { code, data } = await getExceptionByTypeID({
              exceptionTypeID: exceptionClassifyID
            })
            if (code === 200) {
              updateSchemaProblemDesc({
                field: 'exceptionTypeID',
                componentProps: { options: data }
              })
            }
          } else {
            updateSchemaProblemDesc({ field: 'exceptionTypeID', componentProps: { options: [] } })
          }
        }
      },
      colProps: {
        span: 8
      }
    },
    {
      field: 'dutyDepartmentID',
      component: 'ApiCascader',
      label: '责任部门',
      dynamicRules({ model }) {
        return [{ required: model.result === UNPASS, trigger: 'change', message: '请选择责任部门' }]
      },
      componentProps: {
        api: getDepartment,
        resultField: 'data.result',
        labelField: 'departmentName',
        valueField: 'id',
        childrenField: 'sonData',
        props: {
          checkStrictly: true,
          emitPath: false
        }
      },
      colProps: {
        span: 8
      }
    },
    {
      field: 'dutyEmployeeName',
      component: 'ElInput',
      label: '责任人',
      dynamicRules({ model }) {
        return [{ required: model.result === UNPASS, trigger: 'blur', message: '请输入责任人' }]
      },
      colProps: {
        span: 8
      }
    },
    {
      field: 'effectConfirmEmployeeName',
      component: 'ElInput',
      label: '效果确认人',
      // dynamicRules({ model }) {
      //   return [{ required: model.result === UNPASS, trigger: 'blur', message: '请输入效果确认人' }]
      // },
      colProps: {
        span: 8
      }
    },
    {
      field: 'groupID',
      component: 'Select',
      label: '组别',
      rules: [{ required: true, trigger: 'change' }],
      componentProps: {
        options: []
      },
      colProps: {
        span: 8
      }
    },
    {
      field: 'plannedCompletionTime',
      component: 'ElDatePicker',
      label: '预计完成时间',
      // dynamicRules({ model }) {
      //   return [
      //     { required: model.result === UNPASS, trigger: 'change', message: '请选择预计完成时间' }
      //   ]
      // },
      componentProps({ formModel }) {
        return {
          type: 'datetime',
          valueFormat: 'YYYY-MM-DD HH:mm',
          format: 'YYYY-MM-DD HH:mm',
          onChange(plannedCompletionTime: string) {
            if (formModel['actualCompletionTime']) {
              const takeTime = dayjs
                .duration(
                  dayjs(formModel['actualCompletionTime']).diff(dayjs(plannedCompletionTime))
                )
                .as('hour')
              setFieldsValueCheckResult({ takeTime: floor(takeTime, 1) + 'h' })
            }
          }
        }
      },
      colProps: {
        span: 8
      }
    },
    {
      field: 'actualCompletionTime',
      component: 'ElDatePicker',
      label: '实际完成时间',
      // dynamicRules({ model }) {
      //   return [
      //     { required: model.result === UNPASS, trigger: 'change', message: '请选择实际完成时间' }
      //   ]
      // },
      componentProps({ formModel }) {
        return {
          type: 'datetime',
          valueFormat: 'YYYY-MM-DD HH:mm',
          format: 'YYYY-MM-DD HH:mm',
          onChange(actualCompletionTime: string) {
            if (formModel['plannedCompletionTime']) {
              const takeTime = dayjs
                .duration(
                  dayjs(actualCompletionTime).diff(dayjs(formModel['plannedCompletionTime']))
                )
                .as('hour')
              setFieldsValueCheckResult({ takeTime: floor(takeTime, 1) + 'h' })
            }
          }
        }
      },
      colProps: {
        span: 8
      }
    },
    {
      field: 'takeTime',
      component: 'ElInput',
      label: '工时损耗',
      componentProps: { disabled: true },
      colProps: {
        span: 8
      }
    },
    {
      field: 'resultConfirm',
      component: 'Select',
      label: '状态',
      rules: [{ required: true, trigger: 'change' }],
      defaultValue: 5,
      componentProps: {
        options: resultConfirmOptions
      },
      colProps: {
        span: 8
      }
    },
    {
      field: 'dataDescribe',
      component: 'ElInput',
      label: '备注',
      colProps: {
        span: 16
      }
    }
  ]
})

const [
  registerFormProblemDesc,
  {
    setFieldsValue: setFieldsValueProblemDesc,
    resetFields: resetFieldsProblemDesc,
    getFieldsValue: getFieldsValueProblemDesc,
    updateSchema: updateSchemaProblemDesc,
    validate: validateProblemDesc,
    clearValidate: clearValidateProblemDesc
  }
] = useForm({
  labelWidth: labelWidth,
  schemas: [
    {
      field: 'ipqcProblemStageID',
      component: 'ApiSelect',
      label: '发生阶段',
      componentProps: {
        api: getKeyValueByClassify,
        valueField: 'id',
        labelField: 'value',
        resultField: 'data',
        params: { typeName: 'IPQCProblemStage' }
      },
      colProps: {
        span: 8
      }
    },
    {
      field: 'checkEmployeeID',
      component: 'PersonSelect',
      label: '提出人',
      componentProps: {},
      colProps: {
        span: 8
      }
    },
    {
      field: 'resultDate',
      component: 'ElDatePicker',
      label: '提出时间',
      componentProps: {
        type: 'datetime',
        valueFormat: 'YYYY-MM-DD HH:mm',
        format: 'YYYY-MM-DD HH:mm'
      },
      colProps: {
        span: 8
      }
    },
    {
      field: 'ipqcProblemCategoryID',
      component: 'ApiSelect',
      label: '问题类别',
      componentProps: {
        api: getKeyValueByClassify,
        valueField: 'id',
        labelField: 'value',
        resultField: 'data',
        params: { typeName: 'IPQCProblemCategory' }
      },
      colProps: {
        span: 8
      }
    },
    {
      field: 'exceptionTypeID',
      component: 'Select',
      label: '异常项',
      componentProps: {
        options: [],
        valueField: 'id',
        labelField: 'name'
      },
      colProps: {
        span: 8
      }
    },
    {
      field: 'severity',
      component: 'Select',
      label: '严重度',
      componentProps: {
        options: severityOptions
      },
      colProps: {
        span: 8
      }
    },
    {
      field: 'exceptionDescription',
      component: 'ElInput',
      label: '问题描述',
      componentProps: {
        type: 'textarea'
      },
      colProps: {
        span: 24
      }
    },
    {
      field: 'problemImagePath',
      component: 'ElInput',
      label: '图示',
      render({ model, field }) {
        return (
          <el-upload
            ref={problemImagePathRef}
            v-model:file-list={model[field]}
            list-type="picture"
            accept=".jpg,.jpeg,.png"
            action="/api/IPQC/ImportIPQCImage"
            name="picture"
            headers={{ Authorization: appStore.token }}
            multiple={true}
            before-upload={handleBeforeUpload}
            on-preview={handlePictureCardPreview}
            on-progress={() => {
              problemImagePathLoading.value = true
            }}
            on-success={() => {
              problemImagePathLoading.value = false
            }}
            on-error={() => {
              problemImagePathLoading.value = false
            }}
          >
            {{
              default: () => (
                <el-button type="primary" loading={problemImagePathLoading.value}>
                  点击上传
                </el-button>
              ),
              tip: () => <div class="el-upload__tip">只能上传jpg/png文件，且不超过3MB</div>
            }}
          </el-upload>
        )
      },
      colProps: {
        span: 12
      }
    }
  ]
})

const [
  registerFormSolution,
  {
    setFieldsValue: setFieldsValueSolution,
    resetFields: resetFieldsSolution,
    getFieldsValue: getFieldsValueSolution,
    updateSchema: updateSchemaSolution,
    validate: validateSolution,
    clearValidate: clearValidateSolution
  }
] = useForm({
  labelWidth: labelWidth,
  schemas: [
    {
      field: 'reasonAnalyze',
      component: 'ElInput',
      label: '原因分析',
      componentProps: {
        type: 'textarea'
      }
    },
    {
      field: 'temporarySolution',
      component: 'ElInput',
      label: '临时解决方案',
      componentProps: {
        type: 'textarea'
      }
    },
    {
      field: 'longTermSolution',
      component: 'ElInput',
      label: '长期解决方案',
      componentProps: {
        type: 'textarea'
      }
    },
    {
      field: 'effectImagePath',
      component: 'ElInput',
      label: '图示',
      render({ model, field }) {
        return (
          <el-upload
            ref={effectImagePathRef}
            v-model:file-list={model[field]}
            list-type="picture"
            accept=".jpg,.jpeg,.png"
            action="/api/IPQC/ImportIPQCImage"
            name="picture"
            headers={{ Authorization: appStore.token }}
            multiple={true}
            before-upload={handleBeforeUpload}
            on-preview={handlePictureCardPreview}
            on-progress={() => {
              effectImagePathLoading.value = true
            }}
            on-success={() => {
              effectImagePathLoading.value = false
            }}
            on-error={() => {
              effectImagePathLoading.value = false
            }}
          >
            {{
              default: () => (
                <el-button type="primary" loading={effectImagePathLoading.value}>
                  点击上传
                </el-button>
              ),
              tip: () => <div class="el-upload__tip">只能上传jpg/png文件，且不超过3MB</div>
            }}
          </el-upload>
        )
      }
    }
  ]
})

const problemImagePathRef = ref<InstanceType<typeof ElUpload>>()
const effectImagePathRef = ref<InstanceType<typeof ElUpload>>()

const problemImagePathLoading = ref(false)
const effectImagePathLoading = ref(false)

const handleBeforeUpload: UploadProps['beforeUpload'] = (rawFile) => {
  const { size } = rawFile
  if (size > 1024 * 1024 * 3) {
    ElMessage.warning('只能上传jpg/png文件，且不超过3MB')
    return false
  }
  return true
}

const dialogImageUrl = ref('')
const dialogVisible = ref(false)

const handlePictureCardPreview: UploadProps['onPreview'] = (uploadFile) => {
  dialogImageUrl.value = uploadFile.url!
  dialogVisible.value = true
}

// 提交
const handleSubmit = async () => {
  if (problemImagePathLoading.value || effectImagePathLoading.value) {
    ElMessage.warning('请等待图片上传完成后提交')
    return
  }

  await handleValidate()

  const formData = handleGetFieldsValue()
  const allData = {
    ...handleGetFieldsValue(),
    rejectRate: Number(formData.rejectRate?.split('%')[0]),
    takeTime: Number(formData.takeTime?.split('h')[0]),
    problemImagePath: formData.problemImagePath?.map((item: any) => {
      return unref(item).response?.data?.fileName || unref(item).url
    }),
    effectImagePath: formData.effectImagePath?.map((item: any) => {
      return unref(item).response?.data?.fileName || unref(item).url
    })
  }
  try {
    // 新增
    if (!unref(isUpdate)) {
      const { code, message } = await addIPQC(allData as ADDIPQCData)
      if (code === 200) {
        ElMessage.success('新增成功')
        emit('success', { isUpdate: unref(isUpdate) })
      } else {
        ElMessage.error(message)
      }
    } else {
      const updateData = {
        id: unref(rowId),
        ...allData
      } as UpdateIPQCData
      const { code, data, message } = await updateIPQC(updateData)

      if (code === 200) {
        if (data) {
          ElMessage.success('修改成功')
          emit('success', { isUpdate: unref(isUpdate) })
          return
        }
      }
      ElMessage.error(message)
    }
  } catch (error: any) {
    ElMessage(error.message)
  }
}
</script>

<style lang="scss" scoped>
.el-form {
  margin-right: 20px;
}

.collapse-title {
  font-weight: 700;
  font-size: 14px;
  margin-right: 5px;
}
.collapse-title-icon {
  font-size: 18px;
}
</style>
