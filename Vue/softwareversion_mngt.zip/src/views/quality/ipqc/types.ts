interface CachePnameVO {
  ptype: string
  pnameList: GetKeyValueModel[]
}

interface GetKeyValueModel {
  keyValueClassifyID?: string
  id: string
  value: string
}
