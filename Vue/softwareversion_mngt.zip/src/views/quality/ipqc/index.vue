<template>
  <div class="page-container">
    <div class="table-container box">
      <vxe-grid ref="gridRef" v-bind="gridOptions" v-on="gridEvents">
        <template #top>
          <GridHeader
            ref="gridHeaderRef"
            v-bind="headerOptions"
            @quickSearch="handleQuickSearch"
            @advancedSearch="handleAdvancedSearch"
            @add="handleAdd"
            @reset="handleReset"
          >
          </GridHeader>
        </template>
        <template #resultConfirm="{ row }">
          <el-tag :type="getResultConfirmStatusInfo(row.ipqcSplitData?.resultConfirm).type">
            {{ getResultConfirmStatusInfo(row.ipqcSplitData?.resultConfirm).text }}
          </el-tag>
        </template>
        <template #result="{ row }">
          <el-tag :type="getResultStatusInfo(row.result).type">
            {{ getResultStatusInfo(row.result).text }}
          </el-tag>
        </template>
        <template #operation="{ row }">
          <TableAction
            :actions="[
              {
                icon: 'edit',
                tooltip: '编辑',
                onClick: handleModify.bind(null, row)
              },
              {
                icon: 'delete',
                tooltip: '删除',
                onClick: handleDelete.bind(null, row)
              }
            ]"
          />
        </template>
      </vxe-grid>
    </div>
    <div class="box descriptions-container">
      <div class="title">问题描述</div>
      <div style="height: 100%; overflow-y: scroll">
        <el-descriptions :column="4">
          <el-descriptions-item width="25%" label="检验项：">{{
            testSituation?.productCheckItem
          }}</el-descriptions-item>
          <el-descriptions-item width="25%" label="料号：">{{
            testSituation?.materialNo
          }}</el-descriptions-item>
          <el-descriptions-item width="25%" label="料品类型：">{{
            testSituation?.itemFormAttribute
          }}</el-descriptions-item>
          <el-descriptions-item width="25%" label="问题发生阶段：">{{
            testSituation?.ipqcProblemStageName
          }}</el-descriptions-item>
          <el-descriptions-item width="25%" label="问题类别：">{{
            testSituation?.ipqcProblemCategoryName
          }}</el-descriptions-item>
          <el-descriptions-item width="25%" label="异常项：">{{
            testSituation?.exceptionTypeName
          }}</el-descriptions-item>
          <el-descriptions-item width="25%" label="严重度：">{{
            severityOptions.find((item) => item.value === testSituation?.severity)?.label
          }}</el-descriptions-item>
          <el-descriptions-item width="25%" label="问题描述：">{{
            testSituation?.exceptionDescription
          }}</el-descriptions-item>
        </el-descriptions>
      </div>
      <div class="title">解决方案</div>
      <div style="height: 100%; overflow-y: scroll">
        <el-descriptions :column="1">
          <el-descriptions-item label="原因分析：">{{
            testSituation?.reasonAnalyze
          }}</el-descriptions-item>
          <el-descriptions-item label="提临时解决方案：">{{
            testSituation?.temporarySolution
          }}</el-descriptions-item>
          <el-descriptions-item label="长期时解决方案：">{{
            testSituation?.longTermSolution
          }}</el-descriptions-item>
        </el-descriptions>
      </div>
      <div class="title">校验方法</div>
      <div style="height: 100%; overflow-y: scroll">
        <el-descriptions :column="4">
          <el-descriptions-item width="25%" label="校验方式：">{{
            testSituation?.checkMethodName
          }}</el-descriptions-item>
          <el-descriptions-item width="25%" label="校验区域：">{{
            testSituation?.productionAddressName
          }}</el-descriptions-item>
          <el-descriptions-item width="25%" label="责任归类：">{{
            testSituation?.exceptionClassifyName
          }}</el-descriptions-item>
          <el-descriptions-item width="25%" label="责任部门：">{{
            testSituation?.dutyDepartmentName
          }}</el-descriptions-item>
          <el-descriptions-item width="25%" label="责任人：">{{
            testSituation?.dutyEmployeeName
          }}</el-descriptions-item>
          <el-descriptions-item width="25%" label="效果确认人：">{{
            testSituation?.effectConfirmEmployeeName
          }}</el-descriptions-item>
          <el-descriptions-item width="25%" label="预计完成时间：">{{
            testSituation?.plannedCompletionTime
          }}</el-descriptions-item>
          <el-descriptions-item width="25%" label="实际完成时间：">{{
            testSituation?.actualCompletionTime
          }}</el-descriptions-item>
          <el-descriptions-item width="25%" label="工时损耗：">{{
            testSituation?.takeTime ? testSituation?.takeTime + 'h' : testSituation?.takeTime
          }}</el-descriptions-item>
          <el-descriptions-item width="25%" label="状态：">
            <el-tag
              v-if="testSituation"
              :type="getResultConfirmStatusInfo(testSituation.resultConfirm).type"
            >
              {{ getResultConfirmStatusInfo(testSituation.resultConfirm).text }}
            </el-tag>
          </el-descriptions-item>
          <el-descriptions-item width="25%" label="备注：">{{
            testSituation?.dataDescribe
          }}</el-descriptions-item>
        </el-descriptions>
      </div>
    </div>
  </div>
  <IPQCDialog @register="registerModal" @success="handleSuccess" />
</template>

<script setup lang="ts">
import type { ComponentExposed } from 'vue-component-type-helpers'
import type { VxeGridInstance, VxeGridProps, VxeGridListeners } from 'vxe-table'
import type { GridHeaderProps } from '@/components/Table/types/gridHeader'
import type { GetIPQCModel, IpqcSplitData } from '@/api/sys/model/qualityModel'

import { reactive, ref, computed, toRaw } from 'vue'
import { getProductionProjectSelect, getKeyValue } from '@/api/sys/basic'
import { getIPQC, deleteIPQC, exportIPQC } from '@/api/sys/quality'
import { getProductionWoList } from '@/api/sys/work'

import { useModal } from '@/components/Modal/hooks/useModal'

import GridHeader from '@/components/Table/GridHeader.vue'
import IPQCDialog from './components/IPQCDialog.vue'
import { dateShortcuts } from '@/constant'
import { resultConfirmOptions, severityOptions } from './data'

defineOptions({
  name: 'IPQC',
  inheritAttrs: false
})

const gridHeaderRef = ref<ComponentExposed<typeof GridHeader>>()

const headerOptions = reactive<GridHeaderProps>({
  title: '巡检记录',
  quickSearch: {
    singleSearch: {
      field: 'woNo',
      type: 'input',
      title: '单据编号'
    },
    searchFormFields: { woNo: '' }
  },
  advancedSearch: {
    labelWidth: 120,
    fieldMapToTime: [['resultDate', ['StartResultDate', 'EndResultDate'], 'YYYY-MM-DD']],
    schemas: [
      {
        field: 'projectID',
        component: 'ApiSelect',
        label: '项目名称',
        componentProps: {
          api: getProductionProjectSelect,
          resultField: 'data.result',
          labelField: 'projectName',
          valueField: 'id'
        },
        colProps: { span: 8 }
      },
      {
        field: 'woNo',
        component: 'ApiSelect',
        label: '单据编号',
        componentProps: {
          api: getProductionWoList,
          resultField: 'data',
          labelField: 'name',
          valueField: 'name'
        },
        colProps: { span: 8 }
      },
      {
        field: 'productionAddressID',
        component: 'ApiSelect',
        label: '检验区域',
        componentProps: {
          api: getKeyValue,
          resultField: 'data.result',
          labelField: 'value',
          valueField: 'id',
          params: {
            typeName: 'PositionAddress'
          }
        },
        colProps: { span: 8 }
      },
      {
        field: 'productName',
        component: 'ElInput',
        label: '部件名称',
        componentProps: {},
        colProps: { span: 8 }
      },
      {
        field: 'materialNo',
        component: 'ElInput',
        label: '异常物料号',
        componentProps: {},
        colProps: { span: 8 }
      },
      {
        field: 'result',
        component: 'Select',
        label: '判定结果',
        componentProps: {
          options: [
            { label: '不合格', value: -1 },
            { label: '合格', value: 1 }
          ]
        },
        colProps: { span: 8 }
      },
      {
        field: 'resultConfirm',
        component: 'Select',
        label: '结果确认',
        componentProps: {
          options: [
            { label: '未确认', value: 0 },
            { label: 'OK', value: 1 },
            { label: 'NG', value: 2 }
          ]
        },
        colProps: { span: 8 }
      },
      {
        field: 'resultDate',
        component: 'ElDatePicker',
        label: '日期',
        defaultValue: dateShortcuts[0].value(),
        componentProps: {
          type: 'daterange',
          unlinkPanels: true,
          shortcuts: dateShortcuts,
          valueFormat: 'YYYY-MM-DD'
        },
        colProps: { span: 8 }
      }
    ]
  },
  showExportButton: true,
  exportApi: exportIPQC,
  exportParams: computed(() => {
    const advancedSearchForm = gridHeaderRef.value?.advancedSearchForm
    const quickSearchForm = gridHeaderRef.value?.quickSearchForm
    return { ...quickSearchForm, ...advancedSearchForm }
  })
})

const getResultConfirmStatusInfo = computed(() => {
  const statusMap: { [key: number]: { text: string; type: string } } = {}

  resultConfirmOptions.forEach((item) => {
    statusMap[item.value] = { text: item.label, type: item.type }
  })

  return function (status: number) {
    return statusMap[status] || { text: '', color: '' }
  }
})

const getResultStatusInfo = computed(() => {
  const statusMap: { [key: number]: { text: string; type: string } } = {
    '-1': { text: '不合格', type: 'danger' },
    1: { text: '合格', type: 'success' }
  }

  return function (status: number) {
    return statusMap[status] || { text: '', color: '' }
  }
})

const gridRef = ref<VxeGridInstance>()
const gridOptions = reactive<VxeGridProps<GetIPQCModel>>({
  border: true,
  height: '550px',
  align: null,
  columnConfig: {
    resizable: true
  },
  columns: [
    { type: 'seq', width: 50 },
    { field: 'projectName', title: '项目', minWidth: 100 },
    { field: 'productCheckName', title: '设备名称', minWidth: 110 },
    { field: 'woNo', title: '单据编号', minWidth: 100 },
    { field: 'productName', title: '部件名称', minWidth: 100 },
    { field: 'checkEmployeeName', title: '问题提出人', minWidth: 120 },
    { field: 'resultDate', title: '提出时间', minWidth: 150 },
    { field: 'groupName', title: '组别', minWidth: 120 },
    // { field: 'productionAddressName', title: '检验区域', minWidth: 100 },
    // { field: 'checkMethodName', title: '检验方式', minWidth: 100 },
    { field: 'productionOrderNum', title: '订单数量', minWidth: 100 },
    { field: 'checkNum', title: '检验数', minWidth: 100 },
    { field: 'rejectNum', title: '不良数量', minWidth: 100 },
    { field: 'rejectRate', title: '不良率%', minWidth: 100 },
    {
      field: 'result',
      title: '判定',
      minWidth: 90,
      slots: { default: 'result' }
    },
    // {
    //   field: 'ipqcSplitData.resultConfirm',
    //   title: '结果确认',
    //   minWidth: 90,
    //   slots: { default: 'resultConfirm' }
    // },
    { field: 'resultConfirmName', title: '状态', minWidth: 100 },
    // { field: 'checkEmployeeName', title: '检验员', minWidth: 100 },
    {
      field: 'operation',
      title: '操作',
      align: 'center',
      fixed: 'right',
      width: 170,
      slots: {
        default: 'operation'
      }
    }
  ],
  pagerConfig: {
    enabled: true,
    pageSize: 10
  },
  proxyConfig: {
    ajax: {
      query: ({ page }) => {
        const quickSearchForm = gridHeaderRef.value?.quickSearchForm
        const advancedSearchForm = gridHeaderRef.value?.advancedSearchForm
        return getIPQC({
          pageIndex: page.currentPage - 1, // 由于后端接口限制，首页从0开始
          pageSize: page.pageSize,
          ...quickSearchForm,
          ...advancedSearchForm
        })
      }
    }
  }
})

const testSituation = ref<
  IpqcSplitData & { resultConfirm: number; dataDescribe: string; productCheckItem: string }
>()
const gridEvents = reactive<VxeGridListeners<GetIPQCModel>>({
  cellClick({ row }) {
    testSituation.value = {
      ...row.ipqcSplitData,
      resultConfirm: row.resultConfirm,
      dataDescribe: row.dataDescribe,
      productCheckItem: row.productCheckItem
    }
  }
})

const handleQuickSearch = () => {
  gridRef.value?.commitProxy('reload')
  testSituation.value = void 0
}

const handleAdvancedSearch = () => {
  gridRef.value?.commitProxy('reload')
  testSituation.value = void 0
}

const handleReset = () => {
  gridRef.value?.commitProxy('reload')
  testSituation.value = void 0
}

const [registerModal, { openModal, closeModal }] = useModal()

const handleAdd = () => {
  openModal(true, {
    isUpdate: false
  })
}

const handleModify = (row: GetIPQCModel) => {
  openModal(true, {
    isUpdate: true,
    row: toRaw(row)
  })
}

const handleDelete = (row: GetIPQCModel) => {
  ElMessageBox.confirm(`是否删除名称为"${row.productName}"的数据项`, '警告', {
    confirmButtonText: '确定',
    cancelButtonText: '取消',
    type: 'warning'
  }).then(() => {
    deleteIPQC({ id: row.id }).then((res) => {
      if (res.code === 200) {
        ElMessage.success('删除')
        gridRef.value?.commitProxy('query')
      } else {
        ElMessage.error(res.message)
      }
    })
  })
}

const handleSuccess = () => {
  gridRef.value?.commitProxy('query')
  testSituation.value = void 0
  closeModal()
}
</script>

<style scoped lang="scss">
.page-container {
  height: auto;
  // display: flex;
  // flex-direction: column;
  // gap: $margin;
  // box-sizing: border-box;
}
// .table-container {
//   flex: 1;
// }
.descriptions-container {
  // flex: 0 0 215px;
  margin-top: $margin;
  display: flex;
  flex-direction: column;
  gap: $margin;
  .title {
    font-weight: 700;
    padding-bottom: 10px;
    border-bottom: 1px #eee solid;
  }
}
:deep(.el-descriptions__label) {
  margin-right: 0;
}
</style>
