import { fileURLToPath, URL } from 'node:url'
import path from 'node:path'

import { defineConfig } from 'vite'
import vue from '@vitejs/plugin-vue'
import vueJsx from '@vitejs/plugin-vue-jsx'

import AutoImport from 'unplugin-auto-import/vite'
import Components from 'unplugin-vue-components/vite'
import { ElementPlusResolver } from 'unplugin-vue-components/resolvers'
import { createSvgIconsPlugin } from 'vite-plugin-svg-icons'

import viteCompression from 'vite-plugin-compression'

// https://vitejs.dev/config/
export default defineConfig({
  base: './',
  define: {
    __VUE_PROD_HYDRATION_MISMATCH_DETAILS__: true
  },
  build: {
    rollupOptions: {
      output: {
        chunkFileNames: 'js/[name]-[hash].js',
        entryFileNames: 'js/[name]-[hash].js',
        assetFileNames: '[ext]/[name]-[hash].[ext]'
      }
    }
  },
  resolve: {
    alias: {
      'vue-i18n': 'vue-i18n/dist/vue-i18n.cjs.js',
      '@': fileURLToPath(new URL('./src', import.meta.url))
    }
  },
  plugins: [
    vue(),
    vueJsx({}),
    AutoImport({
      resolvers: [ElementPlusResolver({ importStyle: 'sass' })]
    }),
    Components({ resolvers: [ElementPlusResolver({ importStyle: 'sass' })] }),
    createSvgIconsPlugin({
      // 指定需要缓存的图标文件夹
      iconDirs: [path.resolve(process.cwd(), 'src/assets/icons')],
      // 指定symbolId格式
      symbolId: 'icon-[name]'
    }),
    viteCompression({
      threshold: 1024 * 1000, // 对大于1mb的文件进行压缩
      verbose: true, // 控制台打印结果
      algorithm: 'gzip',
      ext: '.gz'
    })
  ],
  // css 预处理
  css: {
    preprocessorOptions: {
      scss: {
        // 覆盖element主题
        additionalData: `
          @use "@/styles/element/index.scss" as *; 
          @use "@/styles/variables.scss" as *;`
      }
    }
  },
  server: {
    port: 5173,
    hmr: true,
    host: '0.0.0.0',
    proxy: {
      // 测试cicd,
      '/api': {
        target: 'http://172.17.10.53:18792',
        changeOrigin: true
      },
      '/sso': {
        target: 'http://172.17.10.147:8440/api',
        changeOrigin: true,
        rewrite: (path) => path.replace(/^\/sso/, '')
      },
      '/PushDataHubService': {
        target: 'http://172.17.10.53:18792',
        ws: true,
        changeOrigin: true
      }
    }
  }
})
