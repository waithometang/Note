export interface AdvanceState {
  isAdvanced: boolean;
  hideAdvanceBtn: boolean;
  isLoad: boolean;
  actionSpan: number;
}
