<template>
  <Col v-bind="actionColOpt" v-if="showActionButtonGroup">
    <div style="width: 100%" :style="{ textAlign: actionColOpt.style.textAlign }">
      <Form.Item>
        <slot name="resetBefore"></slot>
        <Button
          type="default"
          class="mr-2"
          v-bind="getResetBtnOptions"
          @click="resetAction"
          v-if="showResetButton"
        >
          {{ getResetBtnOptions.text }}
        </Button>
        <slot name="submitBefore"></slot>

        <Button
          type="primary"
          class="mr-2"
          v-bind="getSubmitBtnOptions"
          @click="submitAction"
          v-if="showSubmitButton"
        >
          {{ getSubmitBtnOptions.text }}
        </Button>

        <slot name="advanceBefore"></slot>
        <Button
          type="link"
          size="small"
          @click="toggleAdvanced"
          v-if="showAdvancedButton && !hideAdvanceBtn"
        >
          {{ isAdvanced ? t('component.form.putAway') : t('component.form.unfold') }}
          <BasicArrow class="ml-1" :expand="!isAdvanced" up />
        </Button>
        <slot name="advanceAfter"></slot>
      </Form.Item>
    </div>
  </Col>
</template>
<script lang="ts" setup>
  import type { ColEx } from '../types';
  import { computed, PropType } from 'vue';
  import { Form, Col } from 'ant-design-vue';
  import { Button, ButtonProps } from '@/components/Button';
  import { BasicArrow } from '@/components/Basic';
  import { useFormContext } from '../hooks/useFormContext';
  import { useI18n } from '@/hooks/web/useI18n';
  import { propTypes } from '@/utils/propTypes';

  defineOptions({ name: 'BasicFormAction' });

  const props = defineProps({
    // 显示按钮群组
    showActionButtonGroup: propTypes.bool.def(true),
    // 显示重置按钮
    showResetButton: propTypes.bool.def(true),
    // 显示查询按钮
    showSubmitButton: propTypes.bool.def(true),
    // 显示高级查询按钮
    showAdvancedButton: propTypes.bool.def(true),
    // 重置按钮选项-继承自buttons属性
    resetButtonOptions: {
      type: Object as PropType<ButtonProps>,
      default: () => ({}),
    },
    // 查询按钮选项-继承自buttons属性
    submitButtonOptions: {
      type: Object as PropType<ButtonProps>,
      default: () => ({}),
    },
    // 栏数相关属性
    actionColOptions: {
      type: Object as PropType<Partial<ColEx>>,
      default: () => ({}),
    },
    // 操作按钮栏数
    actionSpan: propTypes.number.def(6),
    // 是否高级查询，展开/收缩
    isAdvanced: propTypes.bool,
    // 隐藏高级查询
    hideAdvanceBtn: propTypes.bool,
  });

  // console.log('props', props);

  const emit = defineEmits(['toggle-advanced']);

  const { t } = useI18n();
  const { resetAction, submitAction } = useFormContext();
  // 操作按钮栏数
  const actionColOpt = computed(() => {
    // 获取操作按钮栏数属性
    const { showAdvancedButton, actionSpan: span, actionColOptions } = props;
    // 操作按钮栏数
    const actionSpan = 24 - span;
    // 高级查询栏数 如果高级查询栏数小于6，则高级查询栏数为24，否则为高级查询栏数
    const advancedSpanObj = showAdvancedButton ? { span: actionSpan < 6 ? 24 : actionSpan } : {};
    // 操作按钮栏数属性
    const actionColOpt: Partial<ColEx> = {
      style: { textAlign: 'right' },
      span: showAdvancedButton ? 6 : 4,
      ...advancedSpanObj,
      ...actionColOptions,
    };
    return actionColOpt;
  });

  // 重置按钮选项
  const getResetBtnOptions = computed((): ButtonProps => {
    return Object.assign(
      {
        text: t('common.resetText'),
      },
      props.resetButtonOptions,
    );
  });

  // 查询按钮选项
  const getSubmitBtnOptions = computed((): ButtonProps => {
    return Object.assign(
      {
        text: t('common.queryText'),
      },
      props.submitButtonOptions,
    );
  });

  // 切换高级查询
  function toggleAdvanced() {
    emit('toggle-advanced');
  }
</script>
