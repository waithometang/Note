import type { ColEx } from '../types';
import type { AdvanceState } from '../types/hooks';
import { ComputedRef, getCurrentInstance, Ref, shallowReactive, computed, unref, watch } from 'vue';
import type { FormProps, FormSchemaInner as FormSchema } from '../types/form';
import { isBoolean, isFunction, isNumber, isObject } from '@/utils/is';
import { useBreakpoint } from '@/hooks/event/useBreakpoint';
import { useDebounceFn } from '@vueuse/core';

const BASIC_COL_LEN = 24;

interface UseAdvancedContext {
  advanceState: AdvanceState;
  emit: EmitType;
  getProps: ComputedRef<FormProps>;
  getSchema: ComputedRef<FormSchema[]>;
  formModel: Recordable;
  defaultValueRef: Ref<Recordable>;
}
/**
 * 高级查询 动态处理展开收缩按钮
 * @param param0
 * @returns
 */
export default function ({
  advanceState,
  emit,
  getProps,
  getSchema,
  formModel,
  defaultValueRef,
}: UseAdvancedContext) {
  // debugger;
  // 获取当前实例
  const vm = getCurrentInstance();
  // 获取屏幕宽度/屏幕宽度对应的枚举/屏幕宽度对应的值 比如：XS,SM,MD,LG,XL,XXL
  const { realWidthRef, screenEnum, screenRef } = useBreakpoint();

  // 获取空行数
  const getEmptySpan = computed((): number => {
    if (!advanceState.isAdvanced) {
      return 0;
    }
    // For some special cases, you need to manually specify additional blank lines
    const emptySpan = unref(getProps).emptySpan || 0;

    // 如果emptySpan是数字，则直接返回emptySpan
    if (isNumber(emptySpan)) {
      return emptySpan;
    }
    // 如果emptySpan是对象，则获取对象中的span值 比如：{ span: 8, lg: 16, xl: 24 }
    if (isObject(emptySpan)) {
      const { span = 0 } = emptySpan;
      // 获取屏幕宽度对应的值 比如：XS,SM,MD,LG,XL,XXL
      const screen = unref(screenRef) as string;
      // 获取屏幕宽度对应的值 比如：span: 8, lg: 16, xl: 24
      const screenSpan = (emptySpan as any)[screen.toLowerCase()];
      // 返回屏幕宽度对应的值 比如：8, 16, 24
      return screenSpan || span || 0;
    }
    // 返回默认值，这里没必要
    return emptySpan || 0;
  });
  // 防抖更新展开收缩模式
  const debounceUpdateAdvanced = useDebounceFn(updateAdvanced, 30);
  // 监听表单配置、展开收缩模式、屏幕宽度，更新展开收缩模式
  watch(
    [() => unref(getSchema), () => advanceState.isAdvanced, () => unref(realWidthRef)],
    () => {
      // 是否显示展开收缩按钮
      const { showAdvancedButton } = unref(getProps);
      if (showAdvancedButton) {
        debounceUpdateAdvanced();
      }
    },
    { immediate: true },
  );

  function getAdvanced(itemCol: Partial<ColEx>, itemColSum = 0, isLastAction = false) {
    // 获取屏幕宽度
    const width = unref(realWidthRef);
    // 获取屏幕宽度对应的枚举
    const mdWidth =
      parseInt(itemCol.md as string) ||
      parseInt(itemCol.xs as string) ||
      parseInt(itemCol.sm as string) ||
      (itemCol.span as number) ||
      BASIC_COL_LEN;
    // 获取屏幕宽度对应的值
    const lgWidth = parseInt(itemCol.lg as string) || mdWidth;
    const xlWidth = parseInt(itemCol.xl as string) || lgWidth;
    const xxlWidth = parseInt(itemCol.xxl as string) || xlWidth;
    // 如果屏幕宽度小于等于LG，则itemColSum加上mdWidth
    if (width <= screenEnum.LG) {
      itemColSum += mdWidth;
    } else if (width < screenEnum.XL) {
      itemColSum += lgWidth;
    } else if (width < screenEnum.XXL) {
      itemColSum += xlWidth;
    } else {
      itemColSum += xxlWidth;
    }

    if (isLastAction) {
      advanceState.hideAdvanceBtn = false;
      if (itemColSum <= BASIC_COL_LEN * 2) {
        // When less than or equal to 2 lines, the collapse and expand buttons are not displayed
        // 当小于等于2行时，不显示展开收缩按钮
        advanceState.hideAdvanceBtn = true;
        // 展开收缩模式为true
        advanceState.isAdvanced = true;
      } else if (
        itemColSum > BASIC_COL_LEN * 2 &&
        itemColSum <= BASIC_COL_LEN * (unref(getProps).autoAdvancedLine || 3)
      ) {
        advanceState.hideAdvanceBtn = false;

        // More than 3 lines collapsed by default
      } else if (!advanceState.isLoad) {
        advanceState.isLoad = true;
        advanceState.isAdvanced = !advanceState.isAdvanced;
      }
      return { isAdvanced: advanceState.isAdvanced, itemColSum };
    }
    if (itemColSum > BASIC_COL_LEN * (unref(getProps).alwaysShowLines || 1)) {
      return { isAdvanced: advanceState.isAdvanced, itemColSum };
    } else {
      // The first line is always displayed
      return { isAdvanced: true, itemColSum };
    }
  }

  const fieldsIsAdvancedMap = shallowReactive({});

  function updateAdvanced() {
    let itemColSum = 0;
    let realItemColSum = 0;
    const { baseColProps = {} } = unref(getProps);
    // 遍历表单配置
    for (const schema of unref(getSchema)) {
      const { show, ifShow, colProps } = schema;

      // 获取渲染回调参数,主要用来处理某个表单项的显示，传递对应的参数
      const renderCallbackParams = {
        schema: schema,
        model: formModel,
        field: schema.field,
        values: { ...unref(defaultValueRef), ...formModel },
      };
      // 是否显示
      let isShow = true;
      // 如果ifShow是布尔值，则isShow等于ifShow
      isShow && isBoolean(ifShow) && (isShow = ifShow);
      // 如果ifShow是函数，则isShow等于ifShow的返回值
      isShow && isFunction(ifShow) && (isShow = ifShow(renderCallbackParams));
      // 如果show是布尔值，则isShow等于show
      isShow && isBoolean(show) && (isShow = show);
      // 如果show是函数，则isShow等于show的返回值
      isShow && isFunction(show) && (isShow = show(renderCallbackParams));
      // 如果isShow为true，则处理表单项的布局
      if (isShow && (colProps || baseColProps)) {
        // 获取表单项的布局
        const { itemColSum: sum, isAdvanced } = getAdvanced(
          { ...baseColProps, ...colProps },
          itemColSum,
        );

        itemColSum = sum || 0;
        // 如果isAdvanced为true，则realItemColSum等于itemColSum
        if (isAdvanced) {
          realItemColSum = itemColSum;
        }
        // 将isAdvanced存储到fieldsIsAdvancedMap中
        fieldsIsAdvancedMap[schema.field] = isAdvanced;
      }
    }
    // 确保页面发送更新
    vm?.proxy?.$forceUpdate();
    // 计算actionSpan
    advanceState.actionSpan = (realItemColSum % BASIC_COL_LEN) + unref(getEmptySpan);
    // 获取展开收缩模式
    getAdvanced(unref(getProps).actionColOptions || { span: BASIC_COL_LEN }, itemColSum, true);

    console.log('fieldsIsAdvancedMap', advanceState, fieldsIsAdvancedMap);

    // 触发advanced-change事件
    emit('advanced-change', advanceState.isAdvanced);
  }

  function handleToggleAdvanced() {
    advanceState.isAdvanced = !advanceState.isAdvanced;
  }

  return { handleToggleAdvanced, fieldsIsAdvancedMap };
}
