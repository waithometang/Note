import { isArray, isFunction, isEmpty, isObject, isString, isNil } from '@/utils/is';
import { dateUtil } from '@/utils/dateUtil';
import { unref } from 'vue';
import type { Ref, ComputedRef } from 'vue';
import type { FormProps, FormSchemaInner as FormSchema } from '../types/form';
import { cloneDeep, get, set, unset } from 'lodash-es';

interface UseFormValuesContext {
  defaultValueRef: Ref<any>;
  getSchema: ComputedRef<FormSchema[]>;
  getProps: ComputedRef<FormProps>;
  formModel: Recordable;
}

/**
 * @description deconstruct array-link key. This method will mutate the target.
 */
function tryDeconstructArray(key: string, value: any, target: Recordable) {
  const pattern = /^\[(.+)\]$/;
  if (pattern.test(key)) {
    const match = key.match(pattern);
    if (match && match[1]) {
      const keys = match[1].split(',');
      value = Array.isArray(value) ? value : [value];
      keys.forEach((k, index) => {
        set(target, k.trim(), value[index]);
      });
      return true;
    }
  }
}

/**
 * @description deconstruct object-link key. This method will mutate the target.
 */
function tryDeconstructObject(key: string, value: any, target: Recordable) {
  const pattern = /^\{(.+)\}$/;
  if (pattern.test(key)) {
    const match = key.match(pattern);
    if (match && match[1]) {
      const keys = match[1].split(',');
      value = isObject(value) ? value : {};
      keys.forEach((k) => {
        set(target, k.trim(), value[k.trim()]);
      });
      return true;
    }
  }
}

export function useFormValues({
  defaultValueRef,
  getSchema,
  formModel,
  getProps,
}: UseFormValuesContext) {
  // console.log('useFormValues', /* defaultValueRef, getSchema, */ formModel /* getProps */);
  // Processing form values
  function handleFormValues(values: Recordable) {
    if (!isObject(values)) {
      return {};
    }
    const res: Recordable = {};
    for (const item of Object.entries(values)) {
      let [, value] = item;
      const [key] = item;
      if (!key || (isArray(value) && value.length === 0) || isFunction(value)) {
        continue;
      }
      const transformDateFunc = unref(getProps).transformDateFunc;
      if (isObject(value)) {
        value = transformDateFunc?.(value);
      }

      if (isArray(value) && value[0]?.format && value[1]?.format) {
        value = value.map((item) => transformDateFunc?.(item));
      }
      // Remove spaces
      if (isString(value)) {
        value = value.trim();
      }
      if (!tryDeconstructArray(key, value, res) && !tryDeconstructObject(key, value, res)) {
        // 没有解构成功的，按原样赋值
        set(res, key, value);
      }
    }
    return handleRangeTimeValue(res);
  }

  /**
   * @description: Processing time interval parameters
   */
  function handleRangeTimeValue(values: Recordable) {
    const fieldMapToTime = unref(getProps).fieldMapToTime;

    if (!fieldMapToTime || !Array.isArray(fieldMapToTime)) {
      return values;
    }

    for (const [field, [startTimeKey, endTimeKey], format = 'YYYY-MM-DD'] of fieldMapToTime) {
      if (!field || !startTimeKey || !endTimeKey) {
        continue;
      }
      // If the value to be converted is empty, remove the field
      if (!get(values, field)) {
        unset(values, field);
        continue;
      }

      const [startTime, endTime]: string[] = get(values, field);

      const [startTimeFormat, endTimeFormat] = Array.isArray(format) ? format : [format, format];

      if (!isNil(startTime) && !isEmpty(startTime)) {
        set(values, startTimeKey, formatTime(startTime, startTimeFormat));
      }
      if (!isNil(endTime) && !isEmpty(endTime)) {
        set(values, endTimeKey, formatTime(endTime, endTimeFormat));
      }
      unset(values, field);
    }

    return values;
  }

  function formatTime(time: string, format: string) {
    if (format === 'timestamp') {
      return dateUtil(time).unix();
    } else if (format === 'timestampStartDay') {
      return dateUtil(time).startOf('day').unix();
    }
    return dateUtil(time).format(format);
  }
  /**
   * @description: 初始化默认值
   * 遍历所有schema，构建默认值对象
   */
  function initDefault() {
    // 获取表单字段配置
    const schemas = unref(getSchema);
    // 初始化默认值 构建对象
    const obj: Recordable = {};
    // 遍历表单字段配置
    schemas.forEach((item) => {
      // 获取字段配置 默认值 默认值对象 组件配置
      const { defaultValue, defaultValueObj, componentProps = {} } = item;
      // 获取默认值对象的键
      const fieldKeys = Object.keys(defaultValueObj || {});
      // 如果默认值对象有键
      if (fieldKeys.length) {
        // 遍历默认值对象的键
        fieldKeys.forEach((field) => {
          // 将默认值对象的键赋值给obj
          obj[field] = defaultValueObj![field];
          // 如果表单模型中没有该键，则将默认值对象的键赋值给表单模型
          if (formModel[field] === undefined) {
            formModel[field] = defaultValueObj![field];
          }
        });
      }
      // 如果 value 为null 或 undefined，那么返回 true，否则返回 false
      if (!isNil(defaultValue)) {
        // 将默认值赋值给obj
        obj[item.field] = defaultValue;
        // 如果表单模型中没有该键，则将默认值赋值给表单模型
        if (formModel[item.field] === undefined) {
          formModel[item.field] = defaultValue;
        }
      }
      // 如果组件配置有默认值
      if (!isNil(componentProps?.defaultValue)) {
        // 将组件配置的默认值赋值给obj
        obj[item.field] = componentProps?.defaultValue;
        // 如果表单模型中没有该键，则将组件配置的默认值赋值给表单模型
        if (formModel[item.field] === undefined) {
          formModel[item.field] = componentProps?.defaultValue;
        }
      }
    });
    console.log('obj', obj, formModel);
    defaultValueRef.value = cloneDeep(obj);
  }

  return { handleFormValues, initDefault };
}
