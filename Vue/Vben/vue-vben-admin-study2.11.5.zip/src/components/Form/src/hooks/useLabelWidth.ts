import type { Ref } from 'vue';
import { computed, unref } from 'vue';
import type { FormProps, FormSchemaInner as FormSchema } from '../types/form';
import { isNumber } from '@/utils/is';

/**
 * 使用表单字段标签宽度
 * @param schemaItemRef 表单字段schema
 * @param propsRef 表单配置
 * @returns 表单字段标签宽度
 */
export function useItemLabelWidth(schemaItemRef: Ref<FormSchema>, propsRef: Ref<FormProps>) {
  return computed(() => {
    // debugger;
    // 获取表单字段schema
    const schemaItem = unref(schemaItemRef);
    // 获取表单字段配置
    const { labelCol = {}, wrapperCol = {} } = schemaItem.itemProps || {};
    // 获取表单字段配置
    const { labelWidth, disabledLabelWidth } = schemaItem;
    // console.log('useItemLabelWidth', unref(schemaItemRef), unref(propsRef));
    // 获取表单全局配置
    const {
      labelWidth: globalLabelWidth,
      labelCol: globalLabelCol,
      wrapperCol: globWrapperCol,
      layout,
    } = unref(propsRef);

    // 如果全局标签宽度未设置，且字段标签宽度未设置，且全局标签配置未设置，则设置标签对齐方式为左对齐
    // If labelWidth is set globally, all items setting
    if ((!globalLabelWidth && !labelWidth && !globalLabelCol) || disabledLabelWidth) {
      labelCol.style = {
        textAlign: 'left',
      };
      return { labelCol, wrapperCol };
    }
    // 获取标签宽度
    let width = labelWidth || globalLabelWidth;
    // 获取标签配置
    const col = { ...globalLabelCol, ...labelCol };
    // 获取包裹配置
    const wrapCol = { ...globWrapperCol, ...wrapperCol };

    // 如果标签宽度已设置，则设置标签宽度
    if (width) {
      width = isNumber(width) ? `${width}px` : width;
    }

    // 返回标签和包裹配置
    return {
      labelCol: { style: { width }, ...col },
      wrapperCol: {
        style: { width: layout === 'vertical' ? '100%' : `calc(100% - ${width})` },
        ...wrapCol,
      },
    };
  });
}
