import type {
  FormProps,
  FormActionType,
  UseFormReturnType,
  FormSchemaInner as FormSchema,
} from '../types/form';
import type { NamePath } from 'ant-design-vue/lib/form/interface';
import type { DynamicProps } from '#/utils';
import { ref, onUnmounted, unref, nextTick, watch } from 'vue';
import { isProdMode } from '@/utils/env';
import { error } from '@/utils/log';
import { getDynamicProps } from '@/utils';

export declare type ValidateFields = (nameList?: NamePath[]) => Promise<Recordable>;

type Props = Partial<DynamicProps<FormProps>>;

/**
 * 使用表单
 * @param props 表单配置
 * @returns 表单实例
 */
export function useForm(props?: Props): UseFormReturnType {
  // 表单实例
  const formRef = ref<Nullable<FormActionType>>(null);
  // 表单是否已加载
  const loadedRef = ref<Nullable<boolean>>(false);

  /**
   * 获取表单实例
   * @returns 表单实例
   */
  async function getForm() {
    const form = unref(formRef);
    if (!form) {
      error(
        'The form instance has not been obtained, please make sure that the form has been rendered when performing the form operation!',
      );
    }
    await nextTick();
    return form as FormActionType;
  }

  /**
   * 注册表单实例
   * @param instance 表单实例
   */
  function register(instance: FormActionType) {
    isProdMode() &&
      onUnmounted(() => {
        formRef.value = null;
        loadedRef.value = null;
      });
    if (unref(loadedRef) && isProdMode() && instance === unref(formRef)) return;
    // 注册表单实例
    formRef.value = instance;
    // 表单已加载
    loadedRef.value = true;
    // 监听props变化，设置表单属性
    watch(
      () => props,
      () => {
        props && instance.setProps(getDynamicProps(props));
      },
      {
        immediate: true,
        deep: true,
      },
    );
  }

  /**
   * 表单方法
   */
  const methods: FormActionType = {
    // 滚动到指定字段
    scrollToField: async (name: NamePath, options?: ScrollOptions | undefined) => {
      const form = await getForm();
      form.scrollToField(name, options);
    },
    // 设置表单属性
    setProps: async (formProps: Partial<FormProps>) => {
      const form = await getForm();
      form.setProps(formProps);
    },
    // 更新表单schema
    updateSchema: async (data: Partial<FormSchema> | Partial<FormSchema>[]) => {
      const form = await getForm();
      form.updateSchema(data);
    },
    // 重置表单schema
    resetSchema: async (data: Partial<FormSchema> | Partial<FormSchema>[]) => {
      const form = await getForm();
      form.resetSchema(data);
    },
    // 清除表单验证
    clearValidate: async (name?: string | string[]) => {
      const form = await getForm();
      form.clearValidate(name);
    },
    // 重置表单字段
    resetFields: () => {
      // 修复表单重置后，页面变化了，但是由于异步问题导致表单内部的状态没有及时同步
      return new Promise((resolve) => {
        getForm().then(async (form) => {
          await form.resetFields();
          resolve();
        });
      });
    },
    // 移除表单schema
    removeSchemaByField: async (field: string | string[]) => {
      unref(formRef)?.removeSchemaByField(field);
    },
    // 获取表单字段值
    // TODO promisify
    getFieldsValue: <T>() => {
      return unref(formRef)?.getFieldsValue() as T;
    },
    // 设置表单字段值
    setFieldsValue: async <T extends Recordable<any>>(values: T) => {
      const form = await getForm();
      form.setFieldsValue(values);
    },
    // 追加表单schema
    appendSchemaByField: async (
      schema: FormSchema | FormSchema[],
      prefixField: string | undefined,
      first?: boolean,
    ) => {
      const form = await getForm();
      form.appendSchemaByField(schema, prefixField, first);
    },
    // 提交表单
    submit: async (): Promise<any> => {
      const form = await getForm();
      return form.submit();
    },
    // 验证表单字段
    validate: async <T = Recordable>(nameList?: NamePath[] | false): Promise<T> => {
      const form = await getForm();
      return form.validate(nameList);
    },
    // 验证表单字段
    validateFields: async (nameList?: NamePath[]): Promise<Recordable> => {
      const form = await getForm();
      return form.validateFields(nameList);
    },
    // 重置表单字段
    resetDefaultField: async (nameList?: NamePath[]) => {
      unref(formRef)?.resetDefaultField(nameList);
    },
  };
  // 返回注册表单实例和表单方法
  return [register, methods];
}
