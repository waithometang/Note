import { withInstall } from '@/utils';
import tinymce from './src/Editor.vue';

export const Tinymce = withInstall(tinymce);
