import { withInstall } from '@/utils';
import time from './src/Time.vue';

export const Time = withInstall(time);
