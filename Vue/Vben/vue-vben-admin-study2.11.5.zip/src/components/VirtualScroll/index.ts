import { withInstall } from '@/utils';
import vScroll from './src/VirtualScroll.vue';

export const VScroll = withInstall(vScroll);
