module.exports = {
  root: true,
  extends: ['@vben'],
  rules: {
    'no-undef': 'off',
  },
};
