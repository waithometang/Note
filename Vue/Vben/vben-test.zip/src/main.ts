import { createApp } from "vue";
import "./style.css";
import App from "./App.vue";
import "ant-design-vue/dist/reset.css";
import "./design/var/index.less";
import "virtual:svg-icons-register";

createApp(App).mount("#app");
