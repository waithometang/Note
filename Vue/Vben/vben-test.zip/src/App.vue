<script setup lang="ts">
import Authority from "@/views/Authority/index.vue";
import Modal from "@/views/Modal/index.vue";
import { AppProvider } from "@/components/Application";
import Basic from "@/views/Basic/index.vue";
import Icon from "@/views/Icon/index.vue";
import { Scrollbar } from "@/views/Scrollbar";
import { reactify } from "@vueuse/core";
import { reactive, UnwrapRef } from "vue";
import Form from "@/views/Form/index.vue";
// import { ref } from 'vue'
// import type { ScrollbarInstance } from './views/Scrollbar/src/scrollbar'

// const scrobarRef = ref<InstanceType<typeof Scrollbar>>()

// setTimeout(() => {
//   scrobarRef.value?.scrollTo({
//     top: 200,
//     left: 0,
//     behavior: 'smooth'
//   })
// }, 4000)

interface State {
  count: number;
  name: string;
}



const state: UnwrapRef<State> = reactive<State>({
  count: 0,
  name: "张三",
});


const increment = () => {
  state.count++;
};
</script>

<template>
  <a-config-provider :theme="{
    token: {
      colorPrimary: '#00b96b',
    },
  }">
    <AppProvider>

      <!-- <Modal></Modal> -->
      <Form></Form>
      <!-- <Authority></Authority>
      <Basic></Basic>
      <Icon></Icon> -->
      <!-- <div style="width: 300px; ">
        <Scrollbar ref="scrobarRef" height="400px">
          <p v-for="item in 30" :key="item" class="scrollbar-demo-item">{{ item }}</p>
        </Scrollbar>
      </div> -->
    </AppProvider>
  </a-config-provider>
</template>

<style scoped lang="less">
.scrollbar-demo-item {
  display: flex;
  align-items: center;
  justify-content: center;
  height: 50px;
  text-align: center;
  border-radius: 4px;
  background: #ccc;
  color: #008cd6;
  // width: 500px;
}
</style>
