import type { VNode, VNodeChild } from "vue";

declare global {
  // vue
  type VueNode = VNodeChild | JSX.Element;

  type Recordable<T = any> = Record<string, T>;

  namespace JSX {
    type Element = VNode;
  }
}
