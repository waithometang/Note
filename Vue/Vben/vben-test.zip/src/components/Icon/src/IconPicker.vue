<template>
    <div>
        <div>wqewqeqwe</div>
    </div>
</template>

<script setup lang="ts">

</script>