<!-- <template>
    <svg :class="[prefixCls, $attrs.class, /* spin && 'svg-icon-spin' */]" aria-hidden="true">
        <use :xlink:href="symbolId" />
    </svg>
</template>

<script setup lang="ts">
import { useDesign } from "@/hooks/web/useDesign";
import { computed } from "vue";

const props = defineProps({
    name: { type: String, required: true },
    prefix: { type: String, default: "icon" },
    color: { type: String },
    size: { type: [Number, String] },
});

const { prefixCls } = useDesign("svg-icon");

const symbolId = computed(() => `#${props.prefix}-${props.name}`);

const getStyle = computed(() => {
    const { size } = props
    let s = `${size}`;
    s = `${s.replace('px', '')}px`;
    return {
        width: s,
        height: s,
    }
})
</script>

<style lang="less" scoped>
@prefix-cls: 'vebn-svg-icon';

.@{prefix-cls} {
    display: inline-block;
    overflow: hidden;
    fill: currentcolor;
    vertical-align: -0.15em;
}

.svg-icon-spin {
    // animation: loadingCircle 1s infinite linear;
}
</style> -->
