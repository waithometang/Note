import BasicForm from "./BasicForm.vue";

export { BasicForm };
