import type { CSSProperties, PropType } from "vue";

export const basicProps = {
  // 表单数据
  model: {
    type: Object,
    default: () => ({}),
  },
  // 标签宽度
  labelWidth: {
    type: [Number, String],
    default: 0,
  },
  // 字段映射到时间
  fieldMapToTime: {
    type: Array,
    default: () => [],
  },
  // 紧凑模式
  compact: {
    type: Boolean,
    default: false,
  },
  // 表单配置规则
  schemas: {
    type: Array,
    default: () => [],
  },
  // 合并动态表单
  mergeDynamicData: {
    type: Object,
    default: null,
  },
  // 基础行样式
  baseRowStyle: {
    type: Object,
  },
  // 基础列属性
  baseColProps: {
    type: Object,
  },
  // 自动设置占位符
  autoSetPlaceHolder: {
    type: Boolean,
    default: true,
  },
  // 在input组件上单击回车时是否自动提交
  autoSubmitOnEnter: {
    type: Boolean,
    default: false,
  },
  // 在表单提交时是否自动重置
  submitOnReset: {
    type: Boolean,
    default: false,
  },
  // 在表单提交时是否改变
  submitOnChange: {
    type: Boolean,
    default: false,
  },
  // 表单尺寸
  size: {
    type: String,
    default: "default",
  },
  // 禁用表单
  disabled: {
    type: Boolean,
    default: false,
  },
  // 空值处理
  emptySpan: {
    type: [Number, Object],
    default: 0,
  },
  // 是否显示高级按钮
  showAdvancedButton: {
    type: Boolean,
    default: false,
  },
  // 转换日期函数
  transformDateFunc: {
    type: Function,
    default: (date: any) => {
      return date?.format?.("YYYY-MM-DD HH:mm:ss") ?? date;
    },
  },
  // 规则消息连接标签
  rulesMessageJoinLabel: {
    type: Boolean,
    default: true,
  },
  // 超出多少行自动折叠
  autoAdvancedLine: {
    type: Number,
    default: 3,
  },
  // 不受折叠影响的行数
  alwaysShowLines: {
    type: Number,
    default: 1,
  },
  // 是否显示操作按钮组
  showActionButtonGroup: {
    type: Boolean,
    default: true,
  },
  // 操作列Col配置
  actionColOptions: {
    type: Object,
    default: () => ({}),
  },
  // 是否显示重置按钮
  showResetButton: {
    type: Boolean,
    default: true,
  },
  // 是否聚焦第一个输入框，只在第一个表单项为input的时候作用
  autoFocusFirstItem: {
    type: Boolean,
    default: false,
  },
  // 重置按钮配置
  resetButtonOptions: {
    type: Object,
    default: () => ({}),
  },
  // 显示确认按钮
  showSubmitButton: {
    type: Boolean,
    default: true,
  },
  // 确认按钮配置
  submitButtonOptions: {
    type: Object,
    default: () => ({}),
  },
  // 自定义重置函数
  resetFunc: {
    type: Function,
    default: () => {},
  },
  // 自定义提交函数
  submitFunc: {
    type: Function,
    default: () => {},
  },
  // 是否隐藏必选标记
  hideRequiredMark: {
    type: Boolean,
    default: false,
  },
  // 标签列配置
  labelCol: {
    type: Object,
    default: () => ({}),
  },
  // 布局
  layout: {
    type: String,
    default: "horizontal",
  },
  // 表格操作列配置
  tableAction: {
    type: Object,
    default: () => ({}),
  },
  // 表单项列配置
  wrapperCol: {
    type: Object,
    default: () => ({}),
  },
  // 是否显示冒号
  colon: {
    type: Boolean,
    default: false,
  },
  // 标签对齐
  labelAlign: {
    type: String,
  },
  // 行属性
  rowProps: {
    type: Object,
    default: () => ({}),
  },
};
