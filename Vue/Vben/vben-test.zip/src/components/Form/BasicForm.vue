<template>
    <Form v-bind="getBindValue" :class="getFormClass" ref="formElERef" :model="formModel"
        @keypress.enter="handleEnterPress">
        <Row v-bind="getRow">
            <!-- 表单头部 -->
            <slot name="formHeader"></slot>

            <!-- <template v-for="schema in getSchema" :key="schema.field"> -->
            <FormItem>
                <template #[item]="data" v-for="item in Object.keys($slots)">
                    <slot :name="item" v-bind="data || {}"></slot>
                </template>
            </FormItem>
            <!-- </template> -->

            <!-- 表单按钮操作 -->
            <FormAction v-bind="getFormActionBindProps" @toggle-advanced="handleToggleAdvanced">
                <template #[item]="data"
                    v-for="item in ['resetBefore', 'submitBefore', 'advanceBefore', 'advanceAfter']">
                    <slot :name="item" v-bind="data || {}"></slot>
                </template>
            </FormAction>

            <!-- 表单尾部 -->
            <slot name="formFooter"></slot>
        </Row>

    </Form>
</template>

<script setup lang="ts">
import { Form, Row } from "ant-design-vue";
import { ref, computed, useAttrs, unref, reactive } from 'vue'
import { basicProps } from "./props";
import { useDesign } from "@/hooks/web/useDesign";
import FormAction from "./src/components/FormAction.vue";
import FormItem from "./src/components/FormItem.vue";

const formElERef = ref<InstanceType<typeof Form>>()
// 定义组件名称 
defineOptions({ name: 'BasicForm' })
// 获取attrs
const attrs = useAttrs()
// 获取props
const props = defineProps(basicProps)
// 获取前缀
const { prefixCls } = useDesign('basic-form');

// 表单引用
const propsRef = ref()
// 表单数据
const formModel = reactive({})
// 高级属性
const advanceState = reactive({
    // 是否展开
    isAdvanced: true,
    // 是否隐藏展开按钮
    hideAdvanceBtn: false,
    // 是否加载中
    isLoad: false,
    // 按钮列数
    actionSpan: 6
})

// 获取props
const getProps = computed(() => {
    return { ...props, ...unref(propsRef) }
})
// 获取所有绑定值
const getBindValue = computed(() => {
    return { ...attrs, ...props, ...unref(getProps) }
})
// 获取表单类
const getFormClass = computed(() => {
    return [prefixCls, {
        [`${prefixCls}--compact`]: unref(getProps).compact
    }]
})
// 获得整个表单统一的行样式和行配置
const getRow = computed(() => {
    const { baseRowStyle = {}, rowProps } = unref(getProps)
    return {
        style: baseRowStyle,
        ...rowProps
    }
})
const getFormActionBindProps = computed(() => {
    return {
        ...unref(getProps),
        ...advanceState
    }
})


// function start
/**
 * 处理回车事件
 * @param e 键盘事件
 */
function handleEnterPress(e: KeyboardEvent) {
    // 获取是否自动提交
    const { autoSubmitOnEnter } = unref(getProps)
    if (!autoSubmitOnEnter) return
    // 判断是否是回车键
    if (e.key === 'Enter' && e.target && e.target instanceof HTMLElement) {
        const target = e.target as HTMLElement
        if (target && target.tagName && target.tagName.toUpperCase() === 'INPUT') {
            // 提交表单
            // handleSubmit();
        }
    }
}
/**
 * 切换展开/收缩属性
 */
function handleToggleAdvanced() {
    // advanceState.isAdvanced = !advanceState.isAdvanced
}
</script>

<style scoped></style>
