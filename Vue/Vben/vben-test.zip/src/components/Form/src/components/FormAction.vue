<template>
    <Col v-bind="actionColOpt">
    <div style="width: 100%" :style="{ textAlign: actionColOpt.style.textAlign }">
        <Form.Item>
            <slot name="resetBefore"></slot>
            <Button type="default" class="mr-2" v-bind="getResetBtnOptions" @click="resetAction" v-if="showResetButton">
                {{ getResetBtnOptions.text }}
            </Button>
            <slot name="submitBefore"></slot>
            <Button type="primary" class="mr-2" v-bind="getSubmitBtnOptions" @click="submitAction"
                v-if="showSubmitButton">
                {{ getSubmitBtnOptions.text }}
            </Button>

            <slot name="advanceBefore"></slot>
            <Button type="link" size="small" @click="toggleAdvanced" v-if="showAdvancedButton && !hideAdvanceBtn">
                {{ isAdvanced ? '收起▲' : '展开▼' }}
                <!-- <BasicArrow class="ml-1" :expand="!isAdvanced" up /> -->
            </Button>
            <slot name="advanceAfter"></slot>
        </Form.Item>
    </div>
    </Col>
</template>
<script setup lang="ts">
import { Button, Form, Col, } from 'ant-design-vue'
import { computed, unref } from 'vue';
import { useFormContext } from '../hooks/useFormContext';

defineOptions({ name: 'BasicFormAction' })

const props = defineProps({
    // 是否显示按钮组
    showActionButtonGroup: {
        type: Boolean,
        default: true
    },
    // 是否显示重置按钮
    showResetButton: {
        type: Boolean,
        default: true
    },
    // 是否显示查询按钮
    showSubmitButton: {
        type: Boolean,
        default: true
    },
    // 是否显示展开按钮
    showAdvancedButton: {
        type: Boolean,
        default: true
    },
    // 重置按钮配置
    resetButtonOptions: {
        type: Object,
        default: () => ({})
    },
    // 查询按钮配置
    submitButtonOptions: {
        type: Object,
        default: () => ({})
    },
    // 展开按钮配置
    actionColOptions: {
        type: Object,
        default: () => ({})
    },
    // 按钮列数
    actionSpan: {
        type: Number,
        default: 6
    },
    // 是否展开
    isAdvanced: {
        type: Boolean,
        default: false
    },
    // 是否隐藏展开按钮
    hideAdvanceBtn: {
        type: Boolean,
        default: false
    }
})

console.log('props', unref(props))

const emit = defineEmits(['toggle-advanced']);

const actionColOpt = computed(() => {

    // 获取操作按钮栏数属性
    const { showAdvancedButton, actionSpan: span, actionColOptions } = props;
    // 操作按钮栏数
    const actionSpan = 24 - span;
    // 高级查询栏数 如果高级查询栏数小于6，则高级查询栏数为24，否则为高级查询栏数
    const advancedSpanObj = showAdvancedButton ? { span: actionSpan < 6 ? 24 : actionSpan } : {};
    // 操作按钮栏数属性
    const actionColOpt = {
        style: { textAlign: 'right' },
        span: showAdvancedButton ? 6 : 4,
        ...advancedSpanObj,
        ...actionColOptions,
    };
    return actionColOpt;
})

const getResetBtnOptions = computed(() => {
    return Object.assign({
        text: '重置'
    }, props.resetButtonOptions)
})

const getSubmitBtnOptions = computed(() => {
    return Object.assign({ text: '查询' }, props.submitButtonOptions,)
})

const { resetAction, submitAction } = useFormContext();

console.log('actionColOpt', unref(actionColOpt))


function toggleAdvanced() {
    emit('toggle-advanced');
}

</script>