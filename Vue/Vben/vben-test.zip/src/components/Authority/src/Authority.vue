<script lang="ts">
import type { PropType } from "vue";
import { defineComponent } from "vue";
import { usePermission } from "@/hooks/web/usePermission";
import { getSlots } from "@/utils/helper/tsxHelper";
export default defineComponent({
  name: "Authority",
  props: {
    // 权限码 字符串或者数组
    value: {
      type: [String, Array] as PropType<string | string[]>,
      default: '',
    },
  },
  setup(props, { slots }) {
    // 校验权限
    const { hasPermission } = usePermission();
    const renderAuth = () => {
      const { value } = props;
      // 没有权限码，直接渲染默认组件
      if (!value) {
        return getSlots(slots,/* 'default',{name:111,age:222},{disabled:true,text:'primary'} */);
      }
      // 有权限码，校验权限，有权限渲染组件，无权限不渲染
      return hasPermission(value) ? getSlots(slots,'default') : null;
    }
    // 渲染组件
    return () => {
      return renderAuth();
    };
  },
});
</script>
