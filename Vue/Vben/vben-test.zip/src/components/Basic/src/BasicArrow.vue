<template>
    <span :class="getClass">
        <!-- <Icon icon="ion:chevron-forward" :style="$attrs.iconStyle" /> -->
    </span>
</template>

<script setup lang="ts">
import { computed } from 'vue';
import Icon from '@/components/Icon/Icon.vue';
import { useDesign } from '@/hooks/web/useDesign';

const props = defineProps({
    /**
     * Arrow expand state
     */
    expand: { type: Boolean },
    /**
     * Arrow up by default
     */
    up: { type: Boolean },
    /**
     * Arrow down by default
     */
    down: { type: Boolean },
    /**
     * Cancel padding/margin for inline
     */
    inset: { type: Boolean },
});

const { prefixCls } = useDesign('basic-arrow');

// get component class
const getClass = computed(() => {
    const { expand, up, down, inset } = props;
    return [
        prefixCls,
        {
            [`${prefixCls}--active`]: expand,
            up,
            inset,
            down,
        },
    ];
});
</script>

<style lang="less"></style>
