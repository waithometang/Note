<script lang="ts">
import { defineComponent, toRefs, ref } from "vue";
import { createAppProviderContext } from "./useAppContext";

const props = {
  /**
   * class style prefix
   */
  prefixCls: { type: String, default: "vben" },
};

export default defineComponent({
  name: "AppProvider",
  inheritAttrs: false,
  props,
  setup(props, { slots }) {
    const isMobile = ref(false);

    const { prefixCls } = toRefs(props);

    // console.log("AppProvider");

    // Inject variables into the global
    createAppProviderContext({ prefixCls, isMobile });

    return () => slots.default?.();
  },
});
</script>
