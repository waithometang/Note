import { InjectionKey, Ref } from "vue";
import { createContext, useContext } from "@/hooks/core/useContext";

// 定义应用提供者上下文
export interface AppProviderContextProps {
  prefixCls: Ref<string>;
  isMobile: Ref<boolean>;
}

// 定义注入的key
const key: InjectionKey<AppProviderContextProps> = Symbol();

/**
 * 创建应用提供者上下文
 * @param context 上下文
 * @returns
 */
export function createAppProviderContext(context: AppProviderContextProps) {
  return createContext<AppProviderContextProps>(context, key);
}

/**
 * 使用应用提供者上下文
 * @returns
 */
export function useAppProviderContext() {
  return useContext<AppProviderContextProps>(key);
}
