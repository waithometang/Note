<template>
  <Modal v-bind="getBindValue" @cancel="cancel">
    <template #title>
      <ModalHeader></ModalHeader>
    </template>
    <template #closeIcon>
      <ModalClose @cancel="cancel"></ModalClose>
    </template>
    <template #footer>
      <ModalFooter @cancel="cancel"></ModalFooter>
    </template>
  </Modal>
</template>

<script setup lang="ts">
import { computed, getCurrentInstance, ref, unref, useAttrs, watch, watchEffect } from "vue";
import Modal from "./components/Modal";
import ModalClose from "./components/ModalClose.vue";
import ModalFooter from "./components/ModalFooter.vue";
import ModalHeader from "./components/ModalHeader.vue";
import { basicProps } from "./props";
import { ModalMethods } from "./typing";
import { ModalProps } from "ant-design-vue";
import { omit } from "lodash-es";

const props = defineProps(basicProps);

const openRef = ref(false)

const propsRef = ref<Partial<ModalProps> | null>(null);


const emit = defineEmits([
  'open-change',
  'height-change',
  'cancel',
  'ok',
  'register',
  "update:open",
  "fullscreen",
]);

const attrs = useAttrs();


const getMergeProps = computed((): Recordable => {
  return {
    ...props,
    ...(unref(propsRef) as any),
  };
});

const getBindValue = computed((): Recordable => {
  const attr = {
    ...attrs,
    ...unref(getMergeProps),
    open: unref(openRef),
  };
  // if (attr?.['wrapClassName'] === unref(getWrapClassName)) {
  //   attr['wrapClassName'] = `${attr?.['wrapClassName'] || ''} ` + prefixCls;
  // } else {
  //   attr['wrapClassName'] = `${unref(getWrapClassName) || ''}` + prefixCls;
  // }
  // if (unref(fullScreenRef)) {
  //   return omit(attr, ['height', 'title']);
  // }
  return omit(attr, 'title');
});

const modalMethods: ModalMethods = {
  setModalProps,
  emitOpen: undefined,
  redoModalHeight() {
    console.log("redoModalHeight");
  },
}

function setModalProps(props: Partial<ModalProps>): void {
  console.log("setModalProps", props);
  if (Reflect.has(props, 'open')) {
    openRef.value = !!props.open;
  }
}

const instance = getCurrentInstance();

if (instance) {
  emit("register", modalMethods, instance.uid);
}

console.log("instance", instance);

watchEffect(() => {
  console.log("watchEffect");
  openRef.value = !!props.open;
})

watch(() => unref(openRef), (v) => {
  console.log("watch", v);
  emit('open-change', v);
  emit('update:open', v);
  if (instance && modalMethods.emitOpen) {
    modalMethods.emitOpen(v, instance.uid);
  }
}, {
  immediate: false
})

function cancel(e: Event) {
  // e?.stopPropagation();
  // 过滤自定义关闭按钮的空白区域
  // if ((e.target as HTMLElement)?.classList?.contains(prefixCls + '-close--custom')) return;
  // if (props.closeFunc && isFunction(props.closeFunc)) {
  //   const isClose: boolean = await props.closeFunc();
  //   openRef.value = !isClose;
  //   return;
  // }

  openRef.value = false;
  emit('cancel', e);
}

</script>
