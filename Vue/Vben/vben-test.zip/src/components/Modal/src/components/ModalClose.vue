<template>
  <div :class="getClass">
    <template v-if="canFullscreen">
      <Tooltip title="还原" placement="bottom" v-if="fullScreen">
        <FullscreenExitOutlined role="full" @click="handleFullScreen" />
      </Tooltip>
      <Tooltip title="最大化" placement="bottom" v-else>
        <FullscreenOutlined role="close" @click="handleFullScreen" />
      </Tooltip>
    </template>
    <Tooltip title="关闭" placement="bottom">
      <CloseOutlined @click="handleCancel" />
    </Tooltip>
  </div>
</template>

<script setup lang="ts">
import { computed } from "vue";
import { Tooltip } from "ant-design-vue";
import {
  FullscreenExitOutlined,
  FullscreenOutlined,
  CloseOutlined,
} from "@ant-design/icons-vue";
import { useDesign } from "@/hooks/web/useDesign";

defineOptions({
  name: "ModalClose",
});

const props = defineProps({
  canFullscreen: {
    type: Boolean,
    default: true,
  },
  fullScreen: {
    type: Boolean,
  },
});

const emits = defineEmits(["cancel", "fullScreen"]);

const { prefixCls } = useDesign("basic-modal-close");

console.log("prefixCls", prefixCls);

const getClass = computed(() => {
  return [
    prefixCls,
    `${prefixCls}--custom`,
    {
      [`${prefixCls}--can-full`]: props.canFullscreen,
    },
  ];
});

function handleFullScreen(e: Event) {
  e?.stopPropagation();
  e?.preventDefault();
  emits("fullScreen");
}

function handleCancel(e: Event) {
  emits("cancel", e);
}
</script>
<style lang="less">
@prefix-cls: ~"vben-basic-modal-close";
.@{prefix-cls} {
  display: flex;
  align-items: center;
  height: 95%;

  > span {
    margin-left: 48px;
    font-size: 16px;
  }

  &--can-full {
    > span {
      margin-left: 12px;
    }
  }

  &:not(&--can-full) {
    > span:nth-child(1) {
      &:hover {
        font-weight: 700;
      }
    }
  }

  & span:nth-child(1) {
    display: inline-block;
    padding: 10px;

    &:hover {
      color: #1890ff;
    }
  }

  & span:last-child {
    &:hover {
      color: #ff4d4f;
    }
  }
}
</style>
