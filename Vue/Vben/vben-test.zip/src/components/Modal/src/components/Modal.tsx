import { defineComponent, toRefs, unref } from "vue";
import { Modal } from "ant-design-vue";
import { basicProps } from "../props";
import { extendSlots } from "@/utils/helper/tsxHelper";
export default defineComponent({
  name: "Modal",
  inheritAttrs: false,
  props: basicProps as any,
  emits: ["cancel"],
  setup(props, { slots, emit, attrs }) {
    const { open, draggable, destroyOnClose } = toRefs(props);

    const onCancel = (e: Event) => {
      emit("cancel", e);
    };
    // console.log("here");

    return () => {
      const propsData = { ...props, ...unref(attrs), oncancel } as Recordable;
      return <Modal {...propsData}>{extendSlots(slots)}</Modal>;
    };
  },
});
