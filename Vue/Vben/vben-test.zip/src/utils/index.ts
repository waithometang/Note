import type { App, Component } from "vue";

// 为组件添加 install 方法
export type WithInstall<T> = T & {
  install: (app: App) => void;
};

// 扩展组件类型
export type CustomComponent = Component & { displayName?: string };

/**
 * 为组件添加 install 方法
 * @param component 组件
 * @param alias 组件别名
 * @returns 组件
 */
export function withInstall<T extends CustomComponent>(
  component: T,
  alias?: string
) {
  // 为组件添加 install 方法
  (component as Record<string, unknown>).install = (app: App) => {
    // 获取组件名称
    const name = component.name || component.displayName;
    if (!name) {
      return;
    }
    // 注册组件
    app.component(name, component);
    // 注册组件别名
    if (alias) {
      app.component(alias, component);
    }
  };
  // 返回组件
  return component as WithInstall<T>;
}
