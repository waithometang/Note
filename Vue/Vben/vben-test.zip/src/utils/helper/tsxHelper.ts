import { isFunction } from "@/utils/is";
import { Slots } from "vue";

export type RenderOpts = {
  disabled: boolean;
  [key: string]: any;
};

/**
 * 获取插槽
 * @param slots 插槽
 * @param slot 插槽名称
 * @param data 数据
 * @param options 选项
 * @returns
 */
export function getSlots(
  slots: Slots,
  slot = "default",
  data?: any,
  options?: RenderOpts
) {
  // 没有插槽
  if (!slots || !Reflect.has(slots, slot)) {
    return null;
  }
  // 插槽不是函数
  if (!isFunction(slots[slot])) {
    console.error(`Slot "${slot}" is not a function`);
    return null;
  }
  // 插槽函数
  const slotFn = slots[slot];
  if (!slotFn) {
    return null;
  }
  // 合并数据
  const params = { ...data, ...options };
  // 渲染插槽
  return slotFn(params);
}

/**
 * 扩展插槽
 * @param slots 插槽
 * @param excludeKeys 排除的插槽名称
 * @returns 扩展后的插槽
 */
export function extendSlots(slots: Slots, excludeKeys: string[] = []) {
  const slotKeys = Object.keys(slots);
  const ret: any = {};
  slotKeys.forEach((key) => {
    if (excludeKeys.includes(key)) {
      return;
    }
    ret[key] = (data?: any) => getSlots(slots, key, data);
  });
  return ret;
}
