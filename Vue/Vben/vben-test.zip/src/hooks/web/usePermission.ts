import { intersection } from "lodash-es";

export function usePermission() {
  // 校验权限
  function hasPermission(value: string | string[], def = true): boolean {
    if (!value) {
      return def;
    }
    const allCodeList: string[] = [];
    // 权限码是字符串
    if (!Array.isArray(value)) {
      return allCodeList.includes(value);
    }
    // 权限码是数组，校验是否存在交集
    return (intersection(allCodeList, value) as string[]).length > 0;
  }
  return {
    hasPermission,
  };
}
