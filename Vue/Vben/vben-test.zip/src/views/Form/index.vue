<template>
    <BasicForm />
</template>

<script setup lang="ts">
import { BasicForm } from "@/components/Form";
</script>