<script setup lang="ts">
import { Authority } from "@/components/Authority";
</script>

<template>
  <Authority>
    <template #default="scoped">
      <div>这是Authority组件</div>
    </template>
  </Authority>
</template>
