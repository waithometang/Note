import { withInstall } from "@/utils/index";
import scrollbar from "./src/scrollbar.vue";

export const Scrollbar = withInstall(scrollbar);
