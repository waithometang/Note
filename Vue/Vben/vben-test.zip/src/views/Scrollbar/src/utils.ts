import type { CSSProperties } from "vue";
import type { ThumbProps } from "./thumb.ts";

// 滚动条边距
export const GAP = 4; // top 2+ bottom 2 of bar instance

// 滚动条的配置
export const BAR_MAP = {
  vertical: {
    offset: "offsetHeight",
    scroll: "scrollTop",
    scrollSize: "scrollHeight",
    size: "height",
    key: "vertical",
    axis: "Y",
    client: "clientY",
    direction: "top",
  },
  horizontal: {
    offset: "offsetWidth",
    scroll: "scrollLeft",
    scrollSize: "scrollWidth",
    size: "width",
    key: "horizontal",
    axis: "X",
    client: "clientX",
    direction: "left",
  },
} as const;

// 渲染滚动条样式
export const renderThumbStyle = ({
  move, // 移动的百分比
  size, // 滚动条的大小
  bar, // 滚动条的配置
}: Pick<ThumbProps, "move" | "size"> & {
  bar: (typeof BAR_MAP)[keyof typeof BAR_MAP];
}): CSSProperties => ({
  [bar.size]: size,
  transform: `translate${bar.axis}(${move}%)`,
});
