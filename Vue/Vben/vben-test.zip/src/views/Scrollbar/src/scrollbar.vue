<template>
    <div ref="scrollbarRef" class="scrollbar">
        <div ref="wrapRef" :class="wrapKls" :style="wrapStyle" :tabindex="tabindex" @scroll="handleScroll">
            <component :is="tag" :id="id" ref="resizeRef" :class="resizeKls" :style="viewStyle" :role="role"
                :aria-label="ariaLabel" :aria-orientation="ariaOrientation">
                <slot></slot>
            </component>
        </div>
        <template v-if="!native">
            <bar ref="barRef" :always="always" :min-size="minSize"></bar>
        </template>
    </div>
</template>
<script setup lang="ts">
import { computed, nextTick, onActivated, onMounted, onUpdated, provide, reactive, ref, watch } from 'vue'
import { useEventListener, useResizeObserver } from '@vueuse/core'
import Bar from './bar.vue'
import { scrollbarContextKey } from './constants'
import { scrollbarEmits, scrollbarProps } from './scrollbar'
import type { BarInstance } from './bar'
import type { CSSProperties, StyleValue } from 'vue'
import { isNumber } from './scrollbar'

const COMPONENT_NAME = 'ElScrollbar'

defineOptions({
    name: COMPONENT_NAME,
})

const props = defineProps(scrollbarProps)
const emit = defineEmits(scrollbarEmits)

console.log(props, 'scroll props');


let stopResizeObserver: (() => void) | undefined = undefined
let stopResizeListener: (() => void) | undefined = undefined
let wrapScrollTop = 0
let wrapScrollLeft = 0

// 定义ref
const wrapRef = ref<HTMLDivElement>()
const scrollbarRef = ref<HTMLDivElement>()
const resizeRef = ref<HTMLDivElement>()
const barRef = ref<BarInstance>()

// 计算wrap的样式
const wrapStyle = computed<StyleValue>(() => {
    const style: CSSProperties = {}
    if (props.height) style.height = props.height
    if (props.maxHeight) style.maxHeight = props.maxHeight
    return [props.wrapStyle, style]
})

const wrapKls = computed(() => {
    return [props.wrapClass, 'scrollbar__wrap', {
        'scrollbar__wrap--hidden-default': !props.native,
    }]
})

const resizeKls = computed(() => {
    return [props.viewClass, 'scrollbar__view']
})

/**
 * 处理滚动事件
 */
const handleScroll = () => {
    if (wrapRef.value) {
        barRef.value?.handleScroll(wrapRef.value)
        // 获取滚动位置
        wrapScrollTop = wrapRef.value.scrollTop;
        wrapScrollLeft = wrapRef.value.scrollLeft;

        // 触发滚动事件
        emit('scroll', {
            scrollTop: wrapScrollTop,
            scrollLeft: wrapScrollLeft,
        })
    }
}
function isObject(value: unknown): value is Record<any, any> {
    return value !== null && typeof value === 'object';
}
function scrollTo(xCoord: number, yCord: number): void
function scrollTo(options: ScrollToOptions): void
function scrollTo(arg1: unknown, arg2?: number): void {
    if (isObject(arg1)) {
        wrapRef.value?.scrollTo(arg1 as ScrollToOptions)
    } else if (isNumber(arg1) && isNumber(arg2)) {
        wrapRef.value?.scrollTo(arg1 as number, arg2 as number)
    }
}

const setScrollTop = (value: number) => {
    if (!isNumber(value)) return
    wrapRef.value!.scrollTop = value
}

const setScrollLeft = (value: number) => {
    if (!isNumber(value)) return
    wrapRef.value!.scrollLeft = value
}

const update = () => {
    barRef.value?.update()
}

// 监听noresize的变化
watch(() => props.noresize, (noresize) => {
    if (noresize) {
        // 停止监听
        stopResizeObserver?.()
        stopResizeListener?.()
    } else {
        // 开始监听
        ; ({ stop: stopResizeObserver } = useResizeObserver(resizeRef, update))
        stopResizeListener = useEventListener('resize', update)
    }
}, {
    immediate: true,
})

// 监听maxHeight和height的变化
watch(() => [props.maxHeight, props.height], () => {
    // 如果非原生，则需要更新滚动条
    if (!props.native) {
        nextTick(() => {
            update()
            if (wrapRef.value) {
                barRef.value?.handleScroll(wrapRef.value)
            }
        })
    }
})

provide(scrollbarContextKey, reactive({
    scrollbarElement: scrollbarRef,
    wrapElement: wrapRef,
}))

onActivated(() => {
    if (wrapRef.value) {
        wrapRef.value.scrollTop = wrapScrollTop
        wrapRef.value.scrollLeft = wrapScrollLeft
    }
})

onMounted(() => {
    if (!props.native) {
        nextTick(() => {
            update()
        })
    }
})

onUpdated(() => {
    update()
})

defineExpose({
    wrapRef,
    update,
    scrollTo,
    setScrollTop,
    setScrollLeft,
    handleScroll,
})
</script>
<style lang="less">
.scrollbar {
    position: relative;
    height: 100%;
    overflow: hidden;

    &__wrap {
        height: 100%;
        overflow: auto;

        &--hidden-default {
            scrollbar-width: none;

            &::-webkit-scrollbar {
                display: none;
            }
        }
    }



    .scrollbar_bar {
        position: absolute;
        z-index: 1;
        right: 2px;
        bottom: 2px;
        transition: opacity 80ms ease;
        border-radius: 4px;
        opacity: 0;

        &.is-vertical {
            top: 2px;
            width: 6px;

            &>div {
                width: 100%;
            }
        }

        &.is-horizontal {
            left: 2px;
            height: 6px;

            &>div {
                height: 100%;
            }
        }

        .scrollbar_thumb {
            display: block;
            position: relative;
            width: 0;
            height: 0;
            transition: 0.3s background-color;
            border-radius: inherit;
            background-color: rgb(144 147 153 / 30%);
            cursor: pointer;

            &:hover {
                background-color: rgb(144 147 153 / 50%);
            }
        }
    }
}

.scrollbar:active>.scrollbar_bar,
.scrollbar:focus>.scrollbar_bar,
.scrollbar:hover>.scrollbar_bar {
    transition: opacity 340ms ease-out;
    opacity: 1;
}
</style>