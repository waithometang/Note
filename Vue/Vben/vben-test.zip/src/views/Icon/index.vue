<template>
    <!-- <Icon name="icon-test" /> -->
    <div>wqewqeqwe</div>
    <Icon name="moon"></Icon>
</template>

<script setup lang="ts">
import Icon from "@/components/Icon/Icon.vue";
</script>
