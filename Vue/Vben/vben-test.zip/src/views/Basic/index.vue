<template>
    <BasicArrow />
    <BasicHelp />
    <BasicTitle />
</template>

<script setup lang="ts">
import { BasicArrow, BasicHelp, BasicTitle } from "@/components/Basic";
</script>