<script setup lang="ts">
// import { Modal } from "ant-design-vue";
import { ref } from "vue";
// import { basicModal as Modal } from "@/components/Modal";
import Dialog from "./dialog.vue";
// const open = ref(false);

function showModal() {
  console.log("showModal",);
  methods.openModal()
  //   open.value = true;
  //   // Modal.confirm({
  //   //   title: "Basic Modal",
  //   //   content: "Some contents...",
  //   // });
}

import { useModal } from "@/components/Modal/src/hooks/useModal";

const [register, methods] = useModal();
console.log(/* register, */ methods);
</script>

<template>
  <Dialog @register="register"></Dialog>
  <!-- <Modal v-model:open="open"></Modal> -->
  <a-button type="primary" @click="showModal">Open Modal</a-button>
</template>
