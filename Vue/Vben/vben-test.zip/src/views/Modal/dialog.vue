<template>
    <BasicModal @register="register" v-bind="$attrs">
        这是内容
    </BasicModal>
</template>

<script setup lang="ts">
import { BasicModal, ModalMethods, useModalInner } from "@/components/Modal";
import { ref, useAttrs } from "vue";

const [register, methods] = useModalInner();

const open = ref(false);

console.log("dialog", /* register,  */methods, useAttrs());

function register111(modalMethods: ModalMethods, uid: number) {
    console.log("register111", modalMethods, uid);
}
</script>
